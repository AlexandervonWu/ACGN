sig A {}
pred left { some A }
pred right { some A }
assert CapBenchEquivalent_captest { left iff right }
check CapBenchEquivalent_captest for 4
