sig A {}
pred inner { before some A }
pred left { inner }
pred right { some A }
assert CapBenchEquivalent_captest { left iff right }
check CapBenchEquivalent_captest for 4 but 2..4 steps, exactly 1 A
