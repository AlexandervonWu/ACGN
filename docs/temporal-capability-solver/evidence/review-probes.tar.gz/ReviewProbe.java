package is.fivefivefive.CanDis;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.ast.Command;
import edu.mit.csail.sdg.parser.CompModule;
import edu.mit.csail.sdg.parser.CompUtil;

public final class ReviewProbe {
    public static void main(String[] args) throws Exception {
        System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "warn");
        JSONArray checks = new JSONArray();
        for (String arg : args) {
            Path file = Path.of(arg);
            CompModule module = CompUtil.parseEverything_fromFile(A4Reporter.NOP, null, arg);
            Command original = module.getAllCommands().get(0);
            Command prepared = CapabilitySoundnessCheck.prepareCommand(module, original);
            System.out.println(file.getFileName() + ": native="
                    + CompUtil.isTemporalModel(module.getAllReachableSigs(), original)
                    + ", exposed=" + (prepared != original)
                    + ", idempotent=" + (CapabilitySoundnessCheck.prepareCommand(module, prepared) == prepared)
                    + ", boundsPreserved=" + (original.overall == prepared.overall
                        && original.bitwidth == prepared.bitwidth && original.maxseq == prepared.maxseq
                        && original.minprefix == prepared.minprefix && original.maxprefix == prepared.maxprefix
                        && original.scope.equals(prepared.scope)
                        && original.additionalExactScopes.equals(prepared.additionalExactScopes)));
            CapabilitySoundnessCheck.Result result = CapabilitySoundnessCheck.check(file,
                    Map.of("relativePath", file.getFileName().toString(),
                            "family", "temporal_normalization", "subtype", file.getFileName().toString()));
            System.out.println("failed=" + result.failed() + ": " + result.toJson());
            checks.put(result.toJson());
        }
        Path report = Path.of("/tmp/acgn-temporal-independent-review/probe-results.json");
        Files.writeString(report, new JSONObject().put("checks", checks).toString(2) + "\n");
        StringBuilder summary = new StringBuilder();
        CapabilityBenchmark.appendSoundnessSummary(summary, report);
        System.out.println(summary);
    }
}
