sig A {}
pred inner { before some A }
pred outer { inner }
fact { outer }
pred left { some A }
pred right { no A }
assert CapBenchEquivalent_captest { left iff right }
check CapBenchEquivalent_captest for 4 but 1..4 steps
