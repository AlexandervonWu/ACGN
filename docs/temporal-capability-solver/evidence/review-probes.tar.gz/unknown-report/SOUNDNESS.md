# Capability Benchmark Bounded Soundness

- Cases per transformation subtype: 1
- Checked cases: 1
- Families: 1
- Family/subtype combinations: 1
- Solver-reported counterexamples: 0
- Solver/translation errors: 1
- Completed bounded temporal checks: 0
- Inconclusive checks: 1
- Failed checks (including inconclusive): 1

These checks execute the generated Alloy equivalence assertions with SAT4J. Temporal commands use Pardinus bounded temporal solving; exact scope and trace bounds are recorded per check. Unsatisfiability within those bounds is a finite-scope sanity check, not a semantic proof; the benchmark ground truth remains the recorded sound transformation and side condition. An inconclusive result or solver error fails the check, including temporal cases.
