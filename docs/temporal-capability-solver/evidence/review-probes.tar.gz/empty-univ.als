sig A {}
pred left { not always no univ }
pred right { eventually some univ }
assert CapBenchEquivalent_captest { left iff right }
check CapBenchEquivalent_captest for 0 but 0 Int, 0 seq, 1..1 steps, exactly 0 A
