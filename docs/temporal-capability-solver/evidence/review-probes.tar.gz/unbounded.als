sig A {}
pred left { not always some A }
pred right { eventually no A }
assert CapBenchEquivalent_captest { left iff right }
check CapBenchEquivalent_captest for 4 but 1.. steps
