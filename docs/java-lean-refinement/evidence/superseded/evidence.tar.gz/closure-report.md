# Java-Lean Smart-Construction Refinement

Status: **VERIFIED**

Input root: `fe9b3b951766cd0bec103c81d453313e7d88eecd943193ba98b94985d4cf77e5`

This result applies to the declared source fragment and finite execution family under the listed trusted components.

| Claim | Status | Evidence |
| --- | --- | --- |
| JLR-01 | PASS | COMPILER_CHECKED |
| JLR-02 | PASS | PROVED_UNDER_FRAGMENT_SEMANTICS |
| JLR-03 | PASS | CHECKED |
| JLR-04 | PASS | JAVA_AND_LEAN_REPLAY_CHECKED |
| JLR-05 | PASS | PROVED_AND_EXECUTION_CHECKED |
| JLR-06 | PASS | TESTED |
| JLR-07 | PASS | CHECKED |

