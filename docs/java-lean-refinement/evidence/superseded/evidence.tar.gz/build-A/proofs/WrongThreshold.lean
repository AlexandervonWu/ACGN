import SmartConstructionRefinement
open ACGN.SmartConstructionRefinement
def extractedProgram : Program := { condition := (.and .isSet (.equal .size (.literal 2))), rejectionGuard := (.not .isOne), whenTrue := .singleton, whenFalse := .node }
theorem compiler_program_matches : extractedProgram = expectedProgram := by decide
theorem java_lean_correspondence (head : ACGN.Section3.Phase2.BooleanConnective)
    (values : List Nat) (nonempty : Not (values = [])) :
    execute extractedProgram (Frame.mk true values.length true) = modelOutcome head values :=
  extracted_program_refines_nonempty_carrier extractedProgram compiler_program_matches head values nonempty
#print axioms compiler_program_matches
#print axioms java_lean_correspondence
