"""Join every closed original incident to fresh native observations in both directions on every supplied engine."""
import argparse
import collections
import gzip
import itertools
import tempfile
from pathlib import Path
from ledger import D,W,v,categories,describe_negative,key,receipt,recover,reversekey,selected,text,write_csv,write_json


def source_spec(rows):
 result={}
 for x in rows:
  original=key(x)
  for direction,k in [('forward',original),('reverse',reversekey(original))]:
   assert k not in result
   spec=('paid',x['left'],x['leftPredicate'],x['leftSha256'],x['right'],x['rightPredicate'],x['rightSha256'],str(x['original']['expected']))
   result[k]=(original,direction,spec if direction=='forward' else v.reverse(spec))
 return result


def stage(directory,rows,spec,original=False):
 root=directory/'native'
 reg=W/'runner-identity.json'
 summary=v.read(root/'summary.json')
 assert summary['adapterIdentitySha256']==v.digest(reg)==v.RUNNER and summary['inputManifestSha256']==v.COHORT and summary['pairs']==len(rows) and summary['directions']==2*len(rows)
 assert summary['cohorts']=={'baselineFailure':len(rows)} and summary['ledgerSha256']==v.digest(root/'native-observations.jsonl')
 assert summary['originalIncidentSnapshotSha256']==v.digest(root/'original-incident-snapshot.json') and summary['verifierSha256']==v.digest(W/'packaging/replay_regressions.py')
 registered=v.read(root/'original-incident-snapshot.json');seen={(s['shard'],s['ordinal']):s for s in registered['incidents']}
 assert len(registered['incidents'])==len(seen)==len(rows)
 for r in rows:
  q=seen[r['shard'],r['ordinal']]
  assert key(q)==key(r) and q['incidentSha256']==r['original']['incidentSha256'] and (q['leftSha256'],q['rightSha256'])==(r['leftSha256'],r['rightSha256'])
 if original:
  assert summary['engineSha256']==v.digest(W/'frozen/measured.jar')==v.read(reg)['jarSha256']
  commit=v.read(reg)['sourceCommit'];regfile=reg
 else:
  check=v.read(directory/'independent-recount.json')
  build=v.read(W/'builds'/directory.name/'build-receipt.json')
  assert check['recountStatus']=='VERIFIED' and check['originalIncidents']==len(rows) and check['directions']==2*len(rows) and check['producerSummarySha256']==v.digest(root/'summary.json') and check['observationsSha256']==summary['ledgerSha256']
  commit=build['git']['commit'];regfile=directory/'snapshot.json'
  assert check['candidateCommit']==commit and check['candidateJarSha256']==summary['engineSha256']==build['experimentJar']['sha256'] and check['snapshotSha256']==v.digest(regfile)
 read_rows={};total=collections.Counter();by_score=collections.Counter();phases=collections.Counter();errors=[]
 combined=iter(v.lines(root/'native-observations.jsonl'))
 inp={};raw={}
 for part in sorted(root.glob('part-*')):
  name=part.name; spec_path=part/'inputs.tsv';output=part/(name+'.jsonl');inp[name]=v.digest(spec_path);raw[name]=v.digest(output)
  jobs=spec_path.read_text().splitlines()
  success_ack=v.decode((part/'worker.log').read_bytes().splitlines()[-1]);assert success_ack['shard']==name and success_ack['rows']==success_ack['newRows']==len(jobs)
  capsules=set()
  for i,(job,r) in enumerate(itertools.zip_longest(jobs,v.lines(output))):
   assert job is not None and r is not None
   k=key(r);orig,direction,registered_job=spec[k]
   assert k not in read_rows and tuple(job.split('\t'))==registered_job
   expected={**r,'groups':['baselineFailure'],'direction':direction};merged=next(combined);assert v.object_same(merged,expected)
   v.check_observation(part,name,i,registered_job,r)
   received=receipt(r)
   if not received['checked']:
    capsules.add(r['incidentPath']);d=describe_negative(part,r);received['difference']=d;errors.append(merged)
    received['incidentPath']=name+'/'+r['incidentPath']
    first=d.get('firstFast') or {};second=d.get('firstCertified') or {}
    signal=(direction,received['nativeStatus'],received['reason'],received['mode'],first.get('stage'),first.get('kind'),second.get('stage'),second.get('kind'))
    phases[signal]+=1
   by_score[direction,received['scoreStatus']]+=1
   total[direction,'MATCHED' if received['checked'] else received['nativeStatus']+'/'+received['reason']]+=1;read_rows[k]=received
  assert capsules=={q.relative_to(part).as_posix() for q in (part/'incidents').glob('*')}
 assert next(combined,None) is None and set(read_rows)==set(spec) and len(errors)==summary['failures']
 assert inp==summary['partInputSha256'] and raw==summary['partOutputSha256']
 assert summary['status']==('BLOCKED' if errors else 'VERIFIED') and v.object_same(summary['firstFailure'],errors[0] if errors else None)
 if original:
  stable=[k for k in receipt(merged) if k not in ('incidentPath','incidentSha256')]
  for r in rows:
   a,b=r['original'],read_rows[key(r)]
   assert all(v.object_same(a[k],b[k]) for k in stable),('Non-reproducible original forward selection',key(r))
  bind=dict(recount='VERIFIED',nativeStatus=summary['status'],observations=len(read_rows),originalForwardReproduced=len(rows),newReverseControls=len(rows),engineSha256=summary['engineSha256'],originalFullCensusSha256=v.digest(W/'cohort/closure-attestation.json'),closedOriginalNegativeListSha256=v.digest(D/'original/all-386-original-pairs.jsonl'),summarySha256=v.digest(root/'summary.json'),registrationSha256=v.digest(regfile),verifierSha256=v.digest(Path(__file__)))
  rec=directory/'independent-recount.json'
  if rec.exists():assert v.read(rec)==bind
  else:write_json(rec,bind)
 return read_rows,dict(stage=directory.name,git=commit,jar=summary['engineSha256'],summarySha256=v.digest(root/'summary.json'),ledgerSha256=summary['ledgerSha256'],independentRecountSha256=v.digest(directory/'independent-recount.json'),nativeCounts=[dict(direction=k[0],outcome=k[1],rows=v) for k,v in sorted(total.items())],scoreCounts=[dict(direction=k[0],outcome=k[1],rows=v) for k,v in sorted(by_score.items())],nonconformingSignals=[dict(direction=k[0],status=k[1],reason=k[2],mode=k[3],firstFastStage=k[4],firstFastKind=k[5],firstCertifiedStage=k[6],firstCertifiedKind=k[7],rows=v) for k,v in phases.most_common()])


def transition(prev,new):
 return ('RETAINED' if prev['checked'] else 'RESTORED') if new['checked'] else ('REGRESSED' if prev['checked'] else 'STILL_FAILING')


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);p.add_argument('--stages',nargs='+',required=True);args=p.parse_args()
 rows=recover();spec=source_spec(rows);names=['original-replay',*args.stages];indexed={};stages={}
 assert len(names)==len(set(names))
 for name in names:
  indexed[name],stages[name]=stage(D/name,rows,spec,original=name=='original-replay')
 dirs=[];recorded=[];unresolved=[];trans=collections.Counter();moved=collections.Counter();first_fixes=collections.Counter();cohorts=collections.Counter();pair_line=[];earliest_per_pool=collections.Counter();signature_fixes=collections.Counter()
 for x in rows:
  original=key(x); source_summary={**selected(x),'referenceId':x['referenceId'],'shard':x['shard'],'ordinal':x['ordinal'],'leftSha256':x['leftSha256'],'rightSha256':x['rightSha256'],'expected':x['original']['expected'],'originalForward':x['original'],'originalDifference':x['originalDifference']}
  pool=x['left'].split('/')[0]+'/'+x['leftPredicate'];payload={};one_flat=dict(shard=x['shard'],ordinal=x['ordinal'],pool=pool,submission=x['left'],predicate=x['leftPredicate'],reference=x['right'],referencePredicate=x['rightPredicate'],referenceId=x['referenceId'],measuredDistance=x['original']['expected'])
  for direction,k in [('forward',original),('reverse',reversekey(original))]:
   selected_stages={name:indexed[name][k] for name in names};payload[direction]=selected_stages
   present=[name for name in names if selected_stages[name]['checked']]
   first=next((name for index,name in enumerate(names) if all(selected_stages[z]['checked'] for z in names[index:])),'UNRESOLVED')
   first_fixes[direction,first]+=1;one_flat[direction+'FirstDurableWithinObservedSeries']=first
   if direction=='forward':
    earliest_per_pool[pool,first]+=1
    od=x['originalDifference'];f=od['firstFast'];s=od['firstCertified']
    signature_fixes[first,x['original']['mode'],f['stage'],f.get('kind'),s['stage'],s.get('kind')]+=1
   per=dict(**one_flat,direction=direction,firstDurableWithinObservedSeries=first);history=[]
   for i,name in enumerate(names):
    nd=selected_stages[name];label=name.replace('-','_')
    per[label+'Status']=nd['nativeStatus'];per[label+'Checked']=nd['checked'];per[label+'FastDistance']=nd['fastDistance'];per[label+'CertifiedDistance']=nd['certifiedDistance'];per[label+'ScalarStatus']=nd['scoreStatus'];per[label+'FastProgramSha256']=nd['fastProgramSha256'];per[label+'CertifiedProgramSha256']=nd['certifiedProgramSha256']
    history.append('MATCHED' if nd['checked'] else nd['nativeStatus']);one_flat[name+'_'+direction]=history[-1]
    if i:
     before=selected_stages[names[i-1]];verdict=transition(before,nd);trans[names[i-1],name,direction,verdict]+=1
     am=before['fastProgramSha256']!=nd['fastProgramSha256'];cm=before['certifiedProgramSha256']!=nd['certifiedProgramSha256']
     moved[names[i-1],name,direction,verdict,am,cm]+=1
   dirs.append(per)
   cohorts[direction,tuple(history)]+=1
  origfix=one_flat['forwardFirstDurableWithinObservedSeries'];revfix=one_flat['reverseFirstDurableWithinObservedSeries']
  one_flat['originalIncidentSha256']=x['original']['incidentSha256']
  pair_line.append(one_flat)
  recorded.append({**source_summary,'nativeStages':payload})
  if origfix=='UNRESOLVED' or revfix=='UNRESOLVED':unresolved.append(one_flat)
 assert len(recorded)==386 and len(dirs)==772
 report=dict(originalUniverse=386,originalWholeCensus=1894168,rowsPerStage=772,observedStages=names,engines=stages,
   originalFullRecountSha256=v.digest(D/'original/recount.json'),unresolvedPairsAtLastStage=len(unresolved),
   stageTransitions=[dict(previous=k[0],current=k[1],direction=k[2],state=k[3],count=n) for k,n in sorted(trans.items())],
   operationDigestChanges=[dict(previous=k[0],current=k[1],direction=k[2],state=k[3],fastChanged=k[4],certifiedChanged=k[5],count=n) for k,n in sorted(moved.items())],
   firstDurable=[dict(direction=k[0],stage=k[1],pairs=n) for k,n in sorted(first_fixes.items())],outcomeHistories=[dict(direction=k[0],states=k[1],pairs=n) for k,n in sorted(cohorts.items())],
   forwardStageByPool=[dict(pool=k[0],stage=k[1],pairs=n) for k,n in sorted(earliest_per_pool.items())],
   forwardStageByOriginalSignal=[dict(stage=k[0],mode=k[1],fastStage=k[2],fastKind=k[3],certifiedStage=k[4],certifiedKind=k[5],pairs=n) for k,n in signature_fixes.most_common()],
   interpretation='Each restoration is assigned to the first measured revision after which the exact directional identity always passed through the last named engine. Source root cause still requires code/trace evidence; an observed revision alone does not uniquely identify the responsible change.')
 with tempfile.TemporaryDirectory(dir=args.output.parent) as tmp:
  root=Path(tmp)/'report';root.mkdir()
  write_csv(root/'pairs.csv',pair_line);write_csv(root/'unresolved.csv',unresolved or [one_flat]) if unresolved else (root/'unresolved.csv').write_text(','.join(one_flat)+'\n')
  allkeys={k:None for row in dirs for k in row}
  write_csv(root/'directions.csv',[{k:r.get(k) for k in allkeys} for r in dirs])
  with (root/'complete-pair-observations.jsonl.gz').open('xb') as fp,gzip.GzipFile(filename='',fileobj=fp,mode='wb',mtime=0) as f:
   for r in recorded:f.write((text(r)+'\n').encode())
  report['fileSha256']={path.name:v.digest(path) for path in sorted(root.iterdir())};report['verifierSha256']=v.digest(Path(__file__));write_json(root/'summary.json',report);root.rename(args.output)
 print(v.digest(args.output/'summary.json'),flush=True)
if __name__=='__main__':main()
