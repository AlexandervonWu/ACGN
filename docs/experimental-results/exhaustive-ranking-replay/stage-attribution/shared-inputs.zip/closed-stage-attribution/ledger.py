"""Derive a complete source-level incident inventory and follow the same selection through each named engine."""
import collections,csv,gzip,hashlib,json,re,sys
from pathlib import Path
D=Path(__file__).resolve().parent;W=D.parent
sys.path.insert(0,str(W/'regression-audit'))
import verify_checkpoint as v


def text(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def write_json(path,obj):
 with path.open('x') as f:json.dump(obj,f,sort_keys=True,indent=2);f.write('\n')
def write_rows(path,rows):
 with path.open('x') as f:
  for r in rows:f.write(text(r)+'\n')
def write_csv(path,rows):
 fields=list(rows[0])
 with path.open('x',newline='') as f:
  out=csv.DictWriter(f,fieldnames=fields);out.writeheader();out.writerows(rows)
def key(r):return tuple(r[k] for k in v.FIELDS)
def reversekey(k):return k[2:]+k[:2]
def selected(o):return {k:o[k] for k in v.FIELDS}
def program_hash(seq):return hashlib.sha256(v.canonical(seq).encode()).hexdigest()
def categories(r):
 f,c=r.get('fastDistance'),r.get('certifiedDistance');e=r['expected']
 if type(f) is not int or type(c) is not int:return 'UNAVAILABLE'
 if f!=c:return 'FAST_CERTIFIED_DIFFER'
 if f!=e:return 'BOTH_DIFFER_FROM_MEASURED_SCORE'
 return 'BOTH_MATCH_MEASURED_SCORE'
def receipt(r):
 return dict(nativeStatus=r['status'],reason=r['reason'],checked=r['checked'],expected=r['expected'],fastDistance=r.get('fastDistance'),certifiedDistance=r.get('certifiedDistance'),scoreStatus=categories(r),mode=r.get('sequenceKind'),sequenceEqual=r.get('nativeSequencesEqual'),endpointChecked=r.get('endpointCorrespondenceChecked'),fixedReplaysChecked=r.get('fixedChoiceReplaysChecked'),sourceCertified=r.get('sourceCertificatesChecked'),fastProgramSha256=r.get('fastSequenceSha256'),certifiedProgramSha256=r.get('certifiedSequenceSha256'),fastSteps=r.get('fastActionCount',r.get('fastBlockCount')),certifiedSteps=r.get('certifiedActionCount',r.get('certifiedBlockCount')),firstDifference=r.get('firstDifference'),incidentPath=r.get('incidentPath'),incidentSha256=r.get('incidentSha256'))
def labels(r):
 if r['sequenceKind']=='FLAT_ACTIONS':
  return [[(r.get(a+'First') or {}).get(k) for k in ('stage','kind')] for a in ('fast','certified')]
 return [[(r.get(a+'First') or {}).get('component'),None] for a in ('fast','certified')]
def describe_negative(base,r):
 archive=v.decode(gzip.decompress((base/r['incidentPath']).read_bytes()));e=archive['nativeComparatorEvidence']
 if e is None:return {}
 flat=r.get('sequenceKind')=='FLAT_ACTIONS';suffix='Actions' if flat else 'Blocks'
 if not all(a+suffix in e for a in ('fast','certified')):return {}
 sides=[e[a+suffix] if flat else [[b['component'],b['effect']] for b in e[a+suffix]] for a in ('fast','certified')]
 def keyed(x):
  return x.get('stage') if flat else x[0]
 def signal(x):
  if x is None:return None
  return dict(stage=x.get('stage'),kind=x.get('kind'),sourceTuple=x.get('sourceTuple'),targetTuple=x.get('targetTuple'),source=x.get('source'),target=x.get('target')) if flat else dict(stage=x[0],effectSize=len(x[1]) if isinstance(x[1],list) else None)
 contrasts={}
 for phase in sorted({keyed(x) for s in sides for x in s}):
  a,b=([x for x in seq if keyed(x)==phase] for seq in sides)
  same=v.object_same(a,b)
  first=None if same else next((i for i,(x,y) in enumerate(zip(a,b)) if not v.object_same(x,y)),min(len(a),len(b)))
  contrasts[phase]=dict(same=same,fastLength=len(a),certifiedLength=len(b),firstDifference=first)
 pos=r.get("firstDifference")
 diagnostic=e.get('diagnostic') or {}
 detail={arm:{k:v for k,v in (diagnostic.get(arm) or {}).items() if k in ('quantifierDistance','matrixDistance','temporalDistance','distance')} for arm in ('fast','certified')}
 return dict(firstFast=signal(sides[0][pos]) if pos is not None and pos<len(sides[0]) else None,firstCertified=signal(sides[1][pos]) if pos is not None and pos<len(sides[1]) else None,phasePrograms=contrasts,components=detail)
def recover():
 w=W; c=w/'cohort'; snapshot=v.read(D/'candidate-04/snapshot.json');meta=v.read(c/'manifest.json')
 expected,details,orig=v.recover_original(w,snapshot,meta['shards'])
 assert len(expected)==386 and all(x['payloadRehashed'] for x in orig.values())
 catalog={int(r['referenceId']):(r['source'],r['predicate']) for r in csv.DictReader((c/'reference-catalog.tsv').open(),delimiter='\t')}
 compact=c/'final-verification/nonmatching.jsonl.gz';frozen=collections.defaultdict(dict)
 with gzip.open(compact,'rt') as f:
  for line in f:
   item=v.decode(line);r=item['observation'];k=key(r);job,flags=expected[k]
   assert details[k]['shard']==item['shard'] and details[k]['ordinal']==r['ordinal'] and r['incidentSha256']==details[k]['incidentSha256']
   assert (job[3],job[6])==(item['leftSha256'],item['rightSha256']) and catalog[item['referenceId']]==k[2:] and r['expected']==int(job[7])
   assert k not in frozen
   frozen[k]={**selected(r),'referenceId':item['referenceId'],'shard':item['shard'],'ordinal':r['ordinal'],'leftSha256':job[3],'rightSha256':job[6],'original':receipt(r),'originalDifference':describe_negative(w/'results',r)}
 assert set(frozen)==set(expected)
 for job,flags in expected.values():
  for p,h in ((job[1],job[3]),(job[4],job[6])):v.validated_file(w/'frozen/classified-data',p,h)
 return sorted(frozen.values(),key=lambda x:(x['shard'],x['ordinal']))
def original_report():
 rows=recover();p=D/'original'
 write_rows(p/'all-386-original-pairs.jsonl',rows)
 compact=[];signals=collections.Counter();score=collections.Counter();distinctSources=set();reftally=set();pools=collections.Counter()
 for r in rows:
  a=r['original'];d=r['originalDifference'];st=d['firstFast'];sc=d['firstCertified'];g=r['left'].split('/')[0];pool=g+'/'+r['leftPredicate']
  dominant=(a['mode'],st['stage'],st.get('kind'),sc['stage'],sc.get('kind'))
  signals[dominant]+=1;score[a['scoreStatus']]+=1;pools[pool]+=1;distinctSources.add((r['left'],r['leftPredicate']));reftally.add(r['referenceId'])
  compact.append(dict(shard=r['shard'],ordinal=r['ordinal'],submission=r['left'],predicate=r['leftPredicate'],reference=r['right'],referencePredicate=r['rightPredicate'],referenceId=r['referenceId'],expected=a['expected'],fastDistance=a['fastDistance'],certifiedDistance=a['certifiedDistance'],scoreStatus=a['scoreStatus'],mode=a['mode'],firstDifference=a['firstDifference'],firstFastStage=st['stage'],firstFastKind=st.get('kind'),firstCertifiedStage=sc['stage'],firstCertifiedKind=sc.get('kind'),otherDifferingStages='|'.join(k for k,z in d['phasePrograms'].items() if not z['same'] and k not in (st['stage'],sc['stage'])),incident=a['incidentPath'],incidentSha256=a['incidentSha256']))
 write_csv(p/'all-386-original-pairs.csv',compact)
 stats=dict(pairs=len(rows),submissions=len(distinctSources),distinctReferenceIds=len(reftally),pools=dict(sorted(pools.items())),scalarStatus=dict(score),firstOperationSignals=[{'signature':list(k),'count':v} for k,v in signals.most_common()],inputsSha256=v.digest(p/'all-386-original-pairs.jsonl'),csvSha256=v.digest(p/'all-386-original-pairs.csv'),originalReportSha256=v.digest(W/'cohort/final-verification/summary.json'))
 write_json(p/'original-signals.json',stats);print(text(stats),flush=True)

if __name__=='__main__':original_report()
