import ContainerReplay
open ACGN.ContainerReplay
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
theorem observed_0000 : valid { kind := .seq, input := [], output := [], fibers := [] } = true := by decide
theorem observed_0001 : valid { kind := .seq, input := [0], output := [0], fibers := [[0]] } = true := by decide
theorem observed_0002 : valid { kind := .seq, input := [1], output := [1], fibers := [[0]] } = true := by decide
theorem observed_0003 : valid { kind := .seq, input := [2], output := [2], fibers := [[0]] } = true := by decide
theorem observed_0004 : valid { kind := .seq, input := [0, 0], output := [0, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0005 : valid { kind := .seq, input := [0, 1], output := [0, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0006 : valid { kind := .seq, input := [0, 2], output := [0, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0007 : valid { kind := .seq, input := [1, 0], output := [1, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0008 : valid { kind := .seq, input := [1, 1], output := [1, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0009 : valid { kind := .seq, input := [1, 2], output := [1, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0010 : valid { kind := .seq, input := [2, 0], output := [2, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0011 : valid { kind := .seq, input := [2, 1], output := [2, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0012 : valid { kind := .seq, input := [2, 2], output := [2, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0013 : valid { kind := .seq, input := [0, 0, 0], output := [0, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0014 : valid { kind := .seq, input := [0, 0, 1], output := [0, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0015 : valid { kind := .seq, input := [0, 0, 2], output := [0, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0016 : valid { kind := .seq, input := [0, 1, 0], output := [0, 1, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0017 : valid { kind := .seq, input := [0, 1, 1], output := [0, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0018 : valid { kind := .seq, input := [0, 1, 2], output := [0, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0019 : valid { kind := .seq, input := [0, 2, 0], output := [0, 2, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0020 : valid { kind := .seq, input := [0, 2, 1], output := [0, 2, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0021 : valid { kind := .seq, input := [0, 2, 2], output := [0, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0022 : valid { kind := .seq, input := [1, 0, 0], output := [1, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0023 : valid { kind := .seq, input := [1, 0, 1], output := [1, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0024 : valid { kind := .seq, input := [1, 0, 2], output := [1, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0025 : valid { kind := .seq, input := [1, 1, 0], output := [1, 1, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0026 : valid { kind := .seq, input := [1, 1, 1], output := [1, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0027 : valid { kind := .seq, input := [1, 1, 2], output := [1, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0028 : valid { kind := .seq, input := [1, 2, 0], output := [1, 2, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0029 : valid { kind := .seq, input := [1, 2, 1], output := [1, 2, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0030 : valid { kind := .seq, input := [1, 2, 2], output := [1, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0031 : valid { kind := .seq, input := [2, 0, 0], output := [2, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0032 : valid { kind := .seq, input := [2, 0, 1], output := [2, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0033 : valid { kind := .seq, input := [2, 0, 2], output := [2, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0034 : valid { kind := .seq, input := [2, 1, 0], output := [2, 1, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0035 : valid { kind := .seq, input := [2, 1, 1], output := [2, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0036 : valid { kind := .seq, input := [2, 1, 2], output := [2, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0037 : valid { kind := .seq, input := [2, 2, 0], output := [2, 2, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0038 : valid { kind := .seq, input := [2, 2, 1], output := [2, 2, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0039 : valid { kind := .seq, input := [2, 2, 2], output := [2, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0040 : valid { kind := .seq, input := [0, 0, 0, 0], output := [0, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0041 : valid { kind := .seq, input := [0, 0, 0, 1], output := [0, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0042 : valid { kind := .seq, input := [0, 0, 0, 2], output := [0, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0043 : valid { kind := .seq, input := [0, 0, 1, 0], output := [0, 0, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0044 : valid { kind := .seq, input := [0, 0, 1, 1], output := [0, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0045 : valid { kind := .seq, input := [0, 0, 1, 2], output := [0, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0046 : valid { kind := .seq, input := [0, 0, 2, 0], output := [0, 0, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0047 : valid { kind := .seq, input := [0, 0, 2, 1], output := [0, 0, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0048 : valid { kind := .seq, input := [0, 0, 2, 2], output := [0, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0049 : valid { kind := .seq, input := [0, 1, 0, 0], output := [0, 1, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0050 : valid { kind := .seq, input := [0, 1, 0, 1], output := [0, 1, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0051 : valid { kind := .seq, input := [0, 1, 0, 2], output := [0, 1, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0052 : valid { kind := .seq, input := [0, 1, 1, 0], output := [0, 1, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0053 : valid { kind := .seq, input := [0, 1, 1, 1], output := [0, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0054 : valid { kind := .seq, input := [0, 1, 1, 2], output := [0, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0055 : valid { kind := .seq, input := [0, 1, 2, 0], output := [0, 1, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0056 : valid { kind := .seq, input := [0, 1, 2, 1], output := [0, 1, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0057 : valid { kind := .seq, input := [0, 1, 2, 2], output := [0, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0058 : valid { kind := .seq, input := [0, 2, 0, 0], output := [0, 2, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0059 : valid { kind := .seq, input := [0, 2, 0, 1], output := [0, 2, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0060 : valid { kind := .seq, input := [0, 2, 0, 2], output := [0, 2, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0061 : valid { kind := .seq, input := [0, 2, 1, 0], output := [0, 2, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0062 : valid { kind := .seq, input := [0, 2, 1, 1], output := [0, 2, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0063 : valid { kind := .seq, input := [0, 2, 1, 2], output := [0, 2, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0064 : valid { kind := .seq, input := [0, 2, 2, 0], output := [0, 2, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0065 : valid { kind := .seq, input := [0, 2, 2, 1], output := [0, 2, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0066 : valid { kind := .seq, input := [0, 2, 2, 2], output := [0, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0067 : valid { kind := .seq, input := [1, 0, 0, 0], output := [1, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0068 : valid { kind := .seq, input := [1, 0, 0, 1], output := [1, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0069 : valid { kind := .seq, input := [1, 0, 0, 2], output := [1, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0070 : valid { kind := .seq, input := [1, 0, 1, 0], output := [1, 0, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0071 : valid { kind := .seq, input := [1, 0, 1, 1], output := [1, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0072 : valid { kind := .seq, input := [1, 0, 1, 2], output := [1, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0073 : valid { kind := .seq, input := [1, 0, 2, 0], output := [1, 0, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0074 : valid { kind := .seq, input := [1, 0, 2, 1], output := [1, 0, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0075 : valid { kind := .seq, input := [1, 0, 2, 2], output := [1, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0076 : valid { kind := .seq, input := [1, 1, 0, 0], output := [1, 1, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0077 : valid { kind := .seq, input := [1, 1, 0, 1], output := [1, 1, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0078 : valid { kind := .seq, input := [1, 1, 0, 2], output := [1, 1, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0079 : valid { kind := .seq, input := [1, 1, 1, 0], output := [1, 1, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0080 : valid { kind := .seq, input := [1, 1, 1, 1], output := [1, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0081 : valid { kind := .seq, input := [1, 1, 1, 2], output := [1, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0082 : valid { kind := .seq, input := [1, 1, 2, 0], output := [1, 1, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0083 : valid { kind := .seq, input := [1, 1, 2, 1], output := [1, 1, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0084 : valid { kind := .seq, input := [1, 1, 2, 2], output := [1, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0085 : valid { kind := .seq, input := [1, 2, 0, 0], output := [1, 2, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0086 : valid { kind := .seq, input := [1, 2, 0, 1], output := [1, 2, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0087 : valid { kind := .seq, input := [1, 2, 0, 2], output := [1, 2, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0088 : valid { kind := .seq, input := [1, 2, 1, 0], output := [1, 2, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0089 : valid { kind := .seq, input := [1, 2, 1, 1], output := [1, 2, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0090 : valid { kind := .seq, input := [1, 2, 1, 2], output := [1, 2, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0091 : valid { kind := .seq, input := [1, 2, 2, 0], output := [1, 2, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0092 : valid { kind := .seq, input := [1, 2, 2, 1], output := [1, 2, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0093 : valid { kind := .seq, input := [1, 2, 2, 2], output := [1, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0094 : valid { kind := .seq, input := [2, 0, 0, 0], output := [2, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0095 : valid { kind := .seq, input := [2, 0, 0, 1], output := [2, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0096 : valid { kind := .seq, input := [2, 0, 0, 2], output := [2, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0097 : valid { kind := .seq, input := [2, 0, 1, 0], output := [2, 0, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0098 : valid { kind := .seq, input := [2, 0, 1, 1], output := [2, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0099 : valid { kind := .seq, input := [2, 0, 1, 2], output := [2, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0100 : valid { kind := .seq, input := [2, 0, 2, 0], output := [2, 0, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0101 : valid { kind := .seq, input := [2, 0, 2, 1], output := [2, 0, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0102 : valid { kind := .seq, input := [2, 0, 2, 2], output := [2, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0103 : valid { kind := .seq, input := [2, 1, 0, 0], output := [2, 1, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0104 : valid { kind := .seq, input := [2, 1, 0, 1], output := [2, 1, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0105 : valid { kind := .seq, input := [2, 1, 0, 2], output := [2, 1, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0106 : valid { kind := .seq, input := [2, 1, 1, 0], output := [2, 1, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0107 : valid { kind := .seq, input := [2, 1, 1, 1], output := [2, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0108 : valid { kind := .seq, input := [2, 1, 1, 2], output := [2, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0109 : valid { kind := .seq, input := [2, 1, 2, 0], output := [2, 1, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0110 : valid { kind := .seq, input := [2, 1, 2, 1], output := [2, 1, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0111 : valid { kind := .seq, input := [2, 1, 2, 2], output := [2, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0112 : valid { kind := .seq, input := [2, 2, 0, 0], output := [2, 2, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0113 : valid { kind := .seq, input := [2, 2, 0, 1], output := [2, 2, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0114 : valid { kind := .seq, input := [2, 2, 0, 2], output := [2, 2, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0115 : valid { kind := .seq, input := [2, 2, 1, 0], output := [2, 2, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0116 : valid { kind := .seq, input := [2, 2, 1, 1], output := [2, 2, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0117 : valid { kind := .seq, input := [2, 2, 1, 2], output := [2, 2, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0118 : valid { kind := .seq, input := [2, 2, 2, 0], output := [2, 2, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0119 : valid { kind := .seq, input := [2, 2, 2, 1], output := [2, 2, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0120 : valid { kind := .seq, input := [2, 2, 2, 2], output := [2, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0121 : valid { kind := .bag, input := [], output := [], fibers := [] } = true := by decide
theorem observed_0122 : valid { kind := .bag, input := [0], output := [0], fibers := [[0]] } = true := by decide
theorem observed_0123 : valid { kind := .bag, input := [1], output := [1], fibers := [[0]] } = true := by decide
theorem observed_0124 : valid { kind := .bag, input := [2], output := [2], fibers := [[0]] } = true := by decide
theorem observed_0125 : valid { kind := .bag, input := [0, 0], output := [0, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0126 : valid { kind := .bag, input := [0, 1], output := [0, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0127 : valid { kind := .bag, input := [0, 2], output := [0, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0128 : valid { kind := .bag, input := [1, 0], output := [0, 1], fibers := [[1], [0]] } = true := by decide
theorem observed_0129 : valid { kind := .bag, input := [1, 1], output := [1, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0130 : valid { kind := .bag, input := [1, 2], output := [1, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0131 : valid { kind := .bag, input := [2, 0], output := [0, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0132 : valid { kind := .bag, input := [2, 1], output := [1, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0133 : valid { kind := .bag, input := [2, 2], output := [2, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0134 : valid { kind := .bag, input := [0, 0, 0], output := [0, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0135 : valid { kind := .bag, input := [0, 0, 1], output := [0, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0136 : valid { kind := .bag, input := [0, 0, 2], output := [0, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0137 : valid { kind := .bag, input := [0, 1, 0], output := [0, 0, 1], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0138 : valid { kind := .bag, input := [0, 1, 1], output := [0, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0139 : valid { kind := .bag, input := [0, 1, 2], output := [0, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0140 : valid { kind := .bag, input := [0, 2, 0], output := [0, 0, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0141 : valid { kind := .bag, input := [0, 2, 1], output := [0, 1, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0142 : valid { kind := .bag, input := [0, 2, 2], output := [0, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0143 : valid { kind := .bag, input := [1, 0, 0], output := [0, 0, 1], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0144 : valid { kind := .bag, input := [1, 0, 1], output := [0, 1, 1], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0145 : valid { kind := .bag, input := [1, 0, 2], output := [0, 1, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0146 : valid { kind := .bag, input := [1, 1, 0], output := [0, 1, 1], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0147 : valid { kind := .bag, input := [1, 1, 1], output := [1, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0148 : valid { kind := .bag, input := [1, 1, 2], output := [1, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0149 : valid { kind := .bag, input := [1, 2, 0], output := [0, 1, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0150 : valid { kind := .bag, input := [1, 2, 1], output := [1, 1, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0151 : valid { kind := .bag, input := [1, 2, 2], output := [1, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0152 : valid { kind := .bag, input := [2, 0, 0], output := [0, 0, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0153 : valid { kind := .bag, input := [2, 0, 1], output := [0, 1, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0154 : valid { kind := .bag, input := [2, 0, 2], output := [0, 2, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0155 : valid { kind := .bag, input := [2, 1, 0], output := [0, 1, 2], fibers := [[2], [1], [0]] } = true := by decide
theorem observed_0156 : valid { kind := .bag, input := [2, 1, 1], output := [1, 1, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0157 : valid { kind := .bag, input := [2, 1, 2], output := [1, 2, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0158 : valid { kind := .bag, input := [2, 2, 0], output := [0, 2, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0159 : valid { kind := .bag, input := [2, 2, 1], output := [1, 2, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0160 : valid { kind := .bag, input := [2, 2, 2], output := [2, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0161 : valid { kind := .bag, input := [0, 0, 0, 0], output := [0, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0162 : valid { kind := .bag, input := [0, 0, 0, 1], output := [0, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0163 : valid { kind := .bag, input := [0, 0, 0, 2], output := [0, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0164 : valid { kind := .bag, input := [0, 0, 1, 0], output := [0, 0, 0, 1], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0165 : valid { kind := .bag, input := [0, 0, 1, 1], output := [0, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0166 : valid { kind := .bag, input := [0, 0, 1, 2], output := [0, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0167 : valid { kind := .bag, input := [0, 0, 2, 0], output := [0, 0, 0, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0168 : valid { kind := .bag, input := [0, 0, 2, 1], output := [0, 0, 1, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0169 : valid { kind := .bag, input := [0, 0, 2, 2], output := [0, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0170 : valid { kind := .bag, input := [0, 1, 0, 0], output := [0, 0, 0, 1], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0171 : valid { kind := .bag, input := [0, 1, 0, 1], output := [0, 0, 1, 1], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0172 : valid { kind := .bag, input := [0, 1, 0, 2], output := [0, 0, 1, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0173 : valid { kind := .bag, input := [0, 1, 1, 0], output := [0, 0, 1, 1], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0174 : valid { kind := .bag, input := [0, 1, 1, 1], output := [0, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0175 : valid { kind := .bag, input := [0, 1, 1, 2], output := [0, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0176 : valid { kind := .bag, input := [0, 1, 2, 0], output := [0, 0, 1, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0177 : valid { kind := .bag, input := [0, 1, 2, 1], output := [0, 1, 1, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0178 : valid { kind := .bag, input := [0, 1, 2, 2], output := [0, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0179 : valid { kind := .bag, input := [0, 2, 0, 0], output := [0, 0, 0, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0180 : valid { kind := .bag, input := [0, 2, 0, 1], output := [0, 0, 1, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0181 : valid { kind := .bag, input := [0, 2, 0, 2], output := [0, 0, 2, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0182 : valid { kind := .bag, input := [0, 2, 1, 0], output := [0, 0, 1, 2], fibers := [[0], [3], [2], [1]] } = true := by decide
theorem observed_0183 : valid { kind := .bag, input := [0, 2, 1, 1], output := [0, 1, 1, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0184 : valid { kind := .bag, input := [0, 2, 1, 2], output := [0, 1, 2, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0185 : valid { kind := .bag, input := [0, 2, 2, 0], output := [0, 0, 2, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0186 : valid { kind := .bag, input := [0, 2, 2, 1], output := [0, 1, 2, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0187 : valid { kind := .bag, input := [0, 2, 2, 2], output := [0, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0188 : valid { kind := .bag, input := [1, 0, 0, 0], output := [0, 0, 0, 1], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0189 : valid { kind := .bag, input := [1, 0, 0, 1], output := [0, 0, 1, 1], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0190 : valid { kind := .bag, input := [1, 0, 0, 2], output := [0, 0, 1, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0191 : valid { kind := .bag, input := [1, 0, 1, 0], output := [0, 0, 1, 1], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0192 : valid { kind := .bag, input := [1, 0, 1, 1], output := [0, 1, 1, 1], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0193 : valid { kind := .bag, input := [1, 0, 1, 2], output := [0, 1, 1, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0194 : valid { kind := .bag, input := [1, 0, 2, 0], output := [0, 0, 1, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0195 : valid { kind := .bag, input := [1, 0, 2, 1], output := [0, 1, 1, 2], fibers := [[1], [0], [3], [2]] } = true := by decide
theorem observed_0196 : valid { kind := .bag, input := [1, 0, 2, 2], output := [0, 1, 2, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0197 : valid { kind := .bag, input := [1, 1, 0, 0], output := [0, 0, 1, 1], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0198 : valid { kind := .bag, input := [1, 1, 0, 1], output := [0, 1, 1, 1], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0199 : valid { kind := .bag, input := [1, 1, 0, 2], output := [0, 1, 1, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0200 : valid { kind := .bag, input := [1, 1, 1, 0], output := [0, 1, 1, 1], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0201 : valid { kind := .bag, input := [1, 1, 1, 1], output := [1, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0202 : valid { kind := .bag, input := [1, 1, 1, 2], output := [1, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0203 : valid { kind := .bag, input := [1, 1, 2, 0], output := [0, 1, 1, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0204 : valid { kind := .bag, input := [1, 1, 2, 1], output := [1, 1, 1, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0205 : valid { kind := .bag, input := [1, 1, 2, 2], output := [1, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0206 : valid { kind := .bag, input := [1, 2, 0, 0], output := [0, 0, 1, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0207 : valid { kind := .bag, input := [1, 2, 0, 1], output := [0, 1, 1, 2], fibers := [[2], [0], [3], [1]] } = true := by decide
theorem observed_0208 : valid { kind := .bag, input := [1, 2, 0, 2], output := [0, 1, 2, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0209 : valid { kind := .bag, input := [1, 2, 1, 0], output := [0, 1, 1, 2], fibers := [[3], [0], [2], [1]] } = true := by decide
theorem observed_0210 : valid { kind := .bag, input := [1, 2, 1, 1], output := [1, 1, 1, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0211 : valid { kind := .bag, input := [1, 2, 1, 2], output := [1, 1, 2, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0212 : valid { kind := .bag, input := [1, 2, 2, 0], output := [0, 1, 2, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0213 : valid { kind := .bag, input := [1, 2, 2, 1], output := [1, 1, 2, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0214 : valid { kind := .bag, input := [1, 2, 2, 2], output := [1, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0215 : valid { kind := .bag, input := [2, 0, 0, 0], output := [0, 0, 0, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0216 : valid { kind := .bag, input := [2, 0, 0, 1], output := [0, 0, 1, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0217 : valid { kind := .bag, input := [2, 0, 0, 2], output := [0, 0, 2, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0218 : valid { kind := .bag, input := [2, 0, 1, 0], output := [0, 0, 1, 2], fibers := [[1], [3], [2], [0]] } = true := by decide
theorem observed_0219 : valid { kind := .bag, input := [2, 0, 1, 1], output := [0, 1, 1, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0220 : valid { kind := .bag, input := [2, 0, 1, 2], output := [0, 1, 2, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0221 : valid { kind := .bag, input := [2, 0, 2, 0], output := [0, 0, 2, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0222 : valid { kind := .bag, input := [2, 0, 2, 1], output := [0, 1, 2, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0223 : valid { kind := .bag, input := [2, 0, 2, 2], output := [0, 2, 2, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0224 : valid { kind := .bag, input := [2, 1, 0, 0], output := [0, 0, 1, 2], fibers := [[2], [3], [1], [0]] } = true := by decide
theorem observed_0225 : valid { kind := .bag, input := [2, 1, 0, 1], output := [0, 1, 1, 2], fibers := [[2], [1], [3], [0]] } = true := by decide
theorem observed_0226 : valid { kind := .bag, input := [2, 1, 0, 2], output := [0, 1, 2, 2], fibers := [[2], [1], [0], [3]] } = true := by decide
theorem observed_0227 : valid { kind := .bag, input := [2, 1, 1, 0], output := [0, 1, 1, 2], fibers := [[3], [1], [2], [0]] } = true := by decide
theorem observed_0228 : valid { kind := .bag, input := [2, 1, 1, 1], output := [1, 1, 1, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0229 : valid { kind := .bag, input := [2, 1, 1, 2], output := [1, 1, 2, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0230 : valid { kind := .bag, input := [2, 1, 2, 0], output := [0, 1, 2, 2], fibers := [[3], [1], [0], [2]] } = true := by decide
theorem observed_0231 : valid { kind := .bag, input := [2, 1, 2, 1], output := [1, 1, 2, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0232 : valid { kind := .bag, input := [2, 1, 2, 2], output := [1, 2, 2, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0233 : valid { kind := .bag, input := [2, 2, 0, 0], output := [0, 0, 2, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0234 : valid { kind := .bag, input := [2, 2, 0, 1], output := [0, 1, 2, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0235 : valid { kind := .bag, input := [2, 2, 0, 2], output := [0, 2, 2, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0236 : valid { kind := .bag, input := [2, 2, 1, 0], output := [0, 1, 2, 2], fibers := [[3], [2], [0], [1]] } = true := by decide
theorem observed_0237 : valid { kind := .bag, input := [2, 2, 1, 1], output := [1, 1, 2, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0238 : valid { kind := .bag, input := [2, 2, 1, 2], output := [1, 2, 2, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0239 : valid { kind := .bag, input := [2, 2, 2, 0], output := [0, 2, 2, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0240 : valid { kind := .bag, input := [2, 2, 2, 1], output := [1, 2, 2, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0241 : valid { kind := .bag, input := [2, 2, 2, 2], output := [2, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0242 : valid { kind := .set, input := [], output := [], fibers := [] } = true := by decide
theorem observed_0243 : valid { kind := .set, input := [0], output := [0], fibers := [[0]] } = true := by decide
theorem observed_0244 : valid { kind := .set, input := [1], output := [1], fibers := [[0]] } = true := by decide
theorem observed_0245 : valid { kind := .set, input := [2], output := [2], fibers := [[0]] } = true := by decide
theorem observed_0246 : valid { kind := .set, input := [0, 0], output := [0], fibers := [[0, 1]] } = true := by decide
theorem observed_0247 : valid { kind := .set, input := [0, 1], output := [0, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0248 : valid { kind := .set, input := [0, 2], output := [0, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0249 : valid { kind := .set, input := [1, 0], output := [0, 1], fibers := [[1], [0]] } = true := by decide
theorem observed_0250 : valid { kind := .set, input := [1, 1], output := [1], fibers := [[0, 1]] } = true := by decide
theorem observed_0251 : valid { kind := .set, input := [1, 2], output := [1, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0252 : valid { kind := .set, input := [2, 0], output := [0, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0253 : valid { kind := .set, input := [2, 1], output := [1, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0254 : valid { kind := .set, input := [2, 2], output := [2], fibers := [[0, 1]] } = true := by decide
theorem observed_0255 : valid { kind := .set, input := [0, 0, 0], output := [0], fibers := [[0, 1, 2]] } = true := by decide
theorem observed_0256 : valid { kind := .set, input := [0, 0, 1], output := [0, 1], fibers := [[0, 1], [2]] } = true := by decide
theorem observed_0257 : valid { kind := .set, input := [0, 0, 2], output := [0, 2], fibers := [[0, 1], [2]] } = true := by decide
theorem observed_0258 : valid { kind := .set, input := [0, 1, 0], output := [0, 1], fibers := [[0, 2], [1]] } = true := by decide
theorem observed_0259 : valid { kind := .set, input := [0, 1, 1], output := [0, 1], fibers := [[0], [1, 2]] } = true := by decide
theorem observed_0260 : valid { kind := .set, input := [0, 1, 2], output := [0, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0261 : valid { kind := .set, input := [0, 2, 0], output := [0, 2], fibers := [[0, 2], [1]] } = true := by decide
theorem observed_0262 : valid { kind := .set, input := [0, 2, 1], output := [0, 1, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0263 : valid { kind := .set, input := [0, 2, 2], output := [0, 2], fibers := [[0], [1, 2]] } = true := by decide
theorem observed_0264 : valid { kind := .set, input := [1, 0, 0], output := [0, 1], fibers := [[1, 2], [0]] } = true := by decide
theorem observed_0265 : valid { kind := .set, input := [1, 0, 1], output := [0, 1], fibers := [[1], [0, 2]] } = true := by decide
theorem observed_0266 : valid { kind := .set, input := [1, 0, 2], output := [0, 1, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0267 : valid { kind := .set, input := [1, 1, 0], output := [0, 1], fibers := [[2], [0, 1]] } = true := by decide
theorem observed_0268 : valid { kind := .set, input := [1, 1, 1], output := [1], fibers := [[0, 1, 2]] } = true := by decide
theorem observed_0269 : valid { kind := .set, input := [1, 1, 2], output := [1, 2], fibers := [[0, 1], [2]] } = true := by decide
theorem observed_0270 : valid { kind := .set, input := [1, 2, 0], output := [0, 1, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0271 : valid { kind := .set, input := [1, 2, 1], output := [1, 2], fibers := [[0, 2], [1]] } = true := by decide
theorem observed_0272 : valid { kind := .set, input := [1, 2, 2], output := [1, 2], fibers := [[0], [1, 2]] } = true := by decide
theorem observed_0273 : valid { kind := .set, input := [2, 0, 0], output := [0, 2], fibers := [[1, 2], [0]] } = true := by decide
theorem observed_0274 : valid { kind := .set, input := [2, 0, 1], output := [0, 1, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0275 : valid { kind := .set, input := [2, 0, 2], output := [0, 2], fibers := [[1], [0, 2]] } = true := by decide
theorem observed_0276 : valid { kind := .set, input := [2, 1, 0], output := [0, 1, 2], fibers := [[2], [1], [0]] } = true := by decide
theorem observed_0277 : valid { kind := .set, input := [2, 1, 1], output := [1, 2], fibers := [[1, 2], [0]] } = true := by decide
theorem observed_0278 : valid { kind := .set, input := [2, 1, 2], output := [1, 2], fibers := [[1], [0, 2]] } = true := by decide
theorem observed_0279 : valid { kind := .set, input := [2, 2, 0], output := [0, 2], fibers := [[2], [0, 1]] } = true := by decide
theorem observed_0280 : valid { kind := .set, input := [2, 2, 1], output := [1, 2], fibers := [[2], [0, 1]] } = true := by decide
theorem observed_0281 : valid { kind := .set, input := [2, 2, 2], output := [2], fibers := [[0, 1, 2]] } = true := by decide
theorem observed_0282 : valid { kind := .set, input := [0, 0, 0, 0], output := [0], fibers := [[0, 1, 2, 3]] } = true := by decide
theorem observed_0283 : valid { kind := .set, input := [0, 0, 0, 1], output := [0, 1], fibers := [[0, 1, 2], [3]] } = true := by decide
theorem observed_0284 : valid { kind := .set, input := [0, 0, 0, 2], output := [0, 2], fibers := [[0, 1, 2], [3]] } = true := by decide
theorem observed_0285 : valid { kind := .set, input := [0, 0, 1, 0], output := [0, 1], fibers := [[0, 1, 3], [2]] } = true := by decide
theorem observed_0286 : valid { kind := .set, input := [0, 0, 1, 1], output := [0, 1], fibers := [[0, 1], [2, 3]] } = true := by decide
theorem observed_0287 : valid { kind := .set, input := [0, 0, 1, 2], output := [0, 1, 2], fibers := [[0, 1], [2], [3]] } = true := by decide
theorem observed_0288 : valid { kind := .set, input := [0, 0, 2, 0], output := [0, 2], fibers := [[0, 1, 3], [2]] } = true := by decide
theorem observed_0289 : valid { kind := .set, input := [0, 0, 2, 1], output := [0, 1, 2], fibers := [[0, 1], [3], [2]] } = true := by decide
theorem observed_0290 : valid { kind := .set, input := [0, 0, 2, 2], output := [0, 2], fibers := [[0, 1], [2, 3]] } = true := by decide
theorem observed_0291 : valid { kind := .set, input := [0, 1, 0, 0], output := [0, 1], fibers := [[0, 2, 3], [1]] } = true := by decide
theorem observed_0292 : valid { kind := .set, input := [0, 1, 0, 1], output := [0, 1], fibers := [[0, 2], [1, 3]] } = true := by decide
theorem observed_0293 : valid { kind := .set, input := [0, 1, 0, 2], output := [0, 1, 2], fibers := [[0, 2], [1], [3]] } = true := by decide
theorem observed_0294 : valid { kind := .set, input := [0, 1, 1, 0], output := [0, 1], fibers := [[0, 3], [1, 2]] } = true := by decide
theorem observed_0295 : valid { kind := .set, input := [0, 1, 1, 1], output := [0, 1], fibers := [[0], [1, 2, 3]] } = true := by decide
theorem observed_0296 : valid { kind := .set, input := [0, 1, 1, 2], output := [0, 1, 2], fibers := [[0], [1, 2], [3]] } = true := by decide
theorem observed_0297 : valid { kind := .set, input := [0, 1, 2, 0], output := [0, 1, 2], fibers := [[0, 3], [1], [2]] } = true := by decide
theorem observed_0298 : valid { kind := .set, input := [0, 1, 2, 1], output := [0, 1, 2], fibers := [[0], [1, 3], [2]] } = true := by decide
theorem observed_0299 : valid { kind := .set, input := [0, 1, 2, 2], output := [0, 1, 2], fibers := [[0], [1], [2, 3]] } = true := by decide
theorem observed_0300 : valid { kind := .set, input := [0, 2, 0, 0], output := [0, 2], fibers := [[0, 2, 3], [1]] } = true := by decide
theorem observed_0301 : valid { kind := .set, input := [0, 2, 0, 1], output := [0, 1, 2], fibers := [[0, 2], [3], [1]] } = true := by decide
theorem observed_0302 : valid { kind := .set, input := [0, 2, 0, 2], output := [0, 2], fibers := [[0, 2], [1, 3]] } = true := by decide
theorem observed_0303 : valid { kind := .set, input := [0, 2, 1, 0], output := [0, 1, 2], fibers := [[0, 3], [2], [1]] } = true := by decide
theorem observed_0304 : valid { kind := .set, input := [0, 2, 1, 1], output := [0, 1, 2], fibers := [[0], [2, 3], [1]] } = true := by decide
theorem observed_0305 : valid { kind := .set, input := [0, 2, 1, 2], output := [0, 1, 2], fibers := [[0], [2], [1, 3]] } = true := by decide
theorem observed_0306 : valid { kind := .set, input := [0, 2, 2, 0], output := [0, 2], fibers := [[0, 3], [1, 2]] } = true := by decide
theorem observed_0307 : valid { kind := .set, input := [0, 2, 2, 1], output := [0, 1, 2], fibers := [[0], [3], [1, 2]] } = true := by decide
theorem observed_0308 : valid { kind := .set, input := [0, 2, 2, 2], output := [0, 2], fibers := [[0], [1, 2, 3]] } = true := by decide
theorem observed_0309 : valid { kind := .set, input := [1, 0, 0, 0], output := [0, 1], fibers := [[1, 2, 3], [0]] } = true := by decide
theorem observed_0310 : valid { kind := .set, input := [1, 0, 0, 1], output := [0, 1], fibers := [[1, 2], [0, 3]] } = true := by decide
theorem observed_0311 : valid { kind := .set, input := [1, 0, 0, 2], output := [0, 1, 2], fibers := [[1, 2], [0], [3]] } = true := by decide
theorem observed_0312 : valid { kind := .set, input := [1, 0, 1, 0], output := [0, 1], fibers := [[1, 3], [0, 2]] } = true := by decide
theorem observed_0313 : valid { kind := .set, input := [1, 0, 1, 1], output := [0, 1], fibers := [[1], [0, 2, 3]] } = true := by decide
theorem observed_0314 : valid { kind := .set, input := [1, 0, 1, 2], output := [0, 1, 2], fibers := [[1], [0, 2], [3]] } = true := by decide
theorem observed_0315 : valid { kind := .set, input := [1, 0, 2, 0], output := [0, 1, 2], fibers := [[1, 3], [0], [2]] } = true := by decide
theorem observed_0316 : valid { kind := .set, input := [1, 0, 2, 1], output := [0, 1, 2], fibers := [[1], [0, 3], [2]] } = true := by decide
theorem observed_0317 : valid { kind := .set, input := [1, 0, 2, 2], output := [0, 1, 2], fibers := [[1], [0], [2, 3]] } = true := by decide
theorem observed_0318 : valid { kind := .set, input := [1, 1, 0, 0], output := [0, 1], fibers := [[2, 3], [0, 1]] } = true := by decide
theorem observed_0319 : valid { kind := .set, input := [1, 1, 0, 1], output := [0, 1], fibers := [[2], [0, 1, 3]] } = true := by decide
theorem observed_0320 : valid { kind := .set, input := [1, 1, 0, 2], output := [0, 1, 2], fibers := [[2], [0, 1], [3]] } = true := by decide
theorem observed_0321 : valid { kind := .set, input := [1, 1, 1, 0], output := [0, 1], fibers := [[3], [0, 1, 2]] } = true := by decide
theorem observed_0322 : valid { kind := .set, input := [1, 1, 1, 1], output := [1], fibers := [[0, 1, 2, 3]] } = true := by decide
theorem observed_0323 : valid { kind := .set, input := [1, 1, 1, 2], output := [1, 2], fibers := [[0, 1, 2], [3]] } = true := by decide
theorem observed_0324 : valid { kind := .set, input := [1, 1, 2, 0], output := [0, 1, 2], fibers := [[3], [0, 1], [2]] } = true := by decide
theorem observed_0325 : valid { kind := .set, input := [1, 1, 2, 1], output := [1, 2], fibers := [[0, 1, 3], [2]] } = true := by decide
theorem observed_0326 : valid { kind := .set, input := [1, 1, 2, 2], output := [1, 2], fibers := [[0, 1], [2, 3]] } = true := by decide
theorem observed_0327 : valid { kind := .set, input := [1, 2, 0, 0], output := [0, 1, 2], fibers := [[2, 3], [0], [1]] } = true := by decide
theorem observed_0328 : valid { kind := .set, input := [1, 2, 0, 1], output := [0, 1, 2], fibers := [[2], [0, 3], [1]] } = true := by decide
theorem observed_0329 : valid { kind := .set, input := [1, 2, 0, 2], output := [0, 1, 2], fibers := [[2], [0], [1, 3]] } = true := by decide
theorem observed_0330 : valid { kind := .set, input := [1, 2, 1, 0], output := [0, 1, 2], fibers := [[3], [0, 2], [1]] } = true := by decide
theorem observed_0331 : valid { kind := .set, input := [1, 2, 1, 1], output := [1, 2], fibers := [[0, 2, 3], [1]] } = true := by decide
theorem observed_0332 : valid { kind := .set, input := [1, 2, 1, 2], output := [1, 2], fibers := [[0, 2], [1, 3]] } = true := by decide
theorem observed_0333 : valid { kind := .set, input := [1, 2, 2, 0], output := [0, 1, 2], fibers := [[3], [0], [1, 2]] } = true := by decide
theorem observed_0334 : valid { kind := .set, input := [1, 2, 2, 1], output := [1, 2], fibers := [[0, 3], [1, 2]] } = true := by decide
theorem observed_0335 : valid { kind := .set, input := [1, 2, 2, 2], output := [1, 2], fibers := [[0], [1, 2, 3]] } = true := by decide
theorem observed_0336 : valid { kind := .set, input := [2, 0, 0, 0], output := [0, 2], fibers := [[1, 2, 3], [0]] } = true := by decide
theorem observed_0337 : valid { kind := .set, input := [2, 0, 0, 1], output := [0, 1, 2], fibers := [[1, 2], [3], [0]] } = true := by decide
theorem observed_0338 : valid { kind := .set, input := [2, 0, 0, 2], output := [0, 2], fibers := [[1, 2], [0, 3]] } = true := by decide
theorem observed_0339 : valid { kind := .set, input := [2, 0, 1, 0], output := [0, 1, 2], fibers := [[1, 3], [2], [0]] } = true := by decide
theorem observed_0340 : valid { kind := .set, input := [2, 0, 1, 1], output := [0, 1, 2], fibers := [[1], [2, 3], [0]] } = true := by decide
theorem observed_0341 : valid { kind := .set, input := [2, 0, 1, 2], output := [0, 1, 2], fibers := [[1], [2], [0, 3]] } = true := by decide
theorem observed_0342 : valid { kind := .set, input := [2, 0, 2, 0], output := [0, 2], fibers := [[1, 3], [0, 2]] } = true := by decide
theorem observed_0343 : valid { kind := .set, input := [2, 0, 2, 1], output := [0, 1, 2], fibers := [[1], [3], [0, 2]] } = true := by decide
theorem observed_0344 : valid { kind := .set, input := [2, 0, 2, 2], output := [0, 2], fibers := [[1], [0, 2, 3]] } = true := by decide
theorem observed_0345 : valid { kind := .set, input := [2, 1, 0, 0], output := [0, 1, 2], fibers := [[2, 3], [1], [0]] } = true := by decide
theorem observed_0346 : valid { kind := .set, input := [2, 1, 0, 1], output := [0, 1, 2], fibers := [[2], [1, 3], [0]] } = true := by decide
theorem observed_0347 : valid { kind := .set, input := [2, 1, 0, 2], output := [0, 1, 2], fibers := [[2], [1], [0, 3]] } = true := by decide
theorem observed_0348 : valid { kind := .set, input := [2, 1, 1, 0], output := [0, 1, 2], fibers := [[3], [1, 2], [0]] } = true := by decide
theorem observed_0349 : valid { kind := .set, input := [2, 1, 1, 1], output := [1, 2], fibers := [[1, 2, 3], [0]] } = true := by decide
theorem observed_0350 : valid { kind := .set, input := [2, 1, 1, 2], output := [1, 2], fibers := [[1, 2], [0, 3]] } = true := by decide
theorem observed_0351 : valid { kind := .set, input := [2, 1, 2, 0], output := [0, 1, 2], fibers := [[3], [1], [0, 2]] } = true := by decide
theorem observed_0352 : valid { kind := .set, input := [2, 1, 2, 1], output := [1, 2], fibers := [[1, 3], [0, 2]] } = true := by decide
theorem observed_0353 : valid { kind := .set, input := [2, 1, 2, 2], output := [1, 2], fibers := [[1], [0, 2, 3]] } = true := by decide
theorem observed_0354 : valid { kind := .set, input := [2, 2, 0, 0], output := [0, 2], fibers := [[2, 3], [0, 1]] } = true := by decide
theorem observed_0355 : valid { kind := .set, input := [2, 2, 0, 1], output := [0, 1, 2], fibers := [[2], [3], [0, 1]] } = true := by decide
theorem observed_0356 : valid { kind := .set, input := [2, 2, 0, 2], output := [0, 2], fibers := [[2], [0, 1, 3]] } = true := by decide
theorem observed_0357 : valid { kind := .set, input := [2, 2, 1, 0], output := [0, 1, 2], fibers := [[3], [2], [0, 1]] } = true := by decide
theorem observed_0358 : valid { kind := .set, input := [2, 2, 1, 1], output := [1, 2], fibers := [[2, 3], [0, 1]] } = true := by decide
theorem observed_0359 : valid { kind := .set, input := [2, 2, 1, 2], output := [1, 2], fibers := [[2], [0, 1, 3]] } = true := by decide
theorem observed_0360 : valid { kind := .set, input := [2, 2, 2, 0], output := [0, 2], fibers := [[3], [0, 1, 2]] } = true := by decide
theorem observed_0361 : valid { kind := .set, input := [2, 2, 2, 1], output := [1, 2], fibers := [[3], [0, 1, 2]] } = true := by decide
theorem observed_0362 : valid { kind := .set, input := [2, 2, 2, 2], output := [2], fibers := [[0, 1, 2, 3]] } = true := by decide
theorem observed_0363 : valid { kind := .seq, input := [], output := [], fibers := [] } = true := by decide
theorem observed_0364 : valid { kind := .seq, input := [0], output := [0], fibers := [[0]] } = true := by decide
theorem observed_0365 : valid { kind := .seq, input := [1], output := [1], fibers := [[0]] } = true := by decide
theorem observed_0366 : valid { kind := .seq, input := [2], output := [2], fibers := [[0]] } = true := by decide
theorem observed_0367 : valid { kind := .seq, input := [0, 0], output := [0, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0368 : valid { kind := .seq, input := [0, 1], output := [0, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0369 : valid { kind := .seq, input := [0, 2], output := [0, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0370 : valid { kind := .seq, input := [1, 0], output := [1, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0371 : valid { kind := .seq, input := [1, 1], output := [1, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0372 : valid { kind := .seq, input := [1, 2], output := [1, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0373 : valid { kind := .seq, input := [2, 0], output := [2, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0374 : valid { kind := .seq, input := [2, 1], output := [2, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0375 : valid { kind := .seq, input := [2, 2], output := [2, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0376 : valid { kind := .seq, input := [0, 0, 0], output := [0, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0377 : valid { kind := .seq, input := [0, 0, 1], output := [0, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0378 : valid { kind := .seq, input := [0, 0, 2], output := [0, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0379 : valid { kind := .seq, input := [0, 1, 0], output := [0, 1, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0380 : valid { kind := .seq, input := [0, 1, 1], output := [0, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0381 : valid { kind := .seq, input := [0, 1, 2], output := [0, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0382 : valid { kind := .seq, input := [0, 2, 0], output := [0, 2, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0383 : valid { kind := .seq, input := [0, 2, 1], output := [0, 2, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0384 : valid { kind := .seq, input := [0, 2, 2], output := [0, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0385 : valid { kind := .seq, input := [1, 0, 0], output := [1, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0386 : valid { kind := .seq, input := [1, 0, 1], output := [1, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0387 : valid { kind := .seq, input := [1, 0, 2], output := [1, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0388 : valid { kind := .seq, input := [1, 1, 0], output := [1, 1, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0389 : valid { kind := .seq, input := [1, 1, 1], output := [1, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0390 : valid { kind := .seq, input := [1, 1, 2], output := [1, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0391 : valid { kind := .seq, input := [1, 2, 0], output := [1, 2, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0392 : valid { kind := .seq, input := [1, 2, 1], output := [1, 2, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0393 : valid { kind := .seq, input := [1, 2, 2], output := [1, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0394 : valid { kind := .seq, input := [2, 0, 0], output := [2, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0395 : valid { kind := .seq, input := [2, 0, 1], output := [2, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0396 : valid { kind := .seq, input := [2, 0, 2], output := [2, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0397 : valid { kind := .seq, input := [2, 1, 0], output := [2, 1, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0398 : valid { kind := .seq, input := [2, 1, 1], output := [2, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0399 : valid { kind := .seq, input := [2, 1, 2], output := [2, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0400 : valid { kind := .seq, input := [2, 2, 0], output := [2, 2, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0401 : valid { kind := .seq, input := [2, 2, 1], output := [2, 2, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0402 : valid { kind := .seq, input := [2, 2, 2], output := [2, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0403 : valid { kind := .seq, input := [0, 0, 0, 0], output := [0, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0404 : valid { kind := .seq, input := [0, 0, 0, 1], output := [0, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0405 : valid { kind := .seq, input := [0, 0, 0, 2], output := [0, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0406 : valid { kind := .seq, input := [0, 0, 1, 0], output := [0, 0, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0407 : valid { kind := .seq, input := [0, 0, 1, 1], output := [0, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0408 : valid { kind := .seq, input := [0, 0, 1, 2], output := [0, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0409 : valid { kind := .seq, input := [0, 0, 2, 0], output := [0, 0, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0410 : valid { kind := .seq, input := [0, 0, 2, 1], output := [0, 0, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0411 : valid { kind := .seq, input := [0, 0, 2, 2], output := [0, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0412 : valid { kind := .seq, input := [0, 1, 0, 0], output := [0, 1, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0413 : valid { kind := .seq, input := [0, 1, 0, 1], output := [0, 1, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0414 : valid { kind := .seq, input := [0, 1, 0, 2], output := [0, 1, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0415 : valid { kind := .seq, input := [0, 1, 1, 0], output := [0, 1, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0416 : valid { kind := .seq, input := [0, 1, 1, 1], output := [0, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0417 : valid { kind := .seq, input := [0, 1, 1, 2], output := [0, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0418 : valid { kind := .seq, input := [0, 1, 2, 0], output := [0, 1, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0419 : valid { kind := .seq, input := [0, 1, 2, 1], output := [0, 1, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0420 : valid { kind := .seq, input := [0, 1, 2, 2], output := [0, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0421 : valid { kind := .seq, input := [0, 2, 0, 0], output := [0, 2, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0422 : valid { kind := .seq, input := [0, 2, 0, 1], output := [0, 2, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0423 : valid { kind := .seq, input := [0, 2, 0, 2], output := [0, 2, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0424 : valid { kind := .seq, input := [0, 2, 1, 0], output := [0, 2, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0425 : valid { kind := .seq, input := [0, 2, 1, 1], output := [0, 2, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0426 : valid { kind := .seq, input := [0, 2, 1, 2], output := [0, 2, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0427 : valid { kind := .seq, input := [0, 2, 2, 0], output := [0, 2, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0428 : valid { kind := .seq, input := [0, 2, 2, 1], output := [0, 2, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0429 : valid { kind := .seq, input := [0, 2, 2, 2], output := [0, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0430 : valid { kind := .seq, input := [1, 0, 0, 0], output := [1, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0431 : valid { kind := .seq, input := [1, 0, 0, 1], output := [1, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0432 : valid { kind := .seq, input := [1, 0, 0, 2], output := [1, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0433 : valid { kind := .seq, input := [1, 0, 1, 0], output := [1, 0, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0434 : valid { kind := .seq, input := [1, 0, 1, 1], output := [1, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0435 : valid { kind := .seq, input := [1, 0, 1, 2], output := [1, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0436 : valid { kind := .seq, input := [1, 0, 2, 0], output := [1, 0, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0437 : valid { kind := .seq, input := [1, 0, 2, 1], output := [1, 0, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0438 : valid { kind := .seq, input := [1, 0, 2, 2], output := [1, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0439 : valid { kind := .seq, input := [1, 1, 0, 0], output := [1, 1, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0440 : valid { kind := .seq, input := [1, 1, 0, 1], output := [1, 1, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0441 : valid { kind := .seq, input := [1, 1, 0, 2], output := [1, 1, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0442 : valid { kind := .seq, input := [1, 1, 1, 0], output := [1, 1, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0443 : valid { kind := .seq, input := [1, 1, 1, 1], output := [1, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0444 : valid { kind := .seq, input := [1, 1, 1, 2], output := [1, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0445 : valid { kind := .seq, input := [1, 1, 2, 0], output := [1, 1, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0446 : valid { kind := .seq, input := [1, 1, 2, 1], output := [1, 1, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0447 : valid { kind := .seq, input := [1, 1, 2, 2], output := [1, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0448 : valid { kind := .seq, input := [1, 2, 0, 0], output := [1, 2, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0449 : valid { kind := .seq, input := [1, 2, 0, 1], output := [1, 2, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0450 : valid { kind := .seq, input := [1, 2, 0, 2], output := [1, 2, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0451 : valid { kind := .seq, input := [1, 2, 1, 0], output := [1, 2, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0452 : valid { kind := .seq, input := [1, 2, 1, 1], output := [1, 2, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0453 : valid { kind := .seq, input := [1, 2, 1, 2], output := [1, 2, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0454 : valid { kind := .seq, input := [1, 2, 2, 0], output := [1, 2, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0455 : valid { kind := .seq, input := [1, 2, 2, 1], output := [1, 2, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0456 : valid { kind := .seq, input := [1, 2, 2, 2], output := [1, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0457 : valid { kind := .seq, input := [2, 0, 0, 0], output := [2, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0458 : valid { kind := .seq, input := [2, 0, 0, 1], output := [2, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0459 : valid { kind := .seq, input := [2, 0, 0, 2], output := [2, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0460 : valid { kind := .seq, input := [2, 0, 1, 0], output := [2, 0, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0461 : valid { kind := .seq, input := [2, 0, 1, 1], output := [2, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0462 : valid { kind := .seq, input := [2, 0, 1, 2], output := [2, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0463 : valid { kind := .seq, input := [2, 0, 2, 0], output := [2, 0, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0464 : valid { kind := .seq, input := [2, 0, 2, 1], output := [2, 0, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0465 : valid { kind := .seq, input := [2, 0, 2, 2], output := [2, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0466 : valid { kind := .seq, input := [2, 1, 0, 0], output := [2, 1, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0467 : valid { kind := .seq, input := [2, 1, 0, 1], output := [2, 1, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0468 : valid { kind := .seq, input := [2, 1, 0, 2], output := [2, 1, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0469 : valid { kind := .seq, input := [2, 1, 1, 0], output := [2, 1, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0470 : valid { kind := .seq, input := [2, 1, 1, 1], output := [2, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0471 : valid { kind := .seq, input := [2, 1, 1, 2], output := [2, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0472 : valid { kind := .seq, input := [2, 1, 2, 0], output := [2, 1, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0473 : valid { kind := .seq, input := [2, 1, 2, 1], output := [2, 1, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0474 : valid { kind := .seq, input := [2, 1, 2, 2], output := [2, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0475 : valid { kind := .seq, input := [2, 2, 0, 0], output := [2, 2, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0476 : valid { kind := .seq, input := [2, 2, 0, 1], output := [2, 2, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0477 : valid { kind := .seq, input := [2, 2, 0, 2], output := [2, 2, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0478 : valid { kind := .seq, input := [2, 2, 1, 0], output := [2, 2, 1, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0479 : valid { kind := .seq, input := [2, 2, 1, 1], output := [2, 2, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0480 : valid { kind := .seq, input := [2, 2, 1, 2], output := [2, 2, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0481 : valid { kind := .seq, input := [2, 2, 2, 0], output := [2, 2, 2, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0482 : valid { kind := .seq, input := [2, 2, 2, 1], output := [2, 2, 2, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0483 : valid { kind := .seq, input := [2, 2, 2, 2], output := [2, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0484 : valid { kind := .bag, input := [], output := [], fibers := [] } = true := by decide
theorem observed_0485 : valid { kind := .bag, input := [0], output := [0], fibers := [[0]] } = true := by decide
theorem observed_0486 : valid { kind := .bag, input := [1], output := [1], fibers := [[0]] } = true := by decide
theorem observed_0487 : valid { kind := .bag, input := [2], output := [2], fibers := [[0]] } = true := by decide
theorem observed_0488 : valid { kind := .bag, input := [0, 0], output := [0, 0], fibers := [[0], [1]] } = true := by decide
theorem observed_0489 : valid { kind := .bag, input := [0, 1], output := [0, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0490 : valid { kind := .bag, input := [0, 2], output := [0, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0491 : valid { kind := .bag, input := [1, 0], output := [0, 1], fibers := [[1], [0]] } = true := by decide
theorem observed_0492 : valid { kind := .bag, input := [1, 1], output := [1, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0493 : valid { kind := .bag, input := [1, 2], output := [1, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0494 : valid { kind := .bag, input := [2, 0], output := [0, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0495 : valid { kind := .bag, input := [2, 1], output := [1, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0496 : valid { kind := .bag, input := [2, 2], output := [2, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0497 : valid { kind := .bag, input := [0, 0, 0], output := [0, 0, 0], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0498 : valid { kind := .bag, input := [0, 0, 1], output := [0, 0, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0499 : valid { kind := .bag, input := [0, 0, 2], output := [0, 0, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0500 : valid { kind := .bag, input := [0, 1, 0], output := [0, 0, 1], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0501 : valid { kind := .bag, input := [0, 1, 1], output := [0, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0502 : valid { kind := .bag, input := [0, 1, 2], output := [0, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0503 : valid { kind := .bag, input := [0, 2, 0], output := [0, 0, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0504 : valid { kind := .bag, input := [0, 2, 1], output := [0, 1, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0505 : valid { kind := .bag, input := [0, 2, 2], output := [0, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0506 : valid { kind := .bag, input := [1, 0, 0], output := [0, 0, 1], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0507 : valid { kind := .bag, input := [1, 0, 1], output := [0, 1, 1], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0508 : valid { kind := .bag, input := [1, 0, 2], output := [0, 1, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0509 : valid { kind := .bag, input := [1, 1, 0], output := [0, 1, 1], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0510 : valid { kind := .bag, input := [1, 1, 1], output := [1, 1, 1], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0511 : valid { kind := .bag, input := [1, 1, 2], output := [1, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0512 : valid { kind := .bag, input := [1, 2, 0], output := [0, 1, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0513 : valid { kind := .bag, input := [1, 2, 1], output := [1, 1, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0514 : valid { kind := .bag, input := [1, 2, 2], output := [1, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0515 : valid { kind := .bag, input := [2, 0, 0], output := [0, 0, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0516 : valid { kind := .bag, input := [2, 0, 1], output := [0, 1, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0517 : valid { kind := .bag, input := [2, 0, 2], output := [0, 2, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0518 : valid { kind := .bag, input := [2, 1, 0], output := [0, 1, 2], fibers := [[2], [1], [0]] } = true := by decide
theorem observed_0519 : valid { kind := .bag, input := [2, 1, 1], output := [1, 1, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0520 : valid { kind := .bag, input := [2, 1, 2], output := [1, 2, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0521 : valid { kind := .bag, input := [2, 2, 0], output := [0, 2, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0522 : valid { kind := .bag, input := [2, 2, 1], output := [1, 2, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0523 : valid { kind := .bag, input := [2, 2, 2], output := [2, 2, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0524 : valid { kind := .bag, input := [0, 0, 0, 0], output := [0, 0, 0, 0], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0525 : valid { kind := .bag, input := [0, 0, 0, 1], output := [0, 0, 0, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0526 : valid { kind := .bag, input := [0, 0, 0, 2], output := [0, 0, 0, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0527 : valid { kind := .bag, input := [0, 0, 1, 0], output := [0, 0, 0, 1], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0528 : valid { kind := .bag, input := [0, 0, 1, 1], output := [0, 0, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0529 : valid { kind := .bag, input := [0, 0, 1, 2], output := [0, 0, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0530 : valid { kind := .bag, input := [0, 0, 2, 0], output := [0, 0, 0, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0531 : valid { kind := .bag, input := [0, 0, 2, 1], output := [0, 0, 1, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0532 : valid { kind := .bag, input := [0, 0, 2, 2], output := [0, 0, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0533 : valid { kind := .bag, input := [0, 1, 0, 0], output := [0, 0, 0, 1], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0534 : valid { kind := .bag, input := [0, 1, 0, 1], output := [0, 0, 1, 1], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0535 : valid { kind := .bag, input := [0, 1, 0, 2], output := [0, 0, 1, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0536 : valid { kind := .bag, input := [0, 1, 1, 0], output := [0, 0, 1, 1], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0537 : valid { kind := .bag, input := [0, 1, 1, 1], output := [0, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0538 : valid { kind := .bag, input := [0, 1, 1, 2], output := [0, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0539 : valid { kind := .bag, input := [0, 1, 2, 0], output := [0, 0, 1, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0540 : valid { kind := .bag, input := [0, 1, 2, 1], output := [0, 1, 1, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0541 : valid { kind := .bag, input := [0, 1, 2, 2], output := [0, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0542 : valid { kind := .bag, input := [0, 2, 0, 0], output := [0, 0, 0, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0543 : valid { kind := .bag, input := [0, 2, 0, 1], output := [0, 0, 1, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0544 : valid { kind := .bag, input := [0, 2, 0, 2], output := [0, 0, 2, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0545 : valid { kind := .bag, input := [0, 2, 1, 0], output := [0, 0, 1, 2], fibers := [[0], [3], [2], [1]] } = true := by decide
theorem observed_0546 : valid { kind := .bag, input := [0, 2, 1, 1], output := [0, 1, 1, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0547 : valid { kind := .bag, input := [0, 2, 1, 2], output := [0, 1, 2, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0548 : valid { kind := .bag, input := [0, 2, 2, 0], output := [0, 0, 2, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0549 : valid { kind := .bag, input := [0, 2, 2, 1], output := [0, 1, 2, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0550 : valid { kind := .bag, input := [0, 2, 2, 2], output := [0, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0551 : valid { kind := .bag, input := [1, 0, 0, 0], output := [0, 0, 0, 1], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0552 : valid { kind := .bag, input := [1, 0, 0, 1], output := [0, 0, 1, 1], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0553 : valid { kind := .bag, input := [1, 0, 0, 2], output := [0, 0, 1, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0554 : valid { kind := .bag, input := [1, 0, 1, 0], output := [0, 0, 1, 1], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0555 : valid { kind := .bag, input := [1, 0, 1, 1], output := [0, 1, 1, 1], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0556 : valid { kind := .bag, input := [1, 0, 1, 2], output := [0, 1, 1, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0557 : valid { kind := .bag, input := [1, 0, 2, 0], output := [0, 0, 1, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0558 : valid { kind := .bag, input := [1, 0, 2, 1], output := [0, 1, 1, 2], fibers := [[1], [0], [3], [2]] } = true := by decide
theorem observed_0559 : valid { kind := .bag, input := [1, 0, 2, 2], output := [0, 1, 2, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0560 : valid { kind := .bag, input := [1, 1, 0, 0], output := [0, 0, 1, 1], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0561 : valid { kind := .bag, input := [1, 1, 0, 1], output := [0, 1, 1, 1], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0562 : valid { kind := .bag, input := [1, 1, 0, 2], output := [0, 1, 1, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0563 : valid { kind := .bag, input := [1, 1, 1, 0], output := [0, 1, 1, 1], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0564 : valid { kind := .bag, input := [1, 1, 1, 1], output := [1, 1, 1, 1], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0565 : valid { kind := .bag, input := [1, 1, 1, 2], output := [1, 1, 1, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0566 : valid { kind := .bag, input := [1, 1, 2, 0], output := [0, 1, 1, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0567 : valid { kind := .bag, input := [1, 1, 2, 1], output := [1, 1, 1, 2], fibers := [[0], [1], [3], [2]] } = true := by decide
theorem observed_0568 : valid { kind := .bag, input := [1, 1, 2, 2], output := [1, 1, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0569 : valid { kind := .bag, input := [1, 2, 0, 0], output := [0, 0, 1, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0570 : valid { kind := .bag, input := [1, 2, 0, 1], output := [0, 1, 1, 2], fibers := [[2], [0], [3], [1]] } = true := by decide
theorem observed_0571 : valid { kind := .bag, input := [1, 2, 0, 2], output := [0, 1, 2, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0572 : valid { kind := .bag, input := [1, 2, 1, 0], output := [0, 1, 1, 2], fibers := [[3], [0], [2], [1]] } = true := by decide
theorem observed_0573 : valid { kind := .bag, input := [1, 2, 1, 1], output := [1, 1, 1, 2], fibers := [[0], [2], [3], [1]] } = true := by decide
theorem observed_0574 : valid { kind := .bag, input := [1, 2, 1, 2], output := [1, 1, 2, 2], fibers := [[0], [2], [1], [3]] } = true := by decide
theorem observed_0575 : valid { kind := .bag, input := [1, 2, 2, 0], output := [0, 1, 2, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0576 : valid { kind := .bag, input := [1, 2, 2, 1], output := [1, 1, 2, 2], fibers := [[0], [3], [1], [2]] } = true := by decide
theorem observed_0577 : valid { kind := .bag, input := [1, 2, 2, 2], output := [1, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0578 : valid { kind := .bag, input := [2, 0, 0, 0], output := [0, 0, 0, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0579 : valid { kind := .bag, input := [2, 0, 0, 1], output := [0, 0, 1, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0580 : valid { kind := .bag, input := [2, 0, 0, 2], output := [0, 0, 2, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0581 : valid { kind := .bag, input := [2, 0, 1, 0], output := [0, 0, 1, 2], fibers := [[1], [3], [2], [0]] } = true := by decide
theorem observed_0582 : valid { kind := .bag, input := [2, 0, 1, 1], output := [0, 1, 1, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0583 : valid { kind := .bag, input := [2, 0, 1, 2], output := [0, 1, 2, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0584 : valid { kind := .bag, input := [2, 0, 2, 0], output := [0, 0, 2, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0585 : valid { kind := .bag, input := [2, 0, 2, 1], output := [0, 1, 2, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0586 : valid { kind := .bag, input := [2, 0, 2, 2], output := [0, 2, 2, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0587 : valid { kind := .bag, input := [2, 1, 0, 0], output := [0, 0, 1, 2], fibers := [[2], [3], [1], [0]] } = true := by decide
theorem observed_0588 : valid { kind := .bag, input := [2, 1, 0, 1], output := [0, 1, 1, 2], fibers := [[2], [1], [3], [0]] } = true := by decide
theorem observed_0589 : valid { kind := .bag, input := [2, 1, 0, 2], output := [0, 1, 2, 2], fibers := [[2], [1], [0], [3]] } = true := by decide
theorem observed_0590 : valid { kind := .bag, input := [2, 1, 1, 0], output := [0, 1, 1, 2], fibers := [[3], [1], [2], [0]] } = true := by decide
theorem observed_0591 : valid { kind := .bag, input := [2, 1, 1, 1], output := [1, 1, 1, 2], fibers := [[1], [2], [3], [0]] } = true := by decide
theorem observed_0592 : valid { kind := .bag, input := [2, 1, 1, 2], output := [1, 1, 2, 2], fibers := [[1], [2], [0], [3]] } = true := by decide
theorem observed_0593 : valid { kind := .bag, input := [2, 1, 2, 0], output := [0, 1, 2, 2], fibers := [[3], [1], [0], [2]] } = true := by decide
theorem observed_0594 : valid { kind := .bag, input := [2, 1, 2, 1], output := [1, 1, 2, 2], fibers := [[1], [3], [0], [2]] } = true := by decide
theorem observed_0595 : valid { kind := .bag, input := [2, 1, 2, 2], output := [1, 2, 2, 2], fibers := [[1], [0], [2], [3]] } = true := by decide
theorem observed_0596 : valid { kind := .bag, input := [2, 2, 0, 0], output := [0, 0, 2, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0597 : valid { kind := .bag, input := [2, 2, 0, 1], output := [0, 1, 2, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0598 : valid { kind := .bag, input := [2, 2, 0, 2], output := [0, 2, 2, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0599 : valid { kind := .bag, input := [2, 2, 1, 0], output := [0, 1, 2, 2], fibers := [[3], [2], [0], [1]] } = true := by decide
theorem observed_0600 : valid { kind := .bag, input := [2, 2, 1, 1], output := [1, 1, 2, 2], fibers := [[2], [3], [0], [1]] } = true := by decide
theorem observed_0601 : valid { kind := .bag, input := [2, 2, 1, 2], output := [1, 2, 2, 2], fibers := [[2], [0], [1], [3]] } = true := by decide
theorem observed_0602 : valid { kind := .bag, input := [2, 2, 2, 0], output := [0, 2, 2, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0603 : valid { kind := .bag, input := [2, 2, 2, 1], output := [1, 2, 2, 2], fibers := [[3], [0], [1], [2]] } = true := by decide
theorem observed_0604 : valid { kind := .bag, input := [2, 2, 2, 2], output := [2, 2, 2, 2], fibers := [[0], [1], [2], [3]] } = true := by decide
theorem observed_0605 : valid { kind := .set, input := [], output := [], fibers := [] } = true := by decide
theorem observed_0606 : valid { kind := .set, input := [0], output := [0], fibers := [[0]] } = true := by decide
theorem observed_0607 : valid { kind := .set, input := [1], output := [1], fibers := [[0]] } = true := by decide
theorem observed_0608 : valid { kind := .set, input := [2], output := [2], fibers := [[0]] } = true := by decide
theorem observed_0609 : valid { kind := .set, input := [0, 0], output := [0], fibers := [[0, 1]] } = true := by decide
theorem observed_0610 : valid { kind := .set, input := [0, 1], output := [0, 1], fibers := [[0], [1]] } = true := by decide
theorem observed_0611 : valid { kind := .set, input := [0, 2], output := [0, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0612 : valid { kind := .set, input := [1, 0], output := [0, 1], fibers := [[1], [0]] } = true := by decide
theorem observed_0613 : valid { kind := .set, input := [1, 1], output := [1], fibers := [[0, 1]] } = true := by decide
theorem observed_0614 : valid { kind := .set, input := [1, 2], output := [1, 2], fibers := [[0], [1]] } = true := by decide
theorem observed_0615 : valid { kind := .set, input := [2, 0], output := [0, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0616 : valid { kind := .set, input := [2, 1], output := [1, 2], fibers := [[1], [0]] } = true := by decide
theorem observed_0617 : valid { kind := .set, input := [2, 2], output := [2], fibers := [[0, 1]] } = true := by decide
theorem observed_0618 : valid { kind := .set, input := [0, 0, 0], output := [0], fibers := [[0, 1, 2]] } = true := by decide
theorem observed_0619 : valid { kind := .set, input := [0, 0, 1], output := [0, 1], fibers := [[0, 1], [2]] } = true := by decide
theorem observed_0620 : valid { kind := .set, input := [0, 0, 2], output := [0, 2], fibers := [[0, 1], [2]] } = true := by decide
theorem observed_0621 : valid { kind := .set, input := [0, 1, 0], output := [0, 1], fibers := [[0, 2], [1]] } = true := by decide
theorem observed_0622 : valid { kind := .set, input := [0, 1, 1], output := [0, 1], fibers := [[0], [1, 2]] } = true := by decide
theorem observed_0623 : valid { kind := .set, input := [0, 1, 2], output := [0, 1, 2], fibers := [[0], [1], [2]] } = true := by decide
theorem observed_0624 : valid { kind := .set, input := [0, 2, 0], output := [0, 2], fibers := [[0, 2], [1]] } = true := by decide
theorem observed_0625 : valid { kind := .set, input := [0, 2, 1], output := [0, 1, 2], fibers := [[0], [2], [1]] } = true := by decide
theorem observed_0626 : valid { kind := .set, input := [0, 2, 2], output := [0, 2], fibers := [[0], [1, 2]] } = true := by decide
theorem observed_0627 : valid { kind := .set, input := [1, 0, 0], output := [0, 1], fibers := [[1, 2], [0]] } = true := by decide
theorem observed_0628 : valid { kind := .set, input := [1, 0, 1], output := [0, 1], fibers := [[1], [0, 2]] } = true := by decide
theorem observed_0629 : valid { kind := .set, input := [1, 0, 2], output := [0, 1, 2], fibers := [[1], [0], [2]] } = true := by decide
theorem observed_0630 : valid { kind := .set, input := [1, 1, 0], output := [0, 1], fibers := [[2], [0, 1]] } = true := by decide
theorem observed_0631 : valid { kind := .set, input := [1, 1, 1], output := [1], fibers := [[0, 1, 2]] } = true := by decide
theorem observed_0632 : valid { kind := .set, input := [1, 1, 2], output := [1, 2], fibers := [[0, 1], [2]] } = true := by decide
theorem observed_0633 : valid { kind := .set, input := [1, 2, 0], output := [0, 1, 2], fibers := [[2], [0], [1]] } = true := by decide
theorem observed_0634 : valid { kind := .set, input := [1, 2, 1], output := [1, 2], fibers := [[0, 2], [1]] } = true := by decide
theorem observed_0635 : valid { kind := .set, input := [1, 2, 2], output := [1, 2], fibers := [[0], [1, 2]] } = true := by decide
theorem observed_0636 : valid { kind := .set, input := [2, 0, 0], output := [0, 2], fibers := [[1, 2], [0]] } = true := by decide
theorem observed_0637 : valid { kind := .set, input := [2, 0, 1], output := [0, 1, 2], fibers := [[1], [2], [0]] } = true := by decide
theorem observed_0638 : valid { kind := .set, input := [2, 0, 2], output := [0, 2], fibers := [[1], [0, 2]] } = true := by decide
theorem observed_0639 : valid { kind := .set, input := [2, 1, 0], output := [0, 1, 2], fibers := [[2], [1], [0]] } = true := by decide
theorem observed_0640 : valid { kind := .set, input := [2, 1, 1], output := [1, 2], fibers := [[1, 2], [0]] } = true := by decide
theorem observed_0641 : valid { kind := .set, input := [2, 1, 2], output := [1, 2], fibers := [[1], [0, 2]] } = true := by decide
theorem observed_0642 : valid { kind := .set, input := [2, 2, 0], output := [0, 2], fibers := [[2], [0, 1]] } = true := by decide
theorem observed_0643 : valid { kind := .set, input := [2, 2, 1], output := [1, 2], fibers := [[2], [0, 1]] } = true := by decide
theorem observed_0644 : valid { kind := .set, input := [2, 2, 2], output := [2], fibers := [[0, 1, 2]] } = true := by decide
theorem observed_0645 : valid { kind := .set, input := [0, 0, 0, 0], output := [0], fibers := [[0, 1, 2, 3]] } = true := by decide
theorem observed_0646 : valid { kind := .set, input := [0, 0, 0, 1], output := [0, 1], fibers := [[0, 1, 2], [3]] } = true := by decide
theorem observed_0647 : valid { kind := .set, input := [0, 0, 0, 2], output := [0, 2], fibers := [[0, 1, 2], [3]] } = true := by decide
theorem observed_0648 : valid { kind := .set, input := [0, 0, 1, 0], output := [0, 1], fibers := [[0, 1, 3], [2]] } = true := by decide
theorem observed_0649 : valid { kind := .set, input := [0, 0, 1, 1], output := [0, 1], fibers := [[0, 1], [2, 3]] } = true := by decide
theorem observed_0650 : valid { kind := .set, input := [0, 0, 1, 2], output := [0, 1, 2], fibers := [[0, 1], [2], [3]] } = true := by decide
theorem observed_0651 : valid { kind := .set, input := [0, 0, 2, 0], output := [0, 2], fibers := [[0, 1, 3], [2]] } = true := by decide
theorem observed_0652 : valid { kind := .set, input := [0, 0, 2, 1], output := [0, 1, 2], fibers := [[0, 1], [3], [2]] } = true := by decide
theorem observed_0653 : valid { kind := .set, input := [0, 0, 2, 2], output := [0, 2], fibers := [[0, 1], [2, 3]] } = true := by decide
theorem observed_0654 : valid { kind := .set, input := [0, 1, 0, 0], output := [0, 1], fibers := [[0, 2, 3], [1]] } = true := by decide
theorem observed_0655 : valid { kind := .set, input := [0, 1, 0, 1], output := [0, 1], fibers := [[0, 2], [1, 3]] } = true := by decide
theorem observed_0656 : valid { kind := .set, input := [0, 1, 0, 2], output := [0, 1, 2], fibers := [[0, 2], [1], [3]] } = true := by decide
theorem observed_0657 : valid { kind := .set, input := [0, 1, 1, 0], output := [0, 1], fibers := [[0, 3], [1, 2]] } = true := by decide
theorem observed_0658 : valid { kind := .set, input := [0, 1, 1, 1], output := [0, 1], fibers := [[0], [1, 2, 3]] } = true := by decide
theorem observed_0659 : valid { kind := .set, input := [0, 1, 1, 2], output := [0, 1, 2], fibers := [[0], [1, 2], [3]] } = true := by decide
theorem observed_0660 : valid { kind := .set, input := [0, 1, 2, 0], output := [0, 1, 2], fibers := [[0, 3], [1], [2]] } = true := by decide
theorem observed_0661 : valid { kind := .set, input := [0, 1, 2, 1], output := [0, 1, 2], fibers := [[0], [1, 3], [2]] } = true := by decide
theorem observed_0662 : valid { kind := .set, input := [0, 1, 2, 2], output := [0, 1, 2], fibers := [[0], [1], [2, 3]] } = true := by decide
theorem observed_0663 : valid { kind := .set, input := [0, 2, 0, 0], output := [0, 2], fibers := [[0, 2, 3], [1]] } = true := by decide
theorem observed_0664 : valid { kind := .set, input := [0, 2, 0, 1], output := [0, 1, 2], fibers := [[0, 2], [3], [1]] } = true := by decide
theorem observed_0665 : valid { kind := .set, input := [0, 2, 0, 2], output := [0, 2], fibers := [[0, 2], [1, 3]] } = true := by decide
theorem observed_0666 : valid { kind := .set, input := [0, 2, 1, 0], output := [0, 1, 2], fibers := [[0, 3], [2], [1]] } = true := by decide
theorem observed_0667 : valid { kind := .set, input := [0, 2, 1, 1], output := [0, 1, 2], fibers := [[0], [2, 3], [1]] } = true := by decide
theorem observed_0668 : valid { kind := .set, input := [0, 2, 1, 2], output := [0, 1, 2], fibers := [[0], [2], [1, 3]] } = true := by decide
theorem observed_0669 : valid { kind := .set, input := [0, 2, 2, 0], output := [0, 2], fibers := [[0, 3], [1, 2]] } = true := by decide
theorem observed_0670 : valid { kind := .set, input := [0, 2, 2, 1], output := [0, 1, 2], fibers := [[0], [3], [1, 2]] } = true := by decide
theorem observed_0671 : valid { kind := .set, input := [0, 2, 2, 2], output := [0, 2], fibers := [[0], [1, 2, 3]] } = true := by decide
theorem observed_0672 : valid { kind := .set, input := [1, 0, 0, 0], output := [0, 1], fibers := [[1, 2, 3], [0]] } = true := by decide
theorem observed_0673 : valid { kind := .set, input := [1, 0, 0, 1], output := [0, 1], fibers := [[1, 2], [0, 3]] } = true := by decide
theorem observed_0674 : valid { kind := .set, input := [1, 0, 0, 2], output := [0, 1, 2], fibers := [[1, 2], [0], [3]] } = true := by decide
theorem observed_0675 : valid { kind := .set, input := [1, 0, 1, 0], output := [0, 1], fibers := [[1, 3], [0, 2]] } = true := by decide
theorem observed_0676 : valid { kind := .set, input := [1, 0, 1, 1], output := [0, 1], fibers := [[1], [0, 2, 3]] } = true := by decide
theorem observed_0677 : valid { kind := .set, input := [1, 0, 1, 2], output := [0, 1, 2], fibers := [[1], [0, 2], [3]] } = true := by decide
theorem observed_0678 : valid { kind := .set, input := [1, 0, 2, 0], output := [0, 1, 2], fibers := [[1, 3], [0], [2]] } = true := by decide
theorem observed_0679 : valid { kind := .set, input := [1, 0, 2, 1], output := [0, 1, 2], fibers := [[1], [0, 3], [2]] } = true := by decide
theorem observed_0680 : valid { kind := .set, input := [1, 0, 2, 2], output := [0, 1, 2], fibers := [[1], [0], [2, 3]] } = true := by decide
theorem observed_0681 : valid { kind := .set, input := [1, 1, 0, 0], output := [0, 1], fibers := [[2, 3], [0, 1]] } = true := by decide
theorem observed_0682 : valid { kind := .set, input := [1, 1, 0, 1], output := [0, 1], fibers := [[2], [0, 1, 3]] } = true := by decide
theorem observed_0683 : valid { kind := .set, input := [1, 1, 0, 2], output := [0, 1, 2], fibers := [[2], [0, 1], [3]] } = true := by decide
theorem observed_0684 : valid { kind := .set, input := [1, 1, 1, 0], output := [0, 1], fibers := [[3], [0, 1, 2]] } = true := by decide
theorem observed_0685 : valid { kind := .set, input := [1, 1, 1, 1], output := [1], fibers := [[0, 1, 2, 3]] } = true := by decide
theorem observed_0686 : valid { kind := .set, input := [1, 1, 1, 2], output := [1, 2], fibers := [[0, 1, 2], [3]] } = true := by decide
theorem observed_0687 : valid { kind := .set, input := [1, 1, 2, 0], output := [0, 1, 2], fibers := [[3], [0, 1], [2]] } = true := by decide
theorem observed_0688 : valid { kind := .set, input := [1, 1, 2, 1], output := [1, 2], fibers := [[0, 1, 3], [2]] } = true := by decide
theorem observed_0689 : valid { kind := .set, input := [1, 1, 2, 2], output := [1, 2], fibers := [[0, 1], [2, 3]] } = true := by decide
theorem observed_0690 : valid { kind := .set, input := [1, 2, 0, 0], output := [0, 1, 2], fibers := [[2, 3], [0], [1]] } = true := by decide
theorem observed_0691 : valid { kind := .set, input := [1, 2, 0, 1], output := [0, 1, 2], fibers := [[2], [0, 3], [1]] } = true := by decide
theorem observed_0692 : valid { kind := .set, input := [1, 2, 0, 2], output := [0, 1, 2], fibers := [[2], [0], [1, 3]] } = true := by decide
theorem observed_0693 : valid { kind := .set, input := [1, 2, 1, 0], output := [0, 1, 2], fibers := [[3], [0, 2], [1]] } = true := by decide
theorem observed_0694 : valid { kind := .set, input := [1, 2, 1, 1], output := [1, 2], fibers := [[0, 2, 3], [1]] } = true := by decide
theorem observed_0695 : valid { kind := .set, input := [1, 2, 1, 2], output := [1, 2], fibers := [[0, 2], [1, 3]] } = true := by decide
theorem observed_0696 : valid { kind := .set, input := [1, 2, 2, 0], output := [0, 1, 2], fibers := [[3], [0], [1, 2]] } = true := by decide
theorem observed_0697 : valid { kind := .set, input := [1, 2, 2, 1], output := [1, 2], fibers := [[0, 3], [1, 2]] } = true := by decide
theorem observed_0698 : valid { kind := .set, input := [1, 2, 2, 2], output := [1, 2], fibers := [[0], [1, 2, 3]] } = true := by decide
theorem observed_0699 : valid { kind := .set, input := [2, 0, 0, 0], output := [0, 2], fibers := [[1, 2, 3], [0]] } = true := by decide
theorem observed_0700 : valid { kind := .set, input := [2, 0, 0, 1], output := [0, 1, 2], fibers := [[1, 2], [3], [0]] } = true := by decide
theorem observed_0701 : valid { kind := .set, input := [2, 0, 0, 2], output := [0, 2], fibers := [[1, 2], [0, 3]] } = true := by decide
theorem observed_0702 : valid { kind := .set, input := [2, 0, 1, 0], output := [0, 1, 2], fibers := [[1, 3], [2], [0]] } = true := by decide
theorem observed_0703 : valid { kind := .set, input := [2, 0, 1, 1], output := [0, 1, 2], fibers := [[1], [2, 3], [0]] } = true := by decide
theorem observed_0704 : valid { kind := .set, input := [2, 0, 1, 2], output := [0, 1, 2], fibers := [[1], [2], [0, 3]] } = true := by decide
theorem observed_0705 : valid { kind := .set, input := [2, 0, 2, 0], output := [0, 2], fibers := [[1, 3], [0, 2]] } = true := by decide
theorem observed_0706 : valid { kind := .set, input := [2, 0, 2, 1], output := [0, 1, 2], fibers := [[1], [3], [0, 2]] } = true := by decide
theorem observed_0707 : valid { kind := .set, input := [2, 0, 2, 2], output := [0, 2], fibers := [[1], [0, 2, 3]] } = true := by decide
theorem observed_0708 : valid { kind := .set, input := [2, 1, 0, 0], output := [0, 1, 2], fibers := [[2, 3], [1], [0]] } = true := by decide
theorem observed_0709 : valid { kind := .set, input := [2, 1, 0, 1], output := [0, 1, 2], fibers := [[2], [1, 3], [0]] } = true := by decide
theorem observed_0710 : valid { kind := .set, input := [2, 1, 0, 2], output := [0, 1, 2], fibers := [[2], [1], [0, 3]] } = true := by decide
theorem observed_0711 : valid { kind := .set, input := [2, 1, 1, 0], output := [0, 1, 2], fibers := [[3], [1, 2], [0]] } = true := by decide
theorem observed_0712 : valid { kind := .set, input := [2, 1, 1, 1], output := [1, 2], fibers := [[1, 2, 3], [0]] } = true := by decide
theorem observed_0713 : valid { kind := .set, input := [2, 1, 1, 2], output := [1, 2], fibers := [[1, 2], [0, 3]] } = true := by decide
theorem observed_0714 : valid { kind := .set, input := [2, 1, 2, 0], output := [0, 1, 2], fibers := [[3], [1], [0, 2]] } = true := by decide
theorem observed_0715 : valid { kind := .set, input := [2, 1, 2, 1], output := [1, 2], fibers := [[1, 3], [0, 2]] } = true := by decide
theorem observed_0716 : valid { kind := .set, input := [2, 1, 2, 2], output := [1, 2], fibers := [[1], [0, 2, 3]] } = true := by decide
theorem observed_0717 : valid { kind := .set, input := [2, 2, 0, 0], output := [0, 2], fibers := [[2, 3], [0, 1]] } = true := by decide
theorem observed_0718 : valid { kind := .set, input := [2, 2, 0, 1], output := [0, 1, 2], fibers := [[2], [3], [0, 1]] } = true := by decide
theorem observed_0719 : valid { kind := .set, input := [2, 2, 0, 2], output := [0, 2], fibers := [[2], [0, 1, 3]] } = true := by decide
theorem observed_0720 : valid { kind := .set, input := [2, 2, 1, 0], output := [0, 1, 2], fibers := [[3], [2], [0, 1]] } = true := by decide
theorem observed_0721 : valid { kind := .set, input := [2, 2, 1, 1], output := [1, 2], fibers := [[2, 3], [0, 1]] } = true := by decide
theorem observed_0722 : valid { kind := .set, input := [2, 2, 1, 2], output := [1, 2], fibers := [[2], [0, 1, 3]] } = true := by decide
theorem observed_0723 : valid { kind := .set, input := [2, 2, 2, 0], output := [0, 2], fibers := [[3], [0, 1, 2]] } = true := by decide
theorem observed_0724 : valid { kind := .set, input := [2, 2, 2, 1], output := [1, 2], fibers := [[3], [0, 1, 2]] } = true := by decide
theorem observed_0725 : valid { kind := .set, input := [2, 2, 2, 2], output := [2], fibers := [[0, 1, 2, 3]] } = true := by decide
theorem rejected_00 : valid { kind := .seq, input := [0, 1], output := [1, 0], fibers := [[1], [0]] } = false := by decide
theorem rejected_01 : valid { kind := .seq, input := [0, 0], output := [0], fibers := [[0, 1]] } = false := by decide
theorem rejected_02 : valid { kind := .bag, input := [0, 0, 1], output := [0, 1], fibers := [[0, 1], [2]] } = false := by decide
theorem rejected_03 : valid { kind := .bag, input := [0, 1], output := [0, 0, 1], fibers := [[0], [0], [1]] } = false := by decide
theorem rejected_04 : valid { kind := .set, input := [0, 1], output := [0], fibers := [[0, 1]] } = false := by decide
theorem rejected_05 : valid { kind := .set, input := [0], output := [1], fibers := [[0]] } = false := by decide
theorem rejected_06 : valid { kind := .set, input := [0, 0], output := [0, 0], fibers := [[0], [1]] } = false := by decide
theorem rejected_07 : valid { kind := .set, input := [0, 0], output := [0], fibers := [[0, 0]] } = false := by decide
theorem rejected_08 : valid { kind := .set, input := [0, 0], output := [0], fibers := [[0]] } = false := by decide
theorem rejected_09 : valid { kind := .set, input := [0], output := [0], fibers := [[1]] } = false := by decide
theorem rejected_10 : valid { kind := .bag, input := [0, 1], output := [0, 1], fibers := [[1], [0]] } = false := by decide
theorem rejected_11 : valid { kind := .set, input := [0], output := [0], fibers := [[]] } = false := by decide
theorem rejected_12 : valid { kind := .set, input := [0], output := [0], fibers := [[0], []] } = false := by decide
theorem rejected_13 : valid { kind := .seq, input := [0, 0], output := [0, 0], fibers := [[1], [0]] } = false := by decide
#print axioms ACGN.ContainerReplay.valid_parts
#print axioms ACGN.ContainerReplay.sameSupport_iff
#print axioms ACGN.ContainerReplay.sequence_preserves_order
#print axioms ACGN.ContainerReplay.bag_preserves_multiplicity
#print axioms ACGN.ContainerReplay.set_preserves_support
#print axioms ACGN.ContainerReplay.set_has_no_duplicates
#print axioms ACGN.ContainerReplay.fibers_partition_input
#print axioms ACGN.ContainerReplay.set_preserves_any_denotation
#print axioms ACGN.ContainerReplay.set_preserves_all_denotation
#print axioms ACGN.ContainerReplay.fibers_have_one_entry_per_output
#print axioms ACGN.ContainerReplay.fiber_members_preserve_identity
#print axioms ACGN.ContainerReplay.nonset_fibers_are_singletons
#print axioms observed_0000
#print axioms observed_0001
#print axioms observed_0002
#print axioms observed_0003
#print axioms observed_0004
#print axioms observed_0005
#print axioms observed_0006
#print axioms observed_0007
#print axioms observed_0008
#print axioms observed_0009
#print axioms observed_0010
#print axioms observed_0011
#print axioms observed_0012
#print axioms observed_0013
#print axioms observed_0014
#print axioms observed_0015
#print axioms observed_0016
#print axioms observed_0017
#print axioms observed_0018
#print axioms observed_0019
#print axioms observed_0020
#print axioms observed_0021
#print axioms observed_0022
#print axioms observed_0023
#print axioms observed_0024
#print axioms observed_0025
#print axioms observed_0026
#print axioms observed_0027
#print axioms observed_0028
#print axioms observed_0029
#print axioms observed_0030
#print axioms observed_0031
#print axioms observed_0032
#print axioms observed_0033
#print axioms observed_0034
#print axioms observed_0035
#print axioms observed_0036
#print axioms observed_0037
#print axioms observed_0038
#print axioms observed_0039
#print axioms observed_0040
#print axioms observed_0041
#print axioms observed_0042
#print axioms observed_0043
#print axioms observed_0044
#print axioms observed_0045
#print axioms observed_0046
#print axioms observed_0047
#print axioms observed_0048
#print axioms observed_0049
#print axioms observed_0050
#print axioms observed_0051
#print axioms observed_0052
#print axioms observed_0053
#print axioms observed_0054
#print axioms observed_0055
#print axioms observed_0056
#print axioms observed_0057
#print axioms observed_0058
#print axioms observed_0059
#print axioms observed_0060
#print axioms observed_0061
#print axioms observed_0062
#print axioms observed_0063
#print axioms observed_0064
#print axioms observed_0065
#print axioms observed_0066
#print axioms observed_0067
#print axioms observed_0068
#print axioms observed_0069
#print axioms observed_0070
#print axioms observed_0071
#print axioms observed_0072
#print axioms observed_0073
#print axioms observed_0074
#print axioms observed_0075
#print axioms observed_0076
#print axioms observed_0077
#print axioms observed_0078
#print axioms observed_0079
#print axioms observed_0080
#print axioms observed_0081
#print axioms observed_0082
#print axioms observed_0083
#print axioms observed_0084
#print axioms observed_0085
#print axioms observed_0086
#print axioms observed_0087
#print axioms observed_0088
#print axioms observed_0089
#print axioms observed_0090
#print axioms observed_0091
#print axioms observed_0092
#print axioms observed_0093
#print axioms observed_0094
#print axioms observed_0095
#print axioms observed_0096
#print axioms observed_0097
#print axioms observed_0098
#print axioms observed_0099
#print axioms observed_0100
#print axioms observed_0101
#print axioms observed_0102
#print axioms observed_0103
#print axioms observed_0104
#print axioms observed_0105
#print axioms observed_0106
#print axioms observed_0107
#print axioms observed_0108
#print axioms observed_0109
#print axioms observed_0110
#print axioms observed_0111
#print axioms observed_0112
#print axioms observed_0113
#print axioms observed_0114
#print axioms observed_0115
#print axioms observed_0116
#print axioms observed_0117
#print axioms observed_0118
#print axioms observed_0119
#print axioms observed_0120
#print axioms observed_0121
#print axioms observed_0122
#print axioms observed_0123
#print axioms observed_0124
#print axioms observed_0125
#print axioms observed_0126
#print axioms observed_0127
#print axioms observed_0128
#print axioms observed_0129
#print axioms observed_0130
#print axioms observed_0131
#print axioms observed_0132
#print axioms observed_0133
#print axioms observed_0134
#print axioms observed_0135
#print axioms observed_0136
#print axioms observed_0137
#print axioms observed_0138
#print axioms observed_0139
#print axioms observed_0140
#print axioms observed_0141
#print axioms observed_0142
#print axioms observed_0143
#print axioms observed_0144
#print axioms observed_0145
#print axioms observed_0146
#print axioms observed_0147
#print axioms observed_0148
#print axioms observed_0149
#print axioms observed_0150
#print axioms observed_0151
#print axioms observed_0152
#print axioms observed_0153
#print axioms observed_0154
#print axioms observed_0155
#print axioms observed_0156
#print axioms observed_0157
#print axioms observed_0158
#print axioms observed_0159
#print axioms observed_0160
#print axioms observed_0161
#print axioms observed_0162
#print axioms observed_0163
#print axioms observed_0164
#print axioms observed_0165
#print axioms observed_0166
#print axioms observed_0167
#print axioms observed_0168
#print axioms observed_0169
#print axioms observed_0170
#print axioms observed_0171
#print axioms observed_0172
#print axioms observed_0173
#print axioms observed_0174
#print axioms observed_0175
#print axioms observed_0176
#print axioms observed_0177
#print axioms observed_0178
#print axioms observed_0179
#print axioms observed_0180
#print axioms observed_0181
#print axioms observed_0182
#print axioms observed_0183
#print axioms observed_0184
#print axioms observed_0185
#print axioms observed_0186
#print axioms observed_0187
#print axioms observed_0188
#print axioms observed_0189
#print axioms observed_0190
#print axioms observed_0191
#print axioms observed_0192
#print axioms observed_0193
#print axioms observed_0194
#print axioms observed_0195
#print axioms observed_0196
#print axioms observed_0197
#print axioms observed_0198
#print axioms observed_0199
#print axioms observed_0200
#print axioms observed_0201
#print axioms observed_0202
#print axioms observed_0203
#print axioms observed_0204
#print axioms observed_0205
#print axioms observed_0206
#print axioms observed_0207
#print axioms observed_0208
#print axioms observed_0209
#print axioms observed_0210
#print axioms observed_0211
#print axioms observed_0212
#print axioms observed_0213
#print axioms observed_0214
#print axioms observed_0215
#print axioms observed_0216
#print axioms observed_0217
#print axioms observed_0218
#print axioms observed_0219
#print axioms observed_0220
#print axioms observed_0221
#print axioms observed_0222
#print axioms observed_0223
#print axioms observed_0224
#print axioms observed_0225
#print axioms observed_0226
#print axioms observed_0227
#print axioms observed_0228
#print axioms observed_0229
#print axioms observed_0230
#print axioms observed_0231
#print axioms observed_0232
#print axioms observed_0233
#print axioms observed_0234
#print axioms observed_0235
#print axioms observed_0236
#print axioms observed_0237
#print axioms observed_0238
#print axioms observed_0239
#print axioms observed_0240
#print axioms observed_0241
#print axioms observed_0242
#print axioms observed_0243
#print axioms observed_0244
#print axioms observed_0245
#print axioms observed_0246
#print axioms observed_0247
#print axioms observed_0248
#print axioms observed_0249
#print axioms observed_0250
#print axioms observed_0251
#print axioms observed_0252
#print axioms observed_0253
#print axioms observed_0254
#print axioms observed_0255
#print axioms observed_0256
#print axioms observed_0257
#print axioms observed_0258
#print axioms observed_0259
#print axioms observed_0260
#print axioms observed_0261
#print axioms observed_0262
#print axioms observed_0263
#print axioms observed_0264
#print axioms observed_0265
#print axioms observed_0266
#print axioms observed_0267
#print axioms observed_0268
#print axioms observed_0269
#print axioms observed_0270
#print axioms observed_0271
#print axioms observed_0272
#print axioms observed_0273
#print axioms observed_0274
#print axioms observed_0275
#print axioms observed_0276
#print axioms observed_0277
#print axioms observed_0278
#print axioms observed_0279
#print axioms observed_0280
#print axioms observed_0281
#print axioms observed_0282
#print axioms observed_0283
#print axioms observed_0284
#print axioms observed_0285
#print axioms observed_0286
#print axioms observed_0287
#print axioms observed_0288
#print axioms observed_0289
#print axioms observed_0290
#print axioms observed_0291
#print axioms observed_0292
#print axioms observed_0293
#print axioms observed_0294
#print axioms observed_0295
#print axioms observed_0296
#print axioms observed_0297
#print axioms observed_0298
#print axioms observed_0299
#print axioms observed_0300
#print axioms observed_0301
#print axioms observed_0302
#print axioms observed_0303
#print axioms observed_0304
#print axioms observed_0305
#print axioms observed_0306
#print axioms observed_0307
#print axioms observed_0308
#print axioms observed_0309
#print axioms observed_0310
#print axioms observed_0311
#print axioms observed_0312
#print axioms observed_0313
#print axioms observed_0314
#print axioms observed_0315
#print axioms observed_0316
#print axioms observed_0317
#print axioms observed_0318
#print axioms observed_0319
#print axioms observed_0320
#print axioms observed_0321
#print axioms observed_0322
#print axioms observed_0323
#print axioms observed_0324
#print axioms observed_0325
#print axioms observed_0326
#print axioms observed_0327
#print axioms observed_0328
#print axioms observed_0329
#print axioms observed_0330
#print axioms observed_0331
#print axioms observed_0332
#print axioms observed_0333
#print axioms observed_0334
#print axioms observed_0335
#print axioms observed_0336
#print axioms observed_0337
#print axioms observed_0338
#print axioms observed_0339
#print axioms observed_0340
#print axioms observed_0341
#print axioms observed_0342
#print axioms observed_0343
#print axioms observed_0344
#print axioms observed_0345
#print axioms observed_0346
#print axioms observed_0347
#print axioms observed_0348
#print axioms observed_0349
#print axioms observed_0350
#print axioms observed_0351
#print axioms observed_0352
#print axioms observed_0353
#print axioms observed_0354
#print axioms observed_0355
#print axioms observed_0356
#print axioms observed_0357
#print axioms observed_0358
#print axioms observed_0359
#print axioms observed_0360
#print axioms observed_0361
#print axioms observed_0362
#print axioms observed_0363
#print axioms observed_0364
#print axioms observed_0365
#print axioms observed_0366
#print axioms observed_0367
#print axioms observed_0368
#print axioms observed_0369
#print axioms observed_0370
#print axioms observed_0371
#print axioms observed_0372
#print axioms observed_0373
#print axioms observed_0374
#print axioms observed_0375
#print axioms observed_0376
#print axioms observed_0377
#print axioms observed_0378
#print axioms observed_0379
#print axioms observed_0380
#print axioms observed_0381
#print axioms observed_0382
#print axioms observed_0383
#print axioms observed_0384
#print axioms observed_0385
#print axioms observed_0386
#print axioms observed_0387
#print axioms observed_0388
#print axioms observed_0389
#print axioms observed_0390
#print axioms observed_0391
#print axioms observed_0392
#print axioms observed_0393
#print axioms observed_0394
#print axioms observed_0395
#print axioms observed_0396
#print axioms observed_0397
#print axioms observed_0398
#print axioms observed_0399
#print axioms observed_0400
#print axioms observed_0401
#print axioms observed_0402
#print axioms observed_0403
#print axioms observed_0404
#print axioms observed_0405
#print axioms observed_0406
#print axioms observed_0407
#print axioms observed_0408
#print axioms observed_0409
#print axioms observed_0410
#print axioms observed_0411
#print axioms observed_0412
#print axioms observed_0413
#print axioms observed_0414
#print axioms observed_0415
#print axioms observed_0416
#print axioms observed_0417
#print axioms observed_0418
#print axioms observed_0419
#print axioms observed_0420
#print axioms observed_0421
#print axioms observed_0422
#print axioms observed_0423
#print axioms observed_0424
#print axioms observed_0425
#print axioms observed_0426
#print axioms observed_0427
#print axioms observed_0428
#print axioms observed_0429
#print axioms observed_0430
#print axioms observed_0431
#print axioms observed_0432
#print axioms observed_0433
#print axioms observed_0434
#print axioms observed_0435
#print axioms observed_0436
#print axioms observed_0437
#print axioms observed_0438
#print axioms observed_0439
#print axioms observed_0440
#print axioms observed_0441
#print axioms observed_0442
#print axioms observed_0443
#print axioms observed_0444
#print axioms observed_0445
#print axioms observed_0446
#print axioms observed_0447
#print axioms observed_0448
#print axioms observed_0449
#print axioms observed_0450
#print axioms observed_0451
#print axioms observed_0452
#print axioms observed_0453
#print axioms observed_0454
#print axioms observed_0455
#print axioms observed_0456
#print axioms observed_0457
#print axioms observed_0458
#print axioms observed_0459
#print axioms observed_0460
#print axioms observed_0461
#print axioms observed_0462
#print axioms observed_0463
#print axioms observed_0464
#print axioms observed_0465
#print axioms observed_0466
#print axioms observed_0467
#print axioms observed_0468
#print axioms observed_0469
#print axioms observed_0470
#print axioms observed_0471
#print axioms observed_0472
#print axioms observed_0473
#print axioms observed_0474
#print axioms observed_0475
#print axioms observed_0476
#print axioms observed_0477
#print axioms observed_0478
#print axioms observed_0479
#print axioms observed_0480
#print axioms observed_0481
#print axioms observed_0482
#print axioms observed_0483
#print axioms observed_0484
#print axioms observed_0485
#print axioms observed_0486
#print axioms observed_0487
#print axioms observed_0488
#print axioms observed_0489
#print axioms observed_0490
#print axioms observed_0491
#print axioms observed_0492
#print axioms observed_0493
#print axioms observed_0494
#print axioms observed_0495
#print axioms observed_0496
#print axioms observed_0497
#print axioms observed_0498
#print axioms observed_0499
#print axioms observed_0500
#print axioms observed_0501
#print axioms observed_0502
#print axioms observed_0503
#print axioms observed_0504
#print axioms observed_0505
#print axioms observed_0506
#print axioms observed_0507
#print axioms observed_0508
#print axioms observed_0509
#print axioms observed_0510
#print axioms observed_0511
#print axioms observed_0512
#print axioms observed_0513
#print axioms observed_0514
#print axioms observed_0515
#print axioms observed_0516
#print axioms observed_0517
#print axioms observed_0518
#print axioms observed_0519
#print axioms observed_0520
#print axioms observed_0521
#print axioms observed_0522
#print axioms observed_0523
#print axioms observed_0524
#print axioms observed_0525
#print axioms observed_0526
#print axioms observed_0527
#print axioms observed_0528
#print axioms observed_0529
#print axioms observed_0530
#print axioms observed_0531
#print axioms observed_0532
#print axioms observed_0533
#print axioms observed_0534
#print axioms observed_0535
#print axioms observed_0536
#print axioms observed_0537
#print axioms observed_0538
#print axioms observed_0539
#print axioms observed_0540
#print axioms observed_0541
#print axioms observed_0542
#print axioms observed_0543
#print axioms observed_0544
#print axioms observed_0545
#print axioms observed_0546
#print axioms observed_0547
#print axioms observed_0548
#print axioms observed_0549
#print axioms observed_0550
#print axioms observed_0551
#print axioms observed_0552
#print axioms observed_0553
#print axioms observed_0554
#print axioms observed_0555
#print axioms observed_0556
#print axioms observed_0557
#print axioms observed_0558
#print axioms observed_0559
#print axioms observed_0560
#print axioms observed_0561
#print axioms observed_0562
#print axioms observed_0563
#print axioms observed_0564
#print axioms observed_0565
#print axioms observed_0566
#print axioms observed_0567
#print axioms observed_0568
#print axioms observed_0569
#print axioms observed_0570
#print axioms observed_0571
#print axioms observed_0572
#print axioms observed_0573
#print axioms observed_0574
#print axioms observed_0575
#print axioms observed_0576
#print axioms observed_0577
#print axioms observed_0578
#print axioms observed_0579
#print axioms observed_0580
#print axioms observed_0581
#print axioms observed_0582
#print axioms observed_0583
#print axioms observed_0584
#print axioms observed_0585
#print axioms observed_0586
#print axioms observed_0587
#print axioms observed_0588
#print axioms observed_0589
#print axioms observed_0590
#print axioms observed_0591
#print axioms observed_0592
#print axioms observed_0593
#print axioms observed_0594
#print axioms observed_0595
#print axioms observed_0596
#print axioms observed_0597
#print axioms observed_0598
#print axioms observed_0599
#print axioms observed_0600
#print axioms observed_0601
#print axioms observed_0602
#print axioms observed_0603
#print axioms observed_0604
#print axioms observed_0605
#print axioms observed_0606
#print axioms observed_0607
#print axioms observed_0608
#print axioms observed_0609
#print axioms observed_0610
#print axioms observed_0611
#print axioms observed_0612
#print axioms observed_0613
#print axioms observed_0614
#print axioms observed_0615
#print axioms observed_0616
#print axioms observed_0617
#print axioms observed_0618
#print axioms observed_0619
#print axioms observed_0620
#print axioms observed_0621
#print axioms observed_0622
#print axioms observed_0623
#print axioms observed_0624
#print axioms observed_0625
#print axioms observed_0626
#print axioms observed_0627
#print axioms observed_0628
#print axioms observed_0629
#print axioms observed_0630
#print axioms observed_0631
#print axioms observed_0632
#print axioms observed_0633
#print axioms observed_0634
#print axioms observed_0635
#print axioms observed_0636
#print axioms observed_0637
#print axioms observed_0638
#print axioms observed_0639
#print axioms observed_0640
#print axioms observed_0641
#print axioms observed_0642
#print axioms observed_0643
#print axioms observed_0644
#print axioms observed_0645
#print axioms observed_0646
#print axioms observed_0647
#print axioms observed_0648
#print axioms observed_0649
#print axioms observed_0650
#print axioms observed_0651
#print axioms observed_0652
#print axioms observed_0653
#print axioms observed_0654
#print axioms observed_0655
#print axioms observed_0656
#print axioms observed_0657
#print axioms observed_0658
#print axioms observed_0659
#print axioms observed_0660
#print axioms observed_0661
#print axioms observed_0662
#print axioms observed_0663
#print axioms observed_0664
#print axioms observed_0665
#print axioms observed_0666
#print axioms observed_0667
#print axioms observed_0668
#print axioms observed_0669
#print axioms observed_0670
#print axioms observed_0671
#print axioms observed_0672
#print axioms observed_0673
#print axioms observed_0674
#print axioms observed_0675
#print axioms observed_0676
#print axioms observed_0677
#print axioms observed_0678
#print axioms observed_0679
#print axioms observed_0680
#print axioms observed_0681
#print axioms observed_0682
#print axioms observed_0683
#print axioms observed_0684
#print axioms observed_0685
#print axioms observed_0686
#print axioms observed_0687
#print axioms observed_0688
#print axioms observed_0689
#print axioms observed_0690
#print axioms observed_0691
#print axioms observed_0692
#print axioms observed_0693
#print axioms observed_0694
#print axioms observed_0695
#print axioms observed_0696
#print axioms observed_0697
#print axioms observed_0698
#print axioms observed_0699
#print axioms observed_0700
#print axioms observed_0701
#print axioms observed_0702
#print axioms observed_0703
#print axioms observed_0704
#print axioms observed_0705
#print axioms observed_0706
#print axioms observed_0707
#print axioms observed_0708
#print axioms observed_0709
#print axioms observed_0710
#print axioms observed_0711
#print axioms observed_0712
#print axioms observed_0713
#print axioms observed_0714
#print axioms observed_0715
#print axioms observed_0716
#print axioms observed_0717
#print axioms observed_0718
#print axioms observed_0719
#print axioms observed_0720
#print axioms observed_0721
#print axioms observed_0722
#print axioms observed_0723
#print axioms observed_0724
#print axioms observed_0725
#print axioms rejected_00
#print axioms rejected_01
#print axioms rejected_02
#print axioms rejected_03
#print axioms rejected_04
#print axioms rejected_05
#print axioms rejected_06
#print axioms rejected_07
#print axioms rejected_08
#print axioms rejected_09
#print axioms rejected_10
#print axioms rejected_11
#print axioms rejected_12
#print axioms rejected_13
