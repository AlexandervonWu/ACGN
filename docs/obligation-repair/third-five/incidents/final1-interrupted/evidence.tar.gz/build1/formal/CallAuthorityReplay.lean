import CallAuthorityTransitions
open ACGN.ThirdFive.CallAuthorityTransitions
namespace ACGN.ThirdFive.CallReplay
set_option maxRecDepth 4096
def table0 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration0 : Signature := (Signature.mk 23 0 0 0)
def source0 : Source := (.call (Signature.mk 23 0 0 0) (sourceArgs []))
def masg_tree0 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def ir_tree0 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def cert_tree0 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
theorem call0 : resolve table0 23 0 0 = some declaration0 ∧
    declaration0 = (Signature.mk 23 0 0 0) ∧
    JavaAritySafe declaration0.arity ∧
    (0 : Nat) = declaration0.arity ∧
    declaration0.arity = declaredArity [] ∧
    checkRepresentation source0 masg_tree0 = true ∧
    checkRepresentation source0 ir_tree0 = true ∧
    checkRepresentation source0 cert_tree0 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [11, 11] = [(11, 1), (11, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call0
def table1 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration1 : Signature := (Signature.mk 1 1 0 0)
def source1 : Source := (.call (Signature.mk 1 1 0 0) (sourceArgs []))
def masg_tree1 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def ir_tree1 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def cert_tree1 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
theorem call1 : resolve table1 1 1 0 = some declaration1 ∧
    declaration1 = (Signature.mk 1 1 0 0) ∧
    JavaAritySafe declaration1.arity ∧
    (0 : Nat) = declaration1.arity ∧
    declaration1.arity = declaredArity [] ∧
    checkRepresentation source1 masg_tree1 = true ∧
    checkRepresentation source1 ir_tree1 = true ∧
    checkRepresentation source1 cert_tree1 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [13, 13] = [(13, 1), (13, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call1
def table2 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration2 : Signature := (Signature.mk 23 0 0 0)
def source2 : Source := (.call (Signature.mk 23 0 0 0) (sourceArgs []))
def masg_tree2 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def ir_tree2 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def cert_tree2 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
theorem call2 : resolve table2 23 0 0 = some declaration2 ∧
    declaration2 = (Signature.mk 23 0 0 0) ∧
    JavaAritySafe declaration2.arity ∧
    (0 : Nat) = declaration2.arity ∧
    declaration2.arity = declaredArity [] ∧
    checkRepresentation source2 masg_tree2 = true ∧
    checkRepresentation source2 ir_tree2 = true ∧
    checkRepresentation source2 cert_tree2 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [16, 16] = [(16, 1), (16, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call2
def table3 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration3 : Signature := (Signature.mk 1 1 0 0)
def source3 : Source := (.call (Signature.mk 1 1 0 0) (sourceArgs []))
def masg_tree3 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def ir_tree3 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def cert_tree3 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
theorem call3 : resolve table3 1 1 0 = some declaration3 ∧
    declaration3 = (Signature.mk 1 1 0 0) ∧
    JavaAritySafe declaration3.arity ∧
    (0 : Nat) = declaration3.arity ∧
    declaration3.arity = declaredArity [] ∧
    checkRepresentation source3 masg_tree3 = true ∧
    checkRepresentation source3 ir_tree3 = true ∧
    checkRepresentation source3 cert_tree3 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [18, 18] = [(18, 1), (18, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call3
def table4 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration4 : Signature := (Signature.mk 23 0 0 0)
def source4 : Source := (.call (Signature.mk 23 0 0 0) (sourceArgs []))
def masg_tree4 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def ir_tree4 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def cert_tree4 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
theorem call4 : resolve table4 23 0 0 = some declaration4 ∧
    declaration4 = (Signature.mk 23 0 0 0) ∧
    JavaAritySafe declaration4.arity ∧
    (0 : Nat) = declaration4.arity ∧
    declaration4.arity = declaredArity [] ∧
    checkRepresentation source4 masg_tree4 = true ∧
    checkRepresentation source4 ir_tree4 = true ∧
    checkRepresentation source4 cert_tree4 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [20, 20] = [(20, 1), (20, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call4
def table5 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration5 : Signature := (Signature.mk 1 1 0 0)
def source5 : Source := (.call (Signature.mk 1 1 0 0) (sourceArgs []))
def masg_tree5 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def ir_tree5 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def cert_tree5 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
theorem call5 : resolve table5 1 1 0 = some declaration5 ∧
    declaration5 = (Signature.mk 1 1 0 0) ∧
    JavaAritySafe declaration5.arity ∧
    (0 : Nat) = declaration5.arity ∧
    declaration5.arity = declaredArity [] ∧
    checkRepresentation source5 masg_tree5 = true ∧
    checkRepresentation source5 ir_tree5 = true ∧
    checkRepresentation source5 cert_tree5 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [22, 22] = [(22, 1), (22, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call5
def table6 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration6 : Signature := (Signature.mk 23 0 0 0)
def source6 : Source := (.call (Signature.mk 23 0 0 0) (sourceArgs []))
def masg_tree6 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def ir_tree6 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
def cert_tree6 : Representation := (.application (Signature.mk 23 0 0 0) (ports []))
theorem call6 : resolve table6 23 0 0 = some declaration6 ∧
    declaration6 = (Signature.mk 23 0 0 0) ∧
    JavaAritySafe declaration6.arity ∧
    (0 : Nat) = declaration6.arity ∧
    declaration6.arity = declaredArity [] ∧
    checkRepresentation source6 masg_tree6 = true ∧
    checkRepresentation source6 ir_tree6 = true ∧
    checkRepresentation source6 cert_tree6 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [24, 24] = [(24, 1), (24, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call6
def table7 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 0 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration7 : Signature := (Signature.mk 1 1 0 0)
def source7 : Source := (.call (Signature.mk 1 1 0 0) (sourceArgs []))
def masg_tree7 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def ir_tree7 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
def cert_tree7 : Representation := (.application (Signature.mk 1 1 0 0) (ports []))
theorem call7 : resolve table7 1 1 0 = some declaration7 ∧
    declaration7 = (Signature.mk 1 1 0 0) ∧
    JavaAritySafe declaration7.arity ∧
    (0 : Nat) = declaration7.arity ∧
    declaration7.arity = declaredArity [] ∧
    checkRepresentation source7 masg_tree7 = true ∧
    checkRepresentation source7 ir_tree7 = true ∧
    checkRepresentation source7 cert_tree7 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [26, 26] = [(26, 1), (26, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call7
def table8 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration8 : Signature := (Signature.mk 23 0 1 0)
def source8 : Source := (.call (Signature.mk 23 0 1 0) (sourceArgs [(.atom 1)]))
def masg_tree8 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
def ir_tree8 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
def cert_tree8 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
theorem call8 : resolve table8 23 0 1 = some declaration8 ∧
    declaration8 = (Signature.mk 23 0 1 0) ∧
    JavaAritySafe declaration8.arity ∧
    (1 : Nat) = declaration8.arity ∧
    declaration8.arity = declaredArity [1] ∧
    checkRepresentation source8 masg_tree8 = true ∧
    checkRepresentation source8 ir_tree8 = true ∧
    checkRepresentation source8 cert_tree8 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [13, 13] = [(13, 1), (13, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call8
def table9 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration9 : Signature := (Signature.mk 1 1 1 0)
def source9 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree9 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree9 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree9 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call9 : resolve table9 1 1 1 = some declaration9 ∧
    declaration9 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration9.arity ∧
    (1 : Nat) = declaration9.arity ∧
    declaration9.arity = declaredArity [1] ∧
    checkRepresentation source9 masg_tree9 = true ∧
    checkRepresentation source9 ir_tree9 = true ∧
    checkRepresentation source9 cert_tree9 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [16, 16] = [(16, 1), (16, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call9
def table10 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration10 : Signature := (Signature.mk 23 0 1 0)
def source10 : Source := (.call (Signature.mk 23 0 1 0) (sourceArgs [(.atom 1)]))
def masg_tree10 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
def ir_tree10 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
def cert_tree10 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
theorem call10 : resolve table10 23 0 1 = some declaration10 ∧
    declaration10 = (Signature.mk 23 0 1 0) ∧
    JavaAritySafe declaration10.arity ∧
    (1 : Nat) = declaration10.arity ∧
    declaration10.arity = declaredArity [1] ∧
    checkRepresentation source10 masg_tree10 = true ∧
    checkRepresentation source10 ir_tree10 = true ∧
    checkRepresentation source10 cert_tree10 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [19, 19] = [(19, 1), (19, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call10
def table11 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration11 : Signature := (Signature.mk 1 1 1 0)
def source11 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree11 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree11 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree11 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call11 : resolve table11 1 1 1 = some declaration11 ∧
    declaration11 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration11.arity ∧
    (1 : Nat) = declaration11.arity ∧
    declaration11.arity = declaredArity [1] ∧
    checkRepresentation source11 masg_tree11 = true ∧
    checkRepresentation source11 ir_tree11 = true ∧
    checkRepresentation source11 cert_tree11 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [21, 21] = [(21, 1), (21, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call11
def table12 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration12 : Signature := (Signature.mk 23 0 1 0)
def source12 : Source := (.call (Signature.mk 23 0 1 0) (sourceArgs [(.atom 2)]))
def masg_tree12 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 2)]))
def ir_tree12 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 2)]))
def cert_tree12 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 2)]))
theorem call12 : resolve table12 23 0 1 = some declaration12 ∧
    declaration12 = (Signature.mk 23 0 1 0) ∧
    JavaAritySafe declaration12.arity ∧
    (1 : Nat) = declaration12.arity ∧
    declaration12.arity = declaredArity [1] ∧
    checkRepresentation source12 masg_tree12 = true ∧
    checkRepresentation source12 ir_tree12 = true ∧
    checkRepresentation source12 cert_tree12 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [23, 23] = [(23, 1), (23, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call12
def table13 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration13 : Signature := (Signature.mk 1 1 1 0)
def source13 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))
def masg_tree13 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def ir_tree13 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def cert_tree13 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
theorem call13 : resolve table13 1 1 1 = some declaration13 ∧
    declaration13 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration13.arity ∧
    (1 : Nat) = declaration13.arity ∧
    declaration13.arity = declaredArity [1] ∧
    checkRepresentation source13 masg_tree13 = true ∧
    checkRepresentation source13 ir_tree13 = true ∧
    checkRepresentation source13 cert_tree13 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [26, 26] = [(26, 1), (26, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call13
def table14 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration14 : Signature := (Signature.mk 23 0 1 0)
def source14 : Source := (.call (Signature.mk 23 0 1 0) (sourceArgs [(.atom 1)]))
def masg_tree14 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
def ir_tree14 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
def cert_tree14 : Representation := (.application (Signature.mk 23 0 1 0) (ports [(.scalar 1)]))
theorem call14 : resolve table14 23 0 1 = some declaration14 ∧
    declaration14 = (Signature.mk 23 0 1 0) ∧
    JavaAritySafe declaration14.arity ∧
    (1 : Nat) = declaration14.arity ∧
    declaration14.arity = declaredArity [1] ∧
    checkRepresentation source14 masg_tree14 = true ∧
    checkRepresentation source14 ir_tree14 = true ∧
    checkRepresentation source14 cert_tree14 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [28, 28] = [(28, 1), (28, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call14
def table15 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 1 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration15 : Signature := (Signature.mk 1 1 1 0)
def source15 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree15 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree15 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree15 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call15 : resolve table15 1 1 1 = some declaration15 ∧
    declaration15 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration15.arity ∧
    (1 : Nat) = declaration15.arity ∧
    declaration15.arity = declaredArity [1] ∧
    checkRepresentation source15 masg_tree15 = true ∧
    checkRepresentation source15 ir_tree15 = true ∧
    checkRepresentation source15 cert_tree15 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [30, 30] = [(30, 1), (30, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call15
def table16 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration16 : Signature := (Signature.mk 23 0 2 0)
def source16 : Source := (.call (Signature.mk 23 0 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree16 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree16 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree16 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call16 : resolve table16 23 0 2 = some declaration16 ∧
    declaration16 = (Signature.mk 23 0 2 0) ∧
    JavaAritySafe declaration16.arity ∧
    (2 : Nat) = declaration16.arity ∧
    declaration16.arity = declaredArity [2] ∧
    checkRepresentation source16 masg_tree16 = true ∧
    checkRepresentation source16 ir_tree16 = true ∧
    checkRepresentation source16 cert_tree16 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [14, 14] = [(14, 1), (14, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call16
def table17 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration17 : Signature := (Signature.mk 1 1 2 0)
def source17 : Source := (.call (Signature.mk 1 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree17 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree17 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree17 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call17 : resolve table17 1 1 2 = some declaration17 ∧
    declaration17 = (Signature.mk 1 1 2 0) ∧
    JavaAritySafe declaration17.arity ∧
    (2 : Nat) = declaration17.arity ∧
    declaration17.arity = declaredArity [2] ∧
    checkRepresentation source17 masg_tree17 = true ∧
    checkRepresentation source17 ir_tree17 = true ∧
    checkRepresentation source17 cert_tree17 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [18, 18] = [(18, 1), (18, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call17
def table18 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration18 : Signature := (Signature.mk 23 0 2 0)
def source18 : Source := (.call (Signature.mk 23 0 2 0) (sourceArgs [(.atom 2), (.atom 1)]))
def masg_tree18 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 2), (.scalar 1)]))
def ir_tree18 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 2), (.scalar 1)]))
def cert_tree18 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 2), (.scalar 1)]))
theorem call18 : resolve table18 23 0 2 = some declaration18 ∧
    declaration18 = (Signature.mk 23 0 2 0) ∧
    JavaAritySafe declaration18.arity ∧
    (2 : Nat) = declaration18.arity ∧
    declaration18.arity = declaredArity [2] ∧
    checkRepresentation source18 masg_tree18 = true ∧
    checkRepresentation source18 ir_tree18 = true ∧
    checkRepresentation source18 cert_tree18 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [21, 21] = [(21, 1), (21, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call18
def table19 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration19 : Signature := (Signature.mk 1 1 2 0)
def source19 : Source := (.call (Signature.mk 1 1 2 0) (sourceArgs [(.atom 2), (.atom 1)]))
def masg_tree19 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 2), (.scalar 1)]))
def ir_tree19 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 2), (.scalar 1)]))
def cert_tree19 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 2), (.scalar 1)]))
theorem call19 : resolve table19 1 1 2 = some declaration19 ∧
    declaration19 = (Signature.mk 1 1 2 0) ∧
    JavaAritySafe declaration19.arity ∧
    (2 : Nat) = declaration19.arity ∧
    declaration19.arity = declaredArity [2] ∧
    checkRepresentation source19 masg_tree19 = true ∧
    checkRepresentation source19 ir_tree19 = true ∧
    checkRepresentation source19 cert_tree19 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [23, 23] = [(23, 1), (23, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call19
def table20 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration20 : Signature := (Signature.mk 23 0 2 0)
def source20 : Source := (.call (Signature.mk 23 0 2 0) (sourceArgs [(.atom 2), (.atom 2)]))
def masg_tree20 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 2), (.scalar 2)]))
def ir_tree20 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 2), (.scalar 2)]))
def cert_tree20 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 2), (.scalar 2)]))
theorem call20 : resolve table20 23 0 2 = some declaration20 ∧
    declaration20 = (Signature.mk 23 0 2 0) ∧
    JavaAritySafe declaration20.arity ∧
    (2 : Nat) = declaration20.arity ∧
    declaration20.arity = declaredArity [2] ∧
    checkRepresentation source20 masg_tree20 = true ∧
    checkRepresentation source20 ir_tree20 = true ∧
    checkRepresentation source20 cert_tree20 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [25, 25] = [(25, 1), (25, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call20
def table21 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration21 : Signature := (Signature.mk 1 1 2 0)
def source21 : Source := (.call (Signature.mk 1 1 2 0) (sourceArgs [(.atom 2), (.atom 2)]))
def masg_tree21 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 2), (.scalar 2)]))
def ir_tree21 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 2), (.scalar 2)]))
def cert_tree21 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 2), (.scalar 2)]))
theorem call21 : resolve table21 1 1 2 = some declaration21 ∧
    declaration21 = (Signature.mk 1 1 2 0) ∧
    JavaAritySafe declaration21.arity ∧
    (2 : Nat) = declaration21.arity ∧
    declaration21.arity = declaredArity [2] ∧
    checkRepresentation source21 masg_tree21 = true ∧
    checkRepresentation source21 ir_tree21 = true ∧
    checkRepresentation source21 cert_tree21 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [27, 27] = [(27, 1), (27, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call21
def table22 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration22 : Signature := (Signature.mk 23 0 2 0)
def source22 : Source := (.call (Signature.mk 23 0 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree22 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree22 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree22 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call22 : resolve table22 23 0 2 = some declaration22 ∧
    declaration22 = (Signature.mk 23 0 2 0) ∧
    JavaAritySafe declaration22.arity ∧
    (2 : Nat) = declaration22.arity ∧
    declaration22.arity = declaredArity [2] ∧
    checkRepresentation source22 masg_tree22 = true ∧
    checkRepresentation source22 ir_tree22 = true ∧
    checkRepresentation source22 cert_tree22 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [29, 29] = [(29, 1), (29, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call22
def table23 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration23 : Signature := (Signature.mk 1 1 2 0)
def source23 : Source := (.call (Signature.mk 1 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree23 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree23 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree23 : Representation := (.application (Signature.mk 1 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call23 : resolve table23 1 1 2 = some declaration23 ∧
    declaration23 = (Signature.mk 1 1 2 0) ∧
    JavaAritySafe declaration23.arity ∧
    (2 : Nat) = declaration23.arity ∧
    declaration23.arity = declaredArity [2] ∧
    checkRepresentation source23 masg_tree23 = true ∧
    checkRepresentation source23 ir_tree23 = true ∧
    checkRepresentation source23 cert_tree23 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [31, 31] = [(31, 1), (31, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call23
def table24 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration24 : Signature := (Signature.mk 23 0 3 0)
def source24 : Source := (.call (Signature.mk 23 0 3 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3)]))
def masg_tree24 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def ir_tree24 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def cert_tree24 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
theorem call24 : resolve table24 23 0 3 = some declaration24 ∧
    declaration24 = (Signature.mk 23 0 3 0) ∧
    JavaAritySafe declaration24.arity ∧
    (3 : Nat) = declaration24.arity ∧
    declaration24.arity = declaredArity [3] ∧
    checkRepresentation source24 masg_tree24 = true ∧
    checkRepresentation source24 ir_tree24 = true ∧
    checkRepresentation source24 cert_tree24 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [15, 15] = [(15, 1), (15, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call24
def table25 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration25 : Signature := (Signature.mk 1 1 3 0)
def source25 : Source := (.call (Signature.mk 1 1 3 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3)]))
def masg_tree25 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def ir_tree25 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def cert_tree25 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
theorem call25 : resolve table25 1 1 3 = some declaration25 ∧
    declaration25 = (Signature.mk 1 1 3 0) ∧
    JavaAritySafe declaration25.arity ∧
    (3 : Nat) = declaration25.arity ∧
    declaration25.arity = declaredArity [3] ∧
    checkRepresentation source25 masg_tree25 = true ∧
    checkRepresentation source25 ir_tree25 = true ∧
    checkRepresentation source25 cert_tree25 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [20, 20] = [(20, 1), (20, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call25
def table26 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration26 : Signature := (Signature.mk 23 0 3 0)
def source26 : Source := (.call (Signature.mk 23 0 3 0) (sourceArgs [(.atom 3), (.atom 2), (.atom 1)]))
def masg_tree26 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree26 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree26 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call26 : resolve table26 23 0 3 = some declaration26 ∧
    declaration26 = (Signature.mk 23 0 3 0) ∧
    JavaAritySafe declaration26.arity ∧
    (3 : Nat) = declaration26.arity ∧
    declaration26.arity = declaredArity [3] ∧
    checkRepresentation source26 masg_tree26 = true ∧
    checkRepresentation source26 ir_tree26 = true ∧
    checkRepresentation source26 cert_tree26 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [23, 23] = [(23, 1), (23, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call26
def table27 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration27 : Signature := (Signature.mk 1 1 3 0)
def source27 : Source := (.call (Signature.mk 1 1 3 0) (sourceArgs [(.atom 3), (.atom 2), (.atom 1)]))
def masg_tree27 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree27 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree27 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call27 : resolve table27 1 1 3 = some declaration27 ∧
    declaration27 = (Signature.mk 1 1 3 0) ∧
    JavaAritySafe declaration27.arity ∧
    (3 : Nat) = declaration27.arity ∧
    declaration27.arity = declaredArity [3] ∧
    checkRepresentation source27 masg_tree27 = true ∧
    checkRepresentation source27 ir_tree27 = true ∧
    checkRepresentation source27 cert_tree27 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [25, 25] = [(25, 1), (25, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call27
def table28 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration28 : Signature := (Signature.mk 23 0 3 0)
def source28 : Source := (.call (Signature.mk 23 0 3 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2)]))
def masg_tree28 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree28 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree28 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call28 : resolve table28 23 0 3 = some declaration28 ∧
    declaration28 = (Signature.mk 23 0 3 0) ∧
    JavaAritySafe declaration28.arity ∧
    (3 : Nat) = declaration28.arity ∧
    declaration28.arity = declaredArity [3] ∧
    checkRepresentation source28 masg_tree28 = true ∧
    checkRepresentation source28 ir_tree28 = true ∧
    checkRepresentation source28 cert_tree28 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [27, 27] = [(27, 1), (27, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call28
def table29 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration29 : Signature := (Signature.mk 1 1 3 0)
def source29 : Source := (.call (Signature.mk 1 1 3 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2)]))
def masg_tree29 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree29 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree29 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call29 : resolve table29 1 1 3 = some declaration29 ∧
    declaration29 = (Signature.mk 1 1 3 0) ∧
    JavaAritySafe declaration29.arity ∧
    (3 : Nat) = declaration29.arity ∧
    declaration29.arity = declaredArity [3] ∧
    checkRepresentation source29 masg_tree29 = true ∧
    checkRepresentation source29 ir_tree29 = true ∧
    checkRepresentation source29 cert_tree29 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [29, 29] = [(29, 1), (29, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call29
def table30 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration30 : Signature := (Signature.mk 23 0 3 0)
def source30 : Source := (.call (Signature.mk 23 0 3 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3)]))
def masg_tree30 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def ir_tree30 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def cert_tree30 : Representation := (.application (Signature.mk 23 0 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
theorem call30 : resolve table30 23 0 3 = some declaration30 ∧
    declaration30 = (Signature.mk 23 0 3 0) ∧
    JavaAritySafe declaration30.arity ∧
    (3 : Nat) = declaration30.arity ∧
    declaration30.arity = declaredArity [3] ∧
    checkRepresentation source30 masg_tree30 = true ∧
    checkRepresentation source30 ir_tree30 = true ∧
    checkRepresentation source30 cert_tree30 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [31, 31] = [(31, 1), (31, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call30
def table31 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 3 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 3 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration31 : Signature := (Signature.mk 1 1 3 0)
def source31 : Source := (.call (Signature.mk 1 1 3 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3)]))
def masg_tree31 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def ir_tree31 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
def cert_tree31 : Representation := (.application (Signature.mk 1 1 3 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3)]))
theorem call31 : resolve table31 1 1 3 = some declaration31 ∧
    declaration31 = (Signature.mk 1 1 3 0) ∧
    JavaAritySafe declaration31.arity ∧
    (3 : Nat) = declaration31.arity ∧
    declaration31.arity = declaredArity [3] ∧
    checkRepresentation source31 masg_tree31 = true ∧
    checkRepresentation source31 ir_tree31 = true ∧
    checkRepresentation source31 cert_tree31 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [33, 33] = [(33, 1), (33, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call31
def table32 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration32 : Signature := (Signature.mk 23 0 5 0)
def source32 : Source := (.call (Signature.mk 23 0 5 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree32 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree32 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree32 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call32 : resolve table32 23 0 5 = some declaration32 ∧
    declaration32 = (Signature.mk 23 0 5 0) ∧
    JavaAritySafe declaration32.arity ∧
    (5 : Nat) = declaration32.arity ∧
    declaration32.arity = declaredArity [5] ∧
    checkRepresentation source32 masg_tree32 = true ∧
    checkRepresentation source32 ir_tree32 = true ∧
    checkRepresentation source32 cert_tree32 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [17, 17] = [(17, 1), (17, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call32
def table33 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration33 : Signature := (Signature.mk 1 1 5 0)
def source33 : Source := (.call (Signature.mk 1 1 5 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree33 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree33 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree33 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call33 : resolve table33 1 1 5 = some declaration33 ∧
    declaration33 = (Signature.mk 1 1 5 0) ∧
    JavaAritySafe declaration33.arity ∧
    (5 : Nat) = declaration33.arity ∧
    declaration33.arity = declaredArity [5] ∧
    checkRepresentation source33 masg_tree33 = true ∧
    checkRepresentation source33 ir_tree33 = true ∧
    checkRepresentation source33 cert_tree33 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [22, 22] = [(22, 1), (22, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call33
def table34 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration34 : Signature := (Signature.mk 23 0 5 0)
def source34 : Source := (.call (Signature.mk 23 0 5 0) (sourceArgs [(.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1)]))
def masg_tree34 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree34 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree34 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call34 : resolve table34 23 0 5 = some declaration34 ∧
    declaration34 = (Signature.mk 23 0 5 0) ∧
    JavaAritySafe declaration34.arity ∧
    (5 : Nat) = declaration34.arity ∧
    declaration34.arity = declaredArity [5] ∧
    checkRepresentation source34 masg_tree34 = true ∧
    checkRepresentation source34 ir_tree34 = true ∧
    checkRepresentation source34 cert_tree34 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [25, 25] = [(25, 1), (25, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call34
def table35 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration35 : Signature := (Signature.mk 1 1 5 0)
def source35 : Source := (.call (Signature.mk 1 1 5 0) (sourceArgs [(.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1)]))
def masg_tree35 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree35 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree35 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call35 : resolve table35 1 1 5 = some declaration35 ∧
    declaration35 = (Signature.mk 1 1 5 0) ∧
    JavaAritySafe declaration35.arity ∧
    (5 : Nat) = declaration35.arity ∧
    declaration35.arity = declaredArity [5] ∧
    checkRepresentation source35 masg_tree35 = true ∧
    checkRepresentation source35 ir_tree35 = true ∧
    checkRepresentation source35 cert_tree35 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [27, 27] = [(27, 1), (27, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call35
def table36 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration36 : Signature := (Signature.mk 23 0 5 0)
def source36 : Source := (.call (Signature.mk 23 0 5 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2)]))
def masg_tree36 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree36 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree36 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call36 : resolve table36 23 0 5 = some declaration36 ∧
    declaration36 = (Signature.mk 23 0 5 0) ∧
    JavaAritySafe declaration36.arity ∧
    (5 : Nat) = declaration36.arity ∧
    declaration36.arity = declaredArity [5] ∧
    checkRepresentation source36 masg_tree36 = true ∧
    checkRepresentation source36 ir_tree36 = true ∧
    checkRepresentation source36 cert_tree36 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [29, 29] = [(29, 1), (29, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call36
def table37 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration37 : Signature := (Signature.mk 1 1 5 0)
def source37 : Source := (.call (Signature.mk 1 1 5 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2)]))
def masg_tree37 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree37 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree37 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call37 : resolve table37 1 1 5 = some declaration37 ∧
    declaration37 = (Signature.mk 1 1 5 0) ∧
    JavaAritySafe declaration37.arity ∧
    (5 : Nat) = declaration37.arity ∧
    declaration37.arity = declaredArity [5] ∧
    checkRepresentation source37 masg_tree37 = true ∧
    checkRepresentation source37 ir_tree37 = true ∧
    checkRepresentation source37 cert_tree37 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [31, 31] = [(31, 1), (31, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call37
def table38 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration38 : Signature := (Signature.mk 23 0 5 0)
def source38 : Source := (.call (Signature.mk 23 0 5 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree38 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree38 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree38 : Representation := (.application (Signature.mk 23 0 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call38 : resolve table38 23 0 5 = some declaration38 ∧
    declaration38 = (Signature.mk 23 0 5 0) ∧
    JavaAritySafe declaration38.arity ∧
    (5 : Nat) = declaration38.arity ∧
    declaration38.arity = declaredArity [5] ∧
    checkRepresentation source38 masg_tree38 = true ∧
    checkRepresentation source38 ir_tree38 = true ∧
    checkRepresentation source38 cert_tree38 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [33, 33] = [(33, 1), (33, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call38
def table39 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 5 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 5 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration39 : Signature := (Signature.mk 1 1 5 0)
def source39 : Source := (.call (Signature.mk 1 1 5 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree39 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree39 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree39 : Representation := (.application (Signature.mk 1 1 5 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call39 : resolve table39 1 1 5 = some declaration39 ∧
    declaration39 = (Signature.mk 1 1 5 0) ∧
    JavaAritySafe declaration39.arity ∧
    (5 : Nat) = declaration39.arity ∧
    declaration39.arity = declaredArity [5] ∧
    checkRepresentation source39 masg_tree39 = true ∧
    checkRepresentation source39 ir_tree39 = true ∧
    checkRepresentation source39 cert_tree39 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [35, 35] = [(35, 1), (35, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call39
def table40 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration40 : Signature := (Signature.mk 23 0 8 0)
def source40 : Source := (.call (Signature.mk 23 0 8 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree40 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree40 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree40 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call40 : resolve table40 23 0 8 = some declaration40 ∧
    declaration40 = (Signature.mk 23 0 8 0) ∧
    JavaAritySafe declaration40.arity ∧
    (8 : Nat) = declaration40.arity ∧
    declaration40.arity = declaredArity [8] ∧
    checkRepresentation source40 masg_tree40 = true ∧
    checkRepresentation source40 ir_tree40 = true ∧
    checkRepresentation source40 cert_tree40 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [20, 20] = [(20, 1), (20, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call40
def table41 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration41 : Signature := (Signature.mk 1 1 8 0)
def source41 : Source := (.call (Signature.mk 1 1 8 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree41 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree41 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree41 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call41 : resolve table41 1 1 8 = some declaration41 ∧
    declaration41 = (Signature.mk 1 1 8 0) ∧
    JavaAritySafe declaration41.arity ∧
    (8 : Nat) = declaration41.arity ∧
    declaration41.arity = declaredArity [8] ∧
    checkRepresentation source41 masg_tree41 = true ∧
    checkRepresentation source41 ir_tree41 = true ∧
    checkRepresentation source41 cert_tree41 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [25, 25] = [(25, 1), (25, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call41
def table42 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration42 : Signature := (Signature.mk 23 0 8 0)
def source42 : Source := (.call (Signature.mk 23 0 8 0) (sourceArgs [(.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1)]))
def masg_tree42 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree42 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree42 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call42 : resolve table42 23 0 8 = some declaration42 ∧
    declaration42 = (Signature.mk 23 0 8 0) ∧
    JavaAritySafe declaration42.arity ∧
    (8 : Nat) = declaration42.arity ∧
    declaration42.arity = declaredArity [8] ∧
    checkRepresentation source42 masg_tree42 = true ∧
    checkRepresentation source42 ir_tree42 = true ∧
    checkRepresentation source42 cert_tree42 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [28, 28] = [(28, 1), (28, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call42
def table43 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration43 : Signature := (Signature.mk 1 1 8 0)
def source43 : Source := (.call (Signature.mk 1 1 8 0) (sourceArgs [(.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1)]))
def masg_tree43 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree43 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree43 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call43 : resolve table43 1 1 8 = some declaration43 ∧
    declaration43 = (Signature.mk 1 1 8 0) ∧
    JavaAritySafe declaration43.arity ∧
    (8 : Nat) = declaration43.arity ∧
    declaration43.arity = declaredArity [8] ∧
    checkRepresentation source43 masg_tree43 = true ∧
    checkRepresentation source43 ir_tree43 = true ∧
    checkRepresentation source43 cert_tree43 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [30, 30] = [(30, 1), (30, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call43
def table44 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration44 : Signature := (Signature.mk 23 0 8 0)
def source44 : Source := (.call (Signature.mk 23 0 8 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2)]))
def masg_tree44 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree44 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree44 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call44 : resolve table44 23 0 8 = some declaration44 ∧
    declaration44 = (Signature.mk 23 0 8 0) ∧
    JavaAritySafe declaration44.arity ∧
    (8 : Nat) = declaration44.arity ∧
    declaration44.arity = declaredArity [8] ∧
    checkRepresentation source44 masg_tree44 = true ∧
    checkRepresentation source44 ir_tree44 = true ∧
    checkRepresentation source44 cert_tree44 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [32, 32] = [(32, 1), (32, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call44
def table45 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration45 : Signature := (Signature.mk 1 1 8 0)
def source45 : Source := (.call (Signature.mk 1 1 8 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2)]))
def masg_tree45 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree45 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree45 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call45 : resolve table45 1 1 8 = some declaration45 ∧
    declaration45 = (Signature.mk 1 1 8 0) ∧
    JavaAritySafe declaration45.arity ∧
    (8 : Nat) = declaration45.arity ∧
    declaration45.arity = declaredArity [8] ∧
    checkRepresentation source45 masg_tree45 = true ∧
    checkRepresentation source45 ir_tree45 = true ∧
    checkRepresentation source45 cert_tree45 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [34, 34] = [(34, 1), (34, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call45
def table46 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration46 : Signature := (Signature.mk 23 0 8 0)
def source46 : Source := (.call (Signature.mk 23 0 8 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree46 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree46 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree46 : Representation := (.application (Signature.mk 23 0 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call46 : resolve table46 23 0 8 = some declaration46 ∧
    declaration46 = (Signature.mk 23 0 8 0) ∧
    JavaAritySafe declaration46.arity ∧
    (8 : Nat) = declaration46.arity ∧
    declaration46.arity = declaredArity [8] ∧
    checkRepresentation source46 masg_tree46 = true ∧
    checkRepresentation source46 ir_tree46 = true ∧
    checkRepresentation source46 cert_tree46 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [36, 36] = [(36, 1), (36, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call46
def table47 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 8 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 8 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration47 : Signature := (Signature.mk 1 1 8 0)
def source47 : Source := (.call (Signature.mk 1 1 8 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2)]))
def masg_tree47 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def ir_tree47 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
def cert_tree47 : Representation := (.application (Signature.mk 1 1 8 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2)]))
theorem call47 : resolve table47 1 1 8 = some declaration47 ∧
    declaration47 = (Signature.mk 1 1 8 0) ∧
    JavaAritySafe declaration47.arity ∧
    (8 : Nat) = declaration47.arity ∧
    declaration47.arity = declaredArity [8] ∧
    checkRepresentation source47 masg_tree47 = true ∧
    checkRepresentation source47 ir_tree47 = true ∧
    checkRepresentation source47 cert_tree47 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [38, 38] = [(38, 1), (38, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call47
def table48 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration48 : Signature := (Signature.mk 23 0 16 0)
def source48 : Source := (.call (Signature.mk 23 0 16 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1)]))
def masg_tree48 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def ir_tree48 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def cert_tree48 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
theorem call48 : resolve table48 23 0 16 = some declaration48 ∧
    declaration48 = (Signature.mk 23 0 16 0) ∧
    JavaAritySafe declaration48.arity ∧
    (16 : Nat) = declaration48.arity ∧
    declaration48.arity = declaredArity [16] ∧
    checkRepresentation source48 masg_tree48 = true ∧
    checkRepresentation source48 ir_tree48 = true ∧
    checkRepresentation source48 cert_tree48 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [28, 28] = [(28, 1), (28, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call48
def table49 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration49 : Signature := (Signature.mk 1 1 16 0)
def source49 : Source := (.call (Signature.mk 1 1 16 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1)]))
def masg_tree49 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def ir_tree49 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def cert_tree49 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
theorem call49 : resolve table49 1 1 16 = some declaration49 ∧
    declaration49 = (Signature.mk 1 1 16 0) ∧
    JavaAritySafe declaration49.arity ∧
    (16 : Nat) = declaration49.arity ∧
    declaration49.arity = declaredArity [16] ∧
    checkRepresentation source49 masg_tree49 = true ∧
    checkRepresentation source49 ir_tree49 = true ∧
    checkRepresentation source49 cert_tree49 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [33, 33] = [(33, 1), (33, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call49
def table50 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration50 : Signature := (Signature.mk 23 0 16 0)
def source50 : Source := (.call (Signature.mk 23 0 16 0) (sourceArgs [(.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1)]))
def masg_tree50 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree50 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree50 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call50 : resolve table50 23 0 16 = some declaration50 ∧
    declaration50 = (Signature.mk 23 0 16 0) ∧
    JavaAritySafe declaration50.arity ∧
    (16 : Nat) = declaration50.arity ∧
    declaration50.arity = declaredArity [16] ∧
    checkRepresentation source50 masg_tree50 = true ∧
    checkRepresentation source50 ir_tree50 = true ∧
    checkRepresentation source50 cert_tree50 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [36, 36] = [(36, 1), (36, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call50
def table51 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration51 : Signature := (Signature.mk 1 1 16 0)
def source51 : Source := (.call (Signature.mk 1 1 16 0) (sourceArgs [(.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1), (.atom 3), (.atom 2), (.atom 1)]))
def masg_tree51 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def ir_tree51 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
def cert_tree51 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1), (.scalar 3), (.scalar 2), (.scalar 1)]))
theorem call51 : resolve table51 1 1 16 = some declaration51 ∧
    declaration51 = (Signature.mk 1 1 16 0) ∧
    JavaAritySafe declaration51.arity ∧
    (16 : Nat) = declaration51.arity ∧
    declaration51.arity = declaredArity [16] ∧
    checkRepresentation source51 masg_tree51 = true ∧
    checkRepresentation source51 ir_tree51 = true ∧
    checkRepresentation source51 cert_tree51 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [38, 38] = [(38, 1), (38, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call51
def table52 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration52 : Signature := (Signature.mk 23 0 16 0)
def source52 : Source := (.call (Signature.mk 23 0 16 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2)]))
def masg_tree52 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree52 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree52 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call52 : resolve table52 23 0 16 = some declaration52 ∧
    declaration52 = (Signature.mk 23 0 16 0) ∧
    JavaAritySafe declaration52.arity ∧
    (16 : Nat) = declaration52.arity ∧
    declaration52.arity = declaredArity [16] ∧
    checkRepresentation source52 masg_tree52 = true ∧
    checkRepresentation source52 ir_tree52 = true ∧
    checkRepresentation source52 cert_tree52 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [40, 40] = [(40, 1), (40, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call52
def table53 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration53 : Signature := (Signature.mk 1 1 16 0)
def source53 : Source := (.call (Signature.mk 1 1 16 0) (sourceArgs [(.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2), (.atom 2)]))
def masg_tree53 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def ir_tree53 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
def cert_tree53 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2), (.scalar 2)]))
theorem call53 : resolve table53 1 1 16 = some declaration53 ∧
    declaration53 = (Signature.mk 1 1 16 0) ∧
    JavaAritySafe declaration53.arity ∧
    (16 : Nat) = declaration53.arity ∧
    declaration53.arity = declaredArity [16] ∧
    checkRepresentation source53 masg_tree53 = true ∧
    checkRepresentation source53 ir_tree53 = true ∧
    checkRepresentation source53 cert_tree53 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [42, 42] = [(42, 1), (42, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call53
def table54 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration54 : Signature := (Signature.mk 23 0 16 0)
def source54 : Source := (.call (Signature.mk 23 0 16 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1)]))
def masg_tree54 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def ir_tree54 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def cert_tree54 : Representation := (.application (Signature.mk 23 0 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
theorem call54 : resolve table54 23 0 16 = some declaration54 ∧
    declaration54 = (Signature.mk 23 0 16 0) ∧
    JavaAritySafe declaration54.arity ∧
    (16 : Nat) = declaration54.arity ∧
    declaration54.arity = declaredArity [16] ∧
    checkRepresentation source54 masg_tree54 = true ∧
    checkRepresentation source54 ir_tree54 = true ∧
    checkRepresentation source54 cert_tree54 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [44, 44] = [(44, 1), (44, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call54
def table55 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 16 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 23 0 16 0), (Signature.mk 24 0 0 0), (Signature.mk 25 0 0 0), (Signature.mk 26 0 0 0), (Signature.mk 27 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration55 : Signature := (Signature.mk 1 1 16 0)
def source55 : Source := (.call (Signature.mk 1 1 16 0) (sourceArgs [(.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1), (.atom 2), (.atom 3), (.atom 1)]))
def masg_tree55 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def ir_tree55 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
def cert_tree55 : Representation := (.application (Signature.mk 1 1 16 0) (ports [(.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1), (.scalar 2), (.scalar 3), (.scalar 1)]))
theorem call55 : resolve table55 1 1 16 = some declaration55 ∧
    declaration55 = (Signature.mk 1 1 16 0) ∧
    JavaAritySafe declaration55.arity ∧
    (16 : Nat) = declaration55.arity ∧
    declaration55.arity = declaredArity [16] ∧
    checkRepresentation source55 masg_tree55 = true ∧
    checkRepresentation source55 ir_tree55 = true ∧
    checkRepresentation source55 cert_tree55 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [46, 46] = [(46, 1), (46, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call55
def table56 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration56 : Signature := (Signature.mk 1 1 1 0)
def source56 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))]))
def masg_tree56 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def ir_tree56 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def cert_tree56 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
theorem call56 : resolve table56 1 1 1 = some declaration56 ∧
    declaration56 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration56.arity ∧
    (1 : Nat) = declaration56.arity ∧
    declaration56.arity = declaredArity [1] ∧
    checkRepresentation source56 masg_tree56 = true ∧
    checkRepresentation source56 ir_tree56 = true ∧
    checkRepresentation source56 cert_tree56 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [14, 14] = [(14, 1), (14, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call56
def table57 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration57 : Signature := (Signature.mk 1 1 1 0)
def source57 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree57 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree57 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree57 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call57 : resolve table57 1 1 1 = some declaration57 ∧
    declaration57 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration57.arity ∧
    (1 : Nat) = declaration57.arity ∧
    declaration57.arity = declaredArity [1] ∧
    checkRepresentation source57 masg_tree57 = true ∧
    checkRepresentation source57 ir_tree57 = true ∧
    checkRepresentation source57 cert_tree57 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [16, 16] = [(16, 1), (16, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call57
def table58 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration58 : Signature := (Signature.mk 1 1 1 0)
def source58 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree58 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree58 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree58 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call58 : resolve table58 1 1 1 = some declaration58 ∧
    declaration58 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration58.arity ∧
    (1 : Nat) = declaration58.arity ∧
    declaration58.arity = declaredArity [1] ∧
    checkRepresentation source58 masg_tree58 = true ∧
    checkRepresentation source58 ir_tree58 = true ∧
    checkRepresentation source58 cert_tree58 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [19, 19] = [(19, 1), (19, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call58
def table59 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration59 : Signature := (Signature.mk 6 1 2 0)
def source59 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree59 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree59 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree59 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call59 : resolve table59 6 1 2 = some declaration59 ∧
    declaration59 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration59.arity ∧
    (2 : Nat) = declaration59.arity ∧
    declaration59.arity = declaredArity [2] ∧
    checkRepresentation source59 masg_tree59 = true ∧
    checkRepresentation source59 ir_tree59 = true ∧
    checkRepresentation source59 cert_tree59 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [21, 21] = [(21, 1), (21, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call59
def table60 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration60 : Signature := (Signature.mk 6 1 2 0)
def source60 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 2), (.atom 1)]))
def masg_tree60 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 2), (.scalar 1)]))
def ir_tree60 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 2), (.scalar 1)]))
def cert_tree60 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 2), (.scalar 1)]))
theorem call60 : resolve table60 6 1 2 = some declaration60 ∧
    declaration60 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration60.arity ∧
    (2 : Nat) = declaration60.arity ∧
    declaration60.arity = declaredArity [2] ∧
    checkRepresentation source60 masg_tree60 = true ∧
    checkRepresentation source60 ir_tree60 = true ∧
    checkRepresentation source60 cert_tree60 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [25, 25] = [(25, 1), (25, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call60
def table61 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration61 : Signature := (Signature.mk 6 1 2 0)
def source61 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 1)]))
def masg_tree61 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 1)]))
def ir_tree61 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 1)]))
def cert_tree61 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 1)]))
theorem call61 : resolve table61 6 1 2 = some declaration61 ∧
    declaration61 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration61.arity ∧
    (2 : Nat) = declaration61.arity ∧
    declaration61.arity = declaredArity [2] ∧
    checkRepresentation source61 masg_tree61 = true ∧
    checkRepresentation source61 ir_tree61 = true ∧
    checkRepresentation source61 cert_tree61 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [27, 27] = [(27, 1), (27, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call61
def table62 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration62 : Signature := (Signature.mk 6 1 2 0)
def source62 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)])), (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))]))
def masg_tree62 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def ir_tree62 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def cert_tree62 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
theorem call62 : resolve table62 6 1 2 = some declaration62 ∧
    declaration62 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration62.arity ∧
    (2 : Nat) = declaration62.arity ∧
    declaration62.arity = declaredArity [2] ∧
    checkRepresentation source62 masg_tree62 = true ∧
    checkRepresentation source62 ir_tree62 = true ∧
    checkRepresentation source62 cert_tree62 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [29, 29] = [(29, 1), (29, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call62
def table63 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration63 : Signature := (Signature.mk 1 1 1 0)
def source63 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree63 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree63 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree63 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call63 : resolve table63 1 1 1 = some declaration63 ∧
    declaration63 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration63.arity ∧
    (1 : Nat) = declaration63.arity ∧
    declaration63.arity = declaredArity [1] ∧
    checkRepresentation source63 masg_tree63 = true ∧
    checkRepresentation source63 ir_tree63 = true ∧
    checkRepresentation source63 cert_tree63 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [30, 30] = [(30, 1), (30, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call63
def table64 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration64 : Signature := (Signature.mk 1 1 1 0)
def source64 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree64 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree64 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree64 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call64 : resolve table64 1 1 1 = some declaration64 ∧
    declaration64 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration64.arity ∧
    (1 : Nat) = declaration64.arity ∧
    declaration64.arity = declaredArity [1] ∧
    checkRepresentation source64 masg_tree64 = true ∧
    checkRepresentation source64 ir_tree64 = true ∧
    checkRepresentation source64 cert_tree64 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [31, 31] = [(31, 1), (31, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call64
def table65 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration65 : Signature := (Signature.mk 6 1 2 0)
def source65 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)])), (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))]))
def masg_tree65 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))]))
def ir_tree65 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))]))
def cert_tree65 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))]))
theorem call65 : resolve table65 6 1 2 = some declaration65 ∧
    declaration65 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration65.arity ∧
    (2 : Nat) = declaration65.arity ∧
    declaration65.arity = declaredArity [2] ∧
    checkRepresentation source65 masg_tree65 = true ∧
    checkRepresentation source65 ir_tree65 = true ∧
    checkRepresentation source65 cert_tree65 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [33, 33] = [(33, 1), (33, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call65
def table66 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration66 : Signature := (Signature.mk 1 1 1 0)
def source66 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree66 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree66 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree66 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call66 : resolve table66 1 1 1 = some declaration66 ∧
    declaration66 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration66.arity ∧
    (1 : Nat) = declaration66.arity ∧
    declaration66.arity = declaredArity [1] ∧
    checkRepresentation source66 masg_tree66 = true ∧
    checkRepresentation source66 ir_tree66 = true ∧
    checkRepresentation source66 cert_tree66 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [34, 34] = [(34, 1), (34, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call66
def table67 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration67 : Signature := (Signature.mk 1 1 1 0)
def source67 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))
def masg_tree67 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def ir_tree67 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def cert_tree67 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
theorem call67 : resolve table67 1 1 1 = some declaration67 ∧
    declaration67 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration67.arity ∧
    (1 : Nat) = declaration67.arity ∧
    declaration67.arity = declaredArity [1] ∧
    checkRepresentation source67 masg_tree67 = true ∧
    checkRepresentation source67 ir_tree67 = true ∧
    checkRepresentation source67 cert_tree67 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [35, 35] = [(35, 1), (35, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call67
def table68 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration68 : Signature := (Signature.mk 6 1 2 0)
def source68 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)])), (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))]))
def masg_tree68 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def ir_tree68 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def cert_tree68 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
theorem call68 : resolve table68 6 1 2 = some declaration68 ∧
    declaration68 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration68.arity ∧
    (2 : Nat) = declaration68.arity ∧
    declaration68.arity = declaredArity [2] ∧
    checkRepresentation source68 masg_tree68 = true ∧
    checkRepresentation source68 ir_tree68 = true ∧
    checkRepresentation source68 cert_tree68 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [37, 37] = [(37, 1), (37, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call68
def table69 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration69 : Signature := (Signature.mk 1 1 1 0)
def source69 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))
def masg_tree69 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def ir_tree69 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def cert_tree69 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
theorem call69 : resolve table69 1 1 1 = some declaration69 ∧
    declaration69 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration69.arity ∧
    (1 : Nat) = declaration69.arity ∧
    declaration69.arity = declaredArity [1] ∧
    checkRepresentation source69 masg_tree69 = true ∧
    checkRepresentation source69 ir_tree69 = true ∧
    checkRepresentation source69 cert_tree69 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [38, 38] = [(38, 1), (38, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call69
def table70 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration70 : Signature := (Signature.mk 1 1 1 0)
def source70 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree70 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree70 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree70 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call70 : resolve table70 1 1 1 = some declaration70 ∧
    declaration70 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration70.arity ∧
    (1 : Nat) = declaration70.arity ∧
    declaration70.arity = declaredArity [1] ∧
    checkRepresentation source70 masg_tree70 = true ∧
    checkRepresentation source70 ir_tree70 = true ∧
    checkRepresentation source70 cert_tree70 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [39, 39] = [(39, 1), (39, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call70
def table71 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration71 : Signature := (Signature.mk 1 1 1 0)
def source71 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.barrier 0 (sourceArgs [(.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))]))]))
def masg_tree71 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
def ir_tree71 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
def cert_tree71 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
theorem call71 : resolve table71 1 1 1 = some declaration71 ∧
    declaration71 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration71.arity ∧
    (1 : Nat) = declaration71.arity ∧
    declaration71.arity = declaredArity [1] ∧
    checkRepresentation source71 masg_tree71 = true ∧
    checkRepresentation source71 ir_tree71 = true ∧
    checkRepresentation source71 cert_tree71 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [41, 41] = [(41, 1), (41, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call71
def table72 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration72 : Signature := (Signature.mk 6 1 2 0)
def source72 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree72 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree72 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree72 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call72 : resolve table72 6 1 2 = some declaration72 ∧
    declaration72 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration72.arity ∧
    (2 : Nat) = declaration72.arity ∧
    declaration72.arity = declaredArity [2] ∧
    checkRepresentation source72 masg_tree72 = true ∧
    checkRepresentation source72 ir_tree72 = true ∧
    checkRepresentation source72 cert_tree72 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [43, 43] = [(43, 1), (43, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call72
def table73 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration73 : Signature := (Signature.mk 1 1 1 0)
def source73 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))]))
def masg_tree73 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))
def ir_tree73 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))
def cert_tree73 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))
theorem call73 : resolve table73 1 1 1 = some declaration73 ∧
    declaration73 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration73.arity ∧
    (1 : Nat) = declaration73.arity ∧
    declaration73.arity = declaredArity [1] ∧
    checkRepresentation source73 masg_tree73 = true ∧
    checkRepresentation source73 ir_tree73 = true ∧
    checkRepresentation source73 cert_tree73 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [45, 45] = [(45, 1), (45, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call73
def table74 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration74 : Signature := (Signature.mk 6 1 2 0)
def source74 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree74 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree74 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree74 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call74 : resolve table74 6 1 2 = some declaration74 ∧
    declaration74 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration74.arity ∧
    (2 : Nat) = declaration74.arity ∧
    declaration74.arity = declaredArity [2] ∧
    checkRepresentation source74 masg_tree74 = true ∧
    checkRepresentation source74 ir_tree74 = true ∧
    checkRepresentation source74 cert_tree74 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [46, 46] = [(46, 1), (46, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call74
def table75 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration75 : Signature := (Signature.mk 6 1 2 0)
def source75 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.barrier 0 (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))])), (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))]))
def masg_tree75 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))]))
def ir_tree75 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))]))
def cert_tree75 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))]))
theorem call75 : resolve table75 6 1 2 = some declaration75 ∧
    declaration75 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration75.arity ∧
    (2 : Nat) = declaration75.arity ∧
    declaration75.arity = declaredArity [2] ∧
    checkRepresentation source75 masg_tree75 = true ∧
    checkRepresentation source75 ir_tree75 = true ∧
    checkRepresentation source75 cert_tree75 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [48, 48] = [(48, 1), (48, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call75
def table76 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration76 : Signature := (Signature.mk 1 1 1 0)
def source76 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree76 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree76 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree76 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call76 : resolve table76 1 1 1 = some declaration76 ∧
    declaration76 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration76.arity ∧
    (1 : Nat) = declaration76.arity ∧
    declaration76.arity = declaredArity [1] ∧
    checkRepresentation source76 masg_tree76 = true ∧
    checkRepresentation source76 ir_tree76 = true ∧
    checkRepresentation source76 cert_tree76 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [49, 49] = [(49, 1), (49, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call76
def table77 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration77 : Signature := (Signature.mk 1 1 1 0)
def source77 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))
def masg_tree77 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def ir_tree77 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def cert_tree77 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
theorem call77 : resolve table77 1 1 1 = some declaration77 ∧
    declaration77 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration77.arity ∧
    (1 : Nat) = declaration77.arity ∧
    declaration77.arity = declaredArity [1] ∧
    checkRepresentation source77 masg_tree77 = true ∧
    checkRepresentation source77 ir_tree77 = true ∧
    checkRepresentation source77 cert_tree77 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [50, 50] = [(50, 1), (50, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call77
def table78 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration78 : Signature := (Signature.mk 6 1 2 0)
def source78 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)])), (.barrier 0 (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))]))]))
def masg_tree78 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)])), (.boundary 0 (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))]))
def ir_tree78 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)])), (.boundary 0 (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))]))
def cert_tree78 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)])), (.boundary 0 (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))]))
theorem call78 : resolve table78 6 1 2 = some declaration78 ∧
    declaration78 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration78.arity ∧
    (2 : Nat) = declaration78.arity ∧
    declaration78.arity = declaredArity [2] ∧
    checkRepresentation source78 masg_tree78 = true ∧
    checkRepresentation source78 ir_tree78 = true ∧
    checkRepresentation source78 cert_tree78 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [52, 52] = [(52, 1), (52, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call78
def table79 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration79 : Signature := (Signature.mk 1 1 1 0)
def source79 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 2)]))
def masg_tree79 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def ir_tree79 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
def cert_tree79 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 2)]))
theorem call79 : resolve table79 1 1 1 = some declaration79 ∧
    declaration79 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration79.arity ∧
    (1 : Nat) = declaration79.arity ∧
    declaration79.arity = declaredArity [1] ∧
    checkRepresentation source79 masg_tree79 = true ∧
    checkRepresentation source79 ir_tree79 = true ∧
    checkRepresentation source79 cert_tree79 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [53, 53] = [(53, 1), (53, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call79
def table80 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration80 : Signature := (Signature.mk 1 1 1 0)
def source80 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree80 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree80 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree80 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call80 : resolve table80 1 1 1 = some declaration80 ∧
    declaration80 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration80.arity ∧
    (1 : Nat) = declaration80.arity ∧
    declaration80.arity = declaredArity [1] ∧
    checkRepresentation source80 masg_tree80 = true ∧
    checkRepresentation source80 ir_tree80 = true ∧
    checkRepresentation source80 cert_tree80 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [54, 54] = [(54, 1), (54, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call80
def table81 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration81 : Signature := (Signature.mk 1 1 1 0)
def source81 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.barrier 0 (sourceArgs [(.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))]))]))
def masg_tree81 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
def ir_tree81 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
def cert_tree81 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
theorem call81 : resolve table81 1 1 1 = some declaration81 ∧
    declaration81 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration81.arity ∧
    (1 : Nat) = declaration81.arity ∧
    declaration81.arity = declaredArity [1] ∧
    checkRepresentation source81 masg_tree81 = true ∧
    checkRepresentation source81 ir_tree81 = true ∧
    checkRepresentation source81 cert_tree81 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [56, 56] = [(56, 1), (56, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call81
def table82 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration82 : Signature := (Signature.mk 6 1 2 0)
def source82 : Source := (.call (Signature.mk 6 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))
def masg_tree82 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def ir_tree82 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
def cert_tree82 : Representation := (.application (Signature.mk 6 1 2 0) (ports [(.scalar 1), (.scalar 2)]))
theorem call82 : resolve table82 6 1 2 = some declaration82 ∧
    declaration82 = (Signature.mk 6 1 2 0) ∧
    JavaAritySafe declaration82.arity ∧
    (2 : Nat) = declaration82.arity ∧
    declaration82.arity = declaredArity [2] ∧
    checkRepresentation source82 masg_tree82 = true ∧
    checkRepresentation source82 ir_tree82 = true ∧
    checkRepresentation source82 cert_tree82 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [57, 57] = [(57, 1), (57, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call82
def table83 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration83 : Signature := (Signature.mk 23 0 2 0)
def source83 : Source := (.call (Signature.mk 23 0 2 0) (sourceArgs [(.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)])), (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))]))
def masg_tree83 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def ir_tree83 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
def cert_tree83 : Representation := (.application (Signature.mk 23 0 2 0) (ports [(.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)])), (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))]))
theorem call83 : resolve table83 23 0 2 = some declaration83 ∧
    declaration83 = (Signature.mk 23 0 2 0) ∧
    JavaAritySafe declaration83.arity ∧
    (2 : Nat) = declaration83.arity ∧
    declaration83.arity = declaredArity [2] ∧
    checkRepresentation source83 masg_tree83 = true ∧
    checkRepresentation source83 ir_tree83 = true ∧
    checkRepresentation source83 cert_tree83 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [59, 59] = [(59, 1), (59, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call83
def table84 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration84 : Signature := (Signature.mk 1 1 1 0)
def source84 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree84 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree84 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree84 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call84 : resolve table84 1 1 1 = some declaration84 ∧
    declaration84 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration84.arity ∧
    (1 : Nat) = declaration84.arity ∧
    declaration84.arity = declaredArity [1] ∧
    checkRepresentation source84 masg_tree84 = true ∧
    checkRepresentation source84 ir_tree84 = true ∧
    checkRepresentation source84 cert_tree84 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [60, 60] = [(60, 1), (60, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call84
def table85 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 6 1 2 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 0 0), (Signature.mk 18 0 0 0), (Signature.mk 19 0 0 0), (Signature.mk 20 0 0 0), (Signature.mk 21 0 0 0), (Signature.mk 22 0 0 0), (Signature.mk 23 0 2 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1)]
def declaration85 : Signature := (Signature.mk 1 1 1 0)
def source85 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.atom 1)]))
def masg_tree85 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def ir_tree85 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
def cert_tree85 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.scalar 1)]))
theorem call85 : resolve table85 1 1 1 = some declaration85 ∧
    declaration85 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration85.arity ∧
    (1 : Nat) = declaration85.arity ∧
    declaration85.arity = declaredArity [1] ∧
    checkRepresentation source85 masg_tree85 = true ∧
    checkRepresentation source85 ir_tree85 = true ∧
    checkRepresentation source85 cert_tree85 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [61, 61] = [(61, 1), (61, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call85
def table86 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1), (Signature.mk 32 1 0 1), (Signature.mk 33 0 2 1), (Signature.mk 34 0 2 1), (Signature.mk 35 1 2 1), (Signature.mk 36 1 0 1), (Signature.mk 37 0 2 1), (Signature.mk 38 0 2 1), (Signature.mk 39 1 1 1), (Signature.mk 40 1 1 1), (Signature.mk 41 1 0 1), (Signature.mk 42 1 1 1), (Signature.mk 43 1 0 1), (Signature.mk 44 1 1 1), (Signature.mk 45 1 2 1)]
def declaration86 : Signature := (Signature.mk 37 0 2 1)
def source86 : Source := (.call (Signature.mk 37 0 2 1) (sourceArgs [(.call (Signature.mk 32 1 0 1) (sourceArgs [])), (.call (Signature.mk 36 1 0 1) (sourceArgs []))]))
def masg_tree86 : Representation := (.application (Signature.mk 37 0 2 1) (ports [(.application (Signature.mk 32 1 0 1) (ports [])), (.application (Signature.mk 36 1 0 1) (ports []))]))
def ir_tree86 : Representation := (.application (Signature.mk 37 0 2 1) (ports [(.application (Signature.mk 32 1 0 1) (ports [])), (.application (Signature.mk 36 1 0 1) (ports []))]))
def cert_tree86 : Representation := (.application (Signature.mk 37 0 2 1) (ports [(.application (Signature.mk 32 1 0 1) (ports [])), (.application (Signature.mk 36 1 0 1) (ports []))]))
theorem call86 : resolve table86 37 0 2 = some declaration86 ∧
    declaration86 = (Signature.mk 37 0 2 1) ∧
    JavaAritySafe declaration86.arity ∧
    (2 : Nat) = declaration86.arity ∧
    checkRepresentation source86 masg_tree86 = true ∧
    checkRepresentation source86 ir_tree86 = true ∧
    checkRepresentation source86 cert_tree86 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [12, 12] = [(12, 1), (12, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call86
def table87 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1), (Signature.mk 32 1 0 1), (Signature.mk 33 0 2 1), (Signature.mk 34 0 2 1), (Signature.mk 35 1 2 1), (Signature.mk 36 1 0 1), (Signature.mk 37 0 2 1), (Signature.mk 38 0 2 1), (Signature.mk 39 1 1 1), (Signature.mk 40 1 1 1), (Signature.mk 41 1 0 1), (Signature.mk 42 1 1 1), (Signature.mk 43 1 0 1), (Signature.mk 44 1 1 1), (Signature.mk 45 1 2 1)]
def declaration87 : Signature := (Signature.mk 32 1 0 1)
def source87 : Source := (.call (Signature.mk 32 1 0 1) (sourceArgs []))
def masg_tree87 : Representation := (.application (Signature.mk 32 1 0 1) (ports []))
def ir_tree87 : Representation := (.application (Signature.mk 32 1 0 1) (ports []))
def cert_tree87 : Representation := (.application (Signature.mk 32 1 0 1) (ports []))
theorem call87 : resolve table87 32 1 0 = some declaration87 ∧
    declaration87 = (Signature.mk 32 1 0 1) ∧
    JavaAritySafe declaration87.arity ∧
    (0 : Nat) = declaration87.arity ∧
    checkRepresentation source87 masg_tree87 = true ∧
    checkRepresentation source87 ir_tree87 = true ∧
    checkRepresentation source87 cert_tree87 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [14, 14] = [(14, 1), (14, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call87
def table88 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1), (Signature.mk 32 1 0 1), (Signature.mk 33 0 2 1), (Signature.mk 34 0 2 1), (Signature.mk 35 1 2 1), (Signature.mk 36 1 0 1), (Signature.mk 37 0 2 1), (Signature.mk 38 0 2 1), (Signature.mk 39 1 1 1), (Signature.mk 40 1 1 1), (Signature.mk 41 1 0 1), (Signature.mk 42 1 1 1), (Signature.mk 43 1 0 1), (Signature.mk 44 1 1 1), (Signature.mk 45 1 2 1)]
def declaration88 : Signature := (Signature.mk 36 1 0 1)
def source88 : Source := (.call (Signature.mk 36 1 0 1) (sourceArgs []))
def masg_tree88 : Representation := (.application (Signature.mk 36 1 0 1) (ports []))
def ir_tree88 : Representation := (.application (Signature.mk 36 1 0 1) (ports []))
def cert_tree88 : Representation := (.application (Signature.mk 36 1 0 1) (ports []))
theorem call88 : resolve table88 36 1 0 = some declaration88 ∧
    declaration88 = (Signature.mk 36 1 0 1) ∧
    JavaAritySafe declaration88.arity ∧
    (0 : Nat) = declaration88.arity ∧
    checkRepresentation source88 masg_tree88 = true ∧
    checkRepresentation source88 ir_tree88 = true ∧
    checkRepresentation source88 cert_tree88 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [16, 16] = [(16, 1), (16, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call88
def table89 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1), (Signature.mk 32 1 0 1), (Signature.mk 33 0 2 1), (Signature.mk 34 0 2 1), (Signature.mk 35 1 2 1), (Signature.mk 36 1 0 1), (Signature.mk 37 0 2 1), (Signature.mk 38 0 2 1), (Signature.mk 39 1 1 1), (Signature.mk 40 1 1 1), (Signature.mk 41 1 0 1), (Signature.mk 42 1 1 1), (Signature.mk 43 1 0 1), (Signature.mk 44 1 1 1), (Signature.mk 45 1 2 1)]
def declaration89 : Signature := (Signature.mk 42 1 1 1)
def source89 : Source := (.call (Signature.mk 42 1 1 1) (sourceArgs [(.call (Signature.mk 32 1 0 1) (sourceArgs []))]))
def masg_tree89 : Representation := (.application (Signature.mk 42 1 1 1) (ports [(.application (Signature.mk 32 1 0 1) (ports []))]))
def ir_tree89 : Representation := (.application (Signature.mk 42 1 1 1) (ports [(.application (Signature.mk 32 1 0 1) (ports []))]))
def cert_tree89 : Representation := (.application (Signature.mk 42 1 1 1) (ports [(.application (Signature.mk 32 1 0 1) (ports []))]))
theorem call89 : resolve table89 42 1 1 = some declaration89 ∧
    declaration89 = (Signature.mk 42 1 1 1) ∧
    JavaAritySafe declaration89.arity ∧
    (1 : Nat) = declaration89.arity ∧
    checkRepresentation source89 masg_tree89 = true ∧
    checkRepresentation source89 ir_tree89 = true ∧
    checkRepresentation source89 cert_tree89 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [20, 20] = [(20, 1), (20, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call89
def table90 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 28 1 0 1), (Signature.mk 28 1 1 1), (Signature.mk 29 1 0 1), (Signature.mk 29 1 1 1), (Signature.mk 30 1 0 1), (Signature.mk 31 1 0 1), (Signature.mk 32 1 0 1), (Signature.mk 33 0 2 1), (Signature.mk 34 0 2 1), (Signature.mk 35 1 2 1), (Signature.mk 36 1 0 1), (Signature.mk 37 0 2 1), (Signature.mk 38 0 2 1), (Signature.mk 39 1 1 1), (Signature.mk 40 1 1 1), (Signature.mk 41 1 0 1), (Signature.mk 42 1 1 1), (Signature.mk 43 1 0 1), (Signature.mk 44 1 1 1), (Signature.mk 45 1 2 1)]
def declaration90 : Signature := (Signature.mk 32 1 0 1)
def source90 : Source := (.call (Signature.mk 32 1 0 1) (sourceArgs []))
def masg_tree90 : Representation := (.application (Signature.mk 32 1 0 1) (ports []))
def ir_tree90 : Representation := (.application (Signature.mk 32 1 0 1) (ports []))
def cert_tree90 : Representation := (.application (Signature.mk 32 1 0 1) (ports []))
theorem call90 : resolve table90 32 1 0 = some declaration90 ∧
    declaration90 = (Signature.mk 32 1 0 1) ∧
    JavaAritySafe declaration90.arity ∧
    (0 : Nat) = declaration90.arity ∧
    checkRepresentation source90 masg_tree90 = true ∧
    checkRepresentation source90 ir_tree90 = true ∧
    checkRepresentation source90 cert_tree90 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [22, 22] = [(22, 1), (22, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call90
end ACGN.ThirdFive.CallReplay
