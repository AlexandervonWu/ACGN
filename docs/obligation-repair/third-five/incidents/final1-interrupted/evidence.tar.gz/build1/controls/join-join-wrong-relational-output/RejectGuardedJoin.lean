import GuardedJoinChain
namespace ACGN.ThirdFive.JoinReplay
open ACGN.ThirdFive.GuardedJoinChain
open ACGN.Section3.DependentChainSequence
open ACGN.BoundedFive.DependentJoinGuard (guard)
theorem source0 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source0
theorem source1 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source1
theorem source2 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source2
theorem source3 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source3
theorem observation0 : guard .JOIN [] = false ∧
    guard .JOIN [] = false := by
  simp only [guard_executable]
  decide
#print axioms observation0
theorem observation1 : guard .JOIN [1] = false ∧
    guard .JOIN [1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation1
theorem observation2 : guard .JOIN [2] = false ∧
    guard .JOIN [2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation2
theorem observation3 : guard .JOIN [3] = false ∧
    guard .JOIN [3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation3
theorem observation4 : guard .JOIN [1, 1] = true ∧
    guard .JOIN [1, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation4
theorem observation5 : guard .JOIN [1, 2] = true ∧
    guard .JOIN [1, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation5
theorem observation6 : guard .JOIN [1, 3] = true ∧
    guard .JOIN [1, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation6
theorem observation7 : guard .JOIN [2, 1] = true ∧
    guard .JOIN [2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation7
theorem observation8 : guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation8
theorem observation9 : guard .JOIN [2, 3] = true ∧
    guard .JOIN [2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation9
theorem observation10 : guard .JOIN [3, 1] = true ∧
    guard .JOIN [3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation10
theorem observation11 : guard .JOIN [3, 2] = true ∧
    guard .JOIN [3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation11
theorem observation12 : guard .JOIN [3, 3] = true ∧
    guard .JOIN [3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation12
theorem observation13 : guard .JOIN [1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation13
theorem observation14 : guard .JOIN [1, 1, 2] = false ∧
    guard .JOIN [1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation14
theorem observation15 : guard .JOIN [1, 1, 3] = false ∧
    guard .JOIN [1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation15
theorem observation16 : guard .JOIN [1, 2, 1] = true ∧
    guard .JOIN [1, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation16
theorem observation17 : guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation17
theorem observation18 : guard .JOIN [1, 2, 3] = true ∧
    guard .JOIN [1, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation18
theorem observation19 : guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation19
theorem observation20 : guard .JOIN [1, 3, 2] = true ∧
    guard .JOIN [1, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation20
theorem observation21 : guard .JOIN [1, 3, 3] = true ∧
    guard .JOIN [1, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation21
theorem observation22 : guard .JOIN [2, 1, 1] = false ∧
    guard .JOIN [2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation22
theorem observation23 : guard .JOIN [2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation23
theorem observation24 : guard .JOIN [2, 1, 3] = false ∧
    guard .JOIN [2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation24
theorem observation25 : guard .JOIN [2, 2, 1] = true ∧
    guard .JOIN [2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation25
theorem observation26 : guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation26
theorem observation27 : guard .JOIN [2, 2, 3] = true ∧
    guard .JOIN [2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation27
theorem observation28 : guard .JOIN [2, 3, 1] = true ∧
    guard .JOIN [2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation28
theorem observation29 : guard .JOIN [2, 3, 2] = true ∧
    guard .JOIN [2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation29
theorem observation30 : guard .JOIN [2, 3, 3] = true ∧
    guard .JOIN [2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation30
theorem observation31 : guard .JOIN [3, 1, 1] = false ∧
    guard .JOIN [3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation31
theorem observation32 : guard .JOIN [3, 1, 2] = false ∧
    guard .JOIN [3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation32
theorem observation33 : guard .JOIN [3, 1, 3] = false ∧
    guard .JOIN [3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation33
theorem observation34 : guard .JOIN [3, 2, 1] = true ∧
    guard .JOIN [3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation34
theorem observation35 : guard .JOIN [3, 2, 2] = true ∧
    guard .JOIN [3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation35
theorem observation36 : guard .JOIN [3, 2, 3] = true ∧
    guard .JOIN [3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation36
theorem observation37 : guard .JOIN [3, 3, 1] = true ∧
    guard .JOIN [3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation37
theorem observation38 : guard .JOIN [3, 3, 2] = true ∧
    guard .JOIN [3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation38
theorem observation39 : guard .JOIN [3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation39
theorem observation40 : guard .JOIN [1, 1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation40
theorem observation41 : guard .JOIN [1, 1, 1, 2] = false ∧
    guard .JOIN [1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation41
theorem observation42 : guard .JOIN [1, 1, 1, 3] = false ∧
    guard .JOIN [1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation42
theorem observation43 : guard .JOIN [1, 1, 2, 1] = false ∧
    guard .JOIN [1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation43
theorem observation44 : guard .JOIN [1, 1, 2, 2] = false ∧
    guard .JOIN [1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation44
theorem observation45 : guard .JOIN [1, 1, 2, 3] = false ∧
    guard .JOIN [1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation45
theorem observation46 : guard .JOIN [1, 1, 3, 1] = false ∧
    guard .JOIN [1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation46
theorem observation47 : guard .JOIN [1, 1, 3, 2] = false ∧
    guard .JOIN [1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation47
theorem observation48 : guard .JOIN [1, 1, 3, 3] = false ∧
    guard .JOIN [1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation48
theorem observation49 : guard .JOIN [1, 2, 1, 1] = false ∧
    guard .JOIN [1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation49
theorem observation50 : guard .JOIN [1, 2, 1, 2] = false ∧
    guard .JOIN [1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation50
theorem observation51 : guard .JOIN [1, 2, 1, 3] = false ∧
    guard .JOIN [1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation51
theorem observation52 : guard .JOIN [1, 2, 2, 1] = true ∧
    guard .JOIN [1, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation52
theorem observation53 : guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation53
theorem observation54 : guard .JOIN [1, 2, 2, 3] = true ∧
    guard .JOIN [1, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation54
theorem observation55 : guard .JOIN [1, 2, 3, 1] = true ∧
    guard .JOIN [1, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation55
theorem observation56 : guard .JOIN [1, 2, 3, 2] = true ∧
    guard .JOIN [1, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation56
theorem observation57 : guard .JOIN [1, 2, 3, 3] = true ∧
    guard .JOIN [1, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation57
theorem observation58 : guard .JOIN [1, 3, 1, 1] = false ∧
    guard .JOIN [1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation58
theorem observation59 : guard .JOIN [1, 3, 1, 2] = false ∧
    guard .JOIN [1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation59
theorem observation60 : guard .JOIN [1, 3, 1, 3] = false ∧
    guard .JOIN [1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation60
theorem observation61 : guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation61
theorem observation62 : guard .JOIN [1, 3, 2, 2] = true ∧
    guard .JOIN [1, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation62
theorem observation63 : guard .JOIN [1, 3, 2, 3] = true ∧
    guard .JOIN [1, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation63
theorem observation64 : guard .JOIN [1, 3, 3, 1] = true ∧
    guard .JOIN [1, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation64
theorem observation65 : guard .JOIN [1, 3, 3, 2] = true ∧
    guard .JOIN [1, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation65
theorem observation66 : guard .JOIN [1, 3, 3, 3] = true ∧
    guard .JOIN [1, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation66
theorem observation67 : guard .JOIN [2, 1, 1, 1] = false ∧
    guard .JOIN [2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation67
theorem observation68 : guard .JOIN [2, 1, 1, 2] = false ∧
    guard .JOIN [2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation68
theorem observation69 : guard .JOIN [2, 1, 1, 3] = false ∧
    guard .JOIN [2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation69
theorem observation70 : guard .JOIN [2, 1, 2, 1] = false ∧
    guard .JOIN [2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation70
theorem observation71 : guard .JOIN [2, 1, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation71
theorem observation72 : guard .JOIN [2, 1, 2, 3] = false ∧
    guard .JOIN [2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation72
theorem observation73 : guard .JOIN [2, 1, 3, 1] = false ∧
    guard .JOIN [2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation73
theorem observation74 : guard .JOIN [2, 1, 3, 2] = false ∧
    guard .JOIN [2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation74
theorem observation75 : guard .JOIN [2, 1, 3, 3] = false ∧
    guard .JOIN [2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation75
theorem observation76 : guard .JOIN [2, 2, 1, 1] = false ∧
    guard .JOIN [2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation76
theorem observation77 : guard .JOIN [2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation77
theorem observation78 : guard .JOIN [2, 2, 1, 3] = false ∧
    guard .JOIN [2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation78
theorem observation79 : guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation79
theorem observation80 : guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation80
theorem observation81 : guard .JOIN [2, 2, 2, 3] = true ∧
    guard .JOIN [2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation81
theorem observation82 : guard .JOIN [2, 2, 3, 1] = true ∧
    guard .JOIN [2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation82
theorem observation83 : guard .JOIN [2, 2, 3, 2] = true ∧
    guard .JOIN [2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation83
theorem observation84 : guard .JOIN [2, 2, 3, 3] = true ∧
    guard .JOIN [2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation84
theorem observation85 : guard .JOIN [2, 3, 1, 1] = false ∧
    guard .JOIN [2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation85
theorem observation86 : guard .JOIN [2, 3, 1, 2] = false ∧
    guard .JOIN [2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation86
theorem observation87 : guard .JOIN [2, 3, 1, 3] = false ∧
    guard .JOIN [2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation87
theorem observation88 : guard .JOIN [2, 3, 2, 1] = true ∧
    guard .JOIN [2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation88
theorem observation89 : guard .JOIN [2, 3, 2, 2] = true ∧
    guard .JOIN [2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation89
theorem observation90 : guard .JOIN [2, 3, 2, 3] = true ∧
    guard .JOIN [2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation90
theorem observation91 : guard .JOIN [2, 3, 3, 1] = true ∧
    guard .JOIN [2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation91
theorem observation92 : guard .JOIN [2, 3, 3, 2] = true ∧
    guard .JOIN [2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation92
theorem observation93 : guard .JOIN [2, 3, 3, 3] = true ∧
    guard .JOIN [2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation93
theorem observation94 : guard .JOIN [3, 1, 1, 1] = false ∧
    guard .JOIN [3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation94
theorem observation95 : guard .JOIN [3, 1, 1, 2] = false ∧
    guard .JOIN [3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation95
theorem observation96 : guard .JOIN [3, 1, 1, 3] = false ∧
    guard .JOIN [3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation96
theorem observation97 : guard .JOIN [3, 1, 2, 1] = false ∧
    guard .JOIN [3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation97
theorem observation98 : guard .JOIN [3, 1, 2, 2] = false ∧
    guard .JOIN [3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation98
theorem observation99 : guard .JOIN [3, 1, 2, 3] = false ∧
    guard .JOIN [3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation99
theorem observation100 : guard .JOIN [3, 1, 3, 1] = false ∧
    guard .JOIN [3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation100
theorem observation101 : guard .JOIN [3, 1, 3, 2] = false ∧
    guard .JOIN [3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation101
theorem observation102 : guard .JOIN [3, 1, 3, 3] = false ∧
    guard .JOIN [3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation102
theorem observation103 : guard .JOIN [3, 2, 1, 1] = false ∧
    guard .JOIN [3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation103
theorem observation104 : guard .JOIN [3, 2, 1, 2] = false ∧
    guard .JOIN [3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation104
theorem observation105 : guard .JOIN [3, 2, 1, 3] = false ∧
    guard .JOIN [3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation105
theorem observation106 : guard .JOIN [3, 2, 2, 1] = true ∧
    guard .JOIN [3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation106
theorem observation107 : guard .JOIN [3, 2, 2, 2] = true ∧
    guard .JOIN [3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation107
theorem observation108 : guard .JOIN [3, 2, 2, 3] = true ∧
    guard .JOIN [3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation108
theorem observation109 : guard .JOIN [3, 2, 3, 1] = true ∧
    guard .JOIN [3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation109
theorem observation110 : guard .JOIN [3, 2, 3, 2] = true ∧
    guard .JOIN [3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation110
theorem observation111 : guard .JOIN [3, 2, 3, 3] = true ∧
    guard .JOIN [3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation111
theorem observation112 : guard .JOIN [3, 3, 1, 1] = false ∧
    guard .JOIN [3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation112
theorem observation113 : guard .JOIN [3, 3, 1, 2] = false ∧
    guard .JOIN [3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation113
theorem observation114 : guard .JOIN [3, 3, 1, 3] = false ∧
    guard .JOIN [3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation114
theorem observation115 : guard .JOIN [3, 3, 2, 1] = true ∧
    guard .JOIN [3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation115
theorem observation116 : guard .JOIN [3, 3, 2, 2] = true ∧
    guard .JOIN [3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation116
theorem observation117 : guard .JOIN [3, 3, 2, 3] = true ∧
    guard .JOIN [3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation117
theorem observation118 : guard .JOIN [3, 3, 3, 1] = true ∧
    guard .JOIN [3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation118
theorem observation119 : guard .JOIN [3, 3, 3, 2] = true ∧
    guard .JOIN [3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation119
theorem observation120 : guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation120
theorem observation121 : guard .JOIN [1, 1, 1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation121
theorem observation122 : guard .JOIN [1, 1, 1, 1, 2] = false ∧
    guard .JOIN [1, 1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation122
theorem observation123 : guard .JOIN [1, 1, 1, 1, 3] = false ∧
    guard .JOIN [1, 1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation123
theorem observation124 : guard .JOIN [1, 1, 1, 2, 1] = false ∧
    guard .JOIN [1, 1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation124
theorem observation125 : guard .JOIN [1, 1, 1, 2, 2] = false ∧
    guard .JOIN [1, 1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation125
theorem observation126 : guard .JOIN [1, 1, 1, 2, 3] = false ∧
    guard .JOIN [1, 1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation126
theorem observation127 : guard .JOIN [1, 1, 1, 3, 1] = false ∧
    guard .JOIN [1, 1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation127
theorem observation128 : guard .JOIN [1, 1, 1, 3, 2] = false ∧
    guard .JOIN [1, 1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation128
theorem observation129 : guard .JOIN [1, 1, 1, 3, 3] = false ∧
    guard .JOIN [1, 1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation129
theorem observation130 : guard .JOIN [1, 1, 2, 1, 1] = false ∧
    guard .JOIN [1, 1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation130
theorem observation131 : guard .JOIN [1, 1, 2, 1, 2] = false ∧
    guard .JOIN [1, 1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation131
theorem observation132 : guard .JOIN [1, 1, 2, 1, 3] = false ∧
    guard .JOIN [1, 1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation132
theorem observation133 : guard .JOIN [1, 1, 2, 2, 1] = false ∧
    guard .JOIN [1, 1, 2, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation133
theorem observation134 : guard .JOIN [1, 1, 2, 2, 2] = false ∧
    guard .JOIN [1, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation134
theorem observation135 : guard .JOIN [1, 1, 2, 2, 3] = false ∧
    guard .JOIN [1, 1, 2, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation135
theorem observation136 : guard .JOIN [1, 1, 2, 3, 1] = false ∧
    guard .JOIN [1, 1, 2, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation136
theorem observation137 : guard .JOIN [1, 1, 2, 3, 2] = false ∧
    guard .JOIN [1, 1, 2, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation137
theorem observation138 : guard .JOIN [1, 1, 2, 3, 3] = false ∧
    guard .JOIN [1, 1, 2, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation138
theorem observation139 : guard .JOIN [1, 1, 3, 1, 1] = false ∧
    guard .JOIN [1, 1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation139
theorem observation140 : guard .JOIN [1, 1, 3, 1, 2] = false ∧
    guard .JOIN [1, 1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation140
theorem observation141 : guard .JOIN [1, 1, 3, 1, 3] = false ∧
    guard .JOIN [1, 1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation141
theorem observation142 : guard .JOIN [1, 1, 3, 2, 1] = false ∧
    guard .JOIN [1, 1, 3, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation142
theorem observation143 : guard .JOIN [1, 1, 3, 2, 2] = false ∧
    guard .JOIN [1, 1, 3, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation143
theorem observation144 : guard .JOIN [1, 1, 3, 2, 3] = false ∧
    guard .JOIN [1, 1, 3, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation144
theorem observation145 : guard .JOIN [1, 1, 3, 3, 1] = false ∧
    guard .JOIN [1, 1, 3, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation145
theorem observation146 : guard .JOIN [1, 1, 3, 3, 2] = false ∧
    guard .JOIN [1, 1, 3, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation146
theorem observation147 : guard .JOIN [1, 1, 3, 3, 3] = false ∧
    guard .JOIN [1, 1, 3, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation147
theorem observation148 : guard .JOIN [1, 2, 1, 1, 1] = false ∧
    guard .JOIN [1, 2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation148
theorem observation149 : guard .JOIN [1, 2, 1, 1, 2] = false ∧
    guard .JOIN [1, 2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation149
theorem observation150 : guard .JOIN [1, 2, 1, 1, 3] = false ∧
    guard .JOIN [1, 2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation150
theorem observation151 : guard .JOIN [1, 2, 1, 2, 1] = false ∧
    guard .JOIN [1, 2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation151
theorem observation152 : guard .JOIN [1, 2, 1, 2, 2] = false ∧
    guard .JOIN [1, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation152
theorem observation153 : guard .JOIN [1, 2, 1, 2, 3] = false ∧
    guard .JOIN [1, 2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation153
theorem observation154 : guard .JOIN [1, 2, 1, 3, 1] = false ∧
    guard .JOIN [1, 2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation154
theorem observation155 : guard .JOIN [1, 2, 1, 3, 2] = false ∧
    guard .JOIN [1, 2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation155
theorem observation156 : guard .JOIN [1, 2, 1, 3, 3] = false ∧
    guard .JOIN [1, 2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation156
theorem observation157 : guard .JOIN [1, 2, 2, 1, 1] = false ∧
    guard .JOIN [1, 2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation157
theorem observation158 : guard .JOIN [1, 2, 2, 1, 2] = false ∧
    guard .JOIN [1, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation158
theorem observation159 : guard .JOIN [1, 2, 2, 1, 3] = false ∧
    guard .JOIN [1, 2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation159
theorem observation160 : guard .JOIN [1, 2, 2, 2, 1] = true ∧
    guard .JOIN [1, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation160
theorem observation161 : guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation161
theorem observation162 : guard .JOIN [1, 2, 2, 2, 3] = true ∧
    guard .JOIN [1, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation162
theorem observation163 : guard .JOIN [1, 2, 2, 3, 1] = true ∧
    guard .JOIN [1, 2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation163
theorem observation164 : guard .JOIN [1, 2, 2, 3, 2] = true ∧
    guard .JOIN [1, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation164
theorem observation165 : guard .JOIN [1, 2, 2, 3, 3] = true ∧
    guard .JOIN [1, 2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation165
theorem observation166 : guard .JOIN [1, 2, 3, 1, 1] = false ∧
    guard .JOIN [1, 2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation166
theorem observation167 : guard .JOIN [1, 2, 3, 1, 2] = false ∧
    guard .JOIN [1, 2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation167
theorem observation168 : guard .JOIN [1, 2, 3, 1, 3] = false ∧
    guard .JOIN [1, 2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation168
theorem observation169 : guard .JOIN [1, 2, 3, 2, 1] = true ∧
    guard .JOIN [1, 2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation169
theorem observation170 : guard .JOIN [1, 2, 3, 2, 2] = true ∧
    guard .JOIN [1, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation170
theorem observation171 : guard .JOIN [1, 2, 3, 2, 3] = true ∧
    guard .JOIN [1, 2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation171
theorem observation172 : guard .JOIN [1, 2, 3, 3, 1] = true ∧
    guard .JOIN [1, 2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation172
theorem observation173 : guard .JOIN [1, 2, 3, 3, 2] = true ∧
    guard .JOIN [1, 2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation173
theorem observation174 : guard .JOIN [1, 2, 3, 3, 3] = true ∧
    guard .JOIN [1, 2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation174
theorem observation175 : guard .JOIN [1, 3, 1, 1, 1] = false ∧
    guard .JOIN [1, 3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation175
theorem observation176 : guard .JOIN [1, 3, 1, 1, 2] = false ∧
    guard .JOIN [1, 3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation176
theorem observation177 : guard .JOIN [1, 3, 1, 1, 3] = false ∧
    guard .JOIN [1, 3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation177
theorem observation178 : guard .JOIN [1, 3, 1, 2, 1] = false ∧
    guard .JOIN [1, 3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation178
theorem observation179 : guard .JOIN [1, 3, 1, 2, 2] = false ∧
    guard .JOIN [1, 3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation179
theorem observation180 : guard .JOIN [1, 3, 1, 2, 3] = false ∧
    guard .JOIN [1, 3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation180
theorem observation181 : guard .JOIN [1, 3, 1, 3, 1] = false ∧
    guard .JOIN [1, 3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation181
theorem observation182 : guard .JOIN [1, 3, 1, 3, 2] = false ∧
    guard .JOIN [1, 3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation182
theorem observation183 : guard .JOIN [1, 3, 1, 3, 3] = false ∧
    guard .JOIN [1, 3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation183
theorem observation184 : guard .JOIN [1, 3, 2, 1, 1] = false ∧
    guard .JOIN [1, 3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation184
theorem observation185 : guard .JOIN [1, 3, 2, 1, 2] = false ∧
    guard .JOIN [1, 3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation185
theorem observation186 : guard .JOIN [1, 3, 2, 1, 3] = false ∧
    guard .JOIN [1, 3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation186
theorem observation187 : guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation187
theorem observation188 : guard .JOIN [1, 3, 2, 2, 2] = true ∧
    guard .JOIN [1, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation188
theorem observation189 : guard .JOIN [1, 3, 2, 2, 3] = true ∧
    guard .JOIN [1, 3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation189
theorem observation190 : guard .JOIN [1, 3, 2, 3, 1] = true ∧
    guard .JOIN [1, 3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation190
theorem observation191 : guard .JOIN [1, 3, 2, 3, 2] = true ∧
    guard .JOIN [1, 3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation191
theorem observation192 : guard .JOIN [1, 3, 2, 3, 3] = true ∧
    guard .JOIN [1, 3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation192
theorem observation193 : guard .JOIN [1, 3, 3, 1, 1] = false ∧
    guard .JOIN [1, 3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation193
theorem observation194 : guard .JOIN [1, 3, 3, 1, 2] = false ∧
    guard .JOIN [1, 3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation194
theorem observation195 : guard .JOIN [1, 3, 3, 1, 3] = false ∧
    guard .JOIN [1, 3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation195
theorem observation196 : guard .JOIN [1, 3, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation196
theorem observation197 : guard .JOIN [1, 3, 3, 2, 2] = true ∧
    guard .JOIN [1, 3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation197
theorem observation198 : guard .JOIN [1, 3, 3, 2, 3] = true ∧
    guard .JOIN [1, 3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation198
theorem observation199 : guard .JOIN [1, 3, 3, 3, 1] = true ∧
    guard .JOIN [1, 3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation199
theorem observation200 : guard .JOIN [1, 3, 3, 3, 2] = true ∧
    guard .JOIN [1, 3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation200
theorem observation201 : guard .JOIN [1, 3, 3, 3, 3] = true ∧
    guard .JOIN [1, 3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation201
theorem observation202 : guard .JOIN [2, 1, 1, 1, 1] = false ∧
    guard .JOIN [2, 1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation202
theorem observation203 : guard .JOIN [2, 1, 1, 1, 2] = false ∧
    guard .JOIN [2, 1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation203
theorem observation204 : guard .JOIN [2, 1, 1, 1, 3] = false ∧
    guard .JOIN [2, 1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation204
theorem observation205 : guard .JOIN [2, 1, 1, 2, 1] = false ∧
    guard .JOIN [2, 1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation205
theorem observation206 : guard .JOIN [2, 1, 1, 2, 2] = false ∧
    guard .JOIN [2, 1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation206
theorem observation207 : guard .JOIN [2, 1, 1, 2, 3] = false ∧
    guard .JOIN [2, 1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation207
theorem observation208 : guard .JOIN [2, 1, 1, 3, 1] = false ∧
    guard .JOIN [2, 1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation208
theorem observation209 : guard .JOIN [2, 1, 1, 3, 2] = false ∧
    guard .JOIN [2, 1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation209
theorem observation210 : guard .JOIN [2, 1, 1, 3, 3] = false ∧
    guard .JOIN [2, 1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation210
theorem observation211 : guard .JOIN [2, 1, 2, 1, 1] = false ∧
    guard .JOIN [2, 1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation211
theorem observation212 : guard .JOIN [2, 1, 2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation212
theorem observation213 : guard .JOIN [2, 1, 2, 1, 3] = false ∧
    guard .JOIN [2, 1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation213
theorem observation214 : guard .JOIN [2, 1, 2, 2, 1] = false ∧
    guard .JOIN [2, 1, 2, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation214
theorem observation215 : guard .JOIN [2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation215
theorem observation216 : guard .JOIN [2, 1, 2, 2, 3] = false ∧
    guard .JOIN [2, 1, 2, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation216
theorem observation217 : guard .JOIN [2, 1, 2, 3, 1] = false ∧
    guard .JOIN [2, 1, 2, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation217
theorem observation218 : guard .JOIN [2, 1, 2, 3, 2] = false ∧
    guard .JOIN [2, 1, 2, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation218
theorem observation219 : guard .JOIN [2, 1, 2, 3, 3] = false ∧
    guard .JOIN [2, 1, 2, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation219
theorem observation220 : guard .JOIN [2, 1, 3, 1, 1] = false ∧
    guard .JOIN [2, 1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation220
theorem observation221 : guard .JOIN [2, 1, 3, 1, 2] = false ∧
    guard .JOIN [2, 1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation221
theorem observation222 : guard .JOIN [2, 1, 3, 1, 3] = false ∧
    guard .JOIN [2, 1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation222
theorem observation223 : guard .JOIN [2, 1, 3, 2, 1] = false ∧
    guard .JOIN [2, 1, 3, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation223
theorem observation224 : guard .JOIN [2, 1, 3, 2, 2] = false ∧
    guard .JOIN [2, 1, 3, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation224
theorem observation225 : guard .JOIN [2, 1, 3, 2, 3] = false ∧
    guard .JOIN [2, 1, 3, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation225
theorem observation226 : guard .JOIN [2, 1, 3, 3, 1] = false ∧
    guard .JOIN [2, 1, 3, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation226
theorem observation227 : guard .JOIN [2, 1, 3, 3, 2] = false ∧
    guard .JOIN [2, 1, 3, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation227
theorem observation228 : guard .JOIN [2, 1, 3, 3, 3] = false ∧
    guard .JOIN [2, 1, 3, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation228
theorem observation229 : guard .JOIN [2, 2, 1, 1, 1] = false ∧
    guard .JOIN [2, 2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation229
theorem observation230 : guard .JOIN [2, 2, 1, 1, 2] = false ∧
    guard .JOIN [2, 2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation230
theorem observation231 : guard .JOIN [2, 2, 1, 1, 3] = false ∧
    guard .JOIN [2, 2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation231
theorem observation232 : guard .JOIN [2, 2, 1, 2, 1] = false ∧
    guard .JOIN [2, 2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation232
theorem observation233 : guard .JOIN [2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation233
theorem observation234 : guard .JOIN [2, 2, 1, 2, 3] = false ∧
    guard .JOIN [2, 2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation234
theorem observation235 : guard .JOIN [2, 2, 1, 3, 1] = false ∧
    guard .JOIN [2, 2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation235
theorem observation236 : guard .JOIN [2, 2, 1, 3, 2] = false ∧
    guard .JOIN [2, 2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation236
theorem observation237 : guard .JOIN [2, 2, 1, 3, 3] = false ∧
    guard .JOIN [2, 2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation237
theorem observation238 : guard .JOIN [2, 2, 2, 1, 1] = false ∧
    guard .JOIN [2, 2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation238
theorem observation239 : guard .JOIN [2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation239
theorem observation240 : guard .JOIN [2, 2, 2, 1, 3] = false ∧
    guard .JOIN [2, 2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation240
theorem observation241 : guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation241
theorem observation242 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation242
theorem observation243 : guard .JOIN [2, 2, 2, 2, 3] = true ∧
    guard .JOIN [2, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation243
theorem observation244 : guard .JOIN [2, 2, 2, 3, 1] = true ∧
    guard .JOIN [2, 2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation244
theorem observation245 : guard .JOIN [2, 2, 2, 3, 2] = true ∧
    guard .JOIN [2, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation245
theorem observation246 : guard .JOIN [2, 2, 2, 3, 3] = true ∧
    guard .JOIN [2, 2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation246
theorem observation247 : guard .JOIN [2, 2, 3, 1, 1] = false ∧
    guard .JOIN [2, 2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation247
theorem observation248 : guard .JOIN [2, 2, 3, 1, 2] = false ∧
    guard .JOIN [2, 2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation248
theorem observation249 : guard .JOIN [2, 2, 3, 1, 3] = false ∧
    guard .JOIN [2, 2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation249
theorem observation250 : guard .JOIN [2, 2, 3, 2, 1] = true ∧
    guard .JOIN [2, 2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation250
theorem observation251 : guard .JOIN [2, 2, 3, 2, 2] = true ∧
    guard .JOIN [2, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation251
theorem observation252 : guard .JOIN [2, 2, 3, 2, 3] = true ∧
    guard .JOIN [2, 2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation252
theorem observation253 : guard .JOIN [2, 2, 3, 3, 1] = true ∧
    guard .JOIN [2, 2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation253
theorem observation254 : guard .JOIN [2, 2, 3, 3, 2] = true ∧
    guard .JOIN [2, 2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation254
theorem observation255 : guard .JOIN [2, 2, 3, 3, 3] = true ∧
    guard .JOIN [2, 2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation255
theorem observation256 : guard .JOIN [2, 3, 1, 1, 1] = false ∧
    guard .JOIN [2, 3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation256
theorem observation257 : guard .JOIN [2, 3, 1, 1, 2] = false ∧
    guard .JOIN [2, 3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation257
theorem observation258 : guard .JOIN [2, 3, 1, 1, 3] = false ∧
    guard .JOIN [2, 3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation258
theorem observation259 : guard .JOIN [2, 3, 1, 2, 1] = false ∧
    guard .JOIN [2, 3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation259
theorem observation260 : guard .JOIN [2, 3, 1, 2, 2] = false ∧
    guard .JOIN [2, 3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation260
theorem observation261 : guard .JOIN [2, 3, 1, 2, 3] = false ∧
    guard .JOIN [2, 3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation261
theorem observation262 : guard .JOIN [2, 3, 1, 3, 1] = false ∧
    guard .JOIN [2, 3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation262
theorem observation263 : guard .JOIN [2, 3, 1, 3, 2] = false ∧
    guard .JOIN [2, 3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation263
theorem observation264 : guard .JOIN [2, 3, 1, 3, 3] = false ∧
    guard .JOIN [2, 3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation264
theorem observation265 : guard .JOIN [2, 3, 2, 1, 1] = false ∧
    guard .JOIN [2, 3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation265
theorem observation266 : guard .JOIN [2, 3, 2, 1, 2] = false ∧
    guard .JOIN [2, 3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation266
theorem observation267 : guard .JOIN [2, 3, 2, 1, 3] = false ∧
    guard .JOIN [2, 3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation267
theorem observation268 : guard .JOIN [2, 3, 2, 2, 1] = true ∧
    guard .JOIN [2, 3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation268
theorem observation269 : guard .JOIN [2, 3, 2, 2, 2] = true ∧
    guard .JOIN [2, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation269
theorem observation270 : guard .JOIN [2, 3, 2, 2, 3] = true ∧
    guard .JOIN [2, 3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation270
theorem observation271 : guard .JOIN [2, 3, 2, 3, 1] = true ∧
    guard .JOIN [2, 3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation271
theorem observation272 : guard .JOIN [2, 3, 2, 3, 2] = true ∧
    guard .JOIN [2, 3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation272
theorem observation273 : guard .JOIN [2, 3, 2, 3, 3] = true ∧
    guard .JOIN [2, 3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation273
theorem observation274 : guard .JOIN [2, 3, 3, 1, 1] = false ∧
    guard .JOIN [2, 3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation274
theorem observation275 : guard .JOIN [2, 3, 3, 1, 2] = false ∧
    guard .JOIN [2, 3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation275
theorem observation276 : guard .JOIN [2, 3, 3, 1, 3] = false ∧
    guard .JOIN [2, 3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation276
theorem observation277 : guard .JOIN [2, 3, 3, 2, 1] = true ∧
    guard .JOIN [2, 3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation277
theorem observation278 : guard .JOIN [2, 3, 3, 2, 2] = true ∧
    guard .JOIN [2, 3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation278
theorem observation279 : guard .JOIN [2, 3, 3, 2, 3] = true ∧
    guard .JOIN [2, 3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation279
theorem observation280 : guard .JOIN [2, 3, 3, 3, 1] = true ∧
    guard .JOIN [2, 3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation280
theorem observation281 : guard .JOIN [2, 3, 3, 3, 2] = true ∧
    guard .JOIN [2, 3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation281
theorem observation282 : guard .JOIN [2, 3, 3, 3, 3] = true ∧
    guard .JOIN [2, 3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation282
theorem observation283 : guard .JOIN [3, 1, 1, 1, 1] = false ∧
    guard .JOIN [3, 1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation283
theorem observation284 : guard .JOIN [3, 1, 1, 1, 2] = false ∧
    guard .JOIN [3, 1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation284
theorem observation285 : guard .JOIN [3, 1, 1, 1, 3] = false ∧
    guard .JOIN [3, 1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation285
theorem observation286 : guard .JOIN [3, 1, 1, 2, 1] = false ∧
    guard .JOIN [3, 1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation286
theorem observation287 : guard .JOIN [3, 1, 1, 2, 2] = false ∧
    guard .JOIN [3, 1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation287
theorem observation288 : guard .JOIN [3, 1, 1, 2, 3] = false ∧
    guard .JOIN [3, 1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation288
theorem observation289 : guard .JOIN [3, 1, 1, 3, 1] = false ∧
    guard .JOIN [3, 1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation289
theorem observation290 : guard .JOIN [3, 1, 1, 3, 2] = false ∧
    guard .JOIN [3, 1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation290
theorem observation291 : guard .JOIN [3, 1, 1, 3, 3] = false ∧
    guard .JOIN [3, 1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation291
theorem observation292 : guard .JOIN [3, 1, 2, 1, 1] = false ∧
    guard .JOIN [3, 1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation292
theorem observation293 : guard .JOIN [3, 1, 2, 1, 2] = false ∧
    guard .JOIN [3, 1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation293
theorem observation294 : guard .JOIN [3, 1, 2, 1, 3] = false ∧
    guard .JOIN [3, 1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation294
theorem observation295 : guard .JOIN [3, 1, 2, 2, 1] = false ∧
    guard .JOIN [3, 1, 2, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation295
theorem observation296 : guard .JOIN [3, 1, 2, 2, 2] = false ∧
    guard .JOIN [3, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation296
theorem observation297 : guard .JOIN [3, 1, 2, 2, 3] = false ∧
    guard .JOIN [3, 1, 2, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation297
theorem observation298 : guard .JOIN [3, 1, 2, 3, 1] = false ∧
    guard .JOIN [3, 1, 2, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation298
theorem observation299 : guard .JOIN [3, 1, 2, 3, 2] = false ∧
    guard .JOIN [3, 1, 2, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation299
theorem observation300 : guard .JOIN [3, 1, 2, 3, 3] = false ∧
    guard .JOIN [3, 1, 2, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation300
theorem observation301 : guard .JOIN [3, 1, 3, 1, 1] = false ∧
    guard .JOIN [3, 1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation301
theorem observation302 : guard .JOIN [3, 1, 3, 1, 2] = false ∧
    guard .JOIN [3, 1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation302
theorem observation303 : guard .JOIN [3, 1, 3, 1, 3] = false ∧
    guard .JOIN [3, 1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation303
theorem observation304 : guard .JOIN [3, 1, 3, 2, 1] = false ∧
    guard .JOIN [3, 1, 3, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation304
theorem observation305 : guard .JOIN [3, 1, 3, 2, 2] = false ∧
    guard .JOIN [3, 1, 3, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation305
theorem observation306 : guard .JOIN [3, 1, 3, 2, 3] = false ∧
    guard .JOIN [3, 1, 3, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation306
theorem observation307 : guard .JOIN [3, 1, 3, 3, 1] = false ∧
    guard .JOIN [3, 1, 3, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation307
theorem observation308 : guard .JOIN [3, 1, 3, 3, 2] = false ∧
    guard .JOIN [3, 1, 3, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation308
theorem observation309 : guard .JOIN [3, 1, 3, 3, 3] = false ∧
    guard .JOIN [3, 1, 3, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation309
theorem observation310 : guard .JOIN [3, 2, 1, 1, 1] = false ∧
    guard .JOIN [3, 2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation310
theorem observation311 : guard .JOIN [3, 2, 1, 1, 2] = false ∧
    guard .JOIN [3, 2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation311
theorem observation312 : guard .JOIN [3, 2, 1, 1, 3] = false ∧
    guard .JOIN [3, 2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation312
theorem observation313 : guard .JOIN [3, 2, 1, 2, 1] = false ∧
    guard .JOIN [3, 2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation313
theorem observation314 : guard .JOIN [3, 2, 1, 2, 2] = false ∧
    guard .JOIN [3, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation314
theorem observation315 : guard .JOIN [3, 2, 1, 2, 3] = false ∧
    guard .JOIN [3, 2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation315
theorem observation316 : guard .JOIN [3, 2, 1, 3, 1] = false ∧
    guard .JOIN [3, 2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation316
theorem observation317 : guard .JOIN [3, 2, 1, 3, 2] = false ∧
    guard .JOIN [3, 2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation317
theorem observation318 : guard .JOIN [3, 2, 1, 3, 3] = false ∧
    guard .JOIN [3, 2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation318
theorem observation319 : guard .JOIN [3, 2, 2, 1, 1] = false ∧
    guard .JOIN [3, 2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation319
theorem observation320 : guard .JOIN [3, 2, 2, 1, 2] = false ∧
    guard .JOIN [3, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation320
theorem observation321 : guard .JOIN [3, 2, 2, 1, 3] = false ∧
    guard .JOIN [3, 2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation321
theorem observation322 : guard .JOIN [3, 2, 2, 2, 1] = true ∧
    guard .JOIN [3, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation322
theorem observation323 : guard .JOIN [3, 2, 2, 2, 2] = true ∧
    guard .JOIN [3, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation323
theorem observation324 : guard .JOIN [3, 2, 2, 2, 3] = true ∧
    guard .JOIN [3, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation324
theorem observation325 : guard .JOIN [3, 2, 2, 3, 1] = true ∧
    guard .JOIN [3, 2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation325
theorem observation326 : guard .JOIN [3, 2, 2, 3, 2] = true ∧
    guard .JOIN [3, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation326
theorem observation327 : guard .JOIN [3, 2, 2, 3, 3] = true ∧
    guard .JOIN [3, 2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation327
theorem observation328 : guard .JOIN [3, 2, 3, 1, 1] = false ∧
    guard .JOIN [3, 2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation328
theorem observation329 : guard .JOIN [3, 2, 3, 1, 2] = false ∧
    guard .JOIN [3, 2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation329
theorem observation330 : guard .JOIN [3, 2, 3, 1, 3] = false ∧
    guard .JOIN [3, 2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation330
theorem observation331 : guard .JOIN [3, 2, 3, 2, 1] = true ∧
    guard .JOIN [3, 2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation331
theorem observation332 : guard .JOIN [3, 2, 3, 2, 2] = true ∧
    guard .JOIN [3, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation332
theorem observation333 : guard .JOIN [3, 2, 3, 2, 3] = true ∧
    guard .JOIN [3, 2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation333
theorem observation334 : guard .JOIN [3, 2, 3, 3, 1] = true ∧
    guard .JOIN [3, 2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation334
theorem observation335 : guard .JOIN [3, 2, 3, 3, 2] = true ∧
    guard .JOIN [3, 2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation335
theorem observation336 : guard .JOIN [3, 2, 3, 3, 3] = true ∧
    guard .JOIN [3, 2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation336
theorem observation337 : guard .JOIN [3, 3, 1, 1, 1] = false ∧
    guard .JOIN [3, 3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation337
theorem observation338 : guard .JOIN [3, 3, 1, 1, 2] = false ∧
    guard .JOIN [3, 3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation338
theorem observation339 : guard .JOIN [3, 3, 1, 1, 3] = false ∧
    guard .JOIN [3, 3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation339
theorem observation340 : guard .JOIN [3, 3, 1, 2, 1] = false ∧
    guard .JOIN [3, 3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation340
theorem observation341 : guard .JOIN [3, 3, 1, 2, 2] = false ∧
    guard .JOIN [3, 3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation341
theorem observation342 : guard .JOIN [3, 3, 1, 2, 3] = false ∧
    guard .JOIN [3, 3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation342
theorem observation343 : guard .JOIN [3, 3, 1, 3, 1] = false ∧
    guard .JOIN [3, 3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation343
theorem observation344 : guard .JOIN [3, 3, 1, 3, 2] = false ∧
    guard .JOIN [3, 3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation344
theorem observation345 : guard .JOIN [3, 3, 1, 3, 3] = false ∧
    guard .JOIN [3, 3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation345
theorem observation346 : guard .JOIN [3, 3, 2, 1, 1] = false ∧
    guard .JOIN [3, 3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation346
theorem observation347 : guard .JOIN [3, 3, 2, 1, 2] = false ∧
    guard .JOIN [3, 3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation347
theorem observation348 : guard .JOIN [3, 3, 2, 1, 3] = false ∧
    guard .JOIN [3, 3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation348
theorem observation349 : guard .JOIN [3, 3, 2, 2, 1] = true ∧
    guard .JOIN [3, 3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation349
theorem observation350 : guard .JOIN [3, 3, 2, 2, 2] = true ∧
    guard .JOIN [3, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation350
theorem observation351 : guard .JOIN [3, 3, 2, 2, 3] = true ∧
    guard .JOIN [3, 3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation351
theorem observation352 : guard .JOIN [3, 3, 2, 3, 1] = true ∧
    guard .JOIN [3, 3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation352
theorem observation353 : guard .JOIN [3, 3, 2, 3, 2] = true ∧
    guard .JOIN [3, 3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation353
theorem observation354 : guard .JOIN [3, 3, 2, 3, 3] = true ∧
    guard .JOIN [3, 3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation354
theorem observation355 : guard .JOIN [3, 3, 3, 1, 1] = false ∧
    guard .JOIN [3, 3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation355
theorem observation356 : guard .JOIN [3, 3, 3, 1, 2] = false ∧
    guard .JOIN [3, 3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation356
theorem observation357 : guard .JOIN [3, 3, 3, 1, 3] = false ∧
    guard .JOIN [3, 3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation357
theorem observation358 : guard .JOIN [3, 3, 3, 2, 1] = true ∧
    guard .JOIN [3, 3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation358
theorem observation359 : guard .JOIN [3, 3, 3, 2, 2] = true ∧
    guard .JOIN [3, 3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation359
theorem observation360 : guard .JOIN [3, 3, 3, 2, 3] = true ∧
    guard .JOIN [3, 3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation360
theorem observation361 : guard .JOIN [3, 3, 3, 3, 1] = true ∧
    guard .JOIN [3, 3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation361
theorem observation362 : guard .JOIN [3, 3, 3, 3, 2] = true ∧
    guard .JOIN [3, 3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation362
theorem observation363 : guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation363
theorem observation364 : guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation364
theorem observation365 : guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation365
theorem observation366 : guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation366
theorem observation367 : guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation367
theorem observation368 : guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation368
theorem observation369 : guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation369
theorem observation370 : guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation370
theorem observation371 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation371
theorem observation372 : guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation372
theorem observation373 : guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation373
theorem observation374 : guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation374
theorem observation375 : guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation375
theorem observation376 : guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation376
theorem observation377 : guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation377
theorem observation378 : guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation378
theorem observation379 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation379
theorem observation380 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation380
theorem observation381 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation381
theorem observation382 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation382
theorem observation383 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation383
theorem observation384 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation384
theorem observation385 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation385
theorem observation386 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation386
theorem observation387 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation387
theorem observation388 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation388
theorem observation389 : guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation389
theorem observation390 : guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation390
theorem observation391 : guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation391
theorem observation392 : guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation392
theorem observation393 : guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation393
theorem observation394 : guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation394
theorem observation395 : guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation395
theorem observation396 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation396
theorem observation397 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation397
theorem observation398 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation398
theorem observation399 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation399
theorem observation400 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation400
theorem observation401 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation401
theorem observation402 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation402
theorem observation403 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation403
theorem observation404 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation404
theorem observation405 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation405
theorem observation406 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation406
theorem observation407 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation407
theorem observation408 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation408
theorem observation409 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation409
theorem observation410 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation410
theorem observation411 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation411
theorem observation412 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation412
theorem observation413 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation413
theorem observation414 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation414
theorem observation415 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation415
theorem observation416 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation416
theorem observation417 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation417
theorem observation418 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation418
theorem observation419 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation419
theorem observation420 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation420
theorem observation421 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation421
theorem observation422 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation422
theorem observation423 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation423
theorem observation424 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation424
theorem observation425 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation425
theorem observation426 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation426
theorem observation427 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation427
theorem observation428 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation428
theorem observation429 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation429
theorem observation430 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation430
theorem observation431 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation431
theorem observation432 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation432
theorem observation433 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation433
theorem observation434 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation434
theorem observation435 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation435
theorem observation436 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation436
theorem observation437 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation437
theorem observation438 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation438
theorem observation439 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation439
theorem observation440 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation440
theorem observation441 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation441
theorem observation442 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation442
theorem observation443 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation443
theorem observation444 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation444
theorem observation445 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation445
theorem observation446 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation446
theorem observation447 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation447
theorem observation448 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation448
theorem observation449 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation449
theorem observation450 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation450
theorem observation451 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation451
theorem observation452 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation452
theorem observation453 : guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation453
theorem observation454 : guard .JOIN [2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation454
theorem observation455 : guard .JOIN [2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation455
theorem observation456 : guard .JOIN [2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation456
theorem observation457 : guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation457
theorem observation458 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation458
theorem observation459 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation459
theorem observation460 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation460
theorem observation461 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation461
theorem observation462 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation462
theorem observation463 : guard .JOIN [3, 2, 2, 2, 2] = true ∧
    guard .JOIN [3, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation463
theorem observation464 : guard .JOIN [2, 3, 2, 2, 2] = true ∧
    guard .JOIN [2, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation464
theorem observation465 : guard .JOIN [2, 2, 3, 2, 2] = true ∧
    guard .JOIN [2, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation465
theorem observation466 : guard .JOIN [2, 2, 2, 3, 2] = true ∧
    guard .JOIN [2, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation466
theorem observation467 : guard .JOIN [2, 2, 2, 2, 3] = true ∧
    guard .JOIN [2, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation467
theorem observation468 : guard .JOIN [1, 2, 2, 1] = true ∧
    guard .JOIN [1, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation468
def tree469 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations469 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]]]
theorem observation469 : sourceLeaves tree469 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations469 tree469) [] = true ∧
    sameRelation (finiteEval relations469 tree469) (finiteEval relations469 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide

end ACGN.ThirdFive.JoinReplay
