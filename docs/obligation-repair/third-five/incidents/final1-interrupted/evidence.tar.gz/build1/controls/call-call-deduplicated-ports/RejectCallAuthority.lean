import CallAuthorityTransitions
open ACGN.ThirdFive.CallAuthorityTransitions
namespace ACGN.ThirdFive.CallReplay
set_option maxRecDepth 4096
def table0 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 2 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 6 0 2 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 1 0 1), (Signature.mk 11 1 1 1), (Signature.mk 12 1 0 1), (Signature.mk 12 1 1 1), (Signature.mk 13 1 0 1), (Signature.mk 14 1 0 1)]
def declaration0 : Signature := (Signature.mk 6 0 2 0)
def source0 : Source := (.call (Signature.mk 6 0 2 0) (sourceArgs [(.atom 2), (.atom 2)]))
def masg_tree0 : Representation := (.application (Signature.mk 6 0 2 0) (ports [(.scalar 2), (.scalar 2)]))
def ir_tree0 : Representation := (.application (Signature.mk 6 0 2 0) (ports [(.scalar 2), (.scalar 2)]))
def cert_tree0 : Representation := (.application (Signature.mk 6 0 2 0) (ports [(.scalar 2)]))
theorem call0 : resolve table0 6 0 2 = some declaration0 ∧
    declaration0 = (Signature.mk 6 0 2 0) ∧
    JavaAritySafe declaration0.arity ∧
    (2 : Nat) = declaration0.arity ∧
    declaration0.arity = declaredArity [2] ∧
    checkRepresentation source0 masg_tree0 = true ∧
    checkRepresentation source0 ir_tree0 = true ∧
    checkRepresentation source0 cert_tree0 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [25, 25] = [(25, 1), (25, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call0
end ACGN.ThirdFive.CallReplay
