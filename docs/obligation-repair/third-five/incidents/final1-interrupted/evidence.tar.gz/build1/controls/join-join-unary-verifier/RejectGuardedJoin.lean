import GuardedJoinChain
namespace ACGN.ThirdFive.JoinReplay
open ACGN.ThirdFive.GuardedJoinChain
open ACGN.Section3.DependentChainSequence
open ACGN.BoundedFive.DependentJoinGuard (guard)
theorem source0 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source0
theorem source1 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source1
theorem source2 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source2
theorem source3 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source3
theorem observation0 : guard .JOIN [] = false ∧
    guard .JOIN [] = false := by
  simp only [guard_executable]
  decide
#print axioms observation0
theorem observation1 : guard .JOIN [1] = false ∧
    guard .JOIN [1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation1
theorem observation2 : guard .JOIN [2] = false ∧
    guard .JOIN [2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation2
theorem observation3 : guard .JOIN [3] = false ∧
    guard .JOIN [3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation3
theorem observation4 : guard .JOIN [1, 1] = true ∧
    guard .JOIN [1, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation4
theorem observation5 : guard .JOIN [1, 2] = true ∧
    guard .JOIN [1, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation5
theorem observation6 : guard .JOIN [1, 3] = true ∧
    guard .JOIN [1, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation6
theorem observation7 : guard .JOIN [2, 1] = true ∧
    guard .JOIN [2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation7
theorem observation8 : guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation8
theorem observation9 : guard .JOIN [2, 3] = true ∧
    guard .JOIN [2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation9
theorem observation10 : guard .JOIN [3, 1] = true ∧
    guard .JOIN [3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation10
theorem observation11 : guard .JOIN [3, 2] = true ∧
    guard .JOIN [3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation11
theorem observation12 : guard .JOIN [3, 3] = true ∧
    guard .JOIN [3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation12
theorem observation13 : guard .JOIN [1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation13
theorem observation14 : guard .JOIN [1, 1, 2] = false ∧
    guard .JOIN [1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation14
theorem observation15 : guard .JOIN [1, 1, 3] = false ∧
    guard .JOIN [1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation15
theorem observation16 : guard .JOIN [1, 2, 1] = true ∧
    guard .JOIN [1, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation16
theorem observation17 : guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation17
theorem observation18 : guard .JOIN [1, 2, 3] = true ∧
    guard .JOIN [1, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation18
theorem observation19 : guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation19
theorem observation20 : guard .JOIN [1, 3, 2] = true ∧
    guard .JOIN [1, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation20
theorem observation21 : guard .JOIN [1, 3, 3] = true ∧
    guard .JOIN [1, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation21
theorem observation22 : guard .JOIN [2, 1, 1] = false ∧
    guard .JOIN [2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation22
theorem observation23 : guard .JOIN [2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2] = true := by
  simp only [guard_executable]
  decide

end ACGN.ThirdFive.JoinReplay
