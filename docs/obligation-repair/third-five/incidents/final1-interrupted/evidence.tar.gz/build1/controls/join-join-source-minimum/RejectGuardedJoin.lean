import GuardedJoinChain
namespace ACGN.ThirdFive.JoinReplay
open ACGN.ThirdFive.GuardedJoinChain
open ACGN.Section3.DependentChainSequence
open ACGN.BoundedFive.DependentJoinGuard (guard)
theorem source0 : ([1, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide

end ACGN.ThirdFive.JoinReplay
