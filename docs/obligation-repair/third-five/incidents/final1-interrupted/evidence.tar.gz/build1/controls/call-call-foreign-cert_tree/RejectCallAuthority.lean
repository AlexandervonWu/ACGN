import CallAuthorityTransitions
open ACGN.ThirdFive.CallAuthorityTransitions
namespace ACGN.ThirdFive.CallReplay
set_option maxRecDepth 4096
def table0 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 0 0), (Signature.mk 2 0 0 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 6 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 12 1 0 1), (Signature.mk 12 1 1 1), (Signature.mk 13 1 0 1), (Signature.mk 13 1 1 1), (Signature.mk 14 1 0 1), (Signature.mk 15 1 0 1)]
def declaration0 : Signature := (Signature.mk 6 0 0 0)
def source0 : Source := (.call (Signature.mk 6 0 0 0) (sourceArgs []))
def masg_tree0 : Representation := (.application (Signature.mk 6 0 0 0) (ports []))
def ir_tree0 : Representation := (.application (Signature.mk 6 0 0 0) (ports []))
def cert_tree0 : Representation := (.application (Signature.mk 11 0 0 0) (ports []))
theorem call0 : resolve table0 6 0 0 = some declaration0 ∧
    declaration0 = (Signature.mk 6 0 0 0) ∧
    JavaAritySafe declaration0.arity ∧
    (0 : Nat) = declaration0.arity ∧
    declaration0.arity = declaredArity [] ∧
    checkRepresentation source0 masg_tree0 = true ∧
    checkRepresentation source0 ir_tree0 = true ∧
    checkRepresentation source0 cert_tree0 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [11, 11] = [(11, 1), (11, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call0
end ACGN.ThirdFive.CallReplay
