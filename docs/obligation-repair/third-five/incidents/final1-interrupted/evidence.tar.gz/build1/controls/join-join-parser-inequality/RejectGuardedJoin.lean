import GuardedJoinChain
namespace ACGN.ThirdFive.JoinReplay
open ACGN.ThirdFive.GuardedJoinChain
open ACGN.Section3.DependentChainSequence
open ACGN.BoundedFive.DependentJoinGuard (guard)
theorem source0 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source0
theorem source1 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source1
theorem source2 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source2
theorem source3 : ([2, 1, 1] : List Nat) = [2, 1, 1] ∧
    "last" = "last" ∧ "first" = "first" := by decide
#print axioms source3
theorem observation0 : guard .JOIN [] = false ∧
    guard .JOIN [] = false := by
  simp only [guard_executable]
  decide
#print axioms observation0
theorem observation1 : guard .JOIN [1] = false ∧
    guard .JOIN [1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation1
theorem observation2 : guard .JOIN [2] = false ∧
    guard .JOIN [2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation2
theorem observation3 : guard .JOIN [3] = false ∧
    guard .JOIN [3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation3
theorem observation4 : guard .JOIN [1, 1] = true ∧
    guard .JOIN [1, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation4
theorem observation5 : guard .JOIN [1, 2] = true ∧
    guard .JOIN [1, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation5
theorem observation6 : guard .JOIN [1, 3] = true ∧
    guard .JOIN [1, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation6
theorem observation7 : guard .JOIN [2, 1] = true ∧
    guard .JOIN [2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation7
theorem observation8 : guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation8
theorem observation9 : guard .JOIN [2, 3] = true ∧
    guard .JOIN [2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation9
theorem observation10 : guard .JOIN [3, 1] = true ∧
    guard .JOIN [3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation10
theorem observation11 : guard .JOIN [3, 2] = true ∧
    guard .JOIN [3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation11
theorem observation12 : guard .JOIN [3, 3] = true ∧
    guard .JOIN [3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation12
theorem observation13 : guard .JOIN [1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation13
theorem observation14 : guard .JOIN [1, 1, 2] = false ∧
    guard .JOIN [1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation14
theorem observation15 : guard .JOIN [1, 1, 3] = false ∧
    guard .JOIN [1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation15
theorem observation16 : guard .JOIN [1, 2, 1] = true ∧
    guard .JOIN [1, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation16
theorem observation17 : guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation17
theorem observation18 : guard .JOIN [1, 2, 3] = true ∧
    guard .JOIN [1, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation18
theorem observation19 : guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation19
theorem observation20 : guard .JOIN [1, 3, 2] = true ∧
    guard .JOIN [1, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation20
theorem observation21 : guard .JOIN [1, 3, 3] = true ∧
    guard .JOIN [1, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation21
theorem observation22 : guard .JOIN [2, 1, 1] = false ∧
    guard .JOIN [2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation22
theorem observation23 : guard .JOIN [2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation23
theorem observation24 : guard .JOIN [2, 1, 3] = false ∧
    guard .JOIN [2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation24
theorem observation25 : guard .JOIN [2, 2, 1] = true ∧
    guard .JOIN [2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation25
theorem observation26 : guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation26
theorem observation27 : guard .JOIN [2, 2, 3] = true ∧
    guard .JOIN [2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation27
theorem observation28 : guard .JOIN [2, 3, 1] = true ∧
    guard .JOIN [2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation28
theorem observation29 : guard .JOIN [2, 3, 2] = true ∧
    guard .JOIN [2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation29
theorem observation30 : guard .JOIN [2, 3, 3] = true ∧
    guard .JOIN [2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation30
theorem observation31 : guard .JOIN [3, 1, 1] = false ∧
    guard .JOIN [3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation31
theorem observation32 : guard .JOIN [3, 1, 2] = false ∧
    guard .JOIN [3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation32
theorem observation33 : guard .JOIN [3, 1, 3] = false ∧
    guard .JOIN [3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation33
theorem observation34 : guard .JOIN [3, 2, 1] = true ∧
    guard .JOIN [3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation34
theorem observation35 : guard .JOIN [3, 2, 2] = true ∧
    guard .JOIN [3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation35
theorem observation36 : guard .JOIN [3, 2, 3] = true ∧
    guard .JOIN [3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation36
theorem observation37 : guard .JOIN [3, 3, 1] = true ∧
    guard .JOIN [3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation37
theorem observation38 : guard .JOIN [3, 3, 2] = true ∧
    guard .JOIN [3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation38
theorem observation39 : guard .JOIN [3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation39
theorem observation40 : guard .JOIN [1, 1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation40
theorem observation41 : guard .JOIN [1, 1, 1, 2] = false ∧
    guard .JOIN [1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation41
theorem observation42 : guard .JOIN [1, 1, 1, 3] = false ∧
    guard .JOIN [1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation42
theorem observation43 : guard .JOIN [1, 1, 2, 1] = false ∧
    guard .JOIN [1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation43
theorem observation44 : guard .JOIN [1, 1, 2, 2] = false ∧
    guard .JOIN [1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation44
theorem observation45 : guard .JOIN [1, 1, 2, 3] = false ∧
    guard .JOIN [1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation45
theorem observation46 : guard .JOIN [1, 1, 3, 1] = false ∧
    guard .JOIN [1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation46
theorem observation47 : guard .JOIN [1, 1, 3, 2] = false ∧
    guard .JOIN [1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation47
theorem observation48 : guard .JOIN [1, 1, 3, 3] = false ∧
    guard .JOIN [1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation48
theorem observation49 : guard .JOIN [1, 2, 1, 1] = false ∧
    guard .JOIN [1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation49
theorem observation50 : guard .JOIN [1, 2, 1, 2] = false ∧
    guard .JOIN [1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation50
theorem observation51 : guard .JOIN [1, 2, 1, 3] = false ∧
    guard .JOIN [1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation51
theorem observation52 : guard .JOIN [1, 2, 2, 1] = true ∧
    guard .JOIN [1, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation52
theorem observation53 : guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation53
theorem observation54 : guard .JOIN [1, 2, 2, 3] = true ∧
    guard .JOIN [1, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation54
theorem observation55 : guard .JOIN [1, 2, 3, 1] = true ∧
    guard .JOIN [1, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation55
theorem observation56 : guard .JOIN [1, 2, 3, 2] = true ∧
    guard .JOIN [1, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation56
theorem observation57 : guard .JOIN [1, 2, 3, 3] = true ∧
    guard .JOIN [1, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation57
theorem observation58 : guard .JOIN [1, 3, 1, 1] = false ∧
    guard .JOIN [1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation58
theorem observation59 : guard .JOIN [1, 3, 1, 2] = false ∧
    guard .JOIN [1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation59
theorem observation60 : guard .JOIN [1, 3, 1, 3] = false ∧
    guard .JOIN [1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation60
theorem observation61 : guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation61
theorem observation62 : guard .JOIN [1, 3, 2, 2] = true ∧
    guard .JOIN [1, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation62
theorem observation63 : guard .JOIN [1, 3, 2, 3] = true ∧
    guard .JOIN [1, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation63
theorem observation64 : guard .JOIN [1, 3, 3, 1] = true ∧
    guard .JOIN [1, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation64
theorem observation65 : guard .JOIN [1, 3, 3, 2] = true ∧
    guard .JOIN [1, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation65
theorem observation66 : guard .JOIN [1, 3, 3, 3] = true ∧
    guard .JOIN [1, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation66
theorem observation67 : guard .JOIN [2, 1, 1, 1] = false ∧
    guard .JOIN [2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation67
theorem observation68 : guard .JOIN [2, 1, 1, 2] = false ∧
    guard .JOIN [2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation68
theorem observation69 : guard .JOIN [2, 1, 1, 3] = false ∧
    guard .JOIN [2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation69
theorem observation70 : guard .JOIN [2, 1, 2, 1] = false ∧
    guard .JOIN [2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation70
theorem observation71 : guard .JOIN [2, 1, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation71
theorem observation72 : guard .JOIN [2, 1, 2, 3] = false ∧
    guard .JOIN [2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation72
theorem observation73 : guard .JOIN [2, 1, 3, 1] = false ∧
    guard .JOIN [2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation73
theorem observation74 : guard .JOIN [2, 1, 3, 2] = false ∧
    guard .JOIN [2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation74
theorem observation75 : guard .JOIN [2, 1, 3, 3] = false ∧
    guard .JOIN [2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation75
theorem observation76 : guard .JOIN [2, 2, 1, 1] = false ∧
    guard .JOIN [2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation76
theorem observation77 : guard .JOIN [2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation77
theorem observation78 : guard .JOIN [2, 2, 1, 3] = false ∧
    guard .JOIN [2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation78
theorem observation79 : guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation79
theorem observation80 : guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation80
theorem observation81 : guard .JOIN [2, 2, 2, 3] = true ∧
    guard .JOIN [2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation81
theorem observation82 : guard .JOIN [2, 2, 3, 1] = true ∧
    guard .JOIN [2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation82
theorem observation83 : guard .JOIN [2, 2, 3, 2] = true ∧
    guard .JOIN [2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation83
theorem observation84 : guard .JOIN [2, 2, 3, 3] = true ∧
    guard .JOIN [2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation84
theorem observation85 : guard .JOIN [2, 3, 1, 1] = false ∧
    guard .JOIN [2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation85
theorem observation86 : guard .JOIN [2, 3, 1, 2] = false ∧
    guard .JOIN [2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation86
theorem observation87 : guard .JOIN [2, 3, 1, 3] = false ∧
    guard .JOIN [2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation87
theorem observation88 : guard .JOIN [2, 3, 2, 1] = true ∧
    guard .JOIN [2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation88
theorem observation89 : guard .JOIN [2, 3, 2, 2] = true ∧
    guard .JOIN [2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation89
theorem observation90 : guard .JOIN [2, 3, 2, 3] = true ∧
    guard .JOIN [2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation90
theorem observation91 : guard .JOIN [2, 3, 3, 1] = true ∧
    guard .JOIN [2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation91
theorem observation92 : guard .JOIN [2, 3, 3, 2] = true ∧
    guard .JOIN [2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation92
theorem observation93 : guard .JOIN [2, 3, 3, 3] = true ∧
    guard .JOIN [2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation93
theorem observation94 : guard .JOIN [3, 1, 1, 1] = false ∧
    guard .JOIN [3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation94
theorem observation95 : guard .JOIN [3, 1, 1, 2] = false ∧
    guard .JOIN [3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation95
theorem observation96 : guard .JOIN [3, 1, 1, 3] = false ∧
    guard .JOIN [3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation96
theorem observation97 : guard .JOIN [3, 1, 2, 1] = false ∧
    guard .JOIN [3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation97
theorem observation98 : guard .JOIN [3, 1, 2, 2] = false ∧
    guard .JOIN [3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation98
theorem observation99 : guard .JOIN [3, 1, 2, 3] = false ∧
    guard .JOIN [3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation99
theorem observation100 : guard .JOIN [3, 1, 3, 1] = false ∧
    guard .JOIN [3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation100
theorem observation101 : guard .JOIN [3, 1, 3, 2] = false ∧
    guard .JOIN [3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation101
theorem observation102 : guard .JOIN [3, 1, 3, 3] = false ∧
    guard .JOIN [3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation102
theorem observation103 : guard .JOIN [3, 2, 1, 1] = false ∧
    guard .JOIN [3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation103
theorem observation104 : guard .JOIN [3, 2, 1, 2] = false ∧
    guard .JOIN [3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation104
theorem observation105 : guard .JOIN [3, 2, 1, 3] = false ∧
    guard .JOIN [3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation105
theorem observation106 : guard .JOIN [3, 2, 2, 1] = true ∧
    guard .JOIN [3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation106
theorem observation107 : guard .JOIN [3, 2, 2, 2] = true ∧
    guard .JOIN [3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation107
theorem observation108 : guard .JOIN [3, 2, 2, 3] = true ∧
    guard .JOIN [3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation108
theorem observation109 : guard .JOIN [3, 2, 3, 1] = true ∧
    guard .JOIN [3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation109
theorem observation110 : guard .JOIN [3, 2, 3, 2] = true ∧
    guard .JOIN [3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation110
theorem observation111 : guard .JOIN [3, 2, 3, 3] = true ∧
    guard .JOIN [3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation111
theorem observation112 : guard .JOIN [3, 3, 1, 1] = false ∧
    guard .JOIN [3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation112
theorem observation113 : guard .JOIN [3, 3, 1, 2] = false ∧
    guard .JOIN [3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation113
theorem observation114 : guard .JOIN [3, 3, 1, 3] = false ∧
    guard .JOIN [3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation114
theorem observation115 : guard .JOIN [3, 3, 2, 1] = true ∧
    guard .JOIN [3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation115
theorem observation116 : guard .JOIN [3, 3, 2, 2] = true ∧
    guard .JOIN [3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation116
theorem observation117 : guard .JOIN [3, 3, 2, 3] = true ∧
    guard .JOIN [3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation117
theorem observation118 : guard .JOIN [3, 3, 3, 1] = true ∧
    guard .JOIN [3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation118
theorem observation119 : guard .JOIN [3, 3, 3, 2] = true ∧
    guard .JOIN [3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation119
theorem observation120 : guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation120
theorem observation121 : guard .JOIN [1, 1, 1, 1, 1] = false ∧
    guard .JOIN [1, 1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation121
theorem observation122 : guard .JOIN [1, 1, 1, 1, 2] = false ∧
    guard .JOIN [1, 1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation122
theorem observation123 : guard .JOIN [1, 1, 1, 1, 3] = false ∧
    guard .JOIN [1, 1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation123
theorem observation124 : guard .JOIN [1, 1, 1, 2, 1] = false ∧
    guard .JOIN [1, 1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation124
theorem observation125 : guard .JOIN [1, 1, 1, 2, 2] = false ∧
    guard .JOIN [1, 1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation125
theorem observation126 : guard .JOIN [1, 1, 1, 2, 3] = false ∧
    guard .JOIN [1, 1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation126
theorem observation127 : guard .JOIN [1, 1, 1, 3, 1] = false ∧
    guard .JOIN [1, 1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation127
theorem observation128 : guard .JOIN [1, 1, 1, 3, 2] = false ∧
    guard .JOIN [1, 1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation128
theorem observation129 : guard .JOIN [1, 1, 1, 3, 3] = false ∧
    guard .JOIN [1, 1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation129
theorem observation130 : guard .JOIN [1, 1, 2, 1, 1] = false ∧
    guard .JOIN [1, 1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation130
theorem observation131 : guard .JOIN [1, 1, 2, 1, 2] = false ∧
    guard .JOIN [1, 1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation131
theorem observation132 : guard .JOIN [1, 1, 2, 1, 3] = false ∧
    guard .JOIN [1, 1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation132
theorem observation133 : guard .JOIN [1, 1, 2, 2, 1] = false ∧
    guard .JOIN [1, 1, 2, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation133
theorem observation134 : guard .JOIN [1, 1, 2, 2, 2] = false ∧
    guard .JOIN [1, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation134
theorem observation135 : guard .JOIN [1, 1, 2, 2, 3] = false ∧
    guard .JOIN [1, 1, 2, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation135
theorem observation136 : guard .JOIN [1, 1, 2, 3, 1] = false ∧
    guard .JOIN [1, 1, 2, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation136
theorem observation137 : guard .JOIN [1, 1, 2, 3, 2] = false ∧
    guard .JOIN [1, 1, 2, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation137
theorem observation138 : guard .JOIN [1, 1, 2, 3, 3] = false ∧
    guard .JOIN [1, 1, 2, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation138
theorem observation139 : guard .JOIN [1, 1, 3, 1, 1] = false ∧
    guard .JOIN [1, 1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation139
theorem observation140 : guard .JOIN [1, 1, 3, 1, 2] = false ∧
    guard .JOIN [1, 1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation140
theorem observation141 : guard .JOIN [1, 1, 3, 1, 3] = false ∧
    guard .JOIN [1, 1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation141
theorem observation142 : guard .JOIN [1, 1, 3, 2, 1] = false ∧
    guard .JOIN [1, 1, 3, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation142
theorem observation143 : guard .JOIN [1, 1, 3, 2, 2] = false ∧
    guard .JOIN [1, 1, 3, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation143
theorem observation144 : guard .JOIN [1, 1, 3, 2, 3] = false ∧
    guard .JOIN [1, 1, 3, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation144
theorem observation145 : guard .JOIN [1, 1, 3, 3, 1] = false ∧
    guard .JOIN [1, 1, 3, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation145
theorem observation146 : guard .JOIN [1, 1, 3, 3, 2] = false ∧
    guard .JOIN [1, 1, 3, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation146
theorem observation147 : guard .JOIN [1, 1, 3, 3, 3] = false ∧
    guard .JOIN [1, 1, 3, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation147
theorem observation148 : guard .JOIN [1, 2, 1, 1, 1] = false ∧
    guard .JOIN [1, 2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation148
theorem observation149 : guard .JOIN [1, 2, 1, 1, 2] = false ∧
    guard .JOIN [1, 2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation149
theorem observation150 : guard .JOIN [1, 2, 1, 1, 3] = false ∧
    guard .JOIN [1, 2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation150
theorem observation151 : guard .JOIN [1, 2, 1, 2, 1] = false ∧
    guard .JOIN [1, 2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation151
theorem observation152 : guard .JOIN [1, 2, 1, 2, 2] = false ∧
    guard .JOIN [1, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation152
theorem observation153 : guard .JOIN [1, 2, 1, 2, 3] = false ∧
    guard .JOIN [1, 2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation153
theorem observation154 : guard .JOIN [1, 2, 1, 3, 1] = false ∧
    guard .JOIN [1, 2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation154
theorem observation155 : guard .JOIN [1, 2, 1, 3, 2] = false ∧
    guard .JOIN [1, 2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation155
theorem observation156 : guard .JOIN [1, 2, 1, 3, 3] = false ∧
    guard .JOIN [1, 2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation156
theorem observation157 : guard .JOIN [1, 2, 2, 1, 1] = false ∧
    guard .JOIN [1, 2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation157
theorem observation158 : guard .JOIN [1, 2, 2, 1, 2] = false ∧
    guard .JOIN [1, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation158
theorem observation159 : guard .JOIN [1, 2, 2, 1, 3] = false ∧
    guard .JOIN [1, 2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation159
theorem observation160 : guard .JOIN [1, 2, 2, 2, 1] = true ∧
    guard .JOIN [1, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation160
theorem observation161 : guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation161
theorem observation162 : guard .JOIN [1, 2, 2, 2, 3] = true ∧
    guard .JOIN [1, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation162
theorem observation163 : guard .JOIN [1, 2, 2, 3, 1] = true ∧
    guard .JOIN [1, 2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation163
theorem observation164 : guard .JOIN [1, 2, 2, 3, 2] = true ∧
    guard .JOIN [1, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation164
theorem observation165 : guard .JOIN [1, 2, 2, 3, 3] = true ∧
    guard .JOIN [1, 2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation165
theorem observation166 : guard .JOIN [1, 2, 3, 1, 1] = false ∧
    guard .JOIN [1, 2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation166
theorem observation167 : guard .JOIN [1, 2, 3, 1, 2] = false ∧
    guard .JOIN [1, 2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation167
theorem observation168 : guard .JOIN [1, 2, 3, 1, 3] = false ∧
    guard .JOIN [1, 2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation168
theorem observation169 : guard .JOIN [1, 2, 3, 2, 1] = true ∧
    guard .JOIN [1, 2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation169
theorem observation170 : guard .JOIN [1, 2, 3, 2, 2] = true ∧
    guard .JOIN [1, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation170
theorem observation171 : guard .JOIN [1, 2, 3, 2, 3] = true ∧
    guard .JOIN [1, 2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation171
theorem observation172 : guard .JOIN [1, 2, 3, 3, 1] = true ∧
    guard .JOIN [1, 2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation172
theorem observation173 : guard .JOIN [1, 2, 3, 3, 2] = true ∧
    guard .JOIN [1, 2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation173
theorem observation174 : guard .JOIN [1, 2, 3, 3, 3] = true ∧
    guard .JOIN [1, 2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation174
theorem observation175 : guard .JOIN [1, 3, 1, 1, 1] = false ∧
    guard .JOIN [1, 3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation175
theorem observation176 : guard .JOIN [1, 3, 1, 1, 2] = false ∧
    guard .JOIN [1, 3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation176
theorem observation177 : guard .JOIN [1, 3, 1, 1, 3] = false ∧
    guard .JOIN [1, 3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation177
theorem observation178 : guard .JOIN [1, 3, 1, 2, 1] = false ∧
    guard .JOIN [1, 3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation178
theorem observation179 : guard .JOIN [1, 3, 1, 2, 2] = false ∧
    guard .JOIN [1, 3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation179
theorem observation180 : guard .JOIN [1, 3, 1, 2, 3] = false ∧
    guard .JOIN [1, 3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation180
theorem observation181 : guard .JOIN [1, 3, 1, 3, 1] = false ∧
    guard .JOIN [1, 3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation181
theorem observation182 : guard .JOIN [1, 3, 1, 3, 2] = false ∧
    guard .JOIN [1, 3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation182
theorem observation183 : guard .JOIN [1, 3, 1, 3, 3] = false ∧
    guard .JOIN [1, 3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation183
theorem observation184 : guard .JOIN [1, 3, 2, 1, 1] = false ∧
    guard .JOIN [1, 3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation184
theorem observation185 : guard .JOIN [1, 3, 2, 1, 2] = false ∧
    guard .JOIN [1, 3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation185
theorem observation186 : guard .JOIN [1, 3, 2, 1, 3] = false ∧
    guard .JOIN [1, 3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation186
theorem observation187 : guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation187
theorem observation188 : guard .JOIN [1, 3, 2, 2, 2] = true ∧
    guard .JOIN [1, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation188
theorem observation189 : guard .JOIN [1, 3, 2, 2, 3] = true ∧
    guard .JOIN [1, 3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation189
theorem observation190 : guard .JOIN [1, 3, 2, 3, 1] = true ∧
    guard .JOIN [1, 3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation190
theorem observation191 : guard .JOIN [1, 3, 2, 3, 2] = true ∧
    guard .JOIN [1, 3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation191
theorem observation192 : guard .JOIN [1, 3, 2, 3, 3] = true ∧
    guard .JOIN [1, 3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation192
theorem observation193 : guard .JOIN [1, 3, 3, 1, 1] = false ∧
    guard .JOIN [1, 3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation193
theorem observation194 : guard .JOIN [1, 3, 3, 1, 2] = false ∧
    guard .JOIN [1, 3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation194
theorem observation195 : guard .JOIN [1, 3, 3, 1, 3] = false ∧
    guard .JOIN [1, 3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation195
theorem observation196 : guard .JOIN [1, 3, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation196
theorem observation197 : guard .JOIN [1, 3, 3, 2, 2] = true ∧
    guard .JOIN [1, 3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation197
theorem observation198 : guard .JOIN [1, 3, 3, 2, 3] = true ∧
    guard .JOIN [1, 3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation198
theorem observation199 : guard .JOIN [1, 3, 3, 3, 1] = true ∧
    guard .JOIN [1, 3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation199
theorem observation200 : guard .JOIN [1, 3, 3, 3, 2] = true ∧
    guard .JOIN [1, 3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation200
theorem observation201 : guard .JOIN [1, 3, 3, 3, 3] = true ∧
    guard .JOIN [1, 3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation201
theorem observation202 : guard .JOIN [2, 1, 1, 1, 1] = false ∧
    guard .JOIN [2, 1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation202
theorem observation203 : guard .JOIN [2, 1, 1, 1, 2] = false ∧
    guard .JOIN [2, 1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation203
theorem observation204 : guard .JOIN [2, 1, 1, 1, 3] = false ∧
    guard .JOIN [2, 1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation204
theorem observation205 : guard .JOIN [2, 1, 1, 2, 1] = false ∧
    guard .JOIN [2, 1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation205
theorem observation206 : guard .JOIN [2, 1, 1, 2, 2] = false ∧
    guard .JOIN [2, 1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation206
theorem observation207 : guard .JOIN [2, 1, 1, 2, 3] = false ∧
    guard .JOIN [2, 1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation207
theorem observation208 : guard .JOIN [2, 1, 1, 3, 1] = false ∧
    guard .JOIN [2, 1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation208
theorem observation209 : guard .JOIN [2, 1, 1, 3, 2] = false ∧
    guard .JOIN [2, 1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation209
theorem observation210 : guard .JOIN [2, 1, 1, 3, 3] = false ∧
    guard .JOIN [2, 1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation210
theorem observation211 : guard .JOIN [2, 1, 2, 1, 1] = false ∧
    guard .JOIN [2, 1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation211
theorem observation212 : guard .JOIN [2, 1, 2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation212
theorem observation213 : guard .JOIN [2, 1, 2, 1, 3] = false ∧
    guard .JOIN [2, 1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation213
theorem observation214 : guard .JOIN [2, 1, 2, 2, 1] = false ∧
    guard .JOIN [2, 1, 2, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation214
theorem observation215 : guard .JOIN [2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation215
theorem observation216 : guard .JOIN [2, 1, 2, 2, 3] = false ∧
    guard .JOIN [2, 1, 2, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation216
theorem observation217 : guard .JOIN [2, 1, 2, 3, 1] = false ∧
    guard .JOIN [2, 1, 2, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation217
theorem observation218 : guard .JOIN [2, 1, 2, 3, 2] = false ∧
    guard .JOIN [2, 1, 2, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation218
theorem observation219 : guard .JOIN [2, 1, 2, 3, 3] = false ∧
    guard .JOIN [2, 1, 2, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation219
theorem observation220 : guard .JOIN [2, 1, 3, 1, 1] = false ∧
    guard .JOIN [2, 1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation220
theorem observation221 : guard .JOIN [2, 1, 3, 1, 2] = false ∧
    guard .JOIN [2, 1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation221
theorem observation222 : guard .JOIN [2, 1, 3, 1, 3] = false ∧
    guard .JOIN [2, 1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation222
theorem observation223 : guard .JOIN [2, 1, 3, 2, 1] = false ∧
    guard .JOIN [2, 1, 3, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation223
theorem observation224 : guard .JOIN [2, 1, 3, 2, 2] = false ∧
    guard .JOIN [2, 1, 3, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation224
theorem observation225 : guard .JOIN [2, 1, 3, 2, 3] = false ∧
    guard .JOIN [2, 1, 3, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation225
theorem observation226 : guard .JOIN [2, 1, 3, 3, 1] = false ∧
    guard .JOIN [2, 1, 3, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation226
theorem observation227 : guard .JOIN [2, 1, 3, 3, 2] = false ∧
    guard .JOIN [2, 1, 3, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation227
theorem observation228 : guard .JOIN [2, 1, 3, 3, 3] = false ∧
    guard .JOIN [2, 1, 3, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation228
theorem observation229 : guard .JOIN [2, 2, 1, 1, 1] = false ∧
    guard .JOIN [2, 2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation229
theorem observation230 : guard .JOIN [2, 2, 1, 1, 2] = false ∧
    guard .JOIN [2, 2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation230
theorem observation231 : guard .JOIN [2, 2, 1, 1, 3] = false ∧
    guard .JOIN [2, 2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation231
theorem observation232 : guard .JOIN [2, 2, 1, 2, 1] = false ∧
    guard .JOIN [2, 2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation232
theorem observation233 : guard .JOIN [2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation233
theorem observation234 : guard .JOIN [2, 2, 1, 2, 3] = false ∧
    guard .JOIN [2, 2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation234
theorem observation235 : guard .JOIN [2, 2, 1, 3, 1] = false ∧
    guard .JOIN [2, 2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation235
theorem observation236 : guard .JOIN [2, 2, 1, 3, 2] = false ∧
    guard .JOIN [2, 2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation236
theorem observation237 : guard .JOIN [2, 2, 1, 3, 3] = false ∧
    guard .JOIN [2, 2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation237
theorem observation238 : guard .JOIN [2, 2, 2, 1, 1] = false ∧
    guard .JOIN [2, 2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation238
theorem observation239 : guard .JOIN [2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation239
theorem observation240 : guard .JOIN [2, 2, 2, 1, 3] = false ∧
    guard .JOIN [2, 2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation240
theorem observation241 : guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation241
theorem observation242 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation242
theorem observation243 : guard .JOIN [2, 2, 2, 2, 3] = true ∧
    guard .JOIN [2, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation243
theorem observation244 : guard .JOIN [2, 2, 2, 3, 1] = true ∧
    guard .JOIN [2, 2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation244
theorem observation245 : guard .JOIN [2, 2, 2, 3, 2] = true ∧
    guard .JOIN [2, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation245
theorem observation246 : guard .JOIN [2, 2, 2, 3, 3] = true ∧
    guard .JOIN [2, 2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation246
theorem observation247 : guard .JOIN [2, 2, 3, 1, 1] = false ∧
    guard .JOIN [2, 2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation247
theorem observation248 : guard .JOIN [2, 2, 3, 1, 2] = false ∧
    guard .JOIN [2, 2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation248
theorem observation249 : guard .JOIN [2, 2, 3, 1, 3] = false ∧
    guard .JOIN [2, 2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation249
theorem observation250 : guard .JOIN [2, 2, 3, 2, 1] = true ∧
    guard .JOIN [2, 2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation250
theorem observation251 : guard .JOIN [2, 2, 3, 2, 2] = true ∧
    guard .JOIN [2, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation251
theorem observation252 : guard .JOIN [2, 2, 3, 2, 3] = true ∧
    guard .JOIN [2, 2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation252
theorem observation253 : guard .JOIN [2, 2, 3, 3, 1] = true ∧
    guard .JOIN [2, 2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation253
theorem observation254 : guard .JOIN [2, 2, 3, 3, 2] = true ∧
    guard .JOIN [2, 2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation254
theorem observation255 : guard .JOIN [2, 2, 3, 3, 3] = true ∧
    guard .JOIN [2, 2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation255
theorem observation256 : guard .JOIN [2, 3, 1, 1, 1] = false ∧
    guard .JOIN [2, 3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation256
theorem observation257 : guard .JOIN [2, 3, 1, 1, 2] = false ∧
    guard .JOIN [2, 3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation257
theorem observation258 : guard .JOIN [2, 3, 1, 1, 3] = false ∧
    guard .JOIN [2, 3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation258
theorem observation259 : guard .JOIN [2, 3, 1, 2, 1] = false ∧
    guard .JOIN [2, 3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation259
theorem observation260 : guard .JOIN [2, 3, 1, 2, 2] = false ∧
    guard .JOIN [2, 3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation260
theorem observation261 : guard .JOIN [2, 3, 1, 2, 3] = false ∧
    guard .JOIN [2, 3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation261
theorem observation262 : guard .JOIN [2, 3, 1, 3, 1] = false ∧
    guard .JOIN [2, 3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation262
theorem observation263 : guard .JOIN [2, 3, 1, 3, 2] = false ∧
    guard .JOIN [2, 3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation263
theorem observation264 : guard .JOIN [2, 3, 1, 3, 3] = false ∧
    guard .JOIN [2, 3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation264
theorem observation265 : guard .JOIN [2, 3, 2, 1, 1] = false ∧
    guard .JOIN [2, 3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation265
theorem observation266 : guard .JOIN [2, 3, 2, 1, 2] = false ∧
    guard .JOIN [2, 3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation266
theorem observation267 : guard .JOIN [2, 3, 2, 1, 3] = false ∧
    guard .JOIN [2, 3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation267
theorem observation268 : guard .JOIN [2, 3, 2, 2, 1] = true ∧
    guard .JOIN [2, 3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation268
theorem observation269 : guard .JOIN [2, 3, 2, 2, 2] = true ∧
    guard .JOIN [2, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation269
theorem observation270 : guard .JOIN [2, 3, 2, 2, 3] = true ∧
    guard .JOIN [2, 3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation270
theorem observation271 : guard .JOIN [2, 3, 2, 3, 1] = true ∧
    guard .JOIN [2, 3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation271
theorem observation272 : guard .JOIN [2, 3, 2, 3, 2] = true ∧
    guard .JOIN [2, 3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation272
theorem observation273 : guard .JOIN [2, 3, 2, 3, 3] = true ∧
    guard .JOIN [2, 3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation273
theorem observation274 : guard .JOIN [2, 3, 3, 1, 1] = false ∧
    guard .JOIN [2, 3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation274
theorem observation275 : guard .JOIN [2, 3, 3, 1, 2] = false ∧
    guard .JOIN [2, 3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation275
theorem observation276 : guard .JOIN [2, 3, 3, 1, 3] = false ∧
    guard .JOIN [2, 3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation276
theorem observation277 : guard .JOIN [2, 3, 3, 2, 1] = true ∧
    guard .JOIN [2, 3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation277
theorem observation278 : guard .JOIN [2, 3, 3, 2, 2] = true ∧
    guard .JOIN [2, 3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation278
theorem observation279 : guard .JOIN [2, 3, 3, 2, 3] = true ∧
    guard .JOIN [2, 3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation279
theorem observation280 : guard .JOIN [2, 3, 3, 3, 1] = true ∧
    guard .JOIN [2, 3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation280
theorem observation281 : guard .JOIN [2, 3, 3, 3, 2] = true ∧
    guard .JOIN [2, 3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation281
theorem observation282 : guard .JOIN [2, 3, 3, 3, 3] = true ∧
    guard .JOIN [2, 3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation282
theorem observation283 : guard .JOIN [3, 1, 1, 1, 1] = false ∧
    guard .JOIN [3, 1, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation283
theorem observation284 : guard .JOIN [3, 1, 1, 1, 2] = false ∧
    guard .JOIN [3, 1, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation284
theorem observation285 : guard .JOIN [3, 1, 1, 1, 3] = false ∧
    guard .JOIN [3, 1, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation285
theorem observation286 : guard .JOIN [3, 1, 1, 2, 1] = false ∧
    guard .JOIN [3, 1, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation286
theorem observation287 : guard .JOIN [3, 1, 1, 2, 2] = false ∧
    guard .JOIN [3, 1, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation287
theorem observation288 : guard .JOIN [3, 1, 1, 2, 3] = false ∧
    guard .JOIN [3, 1, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation288
theorem observation289 : guard .JOIN [3, 1, 1, 3, 1] = false ∧
    guard .JOIN [3, 1, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation289
theorem observation290 : guard .JOIN [3, 1, 1, 3, 2] = false ∧
    guard .JOIN [3, 1, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation290
theorem observation291 : guard .JOIN [3, 1, 1, 3, 3] = false ∧
    guard .JOIN [3, 1, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation291
theorem observation292 : guard .JOIN [3, 1, 2, 1, 1] = false ∧
    guard .JOIN [3, 1, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation292
theorem observation293 : guard .JOIN [3, 1, 2, 1, 2] = false ∧
    guard .JOIN [3, 1, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation293
theorem observation294 : guard .JOIN [3, 1, 2, 1, 3] = false ∧
    guard .JOIN [3, 1, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation294
theorem observation295 : guard .JOIN [3, 1, 2, 2, 1] = false ∧
    guard .JOIN [3, 1, 2, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation295
theorem observation296 : guard .JOIN [3, 1, 2, 2, 2] = false ∧
    guard .JOIN [3, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation296
theorem observation297 : guard .JOIN [3, 1, 2, 2, 3] = false ∧
    guard .JOIN [3, 1, 2, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation297
theorem observation298 : guard .JOIN [3, 1, 2, 3, 1] = false ∧
    guard .JOIN [3, 1, 2, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation298
theorem observation299 : guard .JOIN [3, 1, 2, 3, 2] = false ∧
    guard .JOIN [3, 1, 2, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation299
theorem observation300 : guard .JOIN [3, 1, 2, 3, 3] = false ∧
    guard .JOIN [3, 1, 2, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation300
theorem observation301 : guard .JOIN [3, 1, 3, 1, 1] = false ∧
    guard .JOIN [3, 1, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation301
theorem observation302 : guard .JOIN [3, 1, 3, 1, 2] = false ∧
    guard .JOIN [3, 1, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation302
theorem observation303 : guard .JOIN [3, 1, 3, 1, 3] = false ∧
    guard .JOIN [3, 1, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation303
theorem observation304 : guard .JOIN [3, 1, 3, 2, 1] = false ∧
    guard .JOIN [3, 1, 3, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation304
theorem observation305 : guard .JOIN [3, 1, 3, 2, 2] = false ∧
    guard .JOIN [3, 1, 3, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation305
theorem observation306 : guard .JOIN [3, 1, 3, 2, 3] = false ∧
    guard .JOIN [3, 1, 3, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation306
theorem observation307 : guard .JOIN [3, 1, 3, 3, 1] = false ∧
    guard .JOIN [3, 1, 3, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation307
theorem observation308 : guard .JOIN [3, 1, 3, 3, 2] = false ∧
    guard .JOIN [3, 1, 3, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation308
theorem observation309 : guard .JOIN [3, 1, 3, 3, 3] = false ∧
    guard .JOIN [3, 1, 3, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation309
theorem observation310 : guard .JOIN [3, 2, 1, 1, 1] = false ∧
    guard .JOIN [3, 2, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation310
theorem observation311 : guard .JOIN [3, 2, 1, 1, 2] = false ∧
    guard .JOIN [3, 2, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation311
theorem observation312 : guard .JOIN [3, 2, 1, 1, 3] = false ∧
    guard .JOIN [3, 2, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation312
theorem observation313 : guard .JOIN [3, 2, 1, 2, 1] = false ∧
    guard .JOIN [3, 2, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation313
theorem observation314 : guard .JOIN [3, 2, 1, 2, 2] = false ∧
    guard .JOIN [3, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation314
theorem observation315 : guard .JOIN [3, 2, 1, 2, 3] = false ∧
    guard .JOIN [3, 2, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation315
theorem observation316 : guard .JOIN [3, 2, 1, 3, 1] = false ∧
    guard .JOIN [3, 2, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation316
theorem observation317 : guard .JOIN [3, 2, 1, 3, 2] = false ∧
    guard .JOIN [3, 2, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation317
theorem observation318 : guard .JOIN [3, 2, 1, 3, 3] = false ∧
    guard .JOIN [3, 2, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation318
theorem observation319 : guard .JOIN [3, 2, 2, 1, 1] = false ∧
    guard .JOIN [3, 2, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation319
theorem observation320 : guard .JOIN [3, 2, 2, 1, 2] = false ∧
    guard .JOIN [3, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation320
theorem observation321 : guard .JOIN [3, 2, 2, 1, 3] = false ∧
    guard .JOIN [3, 2, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation321
theorem observation322 : guard .JOIN [3, 2, 2, 2, 1] = true ∧
    guard .JOIN [3, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation322
theorem observation323 : guard .JOIN [3, 2, 2, 2, 2] = true ∧
    guard .JOIN [3, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation323
theorem observation324 : guard .JOIN [3, 2, 2, 2, 3] = true ∧
    guard .JOIN [3, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation324
theorem observation325 : guard .JOIN [3, 2, 2, 3, 1] = true ∧
    guard .JOIN [3, 2, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation325
theorem observation326 : guard .JOIN [3, 2, 2, 3, 2] = true ∧
    guard .JOIN [3, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation326
theorem observation327 : guard .JOIN [3, 2, 2, 3, 3] = true ∧
    guard .JOIN [3, 2, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation327
theorem observation328 : guard .JOIN [3, 2, 3, 1, 1] = false ∧
    guard .JOIN [3, 2, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation328
theorem observation329 : guard .JOIN [3, 2, 3, 1, 2] = false ∧
    guard .JOIN [3, 2, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation329
theorem observation330 : guard .JOIN [3, 2, 3, 1, 3] = false ∧
    guard .JOIN [3, 2, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation330
theorem observation331 : guard .JOIN [3, 2, 3, 2, 1] = true ∧
    guard .JOIN [3, 2, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation331
theorem observation332 : guard .JOIN [3, 2, 3, 2, 2] = true ∧
    guard .JOIN [3, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation332
theorem observation333 : guard .JOIN [3, 2, 3, 2, 3] = true ∧
    guard .JOIN [3, 2, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation333
theorem observation334 : guard .JOIN [3, 2, 3, 3, 1] = true ∧
    guard .JOIN [3, 2, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation334
theorem observation335 : guard .JOIN [3, 2, 3, 3, 2] = true ∧
    guard .JOIN [3, 2, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation335
theorem observation336 : guard .JOIN [3, 2, 3, 3, 3] = true ∧
    guard .JOIN [3, 2, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation336
theorem observation337 : guard .JOIN [3, 3, 1, 1, 1] = false ∧
    guard .JOIN [3, 3, 1, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation337
theorem observation338 : guard .JOIN [3, 3, 1, 1, 2] = false ∧
    guard .JOIN [3, 3, 1, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation338
theorem observation339 : guard .JOIN [3, 3, 1, 1, 3] = false ∧
    guard .JOIN [3, 3, 1, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation339
theorem observation340 : guard .JOIN [3, 3, 1, 2, 1] = false ∧
    guard .JOIN [3, 3, 1, 2, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation340
theorem observation341 : guard .JOIN [3, 3, 1, 2, 2] = false ∧
    guard .JOIN [3, 3, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation341
theorem observation342 : guard .JOIN [3, 3, 1, 2, 3] = false ∧
    guard .JOIN [3, 3, 1, 2, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation342
theorem observation343 : guard .JOIN [3, 3, 1, 3, 1] = false ∧
    guard .JOIN [3, 3, 1, 3, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation343
theorem observation344 : guard .JOIN [3, 3, 1, 3, 2] = false ∧
    guard .JOIN [3, 3, 1, 3, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation344
theorem observation345 : guard .JOIN [3, 3, 1, 3, 3] = false ∧
    guard .JOIN [3, 3, 1, 3, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation345
theorem observation346 : guard .JOIN [3, 3, 2, 1, 1] = false ∧
    guard .JOIN [3, 3, 2, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation346
theorem observation347 : guard .JOIN [3, 3, 2, 1, 2] = false ∧
    guard .JOIN [3, 3, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation347
theorem observation348 : guard .JOIN [3, 3, 2, 1, 3] = false ∧
    guard .JOIN [3, 3, 2, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation348
theorem observation349 : guard .JOIN [3, 3, 2, 2, 1] = true ∧
    guard .JOIN [3, 3, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation349
theorem observation350 : guard .JOIN [3, 3, 2, 2, 2] = true ∧
    guard .JOIN [3, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation350
theorem observation351 : guard .JOIN [3, 3, 2, 2, 3] = true ∧
    guard .JOIN [3, 3, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation351
theorem observation352 : guard .JOIN [3, 3, 2, 3, 1] = true ∧
    guard .JOIN [3, 3, 2, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation352
theorem observation353 : guard .JOIN [3, 3, 2, 3, 2] = true ∧
    guard .JOIN [3, 3, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation353
theorem observation354 : guard .JOIN [3, 3, 2, 3, 3] = true ∧
    guard .JOIN [3, 3, 2, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation354
theorem observation355 : guard .JOIN [3, 3, 3, 1, 1] = false ∧
    guard .JOIN [3, 3, 3, 1, 1] = false := by
  simp only [guard_executable]
  decide
#print axioms observation355
theorem observation356 : guard .JOIN [3, 3, 3, 1, 2] = false ∧
    guard .JOIN [3, 3, 3, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation356
theorem observation357 : guard .JOIN [3, 3, 3, 1, 3] = false ∧
    guard .JOIN [3, 3, 3, 1, 3] = false := by
  simp only [guard_executable]
  decide
#print axioms observation357
theorem observation358 : guard .JOIN [3, 3, 3, 2, 1] = true ∧
    guard .JOIN [3, 3, 3, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation358
theorem observation359 : guard .JOIN [3, 3, 3, 2, 2] = true ∧
    guard .JOIN [3, 3, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation359
theorem observation360 : guard .JOIN [3, 3, 3, 2, 3] = true ∧
    guard .JOIN [3, 3, 3, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation360
theorem observation361 : guard .JOIN [3, 3, 3, 3, 1] = true ∧
    guard .JOIN [3, 3, 3, 3, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation361
theorem observation362 : guard .JOIN [3, 3, 3, 3, 2] = true ∧
    guard .JOIN [3, 3, 3, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation362
theorem observation363 : guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation363
theorem observation364 : guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation364
theorem observation365 : guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation365
theorem observation366 : guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation366
theorem observation367 : guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation367
theorem observation368 : guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation368
theorem observation369 : guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation369
theorem observation370 : guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation370
theorem observation371 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation371
theorem observation372 : guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation372
theorem observation373 : guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation373
theorem observation374 : guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation374
theorem observation375 : guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation375
theorem observation376 : guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation376
theorem observation377 : guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation377
theorem observation378 : guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation378
theorem observation379 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation379
theorem observation380 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation380
theorem observation381 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation381
theorem observation382 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation382
theorem observation383 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation383
theorem observation384 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation384
theorem observation385 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation385
theorem observation386 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation386
theorem observation387 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation387
theorem observation388 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation388
theorem observation389 : guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation389
theorem observation390 : guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation390
theorem observation391 : guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation391
theorem observation392 : guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation392
theorem observation393 : guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation393
theorem observation394 : guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation394
theorem observation395 : guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation395
theorem observation396 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation396
theorem observation397 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation397
theorem observation398 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation398
theorem observation399 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation399
theorem observation400 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation400
theorem observation401 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation401
theorem observation402 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation402
theorem observation403 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation403
theorem observation404 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation404
theorem observation405 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation405
theorem observation406 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation406
theorem observation407 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation407
theorem observation408 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation408
theorem observation409 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation409
theorem observation410 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation410
theorem observation411 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation411
theorem observation412 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation412
theorem observation413 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation413
theorem observation414 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation414
theorem observation415 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation415
theorem observation416 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation416
theorem observation417 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation417
theorem observation418 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation418
theorem observation419 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation419
theorem observation420 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation420
theorem observation421 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation421
theorem observation422 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation422
theorem observation423 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation423
theorem observation424 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation424
theorem observation425 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation425
theorem observation426 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation426
theorem observation427 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation427
theorem observation428 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation428
theorem observation429 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation429
theorem observation430 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation430
theorem observation431 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation431
theorem observation432 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation432
theorem observation433 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation433
theorem observation434 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation434
theorem observation435 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation435
theorem observation436 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation436
theorem observation437 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation437
theorem observation438 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation438
theorem observation439 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation439
theorem observation440 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation440
theorem observation441 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation441
theorem observation442 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation442
theorem observation443 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation443
theorem observation444 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation444
theorem observation445 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation445
theorem observation446 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation446
theorem observation447 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation447
theorem observation448 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation448
theorem observation449 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation449
theorem observation450 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation450
theorem observation451 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation451
theorem observation452 : guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation452
theorem observation453 : guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation453
theorem observation454 : guard .JOIN [2, 1, 2, 2, 2] = false ∧
    guard .JOIN [2, 1, 2, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation454
theorem observation455 : guard .JOIN [2, 2, 1, 2, 2] = false ∧
    guard .JOIN [2, 2, 1, 2, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation455
theorem observation456 : guard .JOIN [2, 2, 2, 1, 2] = false ∧
    guard .JOIN [2, 2, 2, 1, 2] = false := by
  simp only [guard_executable]
  decide
#print axioms observation456
theorem observation457 : guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation457
theorem observation458 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation458
theorem observation459 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation459
theorem observation460 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation460
theorem observation461 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation461
theorem observation462 : guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation462
theorem observation463 : guard .JOIN [3, 2, 2, 2, 2] = true ∧
    guard .JOIN [3, 2, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation463
theorem observation464 : guard .JOIN [2, 3, 2, 2, 2] = true ∧
    guard .JOIN [2, 3, 2, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation464
theorem observation465 : guard .JOIN [2, 2, 3, 2, 2] = true ∧
    guard .JOIN [2, 2, 3, 2, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation465
theorem observation466 : guard .JOIN [2, 2, 2, 3, 2] = true ∧
    guard .JOIN [2, 2, 2, 3, 2] = true := by
  simp only [guard_executable]
  decide
#print axioms observation466
theorem observation467 : guard .JOIN [2, 2, 2, 2, 3] = true ∧
    guard .JOIN [2, 2, 2, 2, 3] = true := by
  simp only [guard_executable]
  decide
#print axioms observation467
theorem observation468 : guard .JOIN [1, 2, 2, 1] = true ∧
    guard .JOIN [1, 2, 2, 1] = true := by
  simp only [guard_executable]
  decide
#print axioms observation468
def tree469 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations469 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]]]
theorem observation469 : sourceLeaves tree469 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations469 tree469) [[1, 0]] = true ∧
    sameRelation (finiteEval relations469 tree469) (finiteEval relations469 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation469
def tree470 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations470 : List (List (List Nat)) := [[[1, 0]], [[0, 1]]]
theorem observation470 : sourceLeaves tree470 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations470 tree470) [[1, 1]] = true ∧
    sameRelation (finiteEval relations470 tree470) (finiteEval relations470 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation470
def tree471 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations471 : List (List (List Nat)) := [[[0]], [[1, 0]]]
theorem observation471 : sourceLeaves tree471 = [0, 1] ∧
    guard .JOIN [1, 2] = true ∧
    guard .JOIN [1, 2] = true ∧
    sameRelation (finiteEval relations471 tree471) [] = true ∧
    sameRelation (finiteEval relations471 tree471) (finiteEval relations471 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation471
def tree472 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations472 : List (List (List Nat)) := [[], [[0, 1]]]
theorem observation472 : sourceLeaves tree472 = [0, 1] ∧
    guard .JOIN [1, 2] = true ∧
    guard .JOIN [1, 2] = true ∧
    sameRelation (finiteEval relations472 tree472) [] = true ∧
    sameRelation (finiteEval relations472 tree472) (finiteEval relations472 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation472
def tree473 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations473 : List (List (List Nat)) := [[[0, 0], [1, 1]], []]
theorem observation473 : sourceLeaves tree473 = [0, 1] ∧
    guard .JOIN [2, 1] = true ∧
    guard .JOIN [2, 1] = true ∧
    sameRelation (finiteEval relations473 tree473) [] = true ∧
    sameRelation (finiteEval relations473 tree473) (finiteEval relations473 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation473
def tree474 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations474 : List (List (List Nat)) := [[[1, 0]], [[1]]]
theorem observation474 : sourceLeaves tree474 = [0, 1] ∧
    guard .JOIN [2, 1] = true ∧
    guard .JOIN [2, 1] = true ∧
    sameRelation (finiteEval relations474 tree474) [] = true ∧
    sameRelation (finiteEval relations474 tree474) (finiteEval relations474 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation474
def tree475 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations475 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation475 : sourceLeaves tree475 = [0, 1] ∧
    guard .JOIN [3, 3] = true ∧
    guard .JOIN [3, 3] = true ∧
    sameRelation (finiteEval relations475 tree475) [[0, 0, 1, 0], [0, 1, 0, 1], [1, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations475 tree475) (finiteEval relations475 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation475
def tree476 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations476 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation476 : sourceLeaves tree476 = [0, 1] ∧
    guard .JOIN [3, 3] = true ∧
    guard .JOIN [3, 3] = true ∧
    sameRelation (finiteEval relations476 tree476) [[0, 1, 0, 1], [1, 0, 0, 0], [1, 0, 1, 1]] = true ∧
    sameRelation (finiteEval relations476 tree476) (finiteEval relations476 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation476
def tree477 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations477 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]]]
theorem observation477 : sourceLeaves tree477 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations477 tree477) [[1, 0]] = true ∧
    sameRelation (finiteEval relations477 tree477) (finiteEval relations477 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation477
def tree478 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations478 : List (List (List Nat)) := [[[1, 0]], [[0, 1]]]
theorem observation478 : sourceLeaves tree478 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations478 tree478) [[1, 1]] = true ∧
    sameRelation (finiteEval relations478 tree478) (finiteEval relations478 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation478
def tree479 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations479 : List (List (List Nat)) := [[], [[1, 0]]]
theorem observation479 : sourceLeaves tree479 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations479 tree479) [] = true ∧
    sameRelation (finiteEval relations479 tree479) (finiteEval relations479 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation479
def tree480 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations480 : List (List (List Nat)) := [[], [[0, 1]]]
theorem observation480 : sourceLeaves tree480 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations480 tree480) [] = true ∧
    sameRelation (finiteEval relations480 tree480) (finiteEval relations480 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation480
def tree481 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations481 : List (List (List Nat)) := [[[0, 0], [1, 1]], []]
theorem observation481 : sourceLeaves tree481 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations481 tree481) [] = true ∧
    sameRelation (finiteEval relations481 tree481) (finiteEval relations481 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation481
def tree482 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def relations482 : List (List (List Nat)) := [[[1, 0]], []]
theorem observation482 : sourceLeaves tree482 = [0, 1] ∧
    guard .JOIN [2, 2] = true ∧
    guard .JOIN [2, 2] = true ∧
    sameRelation (finiteEval relations482 tree482) [] = true ∧
    sameRelation (finiteEval relations482 tree482) (finiteEval relations482 (.app .join (.leaf 0) (.leaf 1))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation482
def tree483 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations483 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation483 : sourceLeaves tree483 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations483 tree483) [[1, 1]] = true ∧
    sameRelation (finiteEval relations483 tree483) (finiteEval relations483 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation483
def tree484 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations484 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation484 : sourceLeaves tree484 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations484 tree484) [[1, 1]] = true ∧
    sameRelation (finiteEval relations484 tree484) (finiteEval relations484 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation484
def tree485 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations485 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation485 : sourceLeaves tree485 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations485 tree485) [[1, 1]] = true ∧
    sameRelation (finiteEval relations485 tree485) (finiteEval relations485 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation485
def tree486 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations486 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation486 : sourceLeaves tree486 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations486 tree486) [[1, 1]] = true ∧
    sameRelation (finiteEval relations486 tree486) (finiteEval relations486 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation486
def tree487 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations487 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]]]
theorem observation487 : sourceLeaves tree487 = [0, 1, 2] ∧
    guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true ∧
    sameRelation (finiteEval relations487 tree487) [] = true ∧
    sameRelation (finiteEval relations487 tree487) (finiteEval relations487 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation487
def tree488 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations488 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]]]
theorem observation488 : sourceLeaves tree488 = [0, 1, 2] ∧
    guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true ∧
    sameRelation (finiteEval relations488 tree488) [] = true ∧
    sameRelation (finiteEval relations488 tree488) (finiteEval relations488 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation488
def tree489 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations489 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation489 : sourceLeaves tree489 = [0, 1, 2] ∧
    guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true ∧
    sameRelation (finiteEval relations489 tree489) [] = true ∧
    sameRelation (finiteEval relations489 tree489) (finiteEval relations489 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation489
def tree490 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations490 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation490 : sourceLeaves tree490 = [0, 1, 2] ∧
    guard .JOIN [1, 2, 2] = true ∧
    guard .JOIN [1, 2, 2] = true ∧
    sameRelation (finiteEval relations490 tree490) [] = true ∧
    sameRelation (finiteEval relations490 tree490) (finiteEval relations490 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation490
def tree491 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations491 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation491 : sourceLeaves tree491 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 1] = true ∧
    guard .JOIN [2, 2, 1] = true ∧
    sameRelation (finiteEval relations491 tree491) [] = true ∧
    sameRelation (finiteEval relations491 tree491) (finiteEval relations491 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation491
def tree492 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations492 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation492 : sourceLeaves tree492 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 1] = true ∧
    guard .JOIN [2, 2, 1] = true ∧
    sameRelation (finiteEval relations492 tree492) [] = true ∧
    sameRelation (finiteEval relations492 tree492) (finiteEval relations492 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation492
def tree493 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations493 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0]]]
theorem observation493 : sourceLeaves tree493 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 1] = true ∧
    guard .JOIN [2, 2, 1] = true ∧
    sameRelation (finiteEval relations493 tree493) [] = true ∧
    sameRelation (finiteEval relations493 tree493) (finiteEval relations493 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation493
def tree494 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations494 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0]]]
theorem observation494 : sourceLeaves tree494 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 1] = true ∧
    guard .JOIN [2, 2, 1] = true ∧
    sameRelation (finiteEval relations494 tree494) [] = true ∧
    sameRelation (finiteEval relations494 tree494) (finiteEval relations494 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation494
def tree495 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations495 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation495 : sourceLeaves tree495 = [0, 1, 2] ∧
    guard .JOIN [3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3] = true ∧
    sameRelation (finiteEval relations495 tree495) [[0, 0, 1, 0, 1], [0, 1, 0, 0, 0], [0, 1, 0, 1, 1], [1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations495 tree495) (finiteEval relations495 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation495
def tree496 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations496 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation496 : sourceLeaves tree496 = [0, 1, 2] ∧
    guard .JOIN [3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3] = true ∧
    sameRelation (finiteEval relations496 tree496) [[0, 0, 1, 0, 1], [0, 1, 0, 0, 0], [0, 1, 0, 1, 1], [1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations496 tree496) (finiteEval relations496 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation496
def tree497 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations497 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation497 : sourceLeaves tree497 = [0, 1, 2] ∧
    guard .JOIN [3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3] = true ∧
    sameRelation (finiteEval relations497 tree497) [[0, 1, 0, 1, 0], [1, 0, 0, 0, 0], [1, 0, 0, 1, 1], [1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations497 tree497) (finiteEval relations497 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation497
def tree498 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations498 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation498 : sourceLeaves tree498 = [0, 1, 2] ∧
    guard .JOIN [3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3] = true ∧
    sameRelation (finiteEval relations498 tree498) [[0, 1, 0, 1, 0], [1, 0, 0, 0, 0], [1, 0, 0, 1, 1], [1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations498 tree498) (finiteEval relations498 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation498
def tree499 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations499 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation499 : sourceLeaves tree499 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations499 tree499) [[1, 1]] = true ∧
    sameRelation (finiteEval relations499 tree499) (finiteEval relations499 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation499
def tree500 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations500 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation500 : sourceLeaves tree500 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations500 tree500) [[1, 1]] = true ∧
    sameRelation (finiteEval relations500 tree500) (finiteEval relations500 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation500
def tree501 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations501 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation501 : sourceLeaves tree501 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations501 tree501) [[1, 1]] = true ∧
    sameRelation (finiteEval relations501 tree501) (finiteEval relations501 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation501
def tree502 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations502 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation502 : sourceLeaves tree502 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations502 tree502) [[1, 1]] = true ∧
    sameRelation (finiteEval relations502 tree502) (finiteEval relations502 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation502
def tree503 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations503 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[1]]]
theorem observation503 : sourceLeaves tree503 = [0, 1, 2] ∧
    guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true ∧
    sameRelation (finiteEval relations503 tree503) [] = true ∧
    sameRelation (finiteEval relations503 tree503) (finiteEval relations503 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation503
def tree504 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations504 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[1]]]
theorem observation504 : sourceLeaves tree504 = [0, 1, 2] ∧
    guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true ∧
    sameRelation (finiteEval relations504 tree504) [] = true ∧
    sameRelation (finiteEval relations504 tree504) (finiteEval relations504 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation504
def tree505 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations505 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0]]]
theorem observation505 : sourceLeaves tree505 = [0, 1, 2] ∧
    guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true ∧
    sameRelation (finiteEval relations505 tree505) [] = true ∧
    sameRelation (finiteEval relations505 tree505) (finiteEval relations505 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation505
def tree506 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations506 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0]]]
theorem observation506 : sourceLeaves tree506 = [0, 1, 2] ∧
    guard .JOIN [1, 3, 1] = true ∧
    guard .JOIN [1, 3, 1] = true ∧
    sameRelation (finiteEval relations506 tree506) [] = true ∧
    sameRelation (finiteEval relations506 tree506) (finiteEval relations506 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation506
def tree507 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations507 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]]]
theorem observation507 : sourceLeaves tree507 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations507 tree507) [] = true ∧
    sameRelation (finiteEval relations507 tree507) (finiteEval relations507 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation507
def tree508 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations508 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]]]
theorem observation508 : sourceLeaves tree508 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations508 tree508) [] = true ∧
    sameRelation (finiteEval relations508 tree508) (finiteEval relations508 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation508
def tree509 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations509 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation509 : sourceLeaves tree509 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations509 tree509) [] = true ∧
    sameRelation (finiteEval relations509 tree509) (finiteEval relations509 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation509
def tree510 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations510 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation510 : sourceLeaves tree510 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations510 tree510) [] = true ∧
    sameRelation (finiteEval relations510 tree510) (finiteEval relations510 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation510
def tree511 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations511 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation511 : sourceLeaves tree511 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations511 tree511) [] = true ∧
    sameRelation (finiteEval relations511 tree511) (finiteEval relations511 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation511
def tree512 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations512 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation512 : sourceLeaves tree512 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations512 tree512) [] = true ∧
    sameRelation (finiteEval relations512 tree512) (finiteEval relations512 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation512
def tree513 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations513 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation513 : sourceLeaves tree513 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations513 tree513) [] = true ∧
    sameRelation (finiteEval relations513 tree513) (finiteEval relations513 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation513
def tree514 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations514 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation514 : sourceLeaves tree514 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations514 tree514) [] = true ∧
    sameRelation (finiteEval relations514 tree514) (finiteEval relations514 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation514
def tree515 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations515 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], []]
theorem observation515 : sourceLeaves tree515 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations515 tree515) [] = true ∧
    sameRelation (finiteEval relations515 tree515) (finiteEval relations515 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation515
def tree516 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations516 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], []]
theorem observation516 : sourceLeaves tree516 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations516 tree516) [] = true ∧
    sameRelation (finiteEval relations516 tree516) (finiteEval relations516 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation516
def tree517 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations517 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], []]
theorem observation517 : sourceLeaves tree517 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations517 tree517) [] = true ∧
    sameRelation (finiteEval relations517 tree517) (finiteEval relations517 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation517
def tree518 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations518 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], []]
theorem observation518 : sourceLeaves tree518 = [0, 1, 2] ∧
    guard .JOIN [2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2] = true ∧
    sameRelation (finiteEval relations518 tree518) [] = true ∧
    sameRelation (finiteEval relations518 tree518) (finiteEval relations518 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation518
def tree519 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations519 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation519 : sourceLeaves tree519 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations519 tree519) [[1, 1]] = true ∧
    sameRelation (finiteEval relations519 tree519) (finiteEval relations519 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation519
def tree520 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations520 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation520 : sourceLeaves tree520 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations520 tree520) [[1, 1]] = true ∧
    sameRelation (finiteEval relations520 tree520) (finiteEval relations520 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation520
def tree521 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations521 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation521 : sourceLeaves tree521 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations521 tree521) [[1, 1]] = true ∧
    sameRelation (finiteEval relations521 tree521) (finiteEval relations521 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation521
def tree522 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations522 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation522 : sourceLeaves tree522 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations522 tree522) [[1, 1]] = true ∧
    sameRelation (finiteEval relations522 tree522) (finiteEval relations522 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation522
def tree523 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations523 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation523 : sourceLeaves tree523 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations523 tree523) [[1, 1]] = true ∧
    sameRelation (finiteEval relations523 tree523) (finiteEval relations523 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation523
def tree524 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations524 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation524 : sourceLeaves tree524 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations524 tree524) [[1, 0]] = true ∧
    sameRelation (finiteEval relations524 tree524) (finiteEval relations524 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation524
def tree525 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations525 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation525 : sourceLeaves tree525 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations525 tree525) [[1, 0]] = true ∧
    sameRelation (finiteEval relations525 tree525) (finiteEval relations525 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation525
def tree526 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations526 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation526 : sourceLeaves tree526 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations526 tree526) [[1, 0]] = true ∧
    sameRelation (finiteEval relations526 tree526) (finiteEval relations526 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation526
def tree527 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations527 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation527 : sourceLeaves tree527 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations527 tree527) [[1, 0]] = true ∧
    sameRelation (finiteEval relations527 tree527) (finiteEval relations527 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation527
def tree528 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations528 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation528 : sourceLeaves tree528 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations528 tree528) [[1, 0]] = true ∧
    sameRelation (finiteEval relations528 tree528) (finiteEval relations528 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation528
def tree529 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations529 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation529 : sourceLeaves tree529 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations529 tree529) [] = true ∧
    sameRelation (finiteEval relations529 tree529) (finiteEval relations529 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation529
def tree530 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations530 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation530 : sourceLeaves tree530 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations530 tree530) [] = true ∧
    sameRelation (finiteEval relations530 tree530) (finiteEval relations530 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation530
def tree531 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations531 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation531 : sourceLeaves tree531 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations531 tree531) [] = true ∧
    sameRelation (finiteEval relations531 tree531) (finiteEval relations531 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation531
def tree532 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations532 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation532 : sourceLeaves tree532 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations532 tree532) [] = true ∧
    sameRelation (finiteEval relations532 tree532) (finiteEval relations532 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation532
def tree533 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations533 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation533 : sourceLeaves tree533 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations533 tree533) [] = true ∧
    sameRelation (finiteEval relations533 tree533) (finiteEval relations533 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation533
def tree534 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations534 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation534 : sourceLeaves tree534 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations534 tree534) [] = true ∧
    sameRelation (finiteEval relations534 tree534) (finiteEval relations534 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation534
def tree535 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations535 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation535 : sourceLeaves tree535 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations535 tree535) [] = true ∧
    sameRelation (finiteEval relations535 tree535) (finiteEval relations535 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation535
def tree536 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations536 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation536 : sourceLeaves tree536 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations536 tree536) [] = true ∧
    sameRelation (finiteEval relations536 tree536) (finiteEval relations536 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation536
def tree537 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations537 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation537 : sourceLeaves tree537 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations537 tree537) [] = true ∧
    sameRelation (finiteEval relations537 tree537) (finiteEval relations537 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation537
def tree538 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations538 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation538 : sourceLeaves tree538 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations538 tree538) [] = true ∧
    sameRelation (finiteEval relations538 tree538) (finiteEval relations538 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation538
def tree539 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations539 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0]]]
theorem observation539 : sourceLeaves tree539 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations539 tree539) [] = true ∧
    sameRelation (finiteEval relations539 tree539) (finiteEval relations539 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation539
def tree540 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations540 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0]]]
theorem observation540 : sourceLeaves tree540 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations540 tree540) [] = true ∧
    sameRelation (finiteEval relations540 tree540) (finiteEval relations540 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation540
def tree541 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations541 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0]]]
theorem observation541 : sourceLeaves tree541 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations541 tree541) [] = true ∧
    sameRelation (finiteEval relations541 tree541) (finiteEval relations541 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation541
def tree542 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations542 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0]]]
theorem observation542 : sourceLeaves tree542 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations542 tree542) [] = true ∧
    sameRelation (finiteEval relations542 tree542) (finiteEval relations542 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation542
def tree543 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations543 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0]]]
theorem observation543 : sourceLeaves tree543 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations543 tree543) [] = true ∧
    sameRelation (finiteEval relations543 tree543) (finiteEval relations543 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation543
def tree544 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations544 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation544 : sourceLeaves tree544 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations544 tree544) [] = true ∧
    sameRelation (finiteEval relations544 tree544) (finiteEval relations544 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation544
def tree545 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations545 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation545 : sourceLeaves tree545 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations545 tree545) [] = true ∧
    sameRelation (finiteEval relations545 tree545) (finiteEval relations545 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation545
def tree546 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations546 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation546 : sourceLeaves tree546 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations546 tree546) [] = true ∧
    sameRelation (finiteEval relations546 tree546) (finiteEval relations546 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation546
def tree547 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations547 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation547 : sourceLeaves tree547 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations547 tree547) [] = true ∧
    sameRelation (finiteEval relations547 tree547) (finiteEval relations547 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation547
def tree548 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations548 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation548 : sourceLeaves tree548 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations548 tree548) [] = true ∧
    sameRelation (finiteEval relations548 tree548) (finiteEval relations548 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation548
def tree549 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations549 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation549 : sourceLeaves tree549 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations549 tree549) [[0, 0, 1, 0, 1, 0], [0, 1, 0, 0, 0, 0], [0, 1, 0, 0, 1, 1], [0, 1, 0, 1, 1, 0], [1, 1, 1, 0, 1, 0]] = true ∧
    sameRelation (finiteEval relations549 tree549) (finiteEval relations549 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation549
def tree550 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations550 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation550 : sourceLeaves tree550 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations550 tree550) [[0, 0, 1, 0, 1, 0], [0, 1, 0, 0, 0, 0], [0, 1, 0, 0, 1, 1], [0, 1, 0, 1, 1, 0], [1, 1, 1, 0, 1, 0]] = true ∧
    sameRelation (finiteEval relations550 tree550) (finiteEval relations550 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation550
def tree551 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations551 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation551 : sourceLeaves tree551 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations551 tree551) [[0, 0, 1, 0, 1, 0], [0, 1, 0, 0, 0, 0], [0, 1, 0, 0, 1, 1], [0, 1, 0, 1, 1, 0], [1, 1, 1, 0, 1, 0]] = true ∧
    sameRelation (finiteEval relations551 tree551) (finiteEval relations551 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation551
def tree552 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations552 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation552 : sourceLeaves tree552 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations552 tree552) [[0, 0, 1, 0, 1, 0], [0, 1, 0, 0, 0, 0], [0, 1, 0, 0, 1, 1], [0, 1, 0, 1, 1, 0], [1, 1, 1, 0, 1, 0]] = true ∧
    sameRelation (finiteEval relations552 tree552) (finiteEval relations552 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation552
def tree553 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations553 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]]]
theorem observation553 : sourceLeaves tree553 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations553 tree553) [[0, 0, 1, 0, 1, 0], [0, 1, 0, 0, 0, 0], [0, 1, 0, 0, 1, 1], [0, 1, 0, 1, 1, 0], [1, 1, 1, 0, 1, 0]] = true ∧
    sameRelation (finiteEval relations553 tree553) (finiteEval relations553 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation553
def tree554 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations554 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation554 : sourceLeaves tree554 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations554 tree554) [[0, 1, 0, 1, 1, 0], [1, 0, 0, 0, 1, 0], [1, 0, 0, 1, 0, 1], [1, 0, 1, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations554 tree554) (finiteEval relations554 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation554
def tree555 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations555 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation555 : sourceLeaves tree555 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations555 tree555) [[0, 1, 0, 1, 1, 0], [1, 0, 0, 0, 1, 0], [1, 0, 0, 1, 0, 1], [1, 0, 1, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations555 tree555) (finiteEval relations555 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation555
def tree556 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations556 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation556 : sourceLeaves tree556 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations556 tree556) [[0, 1, 0, 1, 1, 0], [1, 0, 0, 0, 1, 0], [1, 0, 0, 1, 0, 1], [1, 0, 1, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations556 tree556) (finiteEval relations556 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation556
def tree557 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations557 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation557 : sourceLeaves tree557 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations557 tree557) [[0, 1, 0, 1, 1, 0], [1, 0, 0, 0, 1, 0], [1, 0, 0, 1, 0, 1], [1, 0, 1, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations557 tree557) (finiteEval relations557 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation557
def tree558 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations558 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation558 : sourceLeaves tree558 = [0, 1, 2, 3] ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations558 tree558) [[0, 1, 0, 1, 1, 0], [1, 0, 0, 0, 1, 0], [1, 0, 0, 1, 0, 1], [1, 0, 1, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations558 tree558) (finiteEval relations558 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation558
def tree559 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations559 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation559 : sourceLeaves tree559 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations559 tree559) [[1, 1]] = true ∧
    sameRelation (finiteEval relations559 tree559) (finiteEval relations559 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation559
def tree560 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations560 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation560 : sourceLeaves tree560 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations560 tree560) [[1, 1]] = true ∧
    sameRelation (finiteEval relations560 tree560) (finiteEval relations560 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation560
def tree561 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations561 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation561 : sourceLeaves tree561 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations561 tree561) [[1, 1]] = true ∧
    sameRelation (finiteEval relations561 tree561) (finiteEval relations561 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation561
def tree562 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations562 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation562 : sourceLeaves tree562 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations562 tree562) [[1, 1]] = true ∧
    sameRelation (finiteEval relations562 tree562) (finiteEval relations562 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation562
def tree563 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations563 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation563 : sourceLeaves tree563 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations563 tree563) [[1, 1]] = true ∧
    sameRelation (finiteEval relations563 tree563) (finiteEval relations563 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation563
def tree564 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations564 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation564 : sourceLeaves tree564 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations564 tree564) [[1, 0]] = true ∧
    sameRelation (finiteEval relations564 tree564) (finiteEval relations564 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation564
def tree565 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations565 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation565 : sourceLeaves tree565 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations565 tree565) [[1, 0]] = true ∧
    sameRelation (finiteEval relations565 tree565) (finiteEval relations565 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation565
def tree566 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations566 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation566 : sourceLeaves tree566 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations566 tree566) [[1, 0]] = true ∧
    sameRelation (finiteEval relations566 tree566) (finiteEval relations566 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation566
def tree567 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations567 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation567 : sourceLeaves tree567 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations567 tree567) [[1, 0]] = true ∧
    sameRelation (finiteEval relations567 tree567) (finiteEval relations567 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation567
def tree568 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations568 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation568 : sourceLeaves tree568 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations568 tree568) [[1, 0]] = true ∧
    sameRelation (finiteEval relations568 tree568) (finiteEval relations568 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation568
def tree569 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations569 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0]]]
theorem observation569 : sourceLeaves tree569 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations569 tree569) [] = true ∧
    sameRelation (finiteEval relations569 tree569) (finiteEval relations569 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation569
def tree570 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations570 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0]]]
theorem observation570 : sourceLeaves tree570 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations570 tree570) [] = true ∧
    sameRelation (finiteEval relations570 tree570) (finiteEval relations570 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation570
def tree571 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations571 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0]]]
theorem observation571 : sourceLeaves tree571 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations571 tree571) [] = true ∧
    sameRelation (finiteEval relations571 tree571) (finiteEval relations571 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation571
def tree572 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations572 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0]]]
theorem observation572 : sourceLeaves tree572 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations572 tree572) [] = true ∧
    sameRelation (finiteEval relations572 tree572) (finiteEval relations572 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation572
def tree573 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations573 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0]]]
theorem observation573 : sourceLeaves tree573 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations573 tree573) [] = true ∧
    sameRelation (finiteEval relations573 tree573) (finiteEval relations573 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation573
def tree574 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations574 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], []]
theorem observation574 : sourceLeaves tree574 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations574 tree574) [] = true ∧
    sameRelation (finiteEval relations574 tree574) (finiteEval relations574 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation574
def tree575 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations575 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], []]
theorem observation575 : sourceLeaves tree575 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations575 tree575) [] = true ∧
    sameRelation (finiteEval relations575 tree575) (finiteEval relations575 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation575
def tree576 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations576 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], []]
theorem observation576 : sourceLeaves tree576 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations576 tree576) [] = true ∧
    sameRelation (finiteEval relations576 tree576) (finiteEval relations576 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation576
def tree577 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations577 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], []]
theorem observation577 : sourceLeaves tree577 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations577 tree577) [] = true ∧
    sameRelation (finiteEval relations577 tree577) (finiteEval relations577 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation577
def tree578 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations578 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], []]
theorem observation578 : sourceLeaves tree578 = [0, 1, 2, 3] ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 1] = true ∧
    sameRelation (finiteEval relations578 tree578) [] = true ∧
    sameRelation (finiteEval relations578 tree578) (finiteEval relations578 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation578
def tree579 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations579 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation579 : sourceLeaves tree579 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations579 tree579) [] = true ∧
    sameRelation (finiteEval relations579 tree579) (finiteEval relations579 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation579
def tree580 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations580 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation580 : sourceLeaves tree580 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations580 tree580) [] = true ∧
    sameRelation (finiteEval relations580 tree580) (finiteEval relations580 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation580
def tree581 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations581 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation581 : sourceLeaves tree581 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations581 tree581) [] = true ∧
    sameRelation (finiteEval relations581 tree581) (finiteEval relations581 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation581
def tree582 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations582 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation582 : sourceLeaves tree582 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations582 tree582) [] = true ∧
    sameRelation (finiteEval relations582 tree582) (finiteEval relations582 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation582
def tree583 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations583 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation583 : sourceLeaves tree583 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations583 tree583) [] = true ∧
    sameRelation (finiteEval relations583 tree583) (finiteEval relations583 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation583
def tree584 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations584 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation584 : sourceLeaves tree584 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations584 tree584) [] = true ∧
    sameRelation (finiteEval relations584 tree584) (finiteEval relations584 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation584
def tree585 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations585 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation585 : sourceLeaves tree585 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations585 tree585) [] = true ∧
    sameRelation (finiteEval relations585 tree585) (finiteEval relations585 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation585
def tree586 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations586 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation586 : sourceLeaves tree586 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations586 tree586) [] = true ∧
    sameRelation (finiteEval relations586 tree586) (finiteEval relations586 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation586
def tree587 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations587 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation587 : sourceLeaves tree587 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations587 tree587) [] = true ∧
    sameRelation (finiteEval relations587 tree587) (finiteEval relations587 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation587
def tree588 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations588 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation588 : sourceLeaves tree588 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations588 tree588) [] = true ∧
    sameRelation (finiteEval relations588 tree588) (finiteEval relations588 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation588
def tree589 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations589 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation589 : sourceLeaves tree589 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations589 tree589) [] = true ∧
    sameRelation (finiteEval relations589 tree589) (finiteEval relations589 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation589
def tree590 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations590 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation590 : sourceLeaves tree590 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations590 tree590) [] = true ∧
    sameRelation (finiteEval relations590 tree590) (finiteEval relations590 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation590
def tree591 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations591 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation591 : sourceLeaves tree591 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations591 tree591) [] = true ∧
    sameRelation (finiteEval relations591 tree591) (finiteEval relations591 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation591
def tree592 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations592 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation592 : sourceLeaves tree592 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations592 tree592) [] = true ∧
    sameRelation (finiteEval relations592 tree592) (finiteEval relations592 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation592
def tree593 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations593 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]]]
theorem observation593 : sourceLeaves tree593 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations593 tree593) [] = true ∧
    sameRelation (finiteEval relations593 tree593) (finiteEval relations593 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation593
def tree594 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations594 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation594 : sourceLeaves tree594 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations594 tree594) [] = true ∧
    sameRelation (finiteEval relations594 tree594) (finiteEval relations594 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation594
def tree595 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations595 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation595 : sourceLeaves tree595 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations595 tree595) [] = true ∧
    sameRelation (finiteEval relations595 tree595) (finiteEval relations595 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation595
def tree596 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations596 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation596 : sourceLeaves tree596 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations596 tree596) [] = true ∧
    sameRelation (finiteEval relations596 tree596) (finiteEval relations596 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation596
def tree597 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations597 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation597 : sourceLeaves tree597 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations597 tree597) [] = true ∧
    sameRelation (finiteEval relations597 tree597) (finiteEval relations597 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation597
def tree598 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations598 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation598 : sourceLeaves tree598 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations598 tree598) [] = true ∧
    sameRelation (finiteEval relations598 tree598) (finiteEval relations598 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation598
def tree599 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations599 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation599 : sourceLeaves tree599 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations599 tree599) [] = true ∧
    sameRelation (finiteEval relations599 tree599) (finiteEval relations599 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation599
def tree600 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations600 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation600 : sourceLeaves tree600 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations600 tree600) [] = true ∧
    sameRelation (finiteEval relations600 tree600) (finiteEval relations600 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation600
def tree601 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations601 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation601 : sourceLeaves tree601 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations601 tree601) [] = true ∧
    sameRelation (finiteEval relations601 tree601) (finiteEval relations601 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation601
def tree602 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations602 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation602 : sourceLeaves tree602 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations602 tree602) [] = true ∧
    sameRelation (finiteEval relations602 tree602) (finiteEval relations602 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation602
def tree603 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations603 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]]]
theorem observation603 : sourceLeaves tree603 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations603 tree603) [] = true ∧
    sameRelation (finiteEval relations603 tree603) (finiteEval relations603 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation603
def tree604 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations604 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation604 : sourceLeaves tree604 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations604 tree604) [] = true ∧
    sameRelation (finiteEval relations604 tree604) (finiteEval relations604 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation604
def tree605 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations605 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation605 : sourceLeaves tree605 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations605 tree605) [] = true ∧
    sameRelation (finiteEval relations605 tree605) (finiteEval relations605 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation605
def tree606 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations606 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation606 : sourceLeaves tree606 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations606 tree606) [] = true ∧
    sameRelation (finiteEval relations606 tree606) (finiteEval relations606 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation606
def tree607 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations607 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation607 : sourceLeaves tree607 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations607 tree607) [] = true ∧
    sameRelation (finiteEval relations607 tree607) (finiteEval relations607 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation607
def tree608 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations608 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation608 : sourceLeaves tree608 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations608 tree608) [] = true ∧
    sameRelation (finiteEval relations608 tree608) (finiteEval relations608 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation608
def tree609 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations609 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], []]
theorem observation609 : sourceLeaves tree609 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations609 tree609) [] = true ∧
    sameRelation (finiteEval relations609 tree609) (finiteEval relations609 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation609
def tree610 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations610 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], []]
theorem observation610 : sourceLeaves tree610 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations610 tree610) [] = true ∧
    sameRelation (finiteEval relations610 tree610) (finiteEval relations610 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation610
def tree611 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations611 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], []]
theorem observation611 : sourceLeaves tree611 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations611 tree611) [] = true ∧
    sameRelation (finiteEval relations611 tree611) (finiteEval relations611 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation611
def tree612 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations612 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], []]
theorem observation612 : sourceLeaves tree612 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations612 tree612) [] = true ∧
    sameRelation (finiteEval relations612 tree612) (finiteEval relations612 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation612
def tree613 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations613 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], []]
theorem observation613 : sourceLeaves tree613 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations613 tree613) [] = true ∧
    sameRelation (finiteEval relations613 tree613) (finiteEval relations613 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation613
def tree614 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))
def relations614 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation614 : sourceLeaves tree614 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations614 tree614) [] = true ∧
    sameRelation (finiteEval relations614 tree614) (finiteEval relations614 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation614
def tree615 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)))
def relations615 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation615 : sourceLeaves tree615 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations615 tree615) [] = true ∧
    sameRelation (finiteEval relations615 tree615) (finiteEval relations615 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation615
def tree616 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3)))
def relations616 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation616 : sourceLeaves tree616 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations616 tree616) [] = true ∧
    sameRelation (finiteEval relations616 tree616) (finiteEval relations616 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation616
def tree617 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3))
def relations617 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation617 : sourceLeaves tree617 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations617 tree617) [] = true ∧
    sameRelation (finiteEval relations617 tree617) (finiteEval relations617 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation617
def tree618 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3))
def relations618 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation618 : sourceLeaves tree618 = [0, 1, 2, 3] ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations618 tree618) [] = true ∧
    sameRelation (finiteEval relations618 tree618) (finiteEval relations618 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation618
def tree619 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations619 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation619 : sourceLeaves tree619 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations619 tree619) [[1, 0]] = true ∧
    sameRelation (finiteEval relations619 tree619) (finiteEval relations619 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation619
def tree620 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations620 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation620 : sourceLeaves tree620 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations620 tree620) [[1, 0]] = true ∧
    sameRelation (finiteEval relations620 tree620) (finiteEval relations620 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation620
def tree621 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations621 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation621 : sourceLeaves tree621 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations621 tree621) [[1, 0]] = true ∧
    sameRelation (finiteEval relations621 tree621) (finiteEval relations621 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation621
def tree622 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations622 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation622 : sourceLeaves tree622 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations622 tree622) [[1, 0]] = true ∧
    sameRelation (finiteEval relations622 tree622) (finiteEval relations622 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation622
def tree623 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations623 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation623 : sourceLeaves tree623 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations623 tree623) [[1, 0]] = true ∧
    sameRelation (finiteEval relations623 tree623) (finiteEval relations623 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation623
def tree624 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations624 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation624 : sourceLeaves tree624 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations624 tree624) [[1, 0]] = true ∧
    sameRelation (finiteEval relations624 tree624) (finiteEval relations624 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation624
def tree625 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations625 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation625 : sourceLeaves tree625 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations625 tree625) [[1, 0]] = true ∧
    sameRelation (finiteEval relations625 tree625) (finiteEval relations625 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation625
def tree626 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations626 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation626 : sourceLeaves tree626 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations626 tree626) [[1, 0]] = true ∧
    sameRelation (finiteEval relations626 tree626) (finiteEval relations626 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation626
def tree627 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations627 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation627 : sourceLeaves tree627 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations627 tree627) [[1, 0]] = true ∧
    sameRelation (finiteEval relations627 tree627) (finiteEval relations627 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation627
def tree628 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations628 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation628 : sourceLeaves tree628 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations628 tree628) [[1, 0]] = true ∧
    sameRelation (finiteEval relations628 tree628) (finiteEval relations628 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation628
def tree629 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations629 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation629 : sourceLeaves tree629 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations629 tree629) [[1, 0]] = true ∧
    sameRelation (finiteEval relations629 tree629) (finiteEval relations629 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation629
def tree630 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations630 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation630 : sourceLeaves tree630 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations630 tree630) [[1, 0]] = true ∧
    sameRelation (finiteEval relations630 tree630) (finiteEval relations630 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation630
def tree631 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations631 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation631 : sourceLeaves tree631 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations631 tree631) [[1, 0]] = true ∧
    sameRelation (finiteEval relations631 tree631) (finiteEval relations631 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation631
def tree632 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations632 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation632 : sourceLeaves tree632 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations632 tree632) [[1, 0]] = true ∧
    sameRelation (finiteEval relations632 tree632) (finiteEval relations632 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation632
def tree633 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations633 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation633 : sourceLeaves tree633 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations633 tree633) [[1, 1]] = true ∧
    sameRelation (finiteEval relations633 tree633) (finiteEval relations633 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation633
def tree634 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations634 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation634 : sourceLeaves tree634 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations634 tree634) [[1, 1]] = true ∧
    sameRelation (finiteEval relations634 tree634) (finiteEval relations634 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation634
def tree635 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations635 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation635 : sourceLeaves tree635 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations635 tree635) [[1, 1]] = true ∧
    sameRelation (finiteEval relations635 tree635) (finiteEval relations635 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation635
def tree636 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations636 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation636 : sourceLeaves tree636 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations636 tree636) [[1, 1]] = true ∧
    sameRelation (finiteEval relations636 tree636) (finiteEval relations636 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation636
def tree637 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations637 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation637 : sourceLeaves tree637 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations637 tree637) [[1, 1]] = true ∧
    sameRelation (finiteEval relations637 tree637) (finiteEval relations637 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation637
def tree638 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations638 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation638 : sourceLeaves tree638 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations638 tree638) [[1, 1]] = true ∧
    sameRelation (finiteEval relations638 tree638) (finiteEval relations638 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation638
def tree639 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations639 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation639 : sourceLeaves tree639 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations639 tree639) [[1, 1]] = true ∧
    sameRelation (finiteEval relations639 tree639) (finiteEval relations639 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation639
def tree640 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations640 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation640 : sourceLeaves tree640 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations640 tree640) [[1, 1]] = true ∧
    sameRelation (finiteEval relations640 tree640) (finiteEval relations640 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation640
def tree641 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations641 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation641 : sourceLeaves tree641 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations641 tree641) [[1, 1]] = true ∧
    sameRelation (finiteEval relations641 tree641) (finiteEval relations641 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation641
def tree642 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations642 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation642 : sourceLeaves tree642 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations642 tree642) [[1, 1]] = true ∧
    sameRelation (finiteEval relations642 tree642) (finiteEval relations642 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation642
def tree643 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations643 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation643 : sourceLeaves tree643 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations643 tree643) [[1, 1]] = true ∧
    sameRelation (finiteEval relations643 tree643) (finiteEval relations643 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation643
def tree644 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations644 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation644 : sourceLeaves tree644 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations644 tree644) [[1, 1]] = true ∧
    sameRelation (finiteEval relations644 tree644) (finiteEval relations644 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation644
def tree645 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations645 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation645 : sourceLeaves tree645 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations645 tree645) [[1, 1]] = true ∧
    sameRelation (finiteEval relations645 tree645) (finiteEval relations645 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation645
def tree646 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations646 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation646 : sourceLeaves tree646 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations646 tree646) [[1, 1]] = true ∧
    sameRelation (finiteEval relations646 tree646) (finiteEval relations646 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation646
def tree647 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations647 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation647 : sourceLeaves tree647 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations647 tree647) [] = true ∧
    sameRelation (finiteEval relations647 tree647) (finiteEval relations647 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation647
def tree648 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations648 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation648 : sourceLeaves tree648 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations648 tree648) [] = true ∧
    sameRelation (finiteEval relations648 tree648) (finiteEval relations648 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation648
def tree649 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations649 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation649 : sourceLeaves tree649 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations649 tree649) [] = true ∧
    sameRelation (finiteEval relations649 tree649) (finiteEval relations649 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation649
def tree650 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations650 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation650 : sourceLeaves tree650 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations650 tree650) [] = true ∧
    sameRelation (finiteEval relations650 tree650) (finiteEval relations650 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation650
def tree651 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations651 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation651 : sourceLeaves tree651 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations651 tree651) [] = true ∧
    sameRelation (finiteEval relations651 tree651) (finiteEval relations651 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation651
def tree652 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations652 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation652 : sourceLeaves tree652 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations652 tree652) [] = true ∧
    sameRelation (finiteEval relations652 tree652) (finiteEval relations652 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation652
def tree653 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations653 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation653 : sourceLeaves tree653 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations653 tree653) [] = true ∧
    sameRelation (finiteEval relations653 tree653) (finiteEval relations653 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation653
def tree654 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations654 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation654 : sourceLeaves tree654 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations654 tree654) [] = true ∧
    sameRelation (finiteEval relations654 tree654) (finiteEval relations654 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation654
def tree655 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations655 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation655 : sourceLeaves tree655 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations655 tree655) [] = true ∧
    sameRelation (finiteEval relations655 tree655) (finiteEval relations655 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation655
def tree656 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations656 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation656 : sourceLeaves tree656 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations656 tree656) [] = true ∧
    sameRelation (finiteEval relations656 tree656) (finiteEval relations656 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation656
def tree657 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations657 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation657 : sourceLeaves tree657 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations657 tree657) [] = true ∧
    sameRelation (finiteEval relations657 tree657) (finiteEval relations657 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation657
def tree658 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations658 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation658 : sourceLeaves tree658 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations658 tree658) [] = true ∧
    sameRelation (finiteEval relations658 tree658) (finiteEval relations658 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation658
def tree659 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations659 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation659 : sourceLeaves tree659 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations659 tree659) [] = true ∧
    sameRelation (finiteEval relations659 tree659) (finiteEval relations659 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation659
def tree660 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations660 : List (List (List Nat)) := [[[0]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation660 : sourceLeaves tree660 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations660 tree660) [] = true ∧
    sameRelation (finiteEval relations660 tree660) (finiteEval relations660 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation660
def tree661 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations661 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation661 : sourceLeaves tree661 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations661 tree661) [] = true ∧
    sameRelation (finiteEval relations661 tree661) (finiteEval relations661 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation661
def tree662 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations662 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation662 : sourceLeaves tree662 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations662 tree662) [] = true ∧
    sameRelation (finiteEval relations662 tree662) (finiteEval relations662 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation662
def tree663 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations663 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation663 : sourceLeaves tree663 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations663 tree663) [] = true ∧
    sameRelation (finiteEval relations663 tree663) (finiteEval relations663 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation663
def tree664 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations664 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation664 : sourceLeaves tree664 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations664 tree664) [] = true ∧
    sameRelation (finiteEval relations664 tree664) (finiteEval relations664 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation664
def tree665 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations665 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation665 : sourceLeaves tree665 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations665 tree665) [] = true ∧
    sameRelation (finiteEval relations665 tree665) (finiteEval relations665 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation665
def tree666 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations666 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation666 : sourceLeaves tree666 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations666 tree666) [] = true ∧
    sameRelation (finiteEval relations666 tree666) (finiteEval relations666 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation666
def tree667 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations667 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation667 : sourceLeaves tree667 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations667 tree667) [] = true ∧
    sameRelation (finiteEval relations667 tree667) (finiteEval relations667 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation667
def tree668 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations668 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation668 : sourceLeaves tree668 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations668 tree668) [] = true ∧
    sameRelation (finiteEval relations668 tree668) (finiteEval relations668 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation668
def tree669 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations669 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation669 : sourceLeaves tree669 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations669 tree669) [] = true ∧
    sameRelation (finiteEval relations669 tree669) (finiteEval relations669 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation669
def tree670 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations670 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation670 : sourceLeaves tree670 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations670 tree670) [] = true ∧
    sameRelation (finiteEval relations670 tree670) (finiteEval relations670 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation670
def tree671 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations671 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation671 : sourceLeaves tree671 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations671 tree671) [] = true ∧
    sameRelation (finiteEval relations671 tree671) (finiteEval relations671 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation671
def tree672 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations672 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation672 : sourceLeaves tree672 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations672 tree672) [] = true ∧
    sameRelation (finiteEval relations672 tree672) (finiteEval relations672 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation672
def tree673 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations673 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation673 : sourceLeaves tree673 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations673 tree673) [] = true ∧
    sameRelation (finiteEval relations673 tree673) (finiteEval relations673 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation673
def tree674 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations674 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation674 : sourceLeaves tree674 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    guard .JOIN [1, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations674 tree674) [] = true ∧
    sameRelation (finiteEval relations674 tree674) (finiteEval relations674 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation674
def tree675 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations675 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation675 : sourceLeaves tree675 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations675 tree675) [] = true ∧
    sameRelation (finiteEval relations675 tree675) (finiteEval relations675 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation675
def tree676 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations676 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation676 : sourceLeaves tree676 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations676 tree676) [] = true ∧
    sameRelation (finiteEval relations676 tree676) (finiteEval relations676 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation676
def tree677 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations677 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation677 : sourceLeaves tree677 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations677 tree677) [] = true ∧
    sameRelation (finiteEval relations677 tree677) (finiteEval relations677 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation677
def tree678 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations678 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation678 : sourceLeaves tree678 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations678 tree678) [] = true ∧
    sameRelation (finiteEval relations678 tree678) (finiteEval relations678 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation678
def tree679 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations679 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation679 : sourceLeaves tree679 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations679 tree679) [] = true ∧
    sameRelation (finiteEval relations679 tree679) (finiteEval relations679 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation679
def tree680 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations680 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation680 : sourceLeaves tree680 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations680 tree680) [] = true ∧
    sameRelation (finiteEval relations680 tree680) (finiteEval relations680 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation680
def tree681 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations681 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation681 : sourceLeaves tree681 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations681 tree681) [] = true ∧
    sameRelation (finiteEval relations681 tree681) (finiteEval relations681 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation681
def tree682 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations682 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation682 : sourceLeaves tree682 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations682 tree682) [] = true ∧
    sameRelation (finiteEval relations682 tree682) (finiteEval relations682 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation682
def tree683 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations683 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation683 : sourceLeaves tree683 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations683 tree683) [] = true ∧
    sameRelation (finiteEval relations683 tree683) (finiteEval relations683 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation683
def tree684 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations684 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation684 : sourceLeaves tree684 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations684 tree684) [] = true ∧
    sameRelation (finiteEval relations684 tree684) (finiteEval relations684 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation684
def tree685 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations685 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation685 : sourceLeaves tree685 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations685 tree685) [] = true ∧
    sameRelation (finiteEval relations685 tree685) (finiteEval relations685 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation685
def tree686 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations686 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation686 : sourceLeaves tree686 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations686 tree686) [] = true ∧
    sameRelation (finiteEval relations686 tree686) (finiteEval relations686 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation686
def tree687 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations687 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation687 : sourceLeaves tree687 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations687 tree687) [] = true ∧
    sameRelation (finiteEval relations687 tree687) (finiteEval relations687 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation687
def tree688 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations688 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation688 : sourceLeaves tree688 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations688 tree688) [] = true ∧
    sameRelation (finiteEval relations688 tree688) (finiteEval relations688 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation688
def tree689 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations689 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation689 : sourceLeaves tree689 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations689 tree689) [] = true ∧
    sameRelation (finiteEval relations689 tree689) (finiteEval relations689 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation689
def tree690 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations690 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation690 : sourceLeaves tree690 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations690 tree690) [] = true ∧
    sameRelation (finiteEval relations690 tree690) (finiteEval relations690 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation690
def tree691 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations691 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation691 : sourceLeaves tree691 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations691 tree691) [] = true ∧
    sameRelation (finiteEval relations691 tree691) (finiteEval relations691 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation691
def tree692 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations692 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation692 : sourceLeaves tree692 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations692 tree692) [] = true ∧
    sameRelation (finiteEval relations692 tree692) (finiteEval relations692 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation692
def tree693 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations693 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation693 : sourceLeaves tree693 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations693 tree693) [] = true ∧
    sameRelation (finiteEval relations693 tree693) (finiteEval relations693 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation693
def tree694 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations694 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation694 : sourceLeaves tree694 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations694 tree694) [] = true ∧
    sameRelation (finiteEval relations694 tree694) (finiteEval relations694 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation694
def tree695 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations695 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation695 : sourceLeaves tree695 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations695 tree695) [] = true ∧
    sameRelation (finiteEval relations695 tree695) (finiteEval relations695 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation695
def tree696 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations696 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation696 : sourceLeaves tree696 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations696 tree696) [] = true ∧
    sameRelation (finiteEval relations696 tree696) (finiteEval relations696 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation696
def tree697 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations697 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation697 : sourceLeaves tree697 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations697 tree697) [] = true ∧
    sameRelation (finiteEval relations697 tree697) (finiteEval relations697 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation697
def tree698 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations698 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation698 : sourceLeaves tree698 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations698 tree698) [] = true ∧
    sameRelation (finiteEval relations698 tree698) (finiteEval relations698 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation698
def tree699 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations699 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation699 : sourceLeaves tree699 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations699 tree699) [] = true ∧
    sameRelation (finiteEval relations699 tree699) (finiteEval relations699 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation699
def tree700 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations700 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation700 : sourceLeaves tree700 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations700 tree700) [] = true ∧
    sameRelation (finiteEval relations700 tree700) (finiteEval relations700 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation700
def tree701 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations701 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation701 : sourceLeaves tree701 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations701 tree701) [] = true ∧
    sameRelation (finiteEval relations701 tree701) (finiteEval relations701 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation701
def tree702 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations702 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation702 : sourceLeaves tree702 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    guard .JOIN [2, 2, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations702 tree702) [] = true ∧
    sameRelation (finiteEval relations702 tree702) (finiteEval relations702 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation702
def tree703 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations703 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation703 : sourceLeaves tree703 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations703 tree703) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations703 tree703) (finiteEval relations703 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation703
def tree704 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations704 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation704 : sourceLeaves tree704 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations704 tree704) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations704 tree704) (finiteEval relations704 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation704
def tree705 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations705 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation705 : sourceLeaves tree705 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations705 tree705) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations705 tree705) (finiteEval relations705 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation705
def tree706 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations706 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation706 : sourceLeaves tree706 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations706 tree706) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations706 tree706) (finiteEval relations706 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation706
def tree707 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations707 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation707 : sourceLeaves tree707 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations707 tree707) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations707 tree707) (finiteEval relations707 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation707
def tree708 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations708 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation708 : sourceLeaves tree708 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations708 tree708) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations708 tree708) (finiteEval relations708 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation708
def tree709 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations709 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation709 : sourceLeaves tree709 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations709 tree709) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations709 tree709) (finiteEval relations709 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation709
def tree710 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations710 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation710 : sourceLeaves tree710 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations710 tree710) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations710 tree710) (finiteEval relations710 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation710
def tree711 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations711 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation711 : sourceLeaves tree711 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations711 tree711) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations711 tree711) (finiteEval relations711 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation711
def tree712 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations712 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation712 : sourceLeaves tree712 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations712 tree712) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations712 tree712) (finiteEval relations712 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation712
def tree713 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations713 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation713 : sourceLeaves tree713 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations713 tree713) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations713 tree713) (finiteEval relations713 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation713
def tree714 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations714 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation714 : sourceLeaves tree714 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations714 tree714) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations714 tree714) (finiteEval relations714 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation714
def tree715 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations715 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation715 : sourceLeaves tree715 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations715 tree715) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations715 tree715) (finiteEval relations715 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation715
def tree716 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations716 : List (List (List Nat)) := [[[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]]]
theorem observation716 : sourceLeaves tree716 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations716 tree716) [[0, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0], [0, 1, 0, 0, 1, 0, 1], [0, 1, 0, 1, 1, 1, 0], [1, 1, 1, 0, 1, 1, 0]] = true ∧
    sameRelation (finiteEval relations716 tree716) (finiteEval relations716 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation716
def tree717 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations717 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation717 : sourceLeaves tree717 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations717 tree717) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations717 tree717) (finiteEval relations717 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation717
def tree718 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations718 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation718 : sourceLeaves tree718 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations718 tree718) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations718 tree718) (finiteEval relations718 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation718
def tree719 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations719 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation719 : sourceLeaves tree719 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations719 tree719) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations719 tree719) (finiteEval relations719 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation719
def tree720 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations720 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation720 : sourceLeaves tree720 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations720 tree720) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations720 tree720) (finiteEval relations720 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation720
def tree721 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations721 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation721 : sourceLeaves tree721 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations721 tree721) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations721 tree721) (finiteEval relations721 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation721
def tree722 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations722 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation722 : sourceLeaves tree722 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations722 tree722) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations722 tree722) (finiteEval relations722 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation722
def tree723 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations723 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation723 : sourceLeaves tree723 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations723 tree723) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations723 tree723) (finiteEval relations723 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation723
def tree724 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations724 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation724 : sourceLeaves tree724 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations724 tree724) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations724 tree724) (finiteEval relations724 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation724
def tree725 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations725 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation725 : sourceLeaves tree725 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations725 tree725) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations725 tree725) (finiteEval relations725 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation725
def tree726 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations726 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation726 : sourceLeaves tree726 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations726 tree726) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations726 tree726) (finiteEval relations726 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation726
def tree727 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations727 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation727 : sourceLeaves tree727 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations727 tree727) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations727 tree727) (finiteEval relations727 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation727
def tree728 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations728 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation728 : sourceLeaves tree728 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations728 tree728) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations728 tree728) (finiteEval relations728 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation728
def tree729 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations729 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation729 : sourceLeaves tree729 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations729 tree729) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations729 tree729) (finiteEval relations729 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation729
def tree730 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations730 : List (List (List Nat)) := [[[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0, 0], [0, 1, 1], [1, 1, 0]], [[0, 1, 0], [1, 0, 1]], [[0, 0, 1], [1, 0, 0], [1, 1, 1]]]
theorem observation730 : sourceLeaves tree730 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    guard .JOIN [3, 3, 3, 3, 3] = true ∧
    sameRelation (finiteEval relations730 tree730) [[0, 1, 0, 1, 1, 0, 1], [1, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0], [1, 0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 0, 1]] = true ∧
    sameRelation (finiteEval relations730 tree730) (finiteEval relations730 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation730
def tree731 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations731 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation731 : sourceLeaves tree731 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations731 tree731) [[1, 0]] = true ∧
    sameRelation (finiteEval relations731 tree731) (finiteEval relations731 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation731
def tree732 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations732 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation732 : sourceLeaves tree732 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations732 tree732) [[1, 0]] = true ∧
    sameRelation (finiteEval relations732 tree732) (finiteEval relations732 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation732
def tree733 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations733 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation733 : sourceLeaves tree733 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations733 tree733) [[1, 0]] = true ∧
    sameRelation (finiteEval relations733 tree733) (finiteEval relations733 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation733
def tree734 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations734 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation734 : sourceLeaves tree734 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations734 tree734) [[1, 0]] = true ∧
    sameRelation (finiteEval relations734 tree734) (finiteEval relations734 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation734
def tree735 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations735 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation735 : sourceLeaves tree735 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations735 tree735) [[1, 0]] = true ∧
    sameRelation (finiteEval relations735 tree735) (finiteEval relations735 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation735
def tree736 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations736 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation736 : sourceLeaves tree736 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations736 tree736) [[1, 0]] = true ∧
    sameRelation (finiteEval relations736 tree736) (finiteEval relations736 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation736
def tree737 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations737 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation737 : sourceLeaves tree737 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations737 tree737) [[1, 0]] = true ∧
    sameRelation (finiteEval relations737 tree737) (finiteEval relations737 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation737
def tree738 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations738 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation738 : sourceLeaves tree738 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations738 tree738) [[1, 0]] = true ∧
    sameRelation (finiteEval relations738 tree738) (finiteEval relations738 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation738
def tree739 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations739 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation739 : sourceLeaves tree739 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations739 tree739) [[1, 0]] = true ∧
    sameRelation (finiteEval relations739 tree739) (finiteEval relations739 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation739
def tree740 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations740 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation740 : sourceLeaves tree740 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations740 tree740) [[1, 0]] = true ∧
    sameRelation (finiteEval relations740 tree740) (finiteEval relations740 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation740
def tree741 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations741 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation741 : sourceLeaves tree741 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations741 tree741) [[1, 0]] = true ∧
    sameRelation (finiteEval relations741 tree741) (finiteEval relations741 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation741
def tree742 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations742 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation742 : sourceLeaves tree742 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations742 tree742) [[1, 0]] = true ∧
    sameRelation (finiteEval relations742 tree742) (finiteEval relations742 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation742
def tree743 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations743 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation743 : sourceLeaves tree743 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations743 tree743) [[1, 0]] = true ∧
    sameRelation (finiteEval relations743 tree743) (finiteEval relations743 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation743
def tree744 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations744 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation744 : sourceLeaves tree744 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations744 tree744) [[1, 0]] = true ∧
    sameRelation (finiteEval relations744 tree744) (finiteEval relations744 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation744
def tree745 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations745 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation745 : sourceLeaves tree745 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations745 tree745) [[1, 1]] = true ∧
    sameRelation (finiteEval relations745 tree745) (finiteEval relations745 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation745
def tree746 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations746 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation746 : sourceLeaves tree746 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations746 tree746) [[1, 1]] = true ∧
    sameRelation (finiteEval relations746 tree746) (finiteEval relations746 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation746
def tree747 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations747 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation747 : sourceLeaves tree747 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations747 tree747) [[1, 1]] = true ∧
    sameRelation (finiteEval relations747 tree747) (finiteEval relations747 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation747
def tree748 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations748 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation748 : sourceLeaves tree748 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations748 tree748) [[1, 1]] = true ∧
    sameRelation (finiteEval relations748 tree748) (finiteEval relations748 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation748
def tree749 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations749 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation749 : sourceLeaves tree749 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations749 tree749) [[1, 1]] = true ∧
    sameRelation (finiteEval relations749 tree749) (finiteEval relations749 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation749
def tree750 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations750 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation750 : sourceLeaves tree750 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations750 tree750) [[1, 1]] = true ∧
    sameRelation (finiteEval relations750 tree750) (finiteEval relations750 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation750
def tree751 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations751 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation751 : sourceLeaves tree751 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations751 tree751) [[1, 1]] = true ∧
    sameRelation (finiteEval relations751 tree751) (finiteEval relations751 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation751
def tree752 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations752 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation752 : sourceLeaves tree752 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations752 tree752) [[1, 1]] = true ∧
    sameRelation (finiteEval relations752 tree752) (finiteEval relations752 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation752
def tree753 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations753 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation753 : sourceLeaves tree753 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations753 tree753) [[1, 1]] = true ∧
    sameRelation (finiteEval relations753 tree753) (finiteEval relations753 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation753
def tree754 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations754 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation754 : sourceLeaves tree754 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations754 tree754) [[1, 1]] = true ∧
    sameRelation (finiteEval relations754 tree754) (finiteEval relations754 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation754
def tree755 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations755 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation755 : sourceLeaves tree755 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations755 tree755) [[1, 1]] = true ∧
    sameRelation (finiteEval relations755 tree755) (finiteEval relations755 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation755
def tree756 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations756 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation756 : sourceLeaves tree756 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations756 tree756) [[1, 1]] = true ∧
    sameRelation (finiteEval relations756 tree756) (finiteEval relations756 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation756
def tree757 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations757 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation757 : sourceLeaves tree757 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations757 tree757) [[1, 1]] = true ∧
    sameRelation (finiteEval relations757 tree757) (finiteEval relations757 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation757
def tree758 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations758 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation758 : sourceLeaves tree758 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations758 tree758) [[1, 1]] = true ∧
    sameRelation (finiteEval relations758 tree758) (finiteEval relations758 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation758
def tree759 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations759 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation759 : sourceLeaves tree759 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations759 tree759) [] = true ∧
    sameRelation (finiteEval relations759 tree759) (finiteEval relations759 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation759
def tree760 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations760 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation760 : sourceLeaves tree760 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations760 tree760) [] = true ∧
    sameRelation (finiteEval relations760 tree760) (finiteEval relations760 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation760
def tree761 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations761 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation761 : sourceLeaves tree761 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations761 tree761) [] = true ∧
    sameRelation (finiteEval relations761 tree761) (finiteEval relations761 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation761
def tree762 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations762 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation762 : sourceLeaves tree762 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations762 tree762) [] = true ∧
    sameRelation (finiteEval relations762 tree762) (finiteEval relations762 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation762
def tree763 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations763 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation763 : sourceLeaves tree763 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations763 tree763) [] = true ∧
    sameRelation (finiteEval relations763 tree763) (finiteEval relations763 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation763
def tree764 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations764 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation764 : sourceLeaves tree764 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations764 tree764) [] = true ∧
    sameRelation (finiteEval relations764 tree764) (finiteEval relations764 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation764
def tree765 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations765 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation765 : sourceLeaves tree765 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations765 tree765) [] = true ∧
    sameRelation (finiteEval relations765 tree765) (finiteEval relations765 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation765
def tree766 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations766 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation766 : sourceLeaves tree766 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations766 tree766) [] = true ∧
    sameRelation (finiteEval relations766 tree766) (finiteEval relations766 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation766
def tree767 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations767 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation767 : sourceLeaves tree767 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations767 tree767) [] = true ∧
    sameRelation (finiteEval relations767 tree767) (finiteEval relations767 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation767
def tree768 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations768 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation768 : sourceLeaves tree768 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations768 tree768) [] = true ∧
    sameRelation (finiteEval relations768 tree768) (finiteEval relations768 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation768
def tree769 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations769 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation769 : sourceLeaves tree769 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations769 tree769) [] = true ∧
    sameRelation (finiteEval relations769 tree769) (finiteEval relations769 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation769
def tree770 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations770 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation770 : sourceLeaves tree770 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations770 tree770) [] = true ∧
    sameRelation (finiteEval relations770 tree770) (finiteEval relations770 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation770
def tree771 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations771 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation771 : sourceLeaves tree771 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations771 tree771) [] = true ∧
    sameRelation (finiteEval relations771 tree771) (finiteEval relations771 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation771
def tree772 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations772 : List (List (List Nat)) := [[[0]], [[0, 1, 0], [1, 0, 1]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation772 : sourceLeaves tree772 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations772 tree772) [] = true ∧
    sameRelation (finiteEval relations772 tree772) (finiteEval relations772 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation772
def tree773 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations773 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation773 : sourceLeaves tree773 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations773 tree773) [] = true ∧
    sameRelation (finiteEval relations773 tree773) (finiteEval relations773 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation773
def tree774 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations774 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation774 : sourceLeaves tree774 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations774 tree774) [] = true ∧
    sameRelation (finiteEval relations774 tree774) (finiteEval relations774 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation774
def tree775 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations775 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation775 : sourceLeaves tree775 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations775 tree775) [] = true ∧
    sameRelation (finiteEval relations775 tree775) (finiteEval relations775 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation775
def tree776 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations776 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation776 : sourceLeaves tree776 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations776 tree776) [] = true ∧
    sameRelation (finiteEval relations776 tree776) (finiteEval relations776 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation776
def tree777 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations777 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation777 : sourceLeaves tree777 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations777 tree777) [] = true ∧
    sameRelation (finiteEval relations777 tree777) (finiteEval relations777 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation777
def tree778 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations778 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation778 : sourceLeaves tree778 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations778 tree778) [] = true ∧
    sameRelation (finiteEval relations778 tree778) (finiteEval relations778 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation778
def tree779 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations779 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation779 : sourceLeaves tree779 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations779 tree779) [] = true ∧
    sameRelation (finiteEval relations779 tree779) (finiteEval relations779 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation779
def tree780 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations780 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation780 : sourceLeaves tree780 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations780 tree780) [] = true ∧
    sameRelation (finiteEval relations780 tree780) (finiteEval relations780 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation780
def tree781 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations781 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation781 : sourceLeaves tree781 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations781 tree781) [] = true ∧
    sameRelation (finiteEval relations781 tree781) (finiteEval relations781 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation781
def tree782 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations782 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation782 : sourceLeaves tree782 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations782 tree782) [] = true ∧
    sameRelation (finiteEval relations782 tree782) (finiteEval relations782 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation782
def tree783 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations783 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation783 : sourceLeaves tree783 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations783 tree783) [] = true ∧
    sameRelation (finiteEval relations783 tree783) (finiteEval relations783 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation783
def tree784 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations784 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation784 : sourceLeaves tree784 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations784 tree784) [] = true ∧
    sameRelation (finiteEval relations784 tree784) (finiteEval relations784 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation784
def tree785 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations785 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation785 : sourceLeaves tree785 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations785 tree785) [] = true ∧
    sameRelation (finiteEval relations785 tree785) (finiteEval relations785 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation785
def tree786 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations786 : List (List (List Nat)) := [[], [[0, 0, 1], [1, 0, 0], [1, 1, 1]], [[0, 0], [1, 1]], [[1, 0]], [[1]]]
theorem observation786 : sourceLeaves tree786 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    guard .JOIN [1, 3, 2, 2, 1] = true ∧
    sameRelation (finiteEval relations786 tree786) [] = true ∧
    sameRelation (finiteEval relations786 tree786) (finiteEval relations786 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation786
def tree787 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations787 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation787 : sourceLeaves tree787 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations787 tree787) [] = true ∧
    sameRelation (finiteEval relations787 tree787) (finiteEval relations787 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation787
def tree788 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations788 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation788 : sourceLeaves tree788 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations788 tree788) [] = true ∧
    sameRelation (finiteEval relations788 tree788) (finiteEval relations788 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation788
def tree789 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations789 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation789 : sourceLeaves tree789 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations789 tree789) [] = true ∧
    sameRelation (finiteEval relations789 tree789) (finiteEval relations789 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation789
def tree790 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations790 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation790 : sourceLeaves tree790 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations790 tree790) [] = true ∧
    sameRelation (finiteEval relations790 tree790) (finiteEval relations790 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation790
def tree791 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations791 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation791 : sourceLeaves tree791 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations791 tree791) [] = true ∧
    sameRelation (finiteEval relations791 tree791) (finiteEval relations791 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation791
def tree792 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations792 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation792 : sourceLeaves tree792 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations792 tree792) [] = true ∧
    sameRelation (finiteEval relations792 tree792) (finiteEval relations792 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation792
def tree793 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations793 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation793 : sourceLeaves tree793 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations793 tree793) [] = true ∧
    sameRelation (finiteEval relations793 tree793) (finiteEval relations793 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation793
def tree794 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations794 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation794 : sourceLeaves tree794 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations794 tree794) [] = true ∧
    sameRelation (finiteEval relations794 tree794) (finiteEval relations794 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation794
def tree795 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations795 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation795 : sourceLeaves tree795 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations795 tree795) [] = true ∧
    sameRelation (finiteEval relations795 tree795) (finiteEval relations795 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation795
def tree796 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations796 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation796 : sourceLeaves tree796 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations796 tree796) [] = true ∧
    sameRelation (finiteEval relations796 tree796) (finiteEval relations796 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation796
def tree797 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations797 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation797 : sourceLeaves tree797 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations797 tree797) [] = true ∧
    sameRelation (finiteEval relations797 tree797) (finiteEval relations797 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation797
def tree798 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations798 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation798 : sourceLeaves tree798 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations798 tree798) [] = true ∧
    sameRelation (finiteEval relations798 tree798) (finiteEval relations798 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation798
def tree799 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations799 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation799 : sourceLeaves tree799 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations799 tree799) [] = true ∧
    sameRelation (finiteEval relations799 tree799) (finiteEval relations799 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation799
def tree800 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations800 : List (List (List Nat)) := [[], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation800 : sourceLeaves tree800 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations800 tree800) [] = true ∧
    sameRelation (finiteEval relations800 tree800) (finiteEval relations800 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation800
def tree801 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations801 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation801 : sourceLeaves tree801 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations801 tree801) [] = true ∧
    sameRelation (finiteEval relations801 tree801) (finiteEval relations801 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation801
def tree802 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations802 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation802 : sourceLeaves tree802 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations802 tree802) [] = true ∧
    sameRelation (finiteEval relations802 tree802) (finiteEval relations802 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation802
def tree803 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations803 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation803 : sourceLeaves tree803 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations803 tree803) [] = true ∧
    sameRelation (finiteEval relations803 tree803) (finiteEval relations803 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation803
def tree804 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations804 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation804 : sourceLeaves tree804 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations804 tree804) [] = true ∧
    sameRelation (finiteEval relations804 tree804) (finiteEval relations804 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation804
def tree805 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations805 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation805 : sourceLeaves tree805 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations805 tree805) [] = true ∧
    sameRelation (finiteEval relations805 tree805) (finiteEval relations805 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation805
def tree806 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations806 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation806 : sourceLeaves tree806 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations806 tree806) [] = true ∧
    sameRelation (finiteEval relations806 tree806) (finiteEval relations806 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation806
def tree807 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations807 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation807 : sourceLeaves tree807 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations807 tree807) [] = true ∧
    sameRelation (finiteEval relations807 tree807) (finiteEval relations807 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation807
def tree808 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations808 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation808 : sourceLeaves tree808 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations808 tree808) [] = true ∧
    sameRelation (finiteEval relations808 tree808) (finiteEval relations808 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation808
def tree809 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations809 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation809 : sourceLeaves tree809 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations809 tree809) [] = true ∧
    sameRelation (finiteEval relations809 tree809) (finiteEval relations809 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation809
def tree810 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations810 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation810 : sourceLeaves tree810 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations810 tree810) [] = true ∧
    sameRelation (finiteEval relations810 tree810) (finiteEval relations810 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation810
def tree811 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations811 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation811 : sourceLeaves tree811 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations811 tree811) [] = true ∧
    sameRelation (finiteEval relations811 tree811) (finiteEval relations811 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation811
def tree812 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations812 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation812 : sourceLeaves tree812 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations812 tree812) [] = true ∧
    sameRelation (finiteEval relations812 tree812) (finiteEval relations812 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation812
def tree813 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations813 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation813 : sourceLeaves tree813 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations813 tree813) [] = true ∧
    sameRelation (finiteEval relations813 tree813) (finiteEval relations813 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation813
def tree814 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations814 : List (List (List Nat)) := [[], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation814 : sourceLeaves tree814 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations814 tree814) [] = true ∧
    sameRelation (finiteEval relations814 tree814) (finiteEval relations814 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation814
def tree815 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations815 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation815 : sourceLeaves tree815 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations815 tree815) [] = true ∧
    sameRelation (finiteEval relations815 tree815) (finiteEval relations815 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation815
def tree816 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations816 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation816 : sourceLeaves tree816 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations816 tree816) [] = true ∧
    sameRelation (finiteEval relations816 tree816) (finiteEval relations816 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation816
def tree817 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations817 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation817 : sourceLeaves tree817 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations817 tree817) [] = true ∧
    sameRelation (finiteEval relations817 tree817) (finiteEval relations817 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation817
def tree818 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations818 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation818 : sourceLeaves tree818 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations818 tree818) [] = true ∧
    sameRelation (finiteEval relations818 tree818) (finiteEval relations818 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation818
def tree819 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations819 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation819 : sourceLeaves tree819 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations819 tree819) [] = true ∧
    sameRelation (finiteEval relations819 tree819) (finiteEval relations819 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation819
def tree820 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations820 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation820 : sourceLeaves tree820 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations820 tree820) [] = true ∧
    sameRelation (finiteEval relations820 tree820) (finiteEval relations820 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation820
def tree821 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations821 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation821 : sourceLeaves tree821 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations821 tree821) [] = true ∧
    sameRelation (finiteEval relations821 tree821) (finiteEval relations821 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation821
def tree822 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations822 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation822 : sourceLeaves tree822 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations822 tree822) [] = true ∧
    sameRelation (finiteEval relations822 tree822) (finiteEval relations822 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation822
def tree823 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations823 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation823 : sourceLeaves tree823 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations823 tree823) [] = true ∧
    sameRelation (finiteEval relations823 tree823) (finiteEval relations823 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation823
def tree824 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations824 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation824 : sourceLeaves tree824 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations824 tree824) [] = true ∧
    sameRelation (finiteEval relations824 tree824) (finiteEval relations824 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation824
def tree825 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations825 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation825 : sourceLeaves tree825 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations825 tree825) [] = true ∧
    sameRelation (finiteEval relations825 tree825) (finiteEval relations825 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation825
def tree826 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations826 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation826 : sourceLeaves tree826 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations826 tree826) [] = true ∧
    sameRelation (finiteEval relations826 tree826) (finiteEval relations826 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation826
def tree827 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations827 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation827 : sourceLeaves tree827 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations827 tree827) [] = true ∧
    sameRelation (finiteEval relations827 tree827) (finiteEval relations827 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation827
def tree828 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations828 : List (List (List Nat)) := [[[0, 0], [1, 1]], [], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation828 : sourceLeaves tree828 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations828 tree828) [] = true ∧
    sameRelation (finiteEval relations828 tree828) (finiteEval relations828 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation828
def tree829 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations829 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation829 : sourceLeaves tree829 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations829 tree829) [] = true ∧
    sameRelation (finiteEval relations829 tree829) (finiteEval relations829 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation829
def tree830 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations830 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation830 : sourceLeaves tree830 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations830 tree830) [] = true ∧
    sameRelation (finiteEval relations830 tree830) (finiteEval relations830 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation830
def tree831 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations831 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation831 : sourceLeaves tree831 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations831 tree831) [] = true ∧
    sameRelation (finiteEval relations831 tree831) (finiteEval relations831 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation831
def tree832 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations832 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation832 : sourceLeaves tree832 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations832 tree832) [] = true ∧
    sameRelation (finiteEval relations832 tree832) (finiteEval relations832 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation832
def tree833 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations833 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation833 : sourceLeaves tree833 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations833 tree833) [] = true ∧
    sameRelation (finiteEval relations833 tree833) (finiteEval relations833 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation833
def tree834 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations834 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation834 : sourceLeaves tree834 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations834 tree834) [] = true ∧
    sameRelation (finiteEval relations834 tree834) (finiteEval relations834 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation834
def tree835 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations835 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation835 : sourceLeaves tree835 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations835 tree835) [] = true ∧
    sameRelation (finiteEval relations835 tree835) (finiteEval relations835 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation835
def tree836 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations836 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation836 : sourceLeaves tree836 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations836 tree836) [] = true ∧
    sameRelation (finiteEval relations836 tree836) (finiteEval relations836 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation836
def tree837 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations837 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation837 : sourceLeaves tree837 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations837 tree837) [] = true ∧
    sameRelation (finiteEval relations837 tree837) (finiteEval relations837 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation837
def tree838 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations838 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation838 : sourceLeaves tree838 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations838 tree838) [] = true ∧
    sameRelation (finiteEval relations838 tree838) (finiteEval relations838 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation838
def tree839 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations839 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation839 : sourceLeaves tree839 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations839 tree839) [] = true ∧
    sameRelation (finiteEval relations839 tree839) (finiteEval relations839 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation839
def tree840 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations840 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation840 : sourceLeaves tree840 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations840 tree840) [] = true ∧
    sameRelation (finiteEval relations840 tree840) (finiteEval relations840 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation840
def tree841 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations841 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation841 : sourceLeaves tree841 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations841 tree841) [] = true ∧
    sameRelation (finiteEval relations841 tree841) (finiteEval relations841 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation841
def tree842 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations842 : List (List (List Nat)) := [[[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]], [[0, 1]]]
theorem observation842 : sourceLeaves tree842 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations842 tree842) [] = true ∧
    sameRelation (finiteEval relations842 tree842) (finiteEval relations842 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation842
def tree843 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations843 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation843 : sourceLeaves tree843 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations843 tree843) [] = true ∧
    sameRelation (finiteEval relations843 tree843) (finiteEval relations843 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation843
def tree844 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations844 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation844 : sourceLeaves tree844 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations844 tree844) [] = true ∧
    sameRelation (finiteEval relations844 tree844) (finiteEval relations844 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation844
def tree845 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations845 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation845 : sourceLeaves tree845 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations845 tree845) [] = true ∧
    sameRelation (finiteEval relations845 tree845) (finiteEval relations845 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation845
def tree846 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations846 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation846 : sourceLeaves tree846 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations846 tree846) [] = true ∧
    sameRelation (finiteEval relations846 tree846) (finiteEval relations846 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation846
def tree847 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations847 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation847 : sourceLeaves tree847 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations847 tree847) [] = true ∧
    sameRelation (finiteEval relations847 tree847) (finiteEval relations847 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation847
def tree848 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations848 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation848 : sourceLeaves tree848 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations848 tree848) [] = true ∧
    sameRelation (finiteEval relations848 tree848) (finiteEval relations848 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation848
def tree849 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations849 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation849 : sourceLeaves tree849 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations849 tree849) [] = true ∧
    sameRelation (finiteEval relations849 tree849) (finiteEval relations849 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation849
def tree850 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations850 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation850 : sourceLeaves tree850 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations850 tree850) [] = true ∧
    sameRelation (finiteEval relations850 tree850) (finiteEval relations850 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation850
def tree851 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations851 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation851 : sourceLeaves tree851 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations851 tree851) [] = true ∧
    sameRelation (finiteEval relations851 tree851) (finiteEval relations851 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation851
def tree852 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations852 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation852 : sourceLeaves tree852 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations852 tree852) [] = true ∧
    sameRelation (finiteEval relations852 tree852) (finiteEval relations852 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation852
def tree853 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations853 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation853 : sourceLeaves tree853 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations853 tree853) [] = true ∧
    sameRelation (finiteEval relations853 tree853) (finiteEval relations853 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation853
def tree854 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations854 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation854 : sourceLeaves tree854 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations854 tree854) [] = true ∧
    sameRelation (finiteEval relations854 tree854) (finiteEval relations854 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation854
def tree855 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations855 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation855 : sourceLeaves tree855 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations855 tree855) [] = true ∧
    sameRelation (finiteEval relations855 tree855) (finiteEval relations855 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation855
def tree856 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations856 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [], [[0, 0], [1, 1]], [[1, 0]]]
theorem observation856 : sourceLeaves tree856 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations856 tree856) [] = true ∧
    sameRelation (finiteEval relations856 tree856) (finiteEval relations856 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation856
def tree857 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations857 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation857 : sourceLeaves tree857 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations857 tree857) [] = true ∧
    sameRelation (finiteEval relations857 tree857) (finiteEval relations857 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation857
def tree858 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations858 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation858 : sourceLeaves tree858 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations858 tree858) [] = true ∧
    sameRelation (finiteEval relations858 tree858) (finiteEval relations858 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation858
def tree859 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations859 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation859 : sourceLeaves tree859 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations859 tree859) [] = true ∧
    sameRelation (finiteEval relations859 tree859) (finiteEval relations859 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation859
def tree860 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations860 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation860 : sourceLeaves tree860 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations860 tree860) [] = true ∧
    sameRelation (finiteEval relations860 tree860) (finiteEval relations860 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation860
def tree861 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations861 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation861 : sourceLeaves tree861 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations861 tree861) [] = true ∧
    sameRelation (finiteEval relations861 tree861) (finiteEval relations861 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation861
def tree862 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations862 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation862 : sourceLeaves tree862 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations862 tree862) [] = true ∧
    sameRelation (finiteEval relations862 tree862) (finiteEval relations862 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation862
def tree863 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations863 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation863 : sourceLeaves tree863 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations863 tree863) [] = true ∧
    sameRelation (finiteEval relations863 tree863) (finiteEval relations863 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation863
def tree864 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations864 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation864 : sourceLeaves tree864 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations864 tree864) [] = true ∧
    sameRelation (finiteEval relations864 tree864) (finiteEval relations864 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation864
def tree865 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations865 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation865 : sourceLeaves tree865 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations865 tree865) [] = true ∧
    sameRelation (finiteEval relations865 tree865) (finiteEval relations865 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation865
def tree866 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations866 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation866 : sourceLeaves tree866 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations866 tree866) [] = true ∧
    sameRelation (finiteEval relations866 tree866) (finiteEval relations866 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation866
def tree867 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations867 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation867 : sourceLeaves tree867 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations867 tree867) [] = true ∧
    sameRelation (finiteEval relations867 tree867) (finiteEval relations867 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation867
def tree868 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations868 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation868 : sourceLeaves tree868 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations868 tree868) [] = true ∧
    sameRelation (finiteEval relations868 tree868) (finiteEval relations868 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation868
def tree869 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations869 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation869 : sourceLeaves tree869 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations869 tree869) [] = true ∧
    sameRelation (finiteEval relations869 tree869) (finiteEval relations869 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation869
def tree870 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations870 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [], [[1, 0]], [[0, 1]]]
theorem observation870 : sourceLeaves tree870 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations870 tree870) [] = true ∧
    sameRelation (finiteEval relations870 tree870) (finiteEval relations870 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation870
def tree871 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations871 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation871 : sourceLeaves tree871 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations871 tree871) [] = true ∧
    sameRelation (finiteEval relations871 tree871) (finiteEval relations871 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation871
def tree872 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations872 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation872 : sourceLeaves tree872 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations872 tree872) [] = true ∧
    sameRelation (finiteEval relations872 tree872) (finiteEval relations872 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation872
def tree873 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations873 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation873 : sourceLeaves tree873 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations873 tree873) [] = true ∧
    sameRelation (finiteEval relations873 tree873) (finiteEval relations873 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation873
def tree874 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations874 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation874 : sourceLeaves tree874 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations874 tree874) [] = true ∧
    sameRelation (finiteEval relations874 tree874) (finiteEval relations874 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation874
def tree875 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations875 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation875 : sourceLeaves tree875 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations875 tree875) [] = true ∧
    sameRelation (finiteEval relations875 tree875) (finiteEval relations875 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation875
def tree876 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations876 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation876 : sourceLeaves tree876 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations876 tree876) [] = true ∧
    sameRelation (finiteEval relations876 tree876) (finiteEval relations876 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation876
def tree877 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations877 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation877 : sourceLeaves tree877 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations877 tree877) [] = true ∧
    sameRelation (finiteEval relations877 tree877) (finiteEval relations877 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation877
def tree878 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations878 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation878 : sourceLeaves tree878 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations878 tree878) [] = true ∧
    sameRelation (finiteEval relations878 tree878) (finiteEval relations878 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation878
def tree879 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations879 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation879 : sourceLeaves tree879 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations879 tree879) [] = true ∧
    sameRelation (finiteEval relations879 tree879) (finiteEval relations879 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation879
def tree880 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations880 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation880 : sourceLeaves tree880 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations880 tree880) [] = true ∧
    sameRelation (finiteEval relations880 tree880) (finiteEval relations880 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation880
def tree881 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations881 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation881 : sourceLeaves tree881 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations881 tree881) [] = true ∧
    sameRelation (finiteEval relations881 tree881) (finiteEval relations881 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation881
def tree882 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations882 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation882 : sourceLeaves tree882 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations882 tree882) [] = true ∧
    sameRelation (finiteEval relations882 tree882) (finiteEval relations882 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation882
def tree883 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations883 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation883 : sourceLeaves tree883 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations883 tree883) [] = true ∧
    sameRelation (finiteEval relations883 tree883) (finiteEval relations883 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation883
def tree884 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations884 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [], [[1, 0]]]
theorem observation884 : sourceLeaves tree884 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations884 tree884) [] = true ∧
    sameRelation (finiteEval relations884 tree884) (finiteEval relations884 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation884
def tree885 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations885 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation885 : sourceLeaves tree885 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations885 tree885) [] = true ∧
    sameRelation (finiteEval relations885 tree885) (finiteEval relations885 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation885
def tree886 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations886 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation886 : sourceLeaves tree886 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations886 tree886) [] = true ∧
    sameRelation (finiteEval relations886 tree886) (finiteEval relations886 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation886
def tree887 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations887 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation887 : sourceLeaves tree887 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations887 tree887) [] = true ∧
    sameRelation (finiteEval relations887 tree887) (finiteEval relations887 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation887
def tree888 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations888 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation888 : sourceLeaves tree888 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations888 tree888) [] = true ∧
    sameRelation (finiteEval relations888 tree888) (finiteEval relations888 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation888
def tree889 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations889 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation889 : sourceLeaves tree889 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations889 tree889) [] = true ∧
    sameRelation (finiteEval relations889 tree889) (finiteEval relations889 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation889
def tree890 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations890 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation890 : sourceLeaves tree890 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations890 tree890) [] = true ∧
    sameRelation (finiteEval relations890 tree890) (finiteEval relations890 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation890
def tree891 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations891 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation891 : sourceLeaves tree891 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations891 tree891) [] = true ∧
    sameRelation (finiteEval relations891 tree891) (finiteEval relations891 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation891
def tree892 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations892 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation892 : sourceLeaves tree892 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations892 tree892) [] = true ∧
    sameRelation (finiteEval relations892 tree892) (finiteEval relations892 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation892
def tree893 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations893 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation893 : sourceLeaves tree893 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations893 tree893) [] = true ∧
    sameRelation (finiteEval relations893 tree893) (finiteEval relations893 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation893
def tree894 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations894 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation894 : sourceLeaves tree894 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations894 tree894) [] = true ∧
    sameRelation (finiteEval relations894 tree894) (finiteEval relations894 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation894
def tree895 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations895 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation895 : sourceLeaves tree895 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations895 tree895) [] = true ∧
    sameRelation (finiteEval relations895 tree895) (finiteEval relations895 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation895
def tree896 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations896 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation896 : sourceLeaves tree896 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations896 tree896) [] = true ∧
    sameRelation (finiteEval relations896 tree896) (finiteEval relations896 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation896
def tree897 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations897 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation897 : sourceLeaves tree897 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations897 tree897) [] = true ∧
    sameRelation (finiteEval relations897 tree897) (finiteEval relations897 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation897
def tree898 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations898 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [], [[0, 1]]]
theorem observation898 : sourceLeaves tree898 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations898 tree898) [] = true ∧
    sameRelation (finiteEval relations898 tree898) (finiteEval relations898 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation898
def tree899 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations899 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation899 : sourceLeaves tree899 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations899 tree899) [] = true ∧
    sameRelation (finiteEval relations899 tree899) (finiteEval relations899 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation899
def tree900 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations900 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation900 : sourceLeaves tree900 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations900 tree900) [] = true ∧
    sameRelation (finiteEval relations900 tree900) (finiteEval relations900 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation900
def tree901 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations901 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation901 : sourceLeaves tree901 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations901 tree901) [] = true ∧
    sameRelation (finiteEval relations901 tree901) (finiteEval relations901 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation901
def tree902 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations902 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation902 : sourceLeaves tree902 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations902 tree902) [] = true ∧
    sameRelation (finiteEval relations902 tree902) (finiteEval relations902 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation902
def tree903 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations903 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation903 : sourceLeaves tree903 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations903 tree903) [] = true ∧
    sameRelation (finiteEval relations903 tree903) (finiteEval relations903 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation903
def tree904 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations904 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation904 : sourceLeaves tree904 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations904 tree904) [] = true ∧
    sameRelation (finiteEval relations904 tree904) (finiteEval relations904 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation904
def tree905 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations905 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation905 : sourceLeaves tree905 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations905 tree905) [] = true ∧
    sameRelation (finiteEval relations905 tree905) (finiteEval relations905 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation905
def tree906 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations906 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation906 : sourceLeaves tree906 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations906 tree906) [] = true ∧
    sameRelation (finiteEval relations906 tree906) (finiteEval relations906 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation906
def tree907 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations907 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation907 : sourceLeaves tree907 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations907 tree907) [] = true ∧
    sameRelation (finiteEval relations907 tree907) (finiteEval relations907 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation907
def tree908 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations908 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation908 : sourceLeaves tree908 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations908 tree908) [] = true ∧
    sameRelation (finiteEval relations908 tree908) (finiteEval relations908 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation908
def tree909 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations909 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation909 : sourceLeaves tree909 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations909 tree909) [] = true ∧
    sameRelation (finiteEval relations909 tree909) (finiteEval relations909 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation909
def tree910 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations910 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation910 : sourceLeaves tree910 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations910 tree910) [] = true ∧
    sameRelation (finiteEval relations910 tree910) (finiteEval relations910 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation910
def tree911 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations911 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation911 : sourceLeaves tree911 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations911 tree911) [] = true ∧
    sameRelation (finiteEval relations911 tree911) (finiteEval relations911 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation911
def tree912 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations912 : List (List (List Nat)) := [[[0, 0], [1, 1]], [[1, 0]], [[0, 1]], [[0, 0], [1, 1]], []]
theorem observation912 : sourceLeaves tree912 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations912 tree912) [] = true ∧
    sameRelation (finiteEval relations912 tree912) (finiteEval relations912 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation912
def tree913 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))
def relations913 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation913 : sourceLeaves tree913 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations913 tree913) [] = true ∧
    sameRelation (finiteEval relations913 tree913) (finiteEval relations913 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation913
def tree914 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4))))
def relations914 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation914 : sourceLeaves tree914 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations914 tree914) [] = true ∧
    sameRelation (finiteEval relations914 tree914) (finiteEval relations914 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation914
def tree915 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4))))
def relations915 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation915 : sourceLeaves tree915 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations915 tree915) [] = true ∧
    sameRelation (finiteEval relations915 tree915) (finiteEval relations915 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation915
def tree916 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4)))
def relations916 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation916 : sourceLeaves tree916 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations916 tree916) [] = true ∧
    sameRelation (finiteEval relations916 tree916) (finiteEval relations916 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation916
def tree917 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3)) (.leaf 4)))
def relations917 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation917 : sourceLeaves tree917 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations917 tree917) [] = true ∧
    sameRelation (finiteEval relations917 tree917) (finiteEval relations917 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation917
def tree918 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4))))
def relations918 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation918 : sourceLeaves tree918 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations918 tree918) [] = true ∧
    sameRelation (finiteEval relations918 tree918) (finiteEval relations918 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation918
def tree919 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.app .join (.leaf 2) (.leaf 3)) (.leaf 4)))
def relations919 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation919 : sourceLeaves tree919 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations919 tree919) [] = true ∧
    sameRelation (finiteEval relations919 tree919) (finiteEval relations919 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation919
def tree920 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.app .join (.leaf 3) (.leaf 4)))
def relations920 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation920 : sourceLeaves tree920 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations920 tree920) [] = true ∧
    sameRelation (finiteEval relations920 tree920) (finiteEval relations920 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation920
def tree921 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.app .join (.leaf 3) (.leaf 4)))
def relations921 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation921 : sourceLeaves tree921 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations921 tree921) [] = true ∧
    sameRelation (finiteEval relations921 tree921) (finiteEval relations921 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation921
def tree922 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 3)))) (.leaf 4))
def relations922 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation922 : sourceLeaves tree922 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations922 tree922) [] = true ∧
    sameRelation (finiteEval relations922 tree922) (finiteEval relations922 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation922
def tree923 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 3))) (.leaf 4))
def relations923 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation923 : sourceLeaves tree923 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations923 tree923) [] = true ∧
    sameRelation (finiteEval relations923 tree923) (finiteEval relations923 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation923
def tree924 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 3))) (.leaf 4))
def relations924 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation924 : sourceLeaves tree924 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations924 tree924) [] = true ∧
    sameRelation (finiteEval relations924 tree924) (finiteEval relations924 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation924
def tree925 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 3)) (.leaf 4))
def relations925 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation925 : sourceLeaves tree925 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations925 tree925) [] = true ∧
    sameRelation (finiteEval relations925 tree925) (finiteEval relations925 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation925
def tree926 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 3)) (.leaf 4))
def relations926 : List (List (List Nat)) := [[[1, 0]], [[0, 1]], [[0, 0], [1, 1]], [[1, 0]], []]
theorem observation926 : sourceLeaves tree926 = [0, 1, 2, 3, 4] ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    guard .JOIN [2, 2, 2, 2, 2] = true ∧
    sameRelation (finiteEval relations926 tree926) [] = true ∧
    sameRelation (finiteEval relations926 tree926) (finiteEval relations926 (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 3) (.leaf 4)))))) = true ∧
    (true : Bool) = true := by
  simp only [guard_executable]
  decide
#print axioms observation926
def tree927 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def relations927 : List (List (List Nat)) := [[[0, 1]], [[1]], [[0, 0]]]
theorem observation927 : sourceLeaves tree927 = [0, 1, 2] ∧
    guard .JOIN [2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2] = false ∧
    sameRelation (finiteEval relations927 tree927) [] = true ∧
    sameRelation (finiteEval relations927 tree927) (finiteEval relations927 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = true ∧
    (false : Bool) = false := by
  simp only [guard_executable]
  decide
#print axioms observation927
def tree928 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def relations928 : List (List (List Nat)) := [[[0, 1]], [[1]], [[0, 0]]]
theorem observation928 : sourceLeaves tree928 = [0, 1, 2] ∧
    guard .JOIN [2, 1, 2] = false ∧
    guard .JOIN [2, 1, 2] = false ∧
    sameRelation (finiteEval relations928 tree928) [[0]] = true ∧
    sameRelation (finiteEval relations928 tree928) (finiteEval relations928 (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))) = false ∧
    (false : Bool) = false := by
  simp only [guard_executable]
  decide
#print axioms observation928
def tree929 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
theorem observation929 : sourceLeaves tree929 = [0, 1, 2] ∧
    (false : Bool) = true := by decide

end ACGN.ThirdFive.JoinReplay
