import CallAuthorityTransitions
open ACGN.ThirdFive.CallAuthorityTransitions
namespace ACGN.ThirdFive.CallReplay
set_option maxRecDepth 4096
def table0 : List Signature := [(Signature.mk 0 0 0 0), (Signature.mk 1 1 1 0), (Signature.mk 2 1 2 0), (Signature.mk 3 0 0 0), (Signature.mk 4 0 0 0), (Signature.mk 5 0 0 0), (Signature.mk 6 0 0 0), (Signature.mk 7 0 0 0), (Signature.mk 8 0 0 0), (Signature.mk 9 0 0 0), (Signature.mk 10 0 0 0), (Signature.mk 11 0 0 0), (Signature.mk 12 0 0 0), (Signature.mk 13 0 0 0), (Signature.mk 14 0 0 0), (Signature.mk 15 0 0 0), (Signature.mk 16 0 0 0), (Signature.mk 17 0 2 0), (Signature.mk 18 1 0 1), (Signature.mk 18 1 1 1), (Signature.mk 19 1 0 1), (Signature.mk 19 1 1 1), (Signature.mk 20 1 0 1), (Signature.mk 21 1 0 1)]
def declaration0 : Signature := (Signature.mk 1 1 1 0)
def source0 : Source := (.call (Signature.mk 1 1 1 0) (sourceArgs [(.barrier 0 (sourceArgs [(.call (Signature.mk 2 1 2 0) (sourceArgs [(.atom 1), (.atom 2)]))]))]))
def masg_tree0 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 2 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
def ir_tree0 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.boundary 0 (ports [(.application (Signature.mk 2 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))]))
def cert_tree0 : Representation := (.application (Signature.mk 1 1 1 0) (ports [(.application (Signature.mk 2 1 2 0) (ports [(.scalar 1), (.scalar 2)]))]))
theorem call0 : resolve table0 1 1 1 = some declaration0 ∧
    declaration0 = (Signature.mk 1 1 1 0) ∧
    JavaAritySafe declaration0.arity ∧
    (1 : Nat) = declaration0.arity ∧
    declaration0.arity = declaredArity [1] ∧
    checkRepresentation source0 masg_tree0 = true ∧
    checkRepresentation source0 ir_tree0 = true ∧
    checkRepresentation source0 cert_tree0 = true ∧
    consume 0 1 (fun v => decide (v = 1)) = (1, some 1) ∧
    consume 1 1 (fun v => decide (v = 1)) = (2, none) ∧
    allocations (fun _ => 0) [41, 41] = [(41, 1), (41, 2)] ∧
    JavaStepSafe 0 ∧
    JavaStepSafe 1 ∧
    (0 : Nat) = 0 ∧
    (1 : Nat) = 1 ∧
    (1 : Nat) = 1 := by decide
#print axioms call0
end ACGN.ThirdFive.CallReplay
