import FlatContainerRecords
open ACGN.FifthFive.FlatContainerRecords
set_option maxRecDepth 4096
set_option maxHeartbeats 4000000
namespace ACGN.FifthFive.FlatContainerRecordsReplay
def env0 : Environment := ⟨"ref-5", "ref-6", "ref-7", (fun i => if i == 0 then "ref-8" else if i == 1 then "ref-9" else "unbound-term"), (fun s => if sourceCode s == "1" then "ref-0" else if sourceCode s == "0" then "ref-1" else if sourceCode s == "[1,0]" then "ref-2" else if sourceCode s == "[[1,0],1]" then "ref-3" else if sourceCode s == "[[[1,0],1],0]" then "ref-4" else "unbound-source"), (fun _ _ => "ref-10")⟩
def bound0 : FlatRecord := ⟨"ref-11", "ref-12", "ref-5", "0/0", "NODE", "ref-13", "ref-14", "ref-15", "ref-16", leaf "unused" [], [], leaf "unused" []⟩
def expected0 : FlatRecord := reconstructFlat env0 .set (.app [(.app [(.app [(.leaf 1),(.leaf 0)]),(.leaf 1)]),(.leaf 0)]) bound0
def env1 : Environment := ⟨"ref-5", "ref-6", "ref-7", (fun i => if i == 0 then "ref-8" else if i == 1 then "ref-9" else "unbound-term"), (fun s => if sourceCode s == "1" then "ref-0" else if sourceCode s == "0" then "ref-1" else if sourceCode s == "[1,0]" then "ref-2" else if sourceCode s == "[0,[1,0]]" then "ref-17" else if sourceCode s == "[1,[0,[1,0]]]" then "ref-18" else "unbound-source"), (fun _ _ => "ref-10")⟩
def bound1 : FlatRecord := ⟨"ref-19", "ref-12", "ref-5", "0/0", "NODE", "ref-13", "ref-20", "ref-15", "ref-21", leaf "unused" [], [], leaf "unused" []⟩
def expected1 : FlatRecord := reconstructFlat env1 .set (.app [(.leaf 1),(.app [(.leaf 0),(.app [(.leaf 1),(.leaf 0)])])]) bound1
def env2 : Environment := ⟨"ref-5", "ref-6", "ref-7", (fun i => if i == 0 then "ref-8" else if i == 1 then "ref-9" else "unbound-term"), (fun s => if sourceCode s == "1" then "ref-0" else if sourceCode s == "0" then "ref-1" else if sourceCode s == "[1,0]" then "ref-2" else if sourceCode s == "[[1,0],[1,0]]" then "ref-22" else "unbound-source"), (fun _ _ => "ref-10")⟩
def bound2 : FlatRecord := ⟨"ref-23", "ref-12", "ref-5", "0/0", "NODE", "ref-13", "ref-24", "ref-15", "ref-25", leaf "unused" [], [], leaf "unused" []⟩
def expected2 : FlatRecord := reconstructFlat env2 .set (.app [(.app [(.leaf 1),(.leaf 0)]),(.app [(.leaf 1),(.leaf 0)])]) bound2
def env3 : Environment := ⟨"ref-31", "ref-6", "ref-32", (fun i => if i == 0 then "ref-33" else if i == 1 then "ref-34" else "unbound-term"), (fun s => if sourceCode s == "1" then "ref-26" else if sourceCode s == "0" then "ref-27" else if sourceCode s == "[1,0]" then "ref-28" else if sourceCode s == "[[1,0],1]" then "ref-29" else if sourceCode s == "[[[1,0],1],0]" then "ref-30" else "unbound-source"), (fun _ _ => "ref-35")⟩
def bound3 : FlatRecord := ⟨"ref-36", "ref-37", "ref-31", "0/0", "NODE", "ref-38", "ref-39", "ref-40", "ref-41", leaf "unused" [], [], leaf "unused" []⟩
def expected3 : FlatRecord := reconstructFlat env3 .bag (.app [(.app [(.app [(.leaf 1),(.leaf 0)]),(.leaf 1)]),(.leaf 0)]) bound3
def env4 : Environment := ⟨"ref-31", "ref-6", "ref-32", (fun i => if i == 0 then "ref-33" else if i == 1 then "ref-34" else "unbound-term"), (fun s => if sourceCode s == "1" then "ref-26" else if sourceCode s == "0" then "ref-27" else if sourceCode s == "[1,0]" then "ref-28" else if sourceCode s == "[0,[1,0]]" then "ref-42" else if sourceCode s == "[1,[0,[1,0]]]" then "ref-43" else "unbound-source"), (fun _ _ => "ref-35")⟩
def bound4 : FlatRecord := ⟨"ref-44", "ref-37", "ref-31", "0/0", "NODE", "ref-38", "ref-45", "ref-40", "ref-46", leaf "unused" [], [], leaf "unused" []⟩
def expected4 : FlatRecord := reconstructFlat env4 .bag (.app [(.leaf 1),(.app [(.leaf 0),(.app [(.leaf 1),(.leaf 0)])])]) bound4
def env5 : Environment := ⟨"ref-31", "ref-6", "ref-32", (fun i => if i == 0 then "ref-33" else if i == 1 then "ref-34" else "unbound-term"), (fun s => if sourceCode s == "1" then "ref-26" else if sourceCode s == "0" then "ref-27" else if sourceCode s == "[1,0]" then "ref-28" else if sourceCode s == "[[1,0],[1,0]]" then "ref-47" else "unbound-source"), (fun _ _ => "ref-35")⟩
def bound5 : FlatRecord := ⟨"ref-48", "ref-37", "ref-31", "0/0", "NODE", "ref-38", "ref-49", "ref-40", "ref-50", leaf "unused" [], [], leaf "unused" []⟩
def expected5 : FlatRecord := reconstructFlat env5 .bag (.app [(.app [(.leaf 1),(.leaf 0)]),(.app [(.leaf 1),(.leaf 0)])]) bound5
def env6 : Environment := ⟨"ref-51", "ref-6", "ref-52", (fun i => if i == 0 then "ref-8" else if i == 1 then "unused-1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-53")⟩
def bound6 : ContainerRecord := ⟨"ref-54", "ref-12", "ref-51", "0/0", "ref-55", "ref-56", "ref-57", "ref-58", [], leaf "unused" []⟩
def expected6 : ContainerRecord := reconstructContainer env6 .bag [0,0] bound6
def env7 : Environment := ⟨"ref-51", "ref-6", "ref-52", (fun i => if i == 0 then "ref-8" else if i == 1 then "ref-9" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-59")⟩
def bound7 : ContainerRecord := ⟨"ref-60", "ref-12", "ref-51", "0/0", "ref-61", "ref-62", "ref-63", "ref-64", [], leaf "unused" []⟩
def expected7 : ContainerRecord := reconstructContainer env7 .bag [0,1] bound7
def env8 : Environment := ⟨"ref-51", "ref-6", "ref-52", (fun i => if i == 0 then "ref-8" else if i == 1 then "ref-9" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-65")⟩
def bound8 : ContainerRecord := ⟨"ref-66", "ref-12", "ref-51", "0/0", "ref-61", "ref-67", "ref-63", "ref-68", [], leaf "unused" []⟩
def expected8 : ContainerRecord := reconstructContainer env8 .bag [1,0] bound8
def env9 : Environment := ⟨"ref-51", "ref-6", "ref-52", (fun i => if i == 0 then "unused-0" else if i == 1 then "ref-9" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-69")⟩
def bound9 : ContainerRecord := ⟨"ref-70", "ref-12", "ref-51", "0/0", "ref-71", "ref-72", "ref-73", "ref-74", [], leaf "unused" []⟩
def expected9 : ContainerRecord := reconstructContainer env9 .bag [1,1] bound9
def env10 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-75")⟩
def expected10 : Wire := reconstructTrace env10 .seq []
def env11 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-76")⟩
def expected11 : Wire := reconstructTrace env11 .seq [0]
def env12 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-77")⟩
def expected12 : Wire := reconstructTrace env12 .seq [1,0,1,0]
def env13 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-78")⟩
def expected13 : Wire := reconstructTrace env13 .seq [0,1]
def env14 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-79")⟩
def expected14 : Wire := reconstructTrace env14 .seq [0,0]
def env15 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-80")⟩
def expected15 : Wire := reconstructTrace env15 .bag []
def env16 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-81")⟩
def expected16 : Wire := reconstructTrace env16 .bag [0]
def env17 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-82")⟩
def expected17 : Wire := reconstructTrace env17 .bag [1,0,1,0]
def env18 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-83")⟩
def expected18 : Wire := reconstructTrace env18 .bag [0,1]
def env19 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-84")⟩
def expected19 : Wire := reconstructTrace env19 .bag [0,0]
def env20 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-85")⟩
def expected20 : Wire := reconstructTrace env20 .set []
def env21 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-86")⟩
def expected21 : Wire := reconstructTrace env21 .set [0]
def env22 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-87")⟩
def expected22 : Wire := reconstructTrace env22 .set [1,0,1,0]
def env23 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-88")⟩
def expected23 : Wire := reconstructTrace env23 .set [0,1]
def env24 : Environment := ⟨"operator", "context", "schema", (fun i => if i == 0 then "0" else if i == 1 then "1" else "unbound-term"), (fun _ => "unbound-source"), (fun _ _ => "ref-89")⟩
def expected24 : Wire := reconstructTrace env24 .set [0,0]
example : ([((wireEqual expected10 (.node "container-trace" ["schema","context","0","0","ref-75"] []) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","0","0","ref-75"] []) (.node "container-trace" ["schema","context","0","0","ref-75"] [])),
((wireEqual expected11 (.node "container-trace" ["schema","context","1","1","ref-76"] [(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] [])]) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","1","1","ref-76"] [(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] [])]) (.node "container-trace" ["schema","context","1","1","ref-76"] [(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] [])])),
((wireEqual expected12 (.node "container-trace" ["schema","context","4","4","ref-77"] [(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["1","0"] []),(.node "trace-output" ["0","1"] []),(.node "trace-output" ["1","2"] []),(.node "trace-output" ["0","99"] [])]) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","4","4","ref-77"] [(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["1","0"] []),(.node "trace-output" ["0","1"] []),(.node "trace-output" ["1","2"] []),(.node "trace-output" ["0","99"] [])]) (.node "container-trace" ["schema","context","4","4","ref-77"] [(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["1","0"] []),(.node "trace-output" ["0","1"] []),(.node "trace-output" ["1","2"] []),(.node "trace-output" ["0","3"] [])])),
((wireEqual expected13 (.node "container-trace" ["schema","context","2","2","ref-78"] [(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-output" ["0","0"] []),(.node "trace-output" ["1","1"] [])]) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","2","2","ref-78"] [(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-output" ["0","0"] []),(.node "trace-output" ["1","1"] [])]) (.node "container-trace" ["schema","context","2","2","ref-78"] [(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-output" ["0","0"] []),(.node "trace-output" ["1","1"] [])])),
((wireEqual expected14 (.node "container-trace" ["schema","context","2","2","ref-79"] [(.node "trace-input" ["0"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] []),(.node "trace-output" ["0","1"] [])]) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","2","2","ref-79"] [(.node "trace-input" ["0"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] []),(.node "trace-output" ["0","1"] [])]) (.node "container-trace" ["schema","context","2","2","ref-79"] [(.node "trace-input" ["0"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] []),(.node "trace-output" ["0","1"] [])])),
((wireEqual expected15 (.node "container-trace" ["schema","context","0","0","ref-80"] []) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","0","0","ref-80"] []) (.node "container-trace" ["schema","context","0","0","ref-80"] [])),
((wireEqual expected16 (.node "container-trace" ["schema","context","1","1","ref-81"] [(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] [])]) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","1","1","ref-81"] [(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] [])]) (.node "container-trace" ["schema","context","1","1","ref-81"] [(.node "trace-input" ["0"] []),(.node "trace-output" ["0","0"] [])])),
((wireEqual expected17 (.node "container-trace" ["schema","context","4","4","ref-82"] [(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["0","1"] []),(.node "trace-output" ["0","3"] []),(.node "trace-output" ["1","0"] []),(.node "trace-output" ["1","2"] [])]) == true) && (true == true) && (true == true) && wireEqual (.node "container-trace" ["schema","context","4","4","ref-82"] [(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["0","1"] []),(.node "trace-output" ["0","3"] []),(.node "trace-output" ["1","0"] []),(.node "trace-output" ["1","2"] [])]) (.node "container-trace" ["schema","context","4","4","ref-82"] [(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-input" ["1"] []),(.node "trace-input" ["0"] []),(.node "trace-output" ["0","1"] []),(.node "trace-output" ["0","3"] []),(.node "trace-output" ["1","0"] []),(.node "trace-output" ["1","2"] [])]))] : List Bool).all id = true := by decide
end ACGN.FifthFive.FlatContainerRecordsReplay
