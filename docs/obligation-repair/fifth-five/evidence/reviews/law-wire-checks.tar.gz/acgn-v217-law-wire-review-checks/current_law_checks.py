import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
formal = base / 'formal'
sys.path.insert(0, str(base / 'source/scripts'))
spec = importlib.util.spec_from_file_location('law_review_current', base / 'fifth_law_record_replays-current.py')
law = importlib.util.module_from_spec(spec); spec.loader.exec_module(law)
lean = '/tmp/acgn-v215-cold-elan424/toolchains/leanprover--lean4---v4.33.0/bin/lean'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', LEAN_PATH=str(formal))
records = []

def run(label, path, expected=0):
    started = time.monotonic()
    argv = [lean, '--root=' + str(formal), str(path)]
    logpath = base / (label + '.log')
    with logpath.open('w') as log:
        proc = subprocess.run(argv, cwd=formal, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    records.append(dict(label=label, argv=argv, code=proc.returncode, seconds=round(time.monotonic()-started,3)))
    (base / 'law-current-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, proc.returncode, records[-1]['seconds'], flush=True)
    assert proc.returncode == expected, logpath
    if expected == 1:
        text = logpath.read_text()
        assert 'decide' in text and ('false' in text or 'False' in text), text

for name, text, count in law.generate(base, formal):
    path = formal / ('Current' + name)
    path.write_text(text)
    print('theorems', count, 'bytes', len(text.encode()), flush=True)
    run('law-current-replay', path)
for i, (label, name, text) in enumerate(law.negatives(base, formal)):
    path = formal / ('Current' + name)
    path.write_text(text)
    run('law-current-negative-' + str(i), path, 1)
print('DONE', flush=True)
