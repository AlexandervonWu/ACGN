import json
from pathlib import Path
import sys

base = Path(__file__).resolve().parent
rows = [line.split('\t') for line in (base / 'public-wire-probe.tsv').read_text().splitlines()]
units = [r for r in rows if r[0] == 'units']
proofs = ['import CanonicalWireTables', 'import LawRecordWire', 'namespace LawWireIndependentReview',
          'namespace W', 'open ACGN.FifthFive.CanonicalWireTables']
for r in units:
    proofs += [f'def s{r[1]} : Bytes := [{r[2]}]',
               f'theorem units{r[1]} : utf16Units s{r[1]} = [{r[3]}] := by decide +kernel',
               f'#print axioms units{r[1]}']
counts = dict(units=0, order=0, utf8=0, law=0)
for r in rows:
    counts[r[0]] += 1
    if r[0] == 'order':
        _, i, j, lt, code = r
        result = {'ACCEPT': 'accept', 'DUPLICATE_ID': 'duplicate', 'NONCANONICAL_ENCODING': 'order',
                  'INVALID_RECORD_SHAPE': 'shape'}[code]
        name = f'order{i}_{j}'
        proofs += [f'theorem {name} : javaLT s{i} s{j} = {lt} ∧ '
                   f'checkRows (fun _ => []) [119] false none [.mk [119] [s{i}] [], .mk [119] [s{j}] []] = .{result} := by decide +kernel',
                   f'#print axioms {name}']
    elif r[0] == 'utf8':
        _, i, text, code = r
        assert code in ('ACCEPT', 'INVALID_UTF8')
        proofs += [f'theorem utf8_{i} : utf8 [{text}] = {str(code == "ACCEPT").lower()} := by decide +kernel', f'#print axioms utf8_{i}']
proofs += ['end W', 'namespace L', 'open ACGN.FifthFive.LawRecordWire']
for r in units:
    text = bytes(int(n) for n in r[2].split(',') if n).decode('utf8')
    cps = ','.join(str(ord(c)) for c in text)
    counts['law'] += 1
    proofs += [f'def s{r[1]} : Text := ofCodepoints [{cps}]',
               f'theorem units{r[1]} : utf16Units s{r[1]} = [{r[3]}] ∧ utf16Length s{r[1]} = {len(r[3].split(",")) if r[3] else 0} := by decide +kernel',
               f'#print axioms units{r[1]}']
for r in rows:
    if r[0] == 'order':
        _, i, j, lt, _ = r
        counts['law'] += 1
        name = f'order{i}_{j}'
        proofs += [f'theorem {name} : javaLess s{i} s{j} = {lt} := by decide +kernel', f'#print axioms {name}']
proofs += ['end L', 'end LawWireIndependentReview', '']
(base / 'formal/IndependentReview.lean').write_text('\n'.join(proofs))
(base / 'independent-counts.json').write_text(json.dumps(counts, indent=2) + '\n')
print(counts)
