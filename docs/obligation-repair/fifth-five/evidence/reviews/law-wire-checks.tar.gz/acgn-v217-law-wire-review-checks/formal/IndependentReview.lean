import CanonicalWireTables
import LawRecordWire
namespace LawWireIndependentReview
namespace W
open ACGN.FifthFive.CanonicalWireTables
def s0 : Bytes := [0]
theorem units0 : utf16Units s0 = [0] := by decide +kernel
#print axioms units0
def s1 : Bytes := [1]
theorem units1 : utf16Units s1 = [1] := by decide +kernel
#print axioms units1
def s2 : Bytes := [127]
theorem units2 : utf16Units s2 = [127] := by decide +kernel
#print axioms units2
def s3 : Bytes := [194,128]
theorem units3 : utf16Units s3 = [128] := by decide +kernel
#print axioms units3
def s4 : Bytes := [195,191]
theorem units4 : utf16Units s4 = [255] := by decide +kernel
#print axioms units4
def s5 : Bytes := [223,191]
theorem units5 : utf16Units s5 = [2047] := by decide +kernel
#print axioms units5
def s6 : Bytes := [224,160,128]
theorem units6 : utf16Units s6 = [2048] := by decide +kernel
#print axioms units6
def s7 : Bytes := [224,191,191]
theorem units7 : utf16Units s7 = [4095] := by decide +kernel
#print axioms units7
def s8 : Bytes := [237,159,191]
theorem units8 : utf16Units s8 = [55295] := by decide +kernel
#print axioms units8
def s9 : Bytes := [238,128,128]
theorem units9 : utf16Units s9 = [57344] := by decide +kernel
#print axioms units9
def s10 : Bytes := [239,191,191]
theorem units10 : utf16Units s10 = [65535] := by decide +kernel
#print axioms units10
def s11 : Bytes := [240,144,128,128]
theorem units11 : utf16Units s11 = [55296,56320] := by decide +kernel
#print axioms units11
def s12 : Bytes := [240,144,128,129]
theorem units12 : utf16Units s12 = [55296,56321] := by decide +kernel
#print axioms units12
def s13 : Bytes := [244,143,191,191]
theorem units13 : utf16Units s13 = [56319,57343] := by decide +kernel
#print axioms units13
def s14 : Bytes := []
theorem units14 : utf16Units s14 = [] := by decide +kernel
#print axioms units14
def s15 : Bytes := [112,114,101,102,105,120]
theorem units15 : utf16Units s15 = [112,114,101,102,105,120] := by decide +kernel
#print axioms units15
def s16 : Bytes := [112,114,101,102,105,120,45,109,111,114,101]
theorem units16 : utf16Units s16 = [112,114,101,102,105,120,45,109,111,114,101] := by decide +kernel
#print axioms units16
def s17 : Bytes := [115,97,109,101]
theorem units17 : utf16Units s17 = [115,97,109,101] := by decide +kernel
#print axioms units17
def s18 : Bytes := [97,0,98]
theorem units18 : utf16Units s18 = [97,0,98] := by decide +kernel
#print axioms units18
def s19 : Bytes := [240,144,128,128,238,128,128]
theorem units19 : utf16Units s19 = [55296,56320,57344] := by decide +kernel
#print axioms units19
def s20 : Bytes := [238,128,128,240,144,128,128]
theorem units20 : utf16Units s20 = [57344,55296,56320] := by decide +kernel
#print axioms units20
def s21 : Bytes := [101,204,129]
theorem units21 : utf16Units s21 = [101,769] := by decide +kernel
#print axioms units21
theorem order0_0 : javaLT s0 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s0] []] = .duplicate := by decide +kernel
#print axioms order0_0
theorem order0_1 : javaLT s0 s1 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s1] []] = .accept := by decide +kernel
#print axioms order0_1
theorem order0_2 : javaLT s0 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order0_2
theorem order0_3 : javaLT s0 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order0_3
theorem order0_4 : javaLT s0 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order0_4
theorem order0_5 : javaLT s0 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order0_5
theorem order0_6 : javaLT s0 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order0_6
theorem order0_7 : javaLT s0 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order0_7
theorem order0_8 : javaLT s0 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order0_8
theorem order0_9 : javaLT s0 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order0_9
theorem order0_10 : javaLT s0 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order0_10
theorem order0_11 : javaLT s0 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order0_11
theorem order0_12 : javaLT s0 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order0_12
theorem order0_13 : javaLT s0 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order0_13
theorem order0_14 : javaLT s0 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order0_14
theorem order0_15 : javaLT s0 s15 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s15] []] = .accept := by decide +kernel
#print axioms order0_15
theorem order0_16 : javaLT s0 s16 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s16] []] = .accept := by decide +kernel
#print axioms order0_16
theorem order0_17 : javaLT s0 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s17] []] = .accept := by decide +kernel
#print axioms order0_17
theorem order0_18 : javaLT s0 s18 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s18] []] = .accept := by decide +kernel
#print axioms order0_18
theorem order0_19 : javaLT s0 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order0_19
theorem order0_20 : javaLT s0 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order0_20
theorem order0_21 : javaLT s0 s21 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s0] [], .mk [119] [s21] []] = .accept := by decide +kernel
#print axioms order0_21
theorem order1_0 : javaLT s1 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order1_0
theorem order1_1 : javaLT s1 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s1] []] = .duplicate := by decide +kernel
#print axioms order1_1
theorem order1_2 : javaLT s1 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order1_2
theorem order1_3 : javaLT s1 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order1_3
theorem order1_4 : javaLT s1 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order1_4
theorem order1_5 : javaLT s1 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order1_5
theorem order1_6 : javaLT s1 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order1_6
theorem order1_7 : javaLT s1 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order1_7
theorem order1_8 : javaLT s1 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order1_8
theorem order1_9 : javaLT s1 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order1_9
theorem order1_10 : javaLT s1 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order1_10
theorem order1_11 : javaLT s1 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order1_11
theorem order1_12 : javaLT s1 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order1_12
theorem order1_13 : javaLT s1 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order1_13
theorem order1_14 : javaLT s1 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order1_14
theorem order1_15 : javaLT s1 s15 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s15] []] = .accept := by decide +kernel
#print axioms order1_15
theorem order1_16 : javaLT s1 s16 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s16] []] = .accept := by decide +kernel
#print axioms order1_16
theorem order1_17 : javaLT s1 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s17] []] = .accept := by decide +kernel
#print axioms order1_17
theorem order1_18 : javaLT s1 s18 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s18] []] = .accept := by decide +kernel
#print axioms order1_18
theorem order1_19 : javaLT s1 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order1_19
theorem order1_20 : javaLT s1 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order1_20
theorem order1_21 : javaLT s1 s21 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s1] [], .mk [119] [s21] []] = .accept := by decide +kernel
#print axioms order1_21
theorem order2_0 : javaLT s2 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order2_0
theorem order2_1 : javaLT s2 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order2_1
theorem order2_2 : javaLT s2 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s2] []] = .duplicate := by decide +kernel
#print axioms order2_2
theorem order2_3 : javaLT s2 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order2_3
theorem order2_4 : javaLT s2 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order2_4
theorem order2_5 : javaLT s2 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order2_5
theorem order2_6 : javaLT s2 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order2_6
theorem order2_7 : javaLT s2 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order2_7
theorem order2_8 : javaLT s2 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order2_8
theorem order2_9 : javaLT s2 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order2_9
theorem order2_10 : javaLT s2 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order2_10
theorem order2_11 : javaLT s2 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order2_11
theorem order2_12 : javaLT s2 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order2_12
theorem order2_13 : javaLT s2 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order2_13
theorem order2_14 : javaLT s2 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order2_14
theorem order2_15 : javaLT s2 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order2_15
theorem order2_16 : javaLT s2 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order2_16
theorem order2_17 : javaLT s2 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order2_17
theorem order2_18 : javaLT s2 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order2_18
theorem order2_19 : javaLT s2 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order2_19
theorem order2_20 : javaLT s2 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order2_20
theorem order2_21 : javaLT s2 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s2] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order2_21
theorem order3_0 : javaLT s3 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order3_0
theorem order3_1 : javaLT s3 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order3_1
theorem order3_2 : javaLT s3 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order3_2
theorem order3_3 : javaLT s3 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s3] []] = .duplicate := by decide +kernel
#print axioms order3_3
theorem order3_4 : javaLT s3 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order3_4
theorem order3_5 : javaLT s3 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order3_5
theorem order3_6 : javaLT s3 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order3_6
theorem order3_7 : javaLT s3 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order3_7
theorem order3_8 : javaLT s3 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order3_8
theorem order3_9 : javaLT s3 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order3_9
theorem order3_10 : javaLT s3 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order3_10
theorem order3_11 : javaLT s3 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order3_11
theorem order3_12 : javaLT s3 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order3_12
theorem order3_13 : javaLT s3 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order3_13
theorem order3_14 : javaLT s3 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order3_14
theorem order3_15 : javaLT s3 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order3_15
theorem order3_16 : javaLT s3 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order3_16
theorem order3_17 : javaLT s3 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order3_17
theorem order3_18 : javaLT s3 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order3_18
theorem order3_19 : javaLT s3 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order3_19
theorem order3_20 : javaLT s3 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order3_20
theorem order3_21 : javaLT s3 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s3] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order3_21
theorem order4_0 : javaLT s4 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order4_0
theorem order4_1 : javaLT s4 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order4_1
theorem order4_2 : javaLT s4 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order4_2
theorem order4_3 : javaLT s4 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order4_3
theorem order4_4 : javaLT s4 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s4] []] = .duplicate := by decide +kernel
#print axioms order4_4
theorem order4_5 : javaLT s4 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order4_5
theorem order4_6 : javaLT s4 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order4_6
theorem order4_7 : javaLT s4 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order4_7
theorem order4_8 : javaLT s4 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order4_8
theorem order4_9 : javaLT s4 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order4_9
theorem order4_10 : javaLT s4 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order4_10
theorem order4_11 : javaLT s4 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order4_11
theorem order4_12 : javaLT s4 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order4_12
theorem order4_13 : javaLT s4 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order4_13
theorem order4_14 : javaLT s4 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order4_14
theorem order4_15 : javaLT s4 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order4_15
theorem order4_16 : javaLT s4 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order4_16
theorem order4_17 : javaLT s4 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order4_17
theorem order4_18 : javaLT s4 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order4_18
theorem order4_19 : javaLT s4 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order4_19
theorem order4_20 : javaLT s4 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order4_20
theorem order4_21 : javaLT s4 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s4] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order4_21
theorem order5_0 : javaLT s5 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order5_0
theorem order5_1 : javaLT s5 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order5_1
theorem order5_2 : javaLT s5 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order5_2
theorem order5_3 : javaLT s5 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order5_3
theorem order5_4 : javaLT s5 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order5_4
theorem order5_5 : javaLT s5 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s5] []] = .duplicate := by decide +kernel
#print axioms order5_5
theorem order5_6 : javaLT s5 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order5_6
theorem order5_7 : javaLT s5 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order5_7
theorem order5_8 : javaLT s5 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order5_8
theorem order5_9 : javaLT s5 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order5_9
theorem order5_10 : javaLT s5 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order5_10
theorem order5_11 : javaLT s5 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order5_11
theorem order5_12 : javaLT s5 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order5_12
theorem order5_13 : javaLT s5 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order5_13
theorem order5_14 : javaLT s5 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order5_14
theorem order5_15 : javaLT s5 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order5_15
theorem order5_16 : javaLT s5 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order5_16
theorem order5_17 : javaLT s5 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order5_17
theorem order5_18 : javaLT s5 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order5_18
theorem order5_19 : javaLT s5 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order5_19
theorem order5_20 : javaLT s5 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order5_20
theorem order5_21 : javaLT s5 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s5] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order5_21
theorem order6_0 : javaLT s6 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order6_0
theorem order6_1 : javaLT s6 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order6_1
theorem order6_2 : javaLT s6 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order6_2
theorem order6_3 : javaLT s6 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order6_3
theorem order6_4 : javaLT s6 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order6_4
theorem order6_5 : javaLT s6 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order6_5
theorem order6_6 : javaLT s6 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s6] []] = .duplicate := by decide +kernel
#print axioms order6_6
theorem order6_7 : javaLT s6 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order6_7
theorem order6_8 : javaLT s6 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order6_8
theorem order6_9 : javaLT s6 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order6_9
theorem order6_10 : javaLT s6 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order6_10
theorem order6_11 : javaLT s6 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order6_11
theorem order6_12 : javaLT s6 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order6_12
theorem order6_13 : javaLT s6 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order6_13
theorem order6_14 : javaLT s6 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order6_14
theorem order6_15 : javaLT s6 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order6_15
theorem order6_16 : javaLT s6 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order6_16
theorem order6_17 : javaLT s6 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order6_17
theorem order6_18 : javaLT s6 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order6_18
theorem order6_19 : javaLT s6 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order6_19
theorem order6_20 : javaLT s6 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order6_20
theorem order6_21 : javaLT s6 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s6] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order6_21
theorem order7_0 : javaLT s7 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order7_0
theorem order7_1 : javaLT s7 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order7_1
theorem order7_2 : javaLT s7 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order7_2
theorem order7_3 : javaLT s7 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order7_3
theorem order7_4 : javaLT s7 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order7_4
theorem order7_5 : javaLT s7 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order7_5
theorem order7_6 : javaLT s7 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order7_6
theorem order7_7 : javaLT s7 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s7] []] = .duplicate := by decide +kernel
#print axioms order7_7
theorem order7_8 : javaLT s7 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order7_8
theorem order7_9 : javaLT s7 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order7_9
theorem order7_10 : javaLT s7 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order7_10
theorem order7_11 : javaLT s7 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order7_11
theorem order7_12 : javaLT s7 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order7_12
theorem order7_13 : javaLT s7 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order7_13
theorem order7_14 : javaLT s7 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order7_14
theorem order7_15 : javaLT s7 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order7_15
theorem order7_16 : javaLT s7 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order7_16
theorem order7_17 : javaLT s7 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order7_17
theorem order7_18 : javaLT s7 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order7_18
theorem order7_19 : javaLT s7 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order7_19
theorem order7_20 : javaLT s7 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order7_20
theorem order7_21 : javaLT s7 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s7] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order7_21
theorem order8_0 : javaLT s8 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order8_0
theorem order8_1 : javaLT s8 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order8_1
theorem order8_2 : javaLT s8 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order8_2
theorem order8_3 : javaLT s8 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order8_3
theorem order8_4 : javaLT s8 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order8_4
theorem order8_5 : javaLT s8 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order8_5
theorem order8_6 : javaLT s8 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order8_6
theorem order8_7 : javaLT s8 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order8_7
theorem order8_8 : javaLT s8 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s8] []] = .duplicate := by decide +kernel
#print axioms order8_8
theorem order8_9 : javaLT s8 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order8_9
theorem order8_10 : javaLT s8 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order8_10
theorem order8_11 : javaLT s8 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order8_11
theorem order8_12 : javaLT s8 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order8_12
theorem order8_13 : javaLT s8 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order8_13
theorem order8_14 : javaLT s8 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order8_14
theorem order8_15 : javaLT s8 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order8_15
theorem order8_16 : javaLT s8 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order8_16
theorem order8_17 : javaLT s8 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order8_17
theorem order8_18 : javaLT s8 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order8_18
theorem order8_19 : javaLT s8 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order8_19
theorem order8_20 : javaLT s8 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order8_20
theorem order8_21 : javaLT s8 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s8] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order8_21
theorem order9_0 : javaLT s9 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order9_0
theorem order9_1 : javaLT s9 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order9_1
theorem order9_2 : javaLT s9 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order9_2
theorem order9_3 : javaLT s9 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order9_3
theorem order9_4 : javaLT s9 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order9_4
theorem order9_5 : javaLT s9 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order9_5
theorem order9_6 : javaLT s9 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order9_6
theorem order9_7 : javaLT s9 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order9_7
theorem order9_8 : javaLT s9 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order9_8
theorem order9_9 : javaLT s9 s9 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s9] []] = .duplicate := by decide +kernel
#print axioms order9_9
theorem order9_10 : javaLT s9 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order9_10
theorem order9_11 : javaLT s9 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s11] []] = .order := by decide +kernel
#print axioms order9_11
theorem order9_12 : javaLT s9 s12 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s12] []] = .order := by decide +kernel
#print axioms order9_12
theorem order9_13 : javaLT s9 s13 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s13] []] = .order := by decide +kernel
#print axioms order9_13
theorem order9_14 : javaLT s9 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order9_14
theorem order9_15 : javaLT s9 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order9_15
theorem order9_16 : javaLT s9 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order9_16
theorem order9_17 : javaLT s9 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order9_17
theorem order9_18 : javaLT s9 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order9_18
theorem order9_19 : javaLT s9 s19 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s19] []] = .order := by decide +kernel
#print axioms order9_19
theorem order9_20 : javaLT s9 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order9_20
theorem order9_21 : javaLT s9 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s9] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order9_21
theorem order10_0 : javaLT s10 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order10_0
theorem order10_1 : javaLT s10 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order10_1
theorem order10_2 : javaLT s10 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order10_2
theorem order10_3 : javaLT s10 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order10_3
theorem order10_4 : javaLT s10 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order10_4
theorem order10_5 : javaLT s10 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order10_5
theorem order10_6 : javaLT s10 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order10_6
theorem order10_7 : javaLT s10 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order10_7
theorem order10_8 : javaLT s10 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order10_8
theorem order10_9 : javaLT s10 s9 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s9] []] = .order := by decide +kernel
#print axioms order10_9
theorem order10_10 : javaLT s10 s10 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s10] []] = .duplicate := by decide +kernel
#print axioms order10_10
theorem order10_11 : javaLT s10 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s11] []] = .order := by decide +kernel
#print axioms order10_11
theorem order10_12 : javaLT s10 s12 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s12] []] = .order := by decide +kernel
#print axioms order10_12
theorem order10_13 : javaLT s10 s13 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s13] []] = .order := by decide +kernel
#print axioms order10_13
theorem order10_14 : javaLT s10 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order10_14
theorem order10_15 : javaLT s10 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order10_15
theorem order10_16 : javaLT s10 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order10_16
theorem order10_17 : javaLT s10 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order10_17
theorem order10_18 : javaLT s10 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order10_18
theorem order10_19 : javaLT s10 s19 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s19] []] = .order := by decide +kernel
#print axioms order10_19
theorem order10_20 : javaLT s10 s20 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s20] []] = .order := by decide +kernel
#print axioms order10_20
theorem order10_21 : javaLT s10 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s10] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order10_21
theorem order11_0 : javaLT s11 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order11_0
theorem order11_1 : javaLT s11 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order11_1
theorem order11_2 : javaLT s11 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order11_2
theorem order11_3 : javaLT s11 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order11_3
theorem order11_4 : javaLT s11 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order11_4
theorem order11_5 : javaLT s11 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order11_5
theorem order11_6 : javaLT s11 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order11_6
theorem order11_7 : javaLT s11 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order11_7
theorem order11_8 : javaLT s11 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order11_8
theorem order11_9 : javaLT s11 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order11_9
theorem order11_10 : javaLT s11 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order11_10
theorem order11_11 : javaLT s11 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s11] []] = .duplicate := by decide +kernel
#print axioms order11_11
theorem order11_12 : javaLT s11 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order11_12
theorem order11_13 : javaLT s11 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order11_13
theorem order11_14 : javaLT s11 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order11_14
theorem order11_15 : javaLT s11 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order11_15
theorem order11_16 : javaLT s11 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order11_16
theorem order11_17 : javaLT s11 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order11_17
theorem order11_18 : javaLT s11 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order11_18
theorem order11_19 : javaLT s11 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order11_19
theorem order11_20 : javaLT s11 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order11_20
theorem order11_21 : javaLT s11 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s11] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order11_21
theorem order12_0 : javaLT s12 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order12_0
theorem order12_1 : javaLT s12 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order12_1
theorem order12_2 : javaLT s12 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order12_2
theorem order12_3 : javaLT s12 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order12_3
theorem order12_4 : javaLT s12 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order12_4
theorem order12_5 : javaLT s12 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order12_5
theorem order12_6 : javaLT s12 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order12_6
theorem order12_7 : javaLT s12 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order12_7
theorem order12_8 : javaLT s12 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order12_8
theorem order12_9 : javaLT s12 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order12_9
theorem order12_10 : javaLT s12 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order12_10
theorem order12_11 : javaLT s12 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s11] []] = .order := by decide +kernel
#print axioms order12_11
theorem order12_12 : javaLT s12 s12 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s12] []] = .duplicate := by decide +kernel
#print axioms order12_12
theorem order12_13 : javaLT s12 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order12_13
theorem order12_14 : javaLT s12 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order12_14
theorem order12_15 : javaLT s12 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order12_15
theorem order12_16 : javaLT s12 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order12_16
theorem order12_17 : javaLT s12 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order12_17
theorem order12_18 : javaLT s12 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order12_18
theorem order12_19 : javaLT s12 s19 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s19] []] = .order := by decide +kernel
#print axioms order12_19
theorem order12_20 : javaLT s12 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order12_20
theorem order12_21 : javaLT s12 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s12] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order12_21
theorem order13_0 : javaLT s13 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order13_0
theorem order13_1 : javaLT s13 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order13_1
theorem order13_2 : javaLT s13 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order13_2
theorem order13_3 : javaLT s13 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order13_3
theorem order13_4 : javaLT s13 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order13_4
theorem order13_5 : javaLT s13 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order13_5
theorem order13_6 : javaLT s13 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order13_6
theorem order13_7 : javaLT s13 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order13_7
theorem order13_8 : javaLT s13 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order13_8
theorem order13_9 : javaLT s13 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order13_9
theorem order13_10 : javaLT s13 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order13_10
theorem order13_11 : javaLT s13 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s11] []] = .order := by decide +kernel
#print axioms order13_11
theorem order13_12 : javaLT s13 s12 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s12] []] = .order := by decide +kernel
#print axioms order13_12
theorem order13_13 : javaLT s13 s13 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s13] []] = .duplicate := by decide +kernel
#print axioms order13_13
theorem order13_14 : javaLT s13 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order13_14
theorem order13_15 : javaLT s13 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order13_15
theorem order13_16 : javaLT s13 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order13_16
theorem order13_17 : javaLT s13 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order13_17
theorem order13_18 : javaLT s13 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order13_18
theorem order13_19 : javaLT s13 s19 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s19] []] = .order := by decide +kernel
#print axioms order13_19
theorem order13_20 : javaLT s13 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order13_20
theorem order13_21 : javaLT s13 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s13] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order13_21
theorem order14_0 : javaLT s14 s0 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s0] []] = .shape := by decide +kernel
#print axioms order14_0
theorem order14_1 : javaLT s14 s1 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s1] []] = .shape := by decide +kernel
#print axioms order14_1
theorem order14_2 : javaLT s14 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s2] []] = .shape := by decide +kernel
#print axioms order14_2
theorem order14_3 : javaLT s14 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s3] []] = .shape := by decide +kernel
#print axioms order14_3
theorem order14_4 : javaLT s14 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s4] []] = .shape := by decide +kernel
#print axioms order14_4
theorem order14_5 : javaLT s14 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s5] []] = .shape := by decide +kernel
#print axioms order14_5
theorem order14_6 : javaLT s14 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s6] []] = .shape := by decide +kernel
#print axioms order14_6
theorem order14_7 : javaLT s14 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s7] []] = .shape := by decide +kernel
#print axioms order14_7
theorem order14_8 : javaLT s14 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s8] []] = .shape := by decide +kernel
#print axioms order14_8
theorem order14_9 : javaLT s14 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s9] []] = .shape := by decide +kernel
#print axioms order14_9
theorem order14_10 : javaLT s14 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s10] []] = .shape := by decide +kernel
#print axioms order14_10
theorem order14_11 : javaLT s14 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s11] []] = .shape := by decide +kernel
#print axioms order14_11
theorem order14_12 : javaLT s14 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s12] []] = .shape := by decide +kernel
#print axioms order14_12
theorem order14_13 : javaLT s14 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s13] []] = .shape := by decide +kernel
#print axioms order14_13
theorem order14_14 : javaLT s14 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order14_14
theorem order14_15 : javaLT s14 s15 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s15] []] = .shape := by decide +kernel
#print axioms order14_15
theorem order14_16 : javaLT s14 s16 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s16] []] = .shape := by decide +kernel
#print axioms order14_16
theorem order14_17 : javaLT s14 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s17] []] = .shape := by decide +kernel
#print axioms order14_17
theorem order14_18 : javaLT s14 s18 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s18] []] = .shape := by decide +kernel
#print axioms order14_18
theorem order14_19 : javaLT s14 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s19] []] = .shape := by decide +kernel
#print axioms order14_19
theorem order14_20 : javaLT s14 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s20] []] = .shape := by decide +kernel
#print axioms order14_20
theorem order14_21 : javaLT s14 s21 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s14] [], .mk [119] [s21] []] = .shape := by decide +kernel
#print axioms order14_21
theorem order15_0 : javaLT s15 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order15_0
theorem order15_1 : javaLT s15 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order15_1
theorem order15_2 : javaLT s15 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order15_2
theorem order15_3 : javaLT s15 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order15_3
theorem order15_4 : javaLT s15 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order15_4
theorem order15_5 : javaLT s15 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order15_5
theorem order15_6 : javaLT s15 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order15_6
theorem order15_7 : javaLT s15 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order15_7
theorem order15_8 : javaLT s15 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order15_8
theorem order15_9 : javaLT s15 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order15_9
theorem order15_10 : javaLT s15 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order15_10
theorem order15_11 : javaLT s15 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order15_11
theorem order15_12 : javaLT s15 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order15_12
theorem order15_13 : javaLT s15 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order15_13
theorem order15_14 : javaLT s15 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order15_14
theorem order15_15 : javaLT s15 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s15] []] = .duplicate := by decide +kernel
#print axioms order15_15
theorem order15_16 : javaLT s15 s16 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s16] []] = .accept := by decide +kernel
#print axioms order15_16
theorem order15_17 : javaLT s15 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s17] []] = .accept := by decide +kernel
#print axioms order15_17
theorem order15_18 : javaLT s15 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order15_18
theorem order15_19 : javaLT s15 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order15_19
theorem order15_20 : javaLT s15 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order15_20
theorem order15_21 : javaLT s15 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s15] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order15_21
theorem order16_0 : javaLT s16 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order16_0
theorem order16_1 : javaLT s16 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order16_1
theorem order16_2 : javaLT s16 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order16_2
theorem order16_3 : javaLT s16 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order16_3
theorem order16_4 : javaLT s16 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order16_4
theorem order16_5 : javaLT s16 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order16_5
theorem order16_6 : javaLT s16 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order16_6
theorem order16_7 : javaLT s16 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order16_7
theorem order16_8 : javaLT s16 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order16_8
theorem order16_9 : javaLT s16 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order16_9
theorem order16_10 : javaLT s16 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order16_10
theorem order16_11 : javaLT s16 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order16_11
theorem order16_12 : javaLT s16 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order16_12
theorem order16_13 : javaLT s16 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order16_13
theorem order16_14 : javaLT s16 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order16_14
theorem order16_15 : javaLT s16 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order16_15
theorem order16_16 : javaLT s16 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s16] []] = .duplicate := by decide +kernel
#print axioms order16_16
theorem order16_17 : javaLT s16 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s17] []] = .accept := by decide +kernel
#print axioms order16_17
theorem order16_18 : javaLT s16 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order16_18
theorem order16_19 : javaLT s16 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order16_19
theorem order16_20 : javaLT s16 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order16_20
theorem order16_21 : javaLT s16 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s16] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order16_21
theorem order17_0 : javaLT s17 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order17_0
theorem order17_1 : javaLT s17 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order17_1
theorem order17_2 : javaLT s17 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order17_2
theorem order17_3 : javaLT s17 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order17_3
theorem order17_4 : javaLT s17 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order17_4
theorem order17_5 : javaLT s17 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order17_5
theorem order17_6 : javaLT s17 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order17_6
theorem order17_7 : javaLT s17 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order17_7
theorem order17_8 : javaLT s17 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order17_8
theorem order17_9 : javaLT s17 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order17_9
theorem order17_10 : javaLT s17 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order17_10
theorem order17_11 : javaLT s17 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order17_11
theorem order17_12 : javaLT s17 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order17_12
theorem order17_13 : javaLT s17 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order17_13
theorem order17_14 : javaLT s17 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order17_14
theorem order17_15 : javaLT s17 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order17_15
theorem order17_16 : javaLT s17 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order17_16
theorem order17_17 : javaLT s17 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s17] []] = .duplicate := by decide +kernel
#print axioms order17_17
theorem order17_18 : javaLT s17 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order17_18
theorem order17_19 : javaLT s17 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order17_19
theorem order17_20 : javaLT s17 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order17_20
theorem order17_21 : javaLT s17 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s17] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order17_21
theorem order18_0 : javaLT s18 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order18_0
theorem order18_1 : javaLT s18 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order18_1
theorem order18_2 : javaLT s18 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order18_2
theorem order18_3 : javaLT s18 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order18_3
theorem order18_4 : javaLT s18 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order18_4
theorem order18_5 : javaLT s18 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order18_5
theorem order18_6 : javaLT s18 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order18_6
theorem order18_7 : javaLT s18 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order18_7
theorem order18_8 : javaLT s18 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order18_8
theorem order18_9 : javaLT s18 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order18_9
theorem order18_10 : javaLT s18 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order18_10
theorem order18_11 : javaLT s18 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order18_11
theorem order18_12 : javaLT s18 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order18_12
theorem order18_13 : javaLT s18 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order18_13
theorem order18_14 : javaLT s18 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order18_14
theorem order18_15 : javaLT s18 s15 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s15] []] = .accept := by decide +kernel
#print axioms order18_15
theorem order18_16 : javaLT s18 s16 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s16] []] = .accept := by decide +kernel
#print axioms order18_16
theorem order18_17 : javaLT s18 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s17] []] = .accept := by decide +kernel
#print axioms order18_17
theorem order18_18 : javaLT s18 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s18] []] = .duplicate := by decide +kernel
#print axioms order18_18
theorem order18_19 : javaLT s18 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order18_19
theorem order18_20 : javaLT s18 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order18_20
theorem order18_21 : javaLT s18 s21 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s18] [], .mk [119] [s21] []] = .accept := by decide +kernel
#print axioms order18_21
theorem order19_0 : javaLT s19 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order19_0
theorem order19_1 : javaLT s19 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order19_1
theorem order19_2 : javaLT s19 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order19_2
theorem order19_3 : javaLT s19 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order19_3
theorem order19_4 : javaLT s19 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order19_4
theorem order19_5 : javaLT s19 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order19_5
theorem order19_6 : javaLT s19 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order19_6
theorem order19_7 : javaLT s19 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order19_7
theorem order19_8 : javaLT s19 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order19_8
theorem order19_9 : javaLT s19 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order19_9
theorem order19_10 : javaLT s19 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order19_10
theorem order19_11 : javaLT s19 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s11] []] = .order := by decide +kernel
#print axioms order19_11
theorem order19_12 : javaLT s19 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order19_12
theorem order19_13 : javaLT s19 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order19_13
theorem order19_14 : javaLT s19 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order19_14
theorem order19_15 : javaLT s19 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order19_15
theorem order19_16 : javaLT s19 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order19_16
theorem order19_17 : javaLT s19 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order19_17
theorem order19_18 : javaLT s19 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order19_18
theorem order19_19 : javaLT s19 s19 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s19] []] = .duplicate := by decide +kernel
#print axioms order19_19
theorem order19_20 : javaLT s19 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order19_20
theorem order19_21 : javaLT s19 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s19] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order19_21
theorem order20_0 : javaLT s20 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order20_0
theorem order20_1 : javaLT s20 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order20_1
theorem order20_2 : javaLT s20 s2 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s2] []] = .order := by decide +kernel
#print axioms order20_2
theorem order20_3 : javaLT s20 s3 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s3] []] = .order := by decide +kernel
#print axioms order20_3
theorem order20_4 : javaLT s20 s4 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s4] []] = .order := by decide +kernel
#print axioms order20_4
theorem order20_5 : javaLT s20 s5 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s5] []] = .order := by decide +kernel
#print axioms order20_5
theorem order20_6 : javaLT s20 s6 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s6] []] = .order := by decide +kernel
#print axioms order20_6
theorem order20_7 : javaLT s20 s7 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s7] []] = .order := by decide +kernel
#print axioms order20_7
theorem order20_8 : javaLT s20 s8 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s8] []] = .order := by decide +kernel
#print axioms order20_8
theorem order20_9 : javaLT s20 s9 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s9] []] = .order := by decide +kernel
#print axioms order20_9
theorem order20_10 : javaLT s20 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order20_10
theorem order20_11 : javaLT s20 s11 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s11] []] = .order := by decide +kernel
#print axioms order20_11
theorem order20_12 : javaLT s20 s12 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s12] []] = .order := by decide +kernel
#print axioms order20_12
theorem order20_13 : javaLT s20 s13 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s13] []] = .order := by decide +kernel
#print axioms order20_13
theorem order20_14 : javaLT s20 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order20_14
theorem order20_15 : javaLT s20 s15 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s15] []] = .order := by decide +kernel
#print axioms order20_15
theorem order20_16 : javaLT s20 s16 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s16] []] = .order := by decide +kernel
#print axioms order20_16
theorem order20_17 : javaLT s20 s17 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s17] []] = .order := by decide +kernel
#print axioms order20_17
theorem order20_18 : javaLT s20 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order20_18
theorem order20_19 : javaLT s20 s19 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s19] []] = .order := by decide +kernel
#print axioms order20_19
theorem order20_20 : javaLT s20 s20 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s20] []] = .duplicate := by decide +kernel
#print axioms order20_20
theorem order20_21 : javaLT s20 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s20] [], .mk [119] [s21] []] = .order := by decide +kernel
#print axioms order20_21
theorem order21_0 : javaLT s21 s0 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s0] []] = .order := by decide +kernel
#print axioms order21_0
theorem order21_1 : javaLT s21 s1 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s1] []] = .order := by decide +kernel
#print axioms order21_1
theorem order21_2 : javaLT s21 s2 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s2] []] = .accept := by decide +kernel
#print axioms order21_2
theorem order21_3 : javaLT s21 s3 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s3] []] = .accept := by decide +kernel
#print axioms order21_3
theorem order21_4 : javaLT s21 s4 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s4] []] = .accept := by decide +kernel
#print axioms order21_4
theorem order21_5 : javaLT s21 s5 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s5] []] = .accept := by decide +kernel
#print axioms order21_5
theorem order21_6 : javaLT s21 s6 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s6] []] = .accept := by decide +kernel
#print axioms order21_6
theorem order21_7 : javaLT s21 s7 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s7] []] = .accept := by decide +kernel
#print axioms order21_7
theorem order21_8 : javaLT s21 s8 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s8] []] = .accept := by decide +kernel
#print axioms order21_8
theorem order21_9 : javaLT s21 s9 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s9] []] = .accept := by decide +kernel
#print axioms order21_9
theorem order21_10 : javaLT s21 s10 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s10] []] = .accept := by decide +kernel
#print axioms order21_10
theorem order21_11 : javaLT s21 s11 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s11] []] = .accept := by decide +kernel
#print axioms order21_11
theorem order21_12 : javaLT s21 s12 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s12] []] = .accept := by decide +kernel
#print axioms order21_12
theorem order21_13 : javaLT s21 s13 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s13] []] = .accept := by decide +kernel
#print axioms order21_13
theorem order21_14 : javaLT s21 s14 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s14] []] = .shape := by decide +kernel
#print axioms order21_14
theorem order21_15 : javaLT s21 s15 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s15] []] = .accept := by decide +kernel
#print axioms order21_15
theorem order21_16 : javaLT s21 s16 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s16] []] = .accept := by decide +kernel
#print axioms order21_16
theorem order21_17 : javaLT s21 s17 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s17] []] = .accept := by decide +kernel
#print axioms order21_17
theorem order21_18 : javaLT s21 s18 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s18] []] = .order := by decide +kernel
#print axioms order21_18
theorem order21_19 : javaLT s21 s19 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s19] []] = .accept := by decide +kernel
#print axioms order21_19
theorem order21_20 : javaLT s21 s20 = true ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s20] []] = .accept := by decide +kernel
#print axioms order21_20
theorem order21_21 : javaLT s21 s21 = false ∧ checkRows (fun _ => []) [119] false none [.mk [119] [s21] [], .mk [119] [s21] []] = .duplicate := by decide +kernel
#print axioms order21_21
theorem utf8_0 : utf8 [0] = true := by decide +kernel
#print axioms utf8_0
theorem utf8_1 : utf8 [1] = true := by decide +kernel
#print axioms utf8_1
theorem utf8_2 : utf8 [2] = true := by decide +kernel
#print axioms utf8_2
theorem utf8_3 : utf8 [3] = true := by decide +kernel
#print axioms utf8_3
theorem utf8_4 : utf8 [4] = true := by decide +kernel
#print axioms utf8_4
theorem utf8_5 : utf8 [5] = true := by decide +kernel
#print axioms utf8_5
theorem utf8_6 : utf8 [6] = true := by decide +kernel
#print axioms utf8_6
theorem utf8_7 : utf8 [7] = true := by decide +kernel
#print axioms utf8_7
theorem utf8_8 : utf8 [8] = true := by decide +kernel
#print axioms utf8_8
theorem utf8_9 : utf8 [9] = true := by decide +kernel
#print axioms utf8_9
theorem utf8_10 : utf8 [10] = true := by decide +kernel
#print axioms utf8_10
theorem utf8_11 : utf8 [11] = true := by decide +kernel
#print axioms utf8_11
theorem utf8_12 : utf8 [12] = true := by decide +kernel
#print axioms utf8_12
theorem utf8_13 : utf8 [13] = true := by decide +kernel
#print axioms utf8_13
theorem utf8_14 : utf8 [14] = true := by decide +kernel
#print axioms utf8_14
theorem utf8_15 : utf8 [15] = true := by decide +kernel
#print axioms utf8_15
theorem utf8_16 : utf8 [16] = true := by decide +kernel
#print axioms utf8_16
theorem utf8_17 : utf8 [17] = true := by decide +kernel
#print axioms utf8_17
theorem utf8_18 : utf8 [18] = true := by decide +kernel
#print axioms utf8_18
theorem utf8_19 : utf8 [19] = true := by decide +kernel
#print axioms utf8_19
theorem utf8_20 : utf8 [20] = true := by decide +kernel
#print axioms utf8_20
theorem utf8_21 : utf8 [21] = true := by decide +kernel
#print axioms utf8_21
theorem utf8_22 : utf8 [22] = true := by decide +kernel
#print axioms utf8_22
theorem utf8_23 : utf8 [23] = true := by decide +kernel
#print axioms utf8_23
theorem utf8_24 : utf8 [24] = true := by decide +kernel
#print axioms utf8_24
theorem utf8_25 : utf8 [25] = true := by decide +kernel
#print axioms utf8_25
theorem utf8_26 : utf8 [26] = true := by decide +kernel
#print axioms utf8_26
theorem utf8_27 : utf8 [27] = true := by decide +kernel
#print axioms utf8_27
theorem utf8_28 : utf8 [28] = true := by decide +kernel
#print axioms utf8_28
theorem utf8_29 : utf8 [29] = true := by decide +kernel
#print axioms utf8_29
theorem utf8_30 : utf8 [30] = true := by decide +kernel
#print axioms utf8_30
theorem utf8_31 : utf8 [31] = true := by decide +kernel
#print axioms utf8_31
theorem utf8_32 : utf8 [32] = true := by decide +kernel
#print axioms utf8_32
theorem utf8_33 : utf8 [33] = true := by decide +kernel
#print axioms utf8_33
theorem utf8_34 : utf8 [34] = true := by decide +kernel
#print axioms utf8_34
theorem utf8_35 : utf8 [35] = true := by decide +kernel
#print axioms utf8_35
theorem utf8_36 : utf8 [36] = true := by decide +kernel
#print axioms utf8_36
theorem utf8_37 : utf8 [37] = true := by decide +kernel
#print axioms utf8_37
theorem utf8_38 : utf8 [38] = true := by decide +kernel
#print axioms utf8_38
theorem utf8_39 : utf8 [39] = true := by decide +kernel
#print axioms utf8_39
theorem utf8_40 : utf8 [40] = true := by decide +kernel
#print axioms utf8_40
theorem utf8_41 : utf8 [41] = true := by decide +kernel
#print axioms utf8_41
theorem utf8_42 : utf8 [42] = true := by decide +kernel
#print axioms utf8_42
theorem utf8_43 : utf8 [43] = true := by decide +kernel
#print axioms utf8_43
theorem utf8_44 : utf8 [44] = true := by decide +kernel
#print axioms utf8_44
theorem utf8_45 : utf8 [45] = true := by decide +kernel
#print axioms utf8_45
theorem utf8_46 : utf8 [46] = true := by decide +kernel
#print axioms utf8_46
theorem utf8_47 : utf8 [47] = true := by decide +kernel
#print axioms utf8_47
theorem utf8_48 : utf8 [48] = true := by decide +kernel
#print axioms utf8_48
theorem utf8_49 : utf8 [49] = true := by decide +kernel
#print axioms utf8_49
theorem utf8_50 : utf8 [50] = true := by decide +kernel
#print axioms utf8_50
theorem utf8_51 : utf8 [51] = true := by decide +kernel
#print axioms utf8_51
theorem utf8_52 : utf8 [52] = true := by decide +kernel
#print axioms utf8_52
theorem utf8_53 : utf8 [53] = true := by decide +kernel
#print axioms utf8_53
theorem utf8_54 : utf8 [54] = true := by decide +kernel
#print axioms utf8_54
theorem utf8_55 : utf8 [55] = true := by decide +kernel
#print axioms utf8_55
theorem utf8_56 : utf8 [56] = true := by decide +kernel
#print axioms utf8_56
theorem utf8_57 : utf8 [57] = true := by decide +kernel
#print axioms utf8_57
theorem utf8_58 : utf8 [58] = true := by decide +kernel
#print axioms utf8_58
theorem utf8_59 : utf8 [59] = true := by decide +kernel
#print axioms utf8_59
theorem utf8_60 : utf8 [60] = true := by decide +kernel
#print axioms utf8_60
theorem utf8_61 : utf8 [61] = true := by decide +kernel
#print axioms utf8_61
theorem utf8_62 : utf8 [62] = true := by decide +kernel
#print axioms utf8_62
theorem utf8_63 : utf8 [63] = true := by decide +kernel
#print axioms utf8_63
theorem utf8_64 : utf8 [64] = true := by decide +kernel
#print axioms utf8_64
theorem utf8_65 : utf8 [65] = true := by decide +kernel
#print axioms utf8_65
theorem utf8_66 : utf8 [66] = true := by decide +kernel
#print axioms utf8_66
theorem utf8_67 : utf8 [67] = true := by decide +kernel
#print axioms utf8_67
theorem utf8_68 : utf8 [68] = true := by decide +kernel
#print axioms utf8_68
theorem utf8_69 : utf8 [69] = true := by decide +kernel
#print axioms utf8_69
theorem utf8_70 : utf8 [70] = true := by decide +kernel
#print axioms utf8_70
theorem utf8_71 : utf8 [71] = true := by decide +kernel
#print axioms utf8_71
theorem utf8_72 : utf8 [72] = true := by decide +kernel
#print axioms utf8_72
theorem utf8_73 : utf8 [73] = true := by decide +kernel
#print axioms utf8_73
theorem utf8_74 : utf8 [74] = true := by decide +kernel
#print axioms utf8_74
theorem utf8_75 : utf8 [75] = true := by decide +kernel
#print axioms utf8_75
theorem utf8_76 : utf8 [76] = true := by decide +kernel
#print axioms utf8_76
theorem utf8_77 : utf8 [77] = true := by decide +kernel
#print axioms utf8_77
theorem utf8_78 : utf8 [78] = true := by decide +kernel
#print axioms utf8_78
theorem utf8_79 : utf8 [79] = true := by decide +kernel
#print axioms utf8_79
theorem utf8_80 : utf8 [80] = true := by decide +kernel
#print axioms utf8_80
theorem utf8_81 : utf8 [81] = true := by decide +kernel
#print axioms utf8_81
theorem utf8_82 : utf8 [82] = true := by decide +kernel
#print axioms utf8_82
theorem utf8_83 : utf8 [83] = true := by decide +kernel
#print axioms utf8_83
theorem utf8_84 : utf8 [84] = true := by decide +kernel
#print axioms utf8_84
theorem utf8_85 : utf8 [85] = true := by decide +kernel
#print axioms utf8_85
theorem utf8_86 : utf8 [86] = true := by decide +kernel
#print axioms utf8_86
theorem utf8_87 : utf8 [87] = true := by decide +kernel
#print axioms utf8_87
theorem utf8_88 : utf8 [88] = true := by decide +kernel
#print axioms utf8_88
theorem utf8_89 : utf8 [89] = true := by decide +kernel
#print axioms utf8_89
theorem utf8_90 : utf8 [90] = true := by decide +kernel
#print axioms utf8_90
theorem utf8_91 : utf8 [91] = true := by decide +kernel
#print axioms utf8_91
theorem utf8_92 : utf8 [92] = true := by decide +kernel
#print axioms utf8_92
theorem utf8_93 : utf8 [93] = true := by decide +kernel
#print axioms utf8_93
theorem utf8_94 : utf8 [94] = true := by decide +kernel
#print axioms utf8_94
theorem utf8_95 : utf8 [95] = true := by decide +kernel
#print axioms utf8_95
theorem utf8_96 : utf8 [96] = true := by decide +kernel
#print axioms utf8_96
theorem utf8_97 : utf8 [97] = true := by decide +kernel
#print axioms utf8_97
theorem utf8_98 : utf8 [98] = true := by decide +kernel
#print axioms utf8_98
theorem utf8_99 : utf8 [99] = true := by decide +kernel
#print axioms utf8_99
theorem utf8_100 : utf8 [100] = true := by decide +kernel
#print axioms utf8_100
theorem utf8_101 : utf8 [101] = true := by decide +kernel
#print axioms utf8_101
theorem utf8_102 : utf8 [102] = true := by decide +kernel
#print axioms utf8_102
theorem utf8_103 : utf8 [103] = true := by decide +kernel
#print axioms utf8_103
theorem utf8_104 : utf8 [104] = true := by decide +kernel
#print axioms utf8_104
theorem utf8_105 : utf8 [105] = true := by decide +kernel
#print axioms utf8_105
theorem utf8_106 : utf8 [106] = true := by decide +kernel
#print axioms utf8_106
theorem utf8_107 : utf8 [107] = true := by decide +kernel
#print axioms utf8_107
theorem utf8_108 : utf8 [108] = true := by decide +kernel
#print axioms utf8_108
theorem utf8_109 : utf8 [109] = true := by decide +kernel
#print axioms utf8_109
theorem utf8_110 : utf8 [110] = true := by decide +kernel
#print axioms utf8_110
theorem utf8_111 : utf8 [111] = true := by decide +kernel
#print axioms utf8_111
theorem utf8_112 : utf8 [112] = true := by decide +kernel
#print axioms utf8_112
theorem utf8_113 : utf8 [113] = true := by decide +kernel
#print axioms utf8_113
theorem utf8_114 : utf8 [114] = true := by decide +kernel
#print axioms utf8_114
theorem utf8_115 : utf8 [115] = true := by decide +kernel
#print axioms utf8_115
theorem utf8_116 : utf8 [116] = true := by decide +kernel
#print axioms utf8_116
theorem utf8_117 : utf8 [117] = true := by decide +kernel
#print axioms utf8_117
theorem utf8_118 : utf8 [118] = true := by decide +kernel
#print axioms utf8_118
theorem utf8_119 : utf8 [119] = true := by decide +kernel
#print axioms utf8_119
theorem utf8_120 : utf8 [120] = true := by decide +kernel
#print axioms utf8_120
theorem utf8_121 : utf8 [121] = true := by decide +kernel
#print axioms utf8_121
theorem utf8_122 : utf8 [122] = true := by decide +kernel
#print axioms utf8_122
theorem utf8_123 : utf8 [123] = true := by decide +kernel
#print axioms utf8_123
theorem utf8_124 : utf8 [124] = true := by decide +kernel
#print axioms utf8_124
theorem utf8_125 : utf8 [125] = true := by decide +kernel
#print axioms utf8_125
theorem utf8_126 : utf8 [126] = true := by decide +kernel
#print axioms utf8_126
theorem utf8_127 : utf8 [127] = true := by decide +kernel
#print axioms utf8_127
theorem utf8_128 : utf8 [128] = false := by decide +kernel
#print axioms utf8_128
theorem utf8_129 : utf8 [129] = false := by decide +kernel
#print axioms utf8_129
theorem utf8_130 : utf8 [130] = false := by decide +kernel
#print axioms utf8_130
theorem utf8_131 : utf8 [131] = false := by decide +kernel
#print axioms utf8_131
theorem utf8_132 : utf8 [132] = false := by decide +kernel
#print axioms utf8_132
theorem utf8_133 : utf8 [133] = false := by decide +kernel
#print axioms utf8_133
theorem utf8_134 : utf8 [134] = false := by decide +kernel
#print axioms utf8_134
theorem utf8_135 : utf8 [135] = false := by decide +kernel
#print axioms utf8_135
theorem utf8_136 : utf8 [136] = false := by decide +kernel
#print axioms utf8_136
theorem utf8_137 : utf8 [137] = false := by decide +kernel
#print axioms utf8_137
theorem utf8_138 : utf8 [138] = false := by decide +kernel
#print axioms utf8_138
theorem utf8_139 : utf8 [139] = false := by decide +kernel
#print axioms utf8_139
theorem utf8_140 : utf8 [140] = false := by decide +kernel
#print axioms utf8_140
theorem utf8_141 : utf8 [141] = false := by decide +kernel
#print axioms utf8_141
theorem utf8_142 : utf8 [142] = false := by decide +kernel
#print axioms utf8_142
theorem utf8_143 : utf8 [143] = false := by decide +kernel
#print axioms utf8_143
theorem utf8_144 : utf8 [144] = false := by decide +kernel
#print axioms utf8_144
theorem utf8_145 : utf8 [145] = false := by decide +kernel
#print axioms utf8_145
theorem utf8_146 : utf8 [146] = false := by decide +kernel
#print axioms utf8_146
theorem utf8_147 : utf8 [147] = false := by decide +kernel
#print axioms utf8_147
theorem utf8_148 : utf8 [148] = false := by decide +kernel
#print axioms utf8_148
theorem utf8_149 : utf8 [149] = false := by decide +kernel
#print axioms utf8_149
theorem utf8_150 : utf8 [150] = false := by decide +kernel
#print axioms utf8_150
theorem utf8_151 : utf8 [151] = false := by decide +kernel
#print axioms utf8_151
theorem utf8_152 : utf8 [152] = false := by decide +kernel
#print axioms utf8_152
theorem utf8_153 : utf8 [153] = false := by decide +kernel
#print axioms utf8_153
theorem utf8_154 : utf8 [154] = false := by decide +kernel
#print axioms utf8_154
theorem utf8_155 : utf8 [155] = false := by decide +kernel
#print axioms utf8_155
theorem utf8_156 : utf8 [156] = false := by decide +kernel
#print axioms utf8_156
theorem utf8_157 : utf8 [157] = false := by decide +kernel
#print axioms utf8_157
theorem utf8_158 : utf8 [158] = false := by decide +kernel
#print axioms utf8_158
theorem utf8_159 : utf8 [159] = false := by decide +kernel
#print axioms utf8_159
theorem utf8_160 : utf8 [160] = false := by decide +kernel
#print axioms utf8_160
theorem utf8_161 : utf8 [161] = false := by decide +kernel
#print axioms utf8_161
theorem utf8_162 : utf8 [162] = false := by decide +kernel
#print axioms utf8_162
theorem utf8_163 : utf8 [163] = false := by decide +kernel
#print axioms utf8_163
theorem utf8_164 : utf8 [164] = false := by decide +kernel
#print axioms utf8_164
theorem utf8_165 : utf8 [165] = false := by decide +kernel
#print axioms utf8_165
theorem utf8_166 : utf8 [166] = false := by decide +kernel
#print axioms utf8_166
theorem utf8_167 : utf8 [167] = false := by decide +kernel
#print axioms utf8_167
theorem utf8_168 : utf8 [168] = false := by decide +kernel
#print axioms utf8_168
theorem utf8_169 : utf8 [169] = false := by decide +kernel
#print axioms utf8_169
theorem utf8_170 : utf8 [170] = false := by decide +kernel
#print axioms utf8_170
theorem utf8_171 : utf8 [171] = false := by decide +kernel
#print axioms utf8_171
theorem utf8_172 : utf8 [172] = false := by decide +kernel
#print axioms utf8_172
theorem utf8_173 : utf8 [173] = false := by decide +kernel
#print axioms utf8_173
theorem utf8_174 : utf8 [174] = false := by decide +kernel
#print axioms utf8_174
theorem utf8_175 : utf8 [175] = false := by decide +kernel
#print axioms utf8_175
theorem utf8_176 : utf8 [176] = false := by decide +kernel
#print axioms utf8_176
theorem utf8_177 : utf8 [177] = false := by decide +kernel
#print axioms utf8_177
theorem utf8_178 : utf8 [178] = false := by decide +kernel
#print axioms utf8_178
theorem utf8_179 : utf8 [179] = false := by decide +kernel
#print axioms utf8_179
theorem utf8_180 : utf8 [180] = false := by decide +kernel
#print axioms utf8_180
theorem utf8_181 : utf8 [181] = false := by decide +kernel
#print axioms utf8_181
theorem utf8_182 : utf8 [182] = false := by decide +kernel
#print axioms utf8_182
theorem utf8_183 : utf8 [183] = false := by decide +kernel
#print axioms utf8_183
theorem utf8_184 : utf8 [184] = false := by decide +kernel
#print axioms utf8_184
theorem utf8_185 : utf8 [185] = false := by decide +kernel
#print axioms utf8_185
theorem utf8_186 : utf8 [186] = false := by decide +kernel
#print axioms utf8_186
theorem utf8_187 : utf8 [187] = false := by decide +kernel
#print axioms utf8_187
theorem utf8_188 : utf8 [188] = false := by decide +kernel
#print axioms utf8_188
theorem utf8_189 : utf8 [189] = false := by decide +kernel
#print axioms utf8_189
theorem utf8_190 : utf8 [190] = false := by decide +kernel
#print axioms utf8_190
theorem utf8_191 : utf8 [191] = false := by decide +kernel
#print axioms utf8_191
theorem utf8_192 : utf8 [192] = false := by decide +kernel
#print axioms utf8_192
theorem utf8_193 : utf8 [193] = false := by decide +kernel
#print axioms utf8_193
theorem utf8_194 : utf8 [194] = false := by decide +kernel
#print axioms utf8_194
theorem utf8_195 : utf8 [195] = false := by decide +kernel
#print axioms utf8_195
theorem utf8_196 : utf8 [196] = false := by decide +kernel
#print axioms utf8_196
theorem utf8_197 : utf8 [197] = false := by decide +kernel
#print axioms utf8_197
theorem utf8_198 : utf8 [198] = false := by decide +kernel
#print axioms utf8_198
theorem utf8_199 : utf8 [199] = false := by decide +kernel
#print axioms utf8_199
theorem utf8_200 : utf8 [200] = false := by decide +kernel
#print axioms utf8_200
theorem utf8_201 : utf8 [201] = false := by decide +kernel
#print axioms utf8_201
theorem utf8_202 : utf8 [202] = false := by decide +kernel
#print axioms utf8_202
theorem utf8_203 : utf8 [203] = false := by decide +kernel
#print axioms utf8_203
theorem utf8_204 : utf8 [204] = false := by decide +kernel
#print axioms utf8_204
theorem utf8_205 : utf8 [205] = false := by decide +kernel
#print axioms utf8_205
theorem utf8_206 : utf8 [206] = false := by decide +kernel
#print axioms utf8_206
theorem utf8_207 : utf8 [207] = false := by decide +kernel
#print axioms utf8_207
theorem utf8_208 : utf8 [208] = false := by decide +kernel
#print axioms utf8_208
theorem utf8_209 : utf8 [209] = false := by decide +kernel
#print axioms utf8_209
theorem utf8_210 : utf8 [210] = false := by decide +kernel
#print axioms utf8_210
theorem utf8_211 : utf8 [211] = false := by decide +kernel
#print axioms utf8_211
theorem utf8_212 : utf8 [212] = false := by decide +kernel
#print axioms utf8_212
theorem utf8_213 : utf8 [213] = false := by decide +kernel
#print axioms utf8_213
theorem utf8_214 : utf8 [214] = false := by decide +kernel
#print axioms utf8_214
theorem utf8_215 : utf8 [215] = false := by decide +kernel
#print axioms utf8_215
theorem utf8_216 : utf8 [216] = false := by decide +kernel
#print axioms utf8_216
theorem utf8_217 : utf8 [217] = false := by decide +kernel
#print axioms utf8_217
theorem utf8_218 : utf8 [218] = false := by decide +kernel
#print axioms utf8_218
theorem utf8_219 : utf8 [219] = false := by decide +kernel
#print axioms utf8_219
theorem utf8_220 : utf8 [220] = false := by decide +kernel
#print axioms utf8_220
theorem utf8_221 : utf8 [221] = false := by decide +kernel
#print axioms utf8_221
theorem utf8_222 : utf8 [222] = false := by decide +kernel
#print axioms utf8_222
theorem utf8_223 : utf8 [223] = false := by decide +kernel
#print axioms utf8_223
theorem utf8_224 : utf8 [224] = false := by decide +kernel
#print axioms utf8_224
theorem utf8_225 : utf8 [225] = false := by decide +kernel
#print axioms utf8_225
theorem utf8_226 : utf8 [226] = false := by decide +kernel
#print axioms utf8_226
theorem utf8_227 : utf8 [227] = false := by decide +kernel
#print axioms utf8_227
theorem utf8_228 : utf8 [228] = false := by decide +kernel
#print axioms utf8_228
theorem utf8_229 : utf8 [229] = false := by decide +kernel
#print axioms utf8_229
theorem utf8_230 : utf8 [230] = false := by decide +kernel
#print axioms utf8_230
theorem utf8_231 : utf8 [231] = false := by decide +kernel
#print axioms utf8_231
theorem utf8_232 : utf8 [232] = false := by decide +kernel
#print axioms utf8_232
theorem utf8_233 : utf8 [233] = false := by decide +kernel
#print axioms utf8_233
theorem utf8_234 : utf8 [234] = false := by decide +kernel
#print axioms utf8_234
theorem utf8_235 : utf8 [235] = false := by decide +kernel
#print axioms utf8_235
theorem utf8_236 : utf8 [236] = false := by decide +kernel
#print axioms utf8_236
theorem utf8_237 : utf8 [237] = false := by decide +kernel
#print axioms utf8_237
theorem utf8_238 : utf8 [238] = false := by decide +kernel
#print axioms utf8_238
theorem utf8_239 : utf8 [239] = false := by decide +kernel
#print axioms utf8_239
theorem utf8_240 : utf8 [240] = false := by decide +kernel
#print axioms utf8_240
theorem utf8_241 : utf8 [241] = false := by decide +kernel
#print axioms utf8_241
theorem utf8_242 : utf8 [242] = false := by decide +kernel
#print axioms utf8_242
theorem utf8_243 : utf8 [243] = false := by decide +kernel
#print axioms utf8_243
theorem utf8_244 : utf8 [244] = false := by decide +kernel
#print axioms utf8_244
theorem utf8_245 : utf8 [245] = false := by decide +kernel
#print axioms utf8_245
theorem utf8_246 : utf8 [246] = false := by decide +kernel
#print axioms utf8_246
theorem utf8_247 : utf8 [247] = false := by decide +kernel
#print axioms utf8_247
theorem utf8_248 : utf8 [248] = false := by decide +kernel
#print axioms utf8_248
theorem utf8_249 : utf8 [249] = false := by decide +kernel
#print axioms utf8_249
theorem utf8_250 : utf8 [250] = false := by decide +kernel
#print axioms utf8_250
theorem utf8_251 : utf8 [251] = false := by decide +kernel
#print axioms utf8_251
theorem utf8_252 : utf8 [252] = false := by decide +kernel
#print axioms utf8_252
theorem utf8_253 : utf8 [253] = false := by decide +kernel
#print axioms utf8_253
theorem utf8_254 : utf8 [254] = false := by decide +kernel
#print axioms utf8_254
theorem utf8_255 : utf8 [255] = false := by decide +kernel
#print axioms utf8_255
theorem utf8_256 : utf8 [] = true := by decide +kernel
#print axioms utf8_256
theorem utf8_257 : utf8 [192,128] = false := by decide +kernel
#print axioms utf8_257
theorem utf8_258 : utf8 [193,128] = false := by decide +kernel
#print axioms utf8_258
theorem utf8_259 : utf8 [194,128] = true := by decide +kernel
#print axioms utf8_259
theorem utf8_260 : utf8 [223,191] = true := by decide +kernel
#print axioms utf8_260
theorem utf8_261 : utf8 [224,128,128] = false := by decide +kernel
#print axioms utf8_261
theorem utf8_262 : utf8 [224,159,128] = false := by decide +kernel
#print axioms utf8_262
theorem utf8_263 : utf8 [224,160,128] = true := by decide +kernel
#print axioms utf8_263
theorem utf8_264 : utf8 [237,159,191] = true := by decide +kernel
#print axioms utf8_264
theorem utf8_265 : utf8 [237,160,128] = false := by decide +kernel
#print axioms utf8_265
theorem utf8_266 : utf8 [237,191,191] = false := by decide +kernel
#print axioms utf8_266
theorem utf8_267 : utf8 [238,128,128] = true := by decide +kernel
#print axioms utf8_267
theorem utf8_268 : utf8 [239,191,191] = true := by decide +kernel
#print axioms utf8_268
theorem utf8_269 : utf8 [240,128,128,128] = false := by decide +kernel
#print axioms utf8_269
theorem utf8_270 : utf8 [240,143,191,191] = false := by decide +kernel
#print axioms utf8_270
theorem utf8_271 : utf8 [240,144,128,128] = true := by decide +kernel
#print axioms utf8_271
theorem utf8_272 : utf8 [244,143,191,191] = true := by decide +kernel
#print axioms utf8_272
theorem utf8_273 : utf8 [244,144,128,128] = false := by decide +kernel
#print axioms utf8_273
theorem utf8_274 : utf8 [245,128,128,128] = false := by decide +kernel
#print axioms utf8_274
theorem utf8_275 : utf8 [240,144,128] = false := by decide +kernel
#print axioms utf8_275
theorem utf8_276 : utf8 [194] = false := by decide +kernel
#print axioms utf8_276
theorem utf8_277 : utf8 [224,160] = false := by decide +kernel
#print axioms utf8_277
theorem utf8_278 : utf8 [0,194,128] = true := by decide +kernel
#print axioms utf8_278
theorem utf8_279 : utf8 [194,128,0] = true := by decide +kernel
#print axioms utf8_279
theorem utf8_280 : utf8 [224,159,0] = false := by decide +kernel
#print axioms utf8_280
theorem utf8_281 : utf8 [194,255] = false := by decide +kernel
#print axioms utf8_281
end W
namespace L
open ACGN.FifthFive.LawRecordWire
def s0 : Text := ofCodepoints [0]
theorem units0 : utf16Units s0 = [0] ∧ utf16Length s0 = 1 := by decide +kernel
#print axioms units0
def s1 : Text := ofCodepoints [1]
theorem units1 : utf16Units s1 = [1] ∧ utf16Length s1 = 1 := by decide +kernel
#print axioms units1
def s2 : Text := ofCodepoints [127]
theorem units2 : utf16Units s2 = [127] ∧ utf16Length s2 = 1 := by decide +kernel
#print axioms units2
def s3 : Text := ofCodepoints [128]
theorem units3 : utf16Units s3 = [128] ∧ utf16Length s3 = 1 := by decide +kernel
#print axioms units3
def s4 : Text := ofCodepoints [255]
theorem units4 : utf16Units s4 = [255] ∧ utf16Length s4 = 1 := by decide +kernel
#print axioms units4
def s5 : Text := ofCodepoints [2047]
theorem units5 : utf16Units s5 = [2047] ∧ utf16Length s5 = 1 := by decide +kernel
#print axioms units5
def s6 : Text := ofCodepoints [2048]
theorem units6 : utf16Units s6 = [2048] ∧ utf16Length s6 = 1 := by decide +kernel
#print axioms units6
def s7 : Text := ofCodepoints [4095]
theorem units7 : utf16Units s7 = [4095] ∧ utf16Length s7 = 1 := by decide +kernel
#print axioms units7
def s8 : Text := ofCodepoints [55295]
theorem units8 : utf16Units s8 = [55295] ∧ utf16Length s8 = 1 := by decide +kernel
#print axioms units8
def s9 : Text := ofCodepoints [57344]
theorem units9 : utf16Units s9 = [57344] ∧ utf16Length s9 = 1 := by decide +kernel
#print axioms units9
def s10 : Text := ofCodepoints [65535]
theorem units10 : utf16Units s10 = [65535] ∧ utf16Length s10 = 1 := by decide +kernel
#print axioms units10
def s11 : Text := ofCodepoints [65536]
theorem units11 : utf16Units s11 = [55296,56320] ∧ utf16Length s11 = 2 := by decide +kernel
#print axioms units11
def s12 : Text := ofCodepoints [65537]
theorem units12 : utf16Units s12 = [55296,56321] ∧ utf16Length s12 = 2 := by decide +kernel
#print axioms units12
def s13 : Text := ofCodepoints [1114111]
theorem units13 : utf16Units s13 = [56319,57343] ∧ utf16Length s13 = 2 := by decide +kernel
#print axioms units13
def s14 : Text := ofCodepoints []
theorem units14 : utf16Units s14 = [] ∧ utf16Length s14 = 0 := by decide +kernel
#print axioms units14
def s15 : Text := ofCodepoints [112,114,101,102,105,120]
theorem units15 : utf16Units s15 = [112,114,101,102,105,120] ∧ utf16Length s15 = 6 := by decide +kernel
#print axioms units15
def s16 : Text := ofCodepoints [112,114,101,102,105,120,45,109,111,114,101]
theorem units16 : utf16Units s16 = [112,114,101,102,105,120,45,109,111,114,101] ∧ utf16Length s16 = 11 := by decide +kernel
#print axioms units16
def s17 : Text := ofCodepoints [115,97,109,101]
theorem units17 : utf16Units s17 = [115,97,109,101] ∧ utf16Length s17 = 4 := by decide +kernel
#print axioms units17
def s18 : Text := ofCodepoints [97,0,98]
theorem units18 : utf16Units s18 = [97,0,98] ∧ utf16Length s18 = 3 := by decide +kernel
#print axioms units18
def s19 : Text := ofCodepoints [65536,57344]
theorem units19 : utf16Units s19 = [55296,56320,57344] ∧ utf16Length s19 = 3 := by decide +kernel
#print axioms units19
def s20 : Text := ofCodepoints [57344,65536]
theorem units20 : utf16Units s20 = [57344,55296,56320] ∧ utf16Length s20 = 3 := by decide +kernel
#print axioms units20
def s21 : Text := ofCodepoints [101,769]
theorem units21 : utf16Units s21 = [101,769] ∧ utf16Length s21 = 2 := by decide +kernel
#print axioms units21
theorem order0_0 : javaLess s0 s0 = false := by decide +kernel
#print axioms order0_0
theorem order0_1 : javaLess s0 s1 = true := by decide +kernel
#print axioms order0_1
theorem order0_2 : javaLess s0 s2 = true := by decide +kernel
#print axioms order0_2
theorem order0_3 : javaLess s0 s3 = true := by decide +kernel
#print axioms order0_3
theorem order0_4 : javaLess s0 s4 = true := by decide +kernel
#print axioms order0_4
theorem order0_5 : javaLess s0 s5 = true := by decide +kernel
#print axioms order0_5
theorem order0_6 : javaLess s0 s6 = true := by decide +kernel
#print axioms order0_6
theorem order0_7 : javaLess s0 s7 = true := by decide +kernel
#print axioms order0_7
theorem order0_8 : javaLess s0 s8 = true := by decide +kernel
#print axioms order0_8
theorem order0_9 : javaLess s0 s9 = true := by decide +kernel
#print axioms order0_9
theorem order0_10 : javaLess s0 s10 = true := by decide +kernel
#print axioms order0_10
theorem order0_11 : javaLess s0 s11 = true := by decide +kernel
#print axioms order0_11
theorem order0_12 : javaLess s0 s12 = true := by decide +kernel
#print axioms order0_12
theorem order0_13 : javaLess s0 s13 = true := by decide +kernel
#print axioms order0_13
theorem order0_14 : javaLess s0 s14 = false := by decide +kernel
#print axioms order0_14
theorem order0_15 : javaLess s0 s15 = true := by decide +kernel
#print axioms order0_15
theorem order0_16 : javaLess s0 s16 = true := by decide +kernel
#print axioms order0_16
theorem order0_17 : javaLess s0 s17 = true := by decide +kernel
#print axioms order0_17
theorem order0_18 : javaLess s0 s18 = true := by decide +kernel
#print axioms order0_18
theorem order0_19 : javaLess s0 s19 = true := by decide +kernel
#print axioms order0_19
theorem order0_20 : javaLess s0 s20 = true := by decide +kernel
#print axioms order0_20
theorem order0_21 : javaLess s0 s21 = true := by decide +kernel
#print axioms order0_21
theorem order1_0 : javaLess s1 s0 = false := by decide +kernel
#print axioms order1_0
theorem order1_1 : javaLess s1 s1 = false := by decide +kernel
#print axioms order1_1
theorem order1_2 : javaLess s1 s2 = true := by decide +kernel
#print axioms order1_2
theorem order1_3 : javaLess s1 s3 = true := by decide +kernel
#print axioms order1_3
theorem order1_4 : javaLess s1 s4 = true := by decide +kernel
#print axioms order1_4
theorem order1_5 : javaLess s1 s5 = true := by decide +kernel
#print axioms order1_5
theorem order1_6 : javaLess s1 s6 = true := by decide +kernel
#print axioms order1_6
theorem order1_7 : javaLess s1 s7 = true := by decide +kernel
#print axioms order1_7
theorem order1_8 : javaLess s1 s8 = true := by decide +kernel
#print axioms order1_8
theorem order1_9 : javaLess s1 s9 = true := by decide +kernel
#print axioms order1_9
theorem order1_10 : javaLess s1 s10 = true := by decide +kernel
#print axioms order1_10
theorem order1_11 : javaLess s1 s11 = true := by decide +kernel
#print axioms order1_11
theorem order1_12 : javaLess s1 s12 = true := by decide +kernel
#print axioms order1_12
theorem order1_13 : javaLess s1 s13 = true := by decide +kernel
#print axioms order1_13
theorem order1_14 : javaLess s1 s14 = false := by decide +kernel
#print axioms order1_14
theorem order1_15 : javaLess s1 s15 = true := by decide +kernel
#print axioms order1_15
theorem order1_16 : javaLess s1 s16 = true := by decide +kernel
#print axioms order1_16
theorem order1_17 : javaLess s1 s17 = true := by decide +kernel
#print axioms order1_17
theorem order1_18 : javaLess s1 s18 = true := by decide +kernel
#print axioms order1_18
theorem order1_19 : javaLess s1 s19 = true := by decide +kernel
#print axioms order1_19
theorem order1_20 : javaLess s1 s20 = true := by decide +kernel
#print axioms order1_20
theorem order1_21 : javaLess s1 s21 = true := by decide +kernel
#print axioms order1_21
theorem order2_0 : javaLess s2 s0 = false := by decide +kernel
#print axioms order2_0
theorem order2_1 : javaLess s2 s1 = false := by decide +kernel
#print axioms order2_1
theorem order2_2 : javaLess s2 s2 = false := by decide +kernel
#print axioms order2_2
theorem order2_3 : javaLess s2 s3 = true := by decide +kernel
#print axioms order2_3
theorem order2_4 : javaLess s2 s4 = true := by decide +kernel
#print axioms order2_4
theorem order2_5 : javaLess s2 s5 = true := by decide +kernel
#print axioms order2_5
theorem order2_6 : javaLess s2 s6 = true := by decide +kernel
#print axioms order2_6
theorem order2_7 : javaLess s2 s7 = true := by decide +kernel
#print axioms order2_7
theorem order2_8 : javaLess s2 s8 = true := by decide +kernel
#print axioms order2_8
theorem order2_9 : javaLess s2 s9 = true := by decide +kernel
#print axioms order2_9
theorem order2_10 : javaLess s2 s10 = true := by decide +kernel
#print axioms order2_10
theorem order2_11 : javaLess s2 s11 = true := by decide +kernel
#print axioms order2_11
theorem order2_12 : javaLess s2 s12 = true := by decide +kernel
#print axioms order2_12
theorem order2_13 : javaLess s2 s13 = true := by decide +kernel
#print axioms order2_13
theorem order2_14 : javaLess s2 s14 = false := by decide +kernel
#print axioms order2_14
theorem order2_15 : javaLess s2 s15 = false := by decide +kernel
#print axioms order2_15
theorem order2_16 : javaLess s2 s16 = false := by decide +kernel
#print axioms order2_16
theorem order2_17 : javaLess s2 s17 = false := by decide +kernel
#print axioms order2_17
theorem order2_18 : javaLess s2 s18 = false := by decide +kernel
#print axioms order2_18
theorem order2_19 : javaLess s2 s19 = true := by decide +kernel
#print axioms order2_19
theorem order2_20 : javaLess s2 s20 = true := by decide +kernel
#print axioms order2_20
theorem order2_21 : javaLess s2 s21 = false := by decide +kernel
#print axioms order2_21
theorem order3_0 : javaLess s3 s0 = false := by decide +kernel
#print axioms order3_0
theorem order3_1 : javaLess s3 s1 = false := by decide +kernel
#print axioms order3_1
theorem order3_2 : javaLess s3 s2 = false := by decide +kernel
#print axioms order3_2
theorem order3_3 : javaLess s3 s3 = false := by decide +kernel
#print axioms order3_3
theorem order3_4 : javaLess s3 s4 = true := by decide +kernel
#print axioms order3_4
theorem order3_5 : javaLess s3 s5 = true := by decide +kernel
#print axioms order3_5
theorem order3_6 : javaLess s3 s6 = true := by decide +kernel
#print axioms order3_6
theorem order3_7 : javaLess s3 s7 = true := by decide +kernel
#print axioms order3_7
theorem order3_8 : javaLess s3 s8 = true := by decide +kernel
#print axioms order3_8
theorem order3_9 : javaLess s3 s9 = true := by decide +kernel
#print axioms order3_9
theorem order3_10 : javaLess s3 s10 = true := by decide +kernel
#print axioms order3_10
theorem order3_11 : javaLess s3 s11 = true := by decide +kernel
#print axioms order3_11
theorem order3_12 : javaLess s3 s12 = true := by decide +kernel
#print axioms order3_12
theorem order3_13 : javaLess s3 s13 = true := by decide +kernel
#print axioms order3_13
theorem order3_14 : javaLess s3 s14 = false := by decide +kernel
#print axioms order3_14
theorem order3_15 : javaLess s3 s15 = false := by decide +kernel
#print axioms order3_15
theorem order3_16 : javaLess s3 s16 = false := by decide +kernel
#print axioms order3_16
theorem order3_17 : javaLess s3 s17 = false := by decide +kernel
#print axioms order3_17
theorem order3_18 : javaLess s3 s18 = false := by decide +kernel
#print axioms order3_18
theorem order3_19 : javaLess s3 s19 = true := by decide +kernel
#print axioms order3_19
theorem order3_20 : javaLess s3 s20 = true := by decide +kernel
#print axioms order3_20
theorem order3_21 : javaLess s3 s21 = false := by decide +kernel
#print axioms order3_21
theorem order4_0 : javaLess s4 s0 = false := by decide +kernel
#print axioms order4_0
theorem order4_1 : javaLess s4 s1 = false := by decide +kernel
#print axioms order4_1
theorem order4_2 : javaLess s4 s2 = false := by decide +kernel
#print axioms order4_2
theorem order4_3 : javaLess s4 s3 = false := by decide +kernel
#print axioms order4_3
theorem order4_4 : javaLess s4 s4 = false := by decide +kernel
#print axioms order4_4
theorem order4_5 : javaLess s4 s5 = true := by decide +kernel
#print axioms order4_5
theorem order4_6 : javaLess s4 s6 = true := by decide +kernel
#print axioms order4_6
theorem order4_7 : javaLess s4 s7 = true := by decide +kernel
#print axioms order4_7
theorem order4_8 : javaLess s4 s8 = true := by decide +kernel
#print axioms order4_8
theorem order4_9 : javaLess s4 s9 = true := by decide +kernel
#print axioms order4_9
theorem order4_10 : javaLess s4 s10 = true := by decide +kernel
#print axioms order4_10
theorem order4_11 : javaLess s4 s11 = true := by decide +kernel
#print axioms order4_11
theorem order4_12 : javaLess s4 s12 = true := by decide +kernel
#print axioms order4_12
theorem order4_13 : javaLess s4 s13 = true := by decide +kernel
#print axioms order4_13
theorem order4_14 : javaLess s4 s14 = false := by decide +kernel
#print axioms order4_14
theorem order4_15 : javaLess s4 s15 = false := by decide +kernel
#print axioms order4_15
theorem order4_16 : javaLess s4 s16 = false := by decide +kernel
#print axioms order4_16
theorem order4_17 : javaLess s4 s17 = false := by decide +kernel
#print axioms order4_17
theorem order4_18 : javaLess s4 s18 = false := by decide +kernel
#print axioms order4_18
theorem order4_19 : javaLess s4 s19 = true := by decide +kernel
#print axioms order4_19
theorem order4_20 : javaLess s4 s20 = true := by decide +kernel
#print axioms order4_20
theorem order4_21 : javaLess s4 s21 = false := by decide +kernel
#print axioms order4_21
theorem order5_0 : javaLess s5 s0 = false := by decide +kernel
#print axioms order5_0
theorem order5_1 : javaLess s5 s1 = false := by decide +kernel
#print axioms order5_1
theorem order5_2 : javaLess s5 s2 = false := by decide +kernel
#print axioms order5_2
theorem order5_3 : javaLess s5 s3 = false := by decide +kernel
#print axioms order5_3
theorem order5_4 : javaLess s5 s4 = false := by decide +kernel
#print axioms order5_4
theorem order5_5 : javaLess s5 s5 = false := by decide +kernel
#print axioms order5_5
theorem order5_6 : javaLess s5 s6 = true := by decide +kernel
#print axioms order5_6
theorem order5_7 : javaLess s5 s7 = true := by decide +kernel
#print axioms order5_7
theorem order5_8 : javaLess s5 s8 = true := by decide +kernel
#print axioms order5_8
theorem order5_9 : javaLess s5 s9 = true := by decide +kernel
#print axioms order5_9
theorem order5_10 : javaLess s5 s10 = true := by decide +kernel
#print axioms order5_10
theorem order5_11 : javaLess s5 s11 = true := by decide +kernel
#print axioms order5_11
theorem order5_12 : javaLess s5 s12 = true := by decide +kernel
#print axioms order5_12
theorem order5_13 : javaLess s5 s13 = true := by decide +kernel
#print axioms order5_13
theorem order5_14 : javaLess s5 s14 = false := by decide +kernel
#print axioms order5_14
theorem order5_15 : javaLess s5 s15 = false := by decide +kernel
#print axioms order5_15
theorem order5_16 : javaLess s5 s16 = false := by decide +kernel
#print axioms order5_16
theorem order5_17 : javaLess s5 s17 = false := by decide +kernel
#print axioms order5_17
theorem order5_18 : javaLess s5 s18 = false := by decide +kernel
#print axioms order5_18
theorem order5_19 : javaLess s5 s19 = true := by decide +kernel
#print axioms order5_19
theorem order5_20 : javaLess s5 s20 = true := by decide +kernel
#print axioms order5_20
theorem order5_21 : javaLess s5 s21 = false := by decide +kernel
#print axioms order5_21
theorem order6_0 : javaLess s6 s0 = false := by decide +kernel
#print axioms order6_0
theorem order6_1 : javaLess s6 s1 = false := by decide +kernel
#print axioms order6_1
theorem order6_2 : javaLess s6 s2 = false := by decide +kernel
#print axioms order6_2
theorem order6_3 : javaLess s6 s3 = false := by decide +kernel
#print axioms order6_3
theorem order6_4 : javaLess s6 s4 = false := by decide +kernel
#print axioms order6_4
theorem order6_5 : javaLess s6 s5 = false := by decide +kernel
#print axioms order6_5
theorem order6_6 : javaLess s6 s6 = false := by decide +kernel
#print axioms order6_6
theorem order6_7 : javaLess s6 s7 = true := by decide +kernel
#print axioms order6_7
theorem order6_8 : javaLess s6 s8 = true := by decide +kernel
#print axioms order6_8
theorem order6_9 : javaLess s6 s9 = true := by decide +kernel
#print axioms order6_9
theorem order6_10 : javaLess s6 s10 = true := by decide +kernel
#print axioms order6_10
theorem order6_11 : javaLess s6 s11 = true := by decide +kernel
#print axioms order6_11
theorem order6_12 : javaLess s6 s12 = true := by decide +kernel
#print axioms order6_12
theorem order6_13 : javaLess s6 s13 = true := by decide +kernel
#print axioms order6_13
theorem order6_14 : javaLess s6 s14 = false := by decide +kernel
#print axioms order6_14
theorem order6_15 : javaLess s6 s15 = false := by decide +kernel
#print axioms order6_15
theorem order6_16 : javaLess s6 s16 = false := by decide +kernel
#print axioms order6_16
theorem order6_17 : javaLess s6 s17 = false := by decide +kernel
#print axioms order6_17
theorem order6_18 : javaLess s6 s18 = false := by decide +kernel
#print axioms order6_18
theorem order6_19 : javaLess s6 s19 = true := by decide +kernel
#print axioms order6_19
theorem order6_20 : javaLess s6 s20 = true := by decide +kernel
#print axioms order6_20
theorem order6_21 : javaLess s6 s21 = false := by decide +kernel
#print axioms order6_21
theorem order7_0 : javaLess s7 s0 = false := by decide +kernel
#print axioms order7_0
theorem order7_1 : javaLess s7 s1 = false := by decide +kernel
#print axioms order7_1
theorem order7_2 : javaLess s7 s2 = false := by decide +kernel
#print axioms order7_2
theorem order7_3 : javaLess s7 s3 = false := by decide +kernel
#print axioms order7_3
theorem order7_4 : javaLess s7 s4 = false := by decide +kernel
#print axioms order7_4
theorem order7_5 : javaLess s7 s5 = false := by decide +kernel
#print axioms order7_5
theorem order7_6 : javaLess s7 s6 = false := by decide +kernel
#print axioms order7_6
theorem order7_7 : javaLess s7 s7 = false := by decide +kernel
#print axioms order7_7
theorem order7_8 : javaLess s7 s8 = true := by decide +kernel
#print axioms order7_8
theorem order7_9 : javaLess s7 s9 = true := by decide +kernel
#print axioms order7_9
theorem order7_10 : javaLess s7 s10 = true := by decide +kernel
#print axioms order7_10
theorem order7_11 : javaLess s7 s11 = true := by decide +kernel
#print axioms order7_11
theorem order7_12 : javaLess s7 s12 = true := by decide +kernel
#print axioms order7_12
theorem order7_13 : javaLess s7 s13 = true := by decide +kernel
#print axioms order7_13
theorem order7_14 : javaLess s7 s14 = false := by decide +kernel
#print axioms order7_14
theorem order7_15 : javaLess s7 s15 = false := by decide +kernel
#print axioms order7_15
theorem order7_16 : javaLess s7 s16 = false := by decide +kernel
#print axioms order7_16
theorem order7_17 : javaLess s7 s17 = false := by decide +kernel
#print axioms order7_17
theorem order7_18 : javaLess s7 s18 = false := by decide +kernel
#print axioms order7_18
theorem order7_19 : javaLess s7 s19 = true := by decide +kernel
#print axioms order7_19
theorem order7_20 : javaLess s7 s20 = true := by decide +kernel
#print axioms order7_20
theorem order7_21 : javaLess s7 s21 = false := by decide +kernel
#print axioms order7_21
theorem order8_0 : javaLess s8 s0 = false := by decide +kernel
#print axioms order8_0
theorem order8_1 : javaLess s8 s1 = false := by decide +kernel
#print axioms order8_1
theorem order8_2 : javaLess s8 s2 = false := by decide +kernel
#print axioms order8_2
theorem order8_3 : javaLess s8 s3 = false := by decide +kernel
#print axioms order8_3
theorem order8_4 : javaLess s8 s4 = false := by decide +kernel
#print axioms order8_4
theorem order8_5 : javaLess s8 s5 = false := by decide +kernel
#print axioms order8_5
theorem order8_6 : javaLess s8 s6 = false := by decide +kernel
#print axioms order8_6
theorem order8_7 : javaLess s8 s7 = false := by decide +kernel
#print axioms order8_7
theorem order8_8 : javaLess s8 s8 = false := by decide +kernel
#print axioms order8_8
theorem order8_9 : javaLess s8 s9 = true := by decide +kernel
#print axioms order8_9
theorem order8_10 : javaLess s8 s10 = true := by decide +kernel
#print axioms order8_10
theorem order8_11 : javaLess s8 s11 = true := by decide +kernel
#print axioms order8_11
theorem order8_12 : javaLess s8 s12 = true := by decide +kernel
#print axioms order8_12
theorem order8_13 : javaLess s8 s13 = true := by decide +kernel
#print axioms order8_13
theorem order8_14 : javaLess s8 s14 = false := by decide +kernel
#print axioms order8_14
theorem order8_15 : javaLess s8 s15 = false := by decide +kernel
#print axioms order8_15
theorem order8_16 : javaLess s8 s16 = false := by decide +kernel
#print axioms order8_16
theorem order8_17 : javaLess s8 s17 = false := by decide +kernel
#print axioms order8_17
theorem order8_18 : javaLess s8 s18 = false := by decide +kernel
#print axioms order8_18
theorem order8_19 : javaLess s8 s19 = true := by decide +kernel
#print axioms order8_19
theorem order8_20 : javaLess s8 s20 = true := by decide +kernel
#print axioms order8_20
theorem order8_21 : javaLess s8 s21 = false := by decide +kernel
#print axioms order8_21
theorem order9_0 : javaLess s9 s0 = false := by decide +kernel
#print axioms order9_0
theorem order9_1 : javaLess s9 s1 = false := by decide +kernel
#print axioms order9_1
theorem order9_2 : javaLess s9 s2 = false := by decide +kernel
#print axioms order9_2
theorem order9_3 : javaLess s9 s3 = false := by decide +kernel
#print axioms order9_3
theorem order9_4 : javaLess s9 s4 = false := by decide +kernel
#print axioms order9_4
theorem order9_5 : javaLess s9 s5 = false := by decide +kernel
#print axioms order9_5
theorem order9_6 : javaLess s9 s6 = false := by decide +kernel
#print axioms order9_6
theorem order9_7 : javaLess s9 s7 = false := by decide +kernel
#print axioms order9_7
theorem order9_8 : javaLess s9 s8 = false := by decide +kernel
#print axioms order9_8
theorem order9_9 : javaLess s9 s9 = false := by decide +kernel
#print axioms order9_9
theorem order9_10 : javaLess s9 s10 = true := by decide +kernel
#print axioms order9_10
theorem order9_11 : javaLess s9 s11 = false := by decide +kernel
#print axioms order9_11
theorem order9_12 : javaLess s9 s12 = false := by decide +kernel
#print axioms order9_12
theorem order9_13 : javaLess s9 s13 = false := by decide +kernel
#print axioms order9_13
theorem order9_14 : javaLess s9 s14 = false := by decide +kernel
#print axioms order9_14
theorem order9_15 : javaLess s9 s15 = false := by decide +kernel
#print axioms order9_15
theorem order9_16 : javaLess s9 s16 = false := by decide +kernel
#print axioms order9_16
theorem order9_17 : javaLess s9 s17 = false := by decide +kernel
#print axioms order9_17
theorem order9_18 : javaLess s9 s18 = false := by decide +kernel
#print axioms order9_18
theorem order9_19 : javaLess s9 s19 = false := by decide +kernel
#print axioms order9_19
theorem order9_20 : javaLess s9 s20 = true := by decide +kernel
#print axioms order9_20
theorem order9_21 : javaLess s9 s21 = false := by decide +kernel
#print axioms order9_21
theorem order10_0 : javaLess s10 s0 = false := by decide +kernel
#print axioms order10_0
theorem order10_1 : javaLess s10 s1 = false := by decide +kernel
#print axioms order10_1
theorem order10_2 : javaLess s10 s2 = false := by decide +kernel
#print axioms order10_2
theorem order10_3 : javaLess s10 s3 = false := by decide +kernel
#print axioms order10_3
theorem order10_4 : javaLess s10 s4 = false := by decide +kernel
#print axioms order10_4
theorem order10_5 : javaLess s10 s5 = false := by decide +kernel
#print axioms order10_5
theorem order10_6 : javaLess s10 s6 = false := by decide +kernel
#print axioms order10_6
theorem order10_7 : javaLess s10 s7 = false := by decide +kernel
#print axioms order10_7
theorem order10_8 : javaLess s10 s8 = false := by decide +kernel
#print axioms order10_8
theorem order10_9 : javaLess s10 s9 = false := by decide +kernel
#print axioms order10_9
theorem order10_10 : javaLess s10 s10 = false := by decide +kernel
#print axioms order10_10
theorem order10_11 : javaLess s10 s11 = false := by decide +kernel
#print axioms order10_11
theorem order10_12 : javaLess s10 s12 = false := by decide +kernel
#print axioms order10_12
theorem order10_13 : javaLess s10 s13 = false := by decide +kernel
#print axioms order10_13
theorem order10_14 : javaLess s10 s14 = false := by decide +kernel
#print axioms order10_14
theorem order10_15 : javaLess s10 s15 = false := by decide +kernel
#print axioms order10_15
theorem order10_16 : javaLess s10 s16 = false := by decide +kernel
#print axioms order10_16
theorem order10_17 : javaLess s10 s17 = false := by decide +kernel
#print axioms order10_17
theorem order10_18 : javaLess s10 s18 = false := by decide +kernel
#print axioms order10_18
theorem order10_19 : javaLess s10 s19 = false := by decide +kernel
#print axioms order10_19
theorem order10_20 : javaLess s10 s20 = false := by decide +kernel
#print axioms order10_20
theorem order10_21 : javaLess s10 s21 = false := by decide +kernel
#print axioms order10_21
theorem order11_0 : javaLess s11 s0 = false := by decide +kernel
#print axioms order11_0
theorem order11_1 : javaLess s11 s1 = false := by decide +kernel
#print axioms order11_1
theorem order11_2 : javaLess s11 s2 = false := by decide +kernel
#print axioms order11_2
theorem order11_3 : javaLess s11 s3 = false := by decide +kernel
#print axioms order11_3
theorem order11_4 : javaLess s11 s4 = false := by decide +kernel
#print axioms order11_4
theorem order11_5 : javaLess s11 s5 = false := by decide +kernel
#print axioms order11_5
theorem order11_6 : javaLess s11 s6 = false := by decide +kernel
#print axioms order11_6
theorem order11_7 : javaLess s11 s7 = false := by decide +kernel
#print axioms order11_7
theorem order11_8 : javaLess s11 s8 = false := by decide +kernel
#print axioms order11_8
theorem order11_9 : javaLess s11 s9 = true := by decide +kernel
#print axioms order11_9
theorem order11_10 : javaLess s11 s10 = true := by decide +kernel
#print axioms order11_10
theorem order11_11 : javaLess s11 s11 = false := by decide +kernel
#print axioms order11_11
theorem order11_12 : javaLess s11 s12 = true := by decide +kernel
#print axioms order11_12
theorem order11_13 : javaLess s11 s13 = true := by decide +kernel
#print axioms order11_13
theorem order11_14 : javaLess s11 s14 = false := by decide +kernel
#print axioms order11_14
theorem order11_15 : javaLess s11 s15 = false := by decide +kernel
#print axioms order11_15
theorem order11_16 : javaLess s11 s16 = false := by decide +kernel
#print axioms order11_16
theorem order11_17 : javaLess s11 s17 = false := by decide +kernel
#print axioms order11_17
theorem order11_18 : javaLess s11 s18 = false := by decide +kernel
#print axioms order11_18
theorem order11_19 : javaLess s11 s19 = true := by decide +kernel
#print axioms order11_19
theorem order11_20 : javaLess s11 s20 = true := by decide +kernel
#print axioms order11_20
theorem order11_21 : javaLess s11 s21 = false := by decide +kernel
#print axioms order11_21
theorem order12_0 : javaLess s12 s0 = false := by decide +kernel
#print axioms order12_0
theorem order12_1 : javaLess s12 s1 = false := by decide +kernel
#print axioms order12_1
theorem order12_2 : javaLess s12 s2 = false := by decide +kernel
#print axioms order12_2
theorem order12_3 : javaLess s12 s3 = false := by decide +kernel
#print axioms order12_3
theorem order12_4 : javaLess s12 s4 = false := by decide +kernel
#print axioms order12_4
theorem order12_5 : javaLess s12 s5 = false := by decide +kernel
#print axioms order12_5
theorem order12_6 : javaLess s12 s6 = false := by decide +kernel
#print axioms order12_6
theorem order12_7 : javaLess s12 s7 = false := by decide +kernel
#print axioms order12_7
theorem order12_8 : javaLess s12 s8 = false := by decide +kernel
#print axioms order12_8
theorem order12_9 : javaLess s12 s9 = true := by decide +kernel
#print axioms order12_9
theorem order12_10 : javaLess s12 s10 = true := by decide +kernel
#print axioms order12_10
theorem order12_11 : javaLess s12 s11 = false := by decide +kernel
#print axioms order12_11
theorem order12_12 : javaLess s12 s12 = false := by decide +kernel
#print axioms order12_12
theorem order12_13 : javaLess s12 s13 = true := by decide +kernel
#print axioms order12_13
theorem order12_14 : javaLess s12 s14 = false := by decide +kernel
#print axioms order12_14
theorem order12_15 : javaLess s12 s15 = false := by decide +kernel
#print axioms order12_15
theorem order12_16 : javaLess s12 s16 = false := by decide +kernel
#print axioms order12_16
theorem order12_17 : javaLess s12 s17 = false := by decide +kernel
#print axioms order12_17
theorem order12_18 : javaLess s12 s18 = false := by decide +kernel
#print axioms order12_18
theorem order12_19 : javaLess s12 s19 = false := by decide +kernel
#print axioms order12_19
theorem order12_20 : javaLess s12 s20 = true := by decide +kernel
#print axioms order12_20
theorem order12_21 : javaLess s12 s21 = false := by decide +kernel
#print axioms order12_21
theorem order13_0 : javaLess s13 s0 = false := by decide +kernel
#print axioms order13_0
theorem order13_1 : javaLess s13 s1 = false := by decide +kernel
#print axioms order13_1
theorem order13_2 : javaLess s13 s2 = false := by decide +kernel
#print axioms order13_2
theorem order13_3 : javaLess s13 s3 = false := by decide +kernel
#print axioms order13_3
theorem order13_4 : javaLess s13 s4 = false := by decide +kernel
#print axioms order13_4
theorem order13_5 : javaLess s13 s5 = false := by decide +kernel
#print axioms order13_5
theorem order13_6 : javaLess s13 s6 = false := by decide +kernel
#print axioms order13_6
theorem order13_7 : javaLess s13 s7 = false := by decide +kernel
#print axioms order13_7
theorem order13_8 : javaLess s13 s8 = false := by decide +kernel
#print axioms order13_8
theorem order13_9 : javaLess s13 s9 = true := by decide +kernel
#print axioms order13_9
theorem order13_10 : javaLess s13 s10 = true := by decide +kernel
#print axioms order13_10
theorem order13_11 : javaLess s13 s11 = false := by decide +kernel
#print axioms order13_11
theorem order13_12 : javaLess s13 s12 = false := by decide +kernel
#print axioms order13_12
theorem order13_13 : javaLess s13 s13 = false := by decide +kernel
#print axioms order13_13
theorem order13_14 : javaLess s13 s14 = false := by decide +kernel
#print axioms order13_14
theorem order13_15 : javaLess s13 s15 = false := by decide +kernel
#print axioms order13_15
theorem order13_16 : javaLess s13 s16 = false := by decide +kernel
#print axioms order13_16
theorem order13_17 : javaLess s13 s17 = false := by decide +kernel
#print axioms order13_17
theorem order13_18 : javaLess s13 s18 = false := by decide +kernel
#print axioms order13_18
theorem order13_19 : javaLess s13 s19 = false := by decide +kernel
#print axioms order13_19
theorem order13_20 : javaLess s13 s20 = true := by decide +kernel
#print axioms order13_20
theorem order13_21 : javaLess s13 s21 = false := by decide +kernel
#print axioms order13_21
theorem order14_0 : javaLess s14 s0 = true := by decide +kernel
#print axioms order14_0
theorem order14_1 : javaLess s14 s1 = true := by decide +kernel
#print axioms order14_1
theorem order14_2 : javaLess s14 s2 = true := by decide +kernel
#print axioms order14_2
theorem order14_3 : javaLess s14 s3 = true := by decide +kernel
#print axioms order14_3
theorem order14_4 : javaLess s14 s4 = true := by decide +kernel
#print axioms order14_4
theorem order14_5 : javaLess s14 s5 = true := by decide +kernel
#print axioms order14_5
theorem order14_6 : javaLess s14 s6 = true := by decide +kernel
#print axioms order14_6
theorem order14_7 : javaLess s14 s7 = true := by decide +kernel
#print axioms order14_7
theorem order14_8 : javaLess s14 s8 = true := by decide +kernel
#print axioms order14_8
theorem order14_9 : javaLess s14 s9 = true := by decide +kernel
#print axioms order14_9
theorem order14_10 : javaLess s14 s10 = true := by decide +kernel
#print axioms order14_10
theorem order14_11 : javaLess s14 s11 = true := by decide +kernel
#print axioms order14_11
theorem order14_12 : javaLess s14 s12 = true := by decide +kernel
#print axioms order14_12
theorem order14_13 : javaLess s14 s13 = true := by decide +kernel
#print axioms order14_13
theorem order14_14 : javaLess s14 s14 = false := by decide +kernel
#print axioms order14_14
theorem order14_15 : javaLess s14 s15 = true := by decide +kernel
#print axioms order14_15
theorem order14_16 : javaLess s14 s16 = true := by decide +kernel
#print axioms order14_16
theorem order14_17 : javaLess s14 s17 = true := by decide +kernel
#print axioms order14_17
theorem order14_18 : javaLess s14 s18 = true := by decide +kernel
#print axioms order14_18
theorem order14_19 : javaLess s14 s19 = true := by decide +kernel
#print axioms order14_19
theorem order14_20 : javaLess s14 s20 = true := by decide +kernel
#print axioms order14_20
theorem order14_21 : javaLess s14 s21 = true := by decide +kernel
#print axioms order14_21
theorem order15_0 : javaLess s15 s0 = false := by decide +kernel
#print axioms order15_0
theorem order15_1 : javaLess s15 s1 = false := by decide +kernel
#print axioms order15_1
theorem order15_2 : javaLess s15 s2 = true := by decide +kernel
#print axioms order15_2
theorem order15_3 : javaLess s15 s3 = true := by decide +kernel
#print axioms order15_3
theorem order15_4 : javaLess s15 s4 = true := by decide +kernel
#print axioms order15_4
theorem order15_5 : javaLess s15 s5 = true := by decide +kernel
#print axioms order15_5
theorem order15_6 : javaLess s15 s6 = true := by decide +kernel
#print axioms order15_6
theorem order15_7 : javaLess s15 s7 = true := by decide +kernel
#print axioms order15_7
theorem order15_8 : javaLess s15 s8 = true := by decide +kernel
#print axioms order15_8
theorem order15_9 : javaLess s15 s9 = true := by decide +kernel
#print axioms order15_9
theorem order15_10 : javaLess s15 s10 = true := by decide +kernel
#print axioms order15_10
theorem order15_11 : javaLess s15 s11 = true := by decide +kernel
#print axioms order15_11
theorem order15_12 : javaLess s15 s12 = true := by decide +kernel
#print axioms order15_12
theorem order15_13 : javaLess s15 s13 = true := by decide +kernel
#print axioms order15_13
theorem order15_14 : javaLess s15 s14 = false := by decide +kernel
#print axioms order15_14
theorem order15_15 : javaLess s15 s15 = false := by decide +kernel
#print axioms order15_15
theorem order15_16 : javaLess s15 s16 = true := by decide +kernel
#print axioms order15_16
theorem order15_17 : javaLess s15 s17 = true := by decide +kernel
#print axioms order15_17
theorem order15_18 : javaLess s15 s18 = false := by decide +kernel
#print axioms order15_18
theorem order15_19 : javaLess s15 s19 = true := by decide +kernel
#print axioms order15_19
theorem order15_20 : javaLess s15 s20 = true := by decide +kernel
#print axioms order15_20
theorem order15_21 : javaLess s15 s21 = false := by decide +kernel
#print axioms order15_21
theorem order16_0 : javaLess s16 s0 = false := by decide +kernel
#print axioms order16_0
theorem order16_1 : javaLess s16 s1 = false := by decide +kernel
#print axioms order16_1
theorem order16_2 : javaLess s16 s2 = true := by decide +kernel
#print axioms order16_2
theorem order16_3 : javaLess s16 s3 = true := by decide +kernel
#print axioms order16_3
theorem order16_4 : javaLess s16 s4 = true := by decide +kernel
#print axioms order16_4
theorem order16_5 : javaLess s16 s5 = true := by decide +kernel
#print axioms order16_5
theorem order16_6 : javaLess s16 s6 = true := by decide +kernel
#print axioms order16_6
theorem order16_7 : javaLess s16 s7 = true := by decide +kernel
#print axioms order16_7
theorem order16_8 : javaLess s16 s8 = true := by decide +kernel
#print axioms order16_8
theorem order16_9 : javaLess s16 s9 = true := by decide +kernel
#print axioms order16_9
theorem order16_10 : javaLess s16 s10 = true := by decide +kernel
#print axioms order16_10
theorem order16_11 : javaLess s16 s11 = true := by decide +kernel
#print axioms order16_11
theorem order16_12 : javaLess s16 s12 = true := by decide +kernel
#print axioms order16_12
theorem order16_13 : javaLess s16 s13 = true := by decide +kernel
#print axioms order16_13
theorem order16_14 : javaLess s16 s14 = false := by decide +kernel
#print axioms order16_14
theorem order16_15 : javaLess s16 s15 = false := by decide +kernel
#print axioms order16_15
theorem order16_16 : javaLess s16 s16 = false := by decide +kernel
#print axioms order16_16
theorem order16_17 : javaLess s16 s17 = true := by decide +kernel
#print axioms order16_17
theorem order16_18 : javaLess s16 s18 = false := by decide +kernel
#print axioms order16_18
theorem order16_19 : javaLess s16 s19 = true := by decide +kernel
#print axioms order16_19
theorem order16_20 : javaLess s16 s20 = true := by decide +kernel
#print axioms order16_20
theorem order16_21 : javaLess s16 s21 = false := by decide +kernel
#print axioms order16_21
theorem order17_0 : javaLess s17 s0 = false := by decide +kernel
#print axioms order17_0
theorem order17_1 : javaLess s17 s1 = false := by decide +kernel
#print axioms order17_1
theorem order17_2 : javaLess s17 s2 = true := by decide +kernel
#print axioms order17_2
theorem order17_3 : javaLess s17 s3 = true := by decide +kernel
#print axioms order17_3
theorem order17_4 : javaLess s17 s4 = true := by decide +kernel
#print axioms order17_4
theorem order17_5 : javaLess s17 s5 = true := by decide +kernel
#print axioms order17_5
theorem order17_6 : javaLess s17 s6 = true := by decide +kernel
#print axioms order17_6
theorem order17_7 : javaLess s17 s7 = true := by decide +kernel
#print axioms order17_7
theorem order17_8 : javaLess s17 s8 = true := by decide +kernel
#print axioms order17_8
theorem order17_9 : javaLess s17 s9 = true := by decide +kernel
#print axioms order17_9
theorem order17_10 : javaLess s17 s10 = true := by decide +kernel
#print axioms order17_10
theorem order17_11 : javaLess s17 s11 = true := by decide +kernel
#print axioms order17_11
theorem order17_12 : javaLess s17 s12 = true := by decide +kernel
#print axioms order17_12
theorem order17_13 : javaLess s17 s13 = true := by decide +kernel
#print axioms order17_13
theorem order17_14 : javaLess s17 s14 = false := by decide +kernel
#print axioms order17_14
theorem order17_15 : javaLess s17 s15 = false := by decide +kernel
#print axioms order17_15
theorem order17_16 : javaLess s17 s16 = false := by decide +kernel
#print axioms order17_16
theorem order17_17 : javaLess s17 s17 = false := by decide +kernel
#print axioms order17_17
theorem order17_18 : javaLess s17 s18 = false := by decide +kernel
#print axioms order17_18
theorem order17_19 : javaLess s17 s19 = true := by decide +kernel
#print axioms order17_19
theorem order17_20 : javaLess s17 s20 = true := by decide +kernel
#print axioms order17_20
theorem order17_21 : javaLess s17 s21 = false := by decide +kernel
#print axioms order17_21
theorem order18_0 : javaLess s18 s0 = false := by decide +kernel
#print axioms order18_0
theorem order18_1 : javaLess s18 s1 = false := by decide +kernel
#print axioms order18_1
theorem order18_2 : javaLess s18 s2 = true := by decide +kernel
#print axioms order18_2
theorem order18_3 : javaLess s18 s3 = true := by decide +kernel
#print axioms order18_3
theorem order18_4 : javaLess s18 s4 = true := by decide +kernel
#print axioms order18_4
theorem order18_5 : javaLess s18 s5 = true := by decide +kernel
#print axioms order18_5
theorem order18_6 : javaLess s18 s6 = true := by decide +kernel
#print axioms order18_6
theorem order18_7 : javaLess s18 s7 = true := by decide +kernel
#print axioms order18_7
theorem order18_8 : javaLess s18 s8 = true := by decide +kernel
#print axioms order18_8
theorem order18_9 : javaLess s18 s9 = true := by decide +kernel
#print axioms order18_9
theorem order18_10 : javaLess s18 s10 = true := by decide +kernel
#print axioms order18_10
theorem order18_11 : javaLess s18 s11 = true := by decide +kernel
#print axioms order18_11
theorem order18_12 : javaLess s18 s12 = true := by decide +kernel
#print axioms order18_12
theorem order18_13 : javaLess s18 s13 = true := by decide +kernel
#print axioms order18_13
theorem order18_14 : javaLess s18 s14 = false := by decide +kernel
#print axioms order18_14
theorem order18_15 : javaLess s18 s15 = true := by decide +kernel
#print axioms order18_15
theorem order18_16 : javaLess s18 s16 = true := by decide +kernel
#print axioms order18_16
theorem order18_17 : javaLess s18 s17 = true := by decide +kernel
#print axioms order18_17
theorem order18_18 : javaLess s18 s18 = false := by decide +kernel
#print axioms order18_18
theorem order18_19 : javaLess s18 s19 = true := by decide +kernel
#print axioms order18_19
theorem order18_20 : javaLess s18 s20 = true := by decide +kernel
#print axioms order18_20
theorem order18_21 : javaLess s18 s21 = true := by decide +kernel
#print axioms order18_21
theorem order19_0 : javaLess s19 s0 = false := by decide +kernel
#print axioms order19_0
theorem order19_1 : javaLess s19 s1 = false := by decide +kernel
#print axioms order19_1
theorem order19_2 : javaLess s19 s2 = false := by decide +kernel
#print axioms order19_2
theorem order19_3 : javaLess s19 s3 = false := by decide +kernel
#print axioms order19_3
theorem order19_4 : javaLess s19 s4 = false := by decide +kernel
#print axioms order19_4
theorem order19_5 : javaLess s19 s5 = false := by decide +kernel
#print axioms order19_5
theorem order19_6 : javaLess s19 s6 = false := by decide +kernel
#print axioms order19_6
theorem order19_7 : javaLess s19 s7 = false := by decide +kernel
#print axioms order19_7
theorem order19_8 : javaLess s19 s8 = false := by decide +kernel
#print axioms order19_8
theorem order19_9 : javaLess s19 s9 = true := by decide +kernel
#print axioms order19_9
theorem order19_10 : javaLess s19 s10 = true := by decide +kernel
#print axioms order19_10
theorem order19_11 : javaLess s19 s11 = false := by decide +kernel
#print axioms order19_11
theorem order19_12 : javaLess s19 s12 = true := by decide +kernel
#print axioms order19_12
theorem order19_13 : javaLess s19 s13 = true := by decide +kernel
#print axioms order19_13
theorem order19_14 : javaLess s19 s14 = false := by decide +kernel
#print axioms order19_14
theorem order19_15 : javaLess s19 s15 = false := by decide +kernel
#print axioms order19_15
theorem order19_16 : javaLess s19 s16 = false := by decide +kernel
#print axioms order19_16
theorem order19_17 : javaLess s19 s17 = false := by decide +kernel
#print axioms order19_17
theorem order19_18 : javaLess s19 s18 = false := by decide +kernel
#print axioms order19_18
theorem order19_19 : javaLess s19 s19 = false := by decide +kernel
#print axioms order19_19
theorem order19_20 : javaLess s19 s20 = true := by decide +kernel
#print axioms order19_20
theorem order19_21 : javaLess s19 s21 = false := by decide +kernel
#print axioms order19_21
theorem order20_0 : javaLess s20 s0 = false := by decide +kernel
#print axioms order20_0
theorem order20_1 : javaLess s20 s1 = false := by decide +kernel
#print axioms order20_1
theorem order20_2 : javaLess s20 s2 = false := by decide +kernel
#print axioms order20_2
theorem order20_3 : javaLess s20 s3 = false := by decide +kernel
#print axioms order20_3
theorem order20_4 : javaLess s20 s4 = false := by decide +kernel
#print axioms order20_4
theorem order20_5 : javaLess s20 s5 = false := by decide +kernel
#print axioms order20_5
theorem order20_6 : javaLess s20 s6 = false := by decide +kernel
#print axioms order20_6
theorem order20_7 : javaLess s20 s7 = false := by decide +kernel
#print axioms order20_7
theorem order20_8 : javaLess s20 s8 = false := by decide +kernel
#print axioms order20_8
theorem order20_9 : javaLess s20 s9 = false := by decide +kernel
#print axioms order20_9
theorem order20_10 : javaLess s20 s10 = true := by decide +kernel
#print axioms order20_10
theorem order20_11 : javaLess s20 s11 = false := by decide +kernel
#print axioms order20_11
theorem order20_12 : javaLess s20 s12 = false := by decide +kernel
#print axioms order20_12
theorem order20_13 : javaLess s20 s13 = false := by decide +kernel
#print axioms order20_13
theorem order20_14 : javaLess s20 s14 = false := by decide +kernel
#print axioms order20_14
theorem order20_15 : javaLess s20 s15 = false := by decide +kernel
#print axioms order20_15
theorem order20_16 : javaLess s20 s16 = false := by decide +kernel
#print axioms order20_16
theorem order20_17 : javaLess s20 s17 = false := by decide +kernel
#print axioms order20_17
theorem order20_18 : javaLess s20 s18 = false := by decide +kernel
#print axioms order20_18
theorem order20_19 : javaLess s20 s19 = false := by decide +kernel
#print axioms order20_19
theorem order20_20 : javaLess s20 s20 = false := by decide +kernel
#print axioms order20_20
theorem order20_21 : javaLess s20 s21 = false := by decide +kernel
#print axioms order20_21
theorem order21_0 : javaLess s21 s0 = false := by decide +kernel
#print axioms order21_0
theorem order21_1 : javaLess s21 s1 = false := by decide +kernel
#print axioms order21_1
theorem order21_2 : javaLess s21 s2 = true := by decide +kernel
#print axioms order21_2
theorem order21_3 : javaLess s21 s3 = true := by decide +kernel
#print axioms order21_3
theorem order21_4 : javaLess s21 s4 = true := by decide +kernel
#print axioms order21_4
theorem order21_5 : javaLess s21 s5 = true := by decide +kernel
#print axioms order21_5
theorem order21_6 : javaLess s21 s6 = true := by decide +kernel
#print axioms order21_6
theorem order21_7 : javaLess s21 s7 = true := by decide +kernel
#print axioms order21_7
theorem order21_8 : javaLess s21 s8 = true := by decide +kernel
#print axioms order21_8
theorem order21_9 : javaLess s21 s9 = true := by decide +kernel
#print axioms order21_9
theorem order21_10 : javaLess s21 s10 = true := by decide +kernel
#print axioms order21_10
theorem order21_11 : javaLess s21 s11 = true := by decide +kernel
#print axioms order21_11
theorem order21_12 : javaLess s21 s12 = true := by decide +kernel
#print axioms order21_12
theorem order21_13 : javaLess s21 s13 = true := by decide +kernel
#print axioms order21_13
theorem order21_14 : javaLess s21 s14 = false := by decide +kernel
#print axioms order21_14
theorem order21_15 : javaLess s21 s15 = true := by decide +kernel
#print axioms order21_15
theorem order21_16 : javaLess s21 s16 = true := by decide +kernel
#print axioms order21_16
theorem order21_17 : javaLess s21 s17 = true := by decide +kernel
#print axioms order21_17
theorem order21_18 : javaLess s21 s18 = false := by decide +kernel
#print axioms order21_18
theorem order21_19 : javaLess s21 s19 = true := by decide +kernel
#print axioms order21_19
theorem order21_20 : javaLess s21 s20 = true := by decide +kernel
#print axioms order21_20
theorem order21_21 : javaLess s21 s21 = false := by decide +kernel
#print axioms order21_21
end L
end LawWireIndependentReview
