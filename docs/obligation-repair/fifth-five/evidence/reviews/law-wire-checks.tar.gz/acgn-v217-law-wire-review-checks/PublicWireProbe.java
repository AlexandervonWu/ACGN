import org.acgn.cert.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.security.MessageDigest;

public final class PublicWireProbe {
    static final String[] SECTIONS = {"contexts", "embeddings", "terms", "proofs", "witnesses", "snapshots", "events", "canonical-records", "unfoldings", "publication"};
    static Wire.Node n(String tag, List<String> scalars, List<Wire.Node> children) {
        return Wire.node(tag, scalars, children);
    }
    static String digest(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    static Wire.Node root(List<String> ids) throws Exception {
        String zero = "0".repeat(64);
        Wire.Node metadata = n("metadata", List.of("review", "false", "review", "review", "review", "review", "TEST_ONLY", zero, zero, "review", "review", zero, zero, "review", zero, zero, "review", digest("review".getBytes(StandardCharsets.UTF_8))), List.of());
        Wire.Node theory = n("theory", List.of(Bundle.THEORY_ID, Bundle.RULE_SET, Bundle.VOCABULARY_POLICY), List.of(Wire.leaf("axioms")));
        Wire.Node evidence = n("semantic-evidence", Collections.nCopies(8, "review"), List.of(Wire.leaf("law-certificates"), Wire.leaf("flat-constructions"), Wire.leaf("container-constructions"), Wire.leaf("binder-occurrences"), Wire.leaf("exact-types"), Wire.leaf("call-occurrences")));
        Wire.Node vocabulary = n("vocabulary", List.of(Bundle.VOCABULARY_POLICY), List.of(Wire.leaf("schemas"), Wire.leaf("operators"), Wire.leaf("binders"), evidence));
        List<Wire.Node> children = new ArrayList<>(List.of(metadata, n("manifest", List.of(Wire.contentId(theory), Wire.contentId(vocabulary)), List.of(theory, vocabulary))));
        for (String section : SECTIONS) children.add(n(section, List.of(), section.equals("witnesses") ? ids.stream().map(id -> Wire.leaf("witness", id)).toList() : List.of()));
        return n("acgncert-bundle", List.of(Bundle.SCHEMA_VERSION), children);
    }
    static String bytes(byte[] xs) {
        List<String> out = new ArrayList<>();
        for (byte b : xs) out.add(Integer.toString(b & 255));
        return String.join(",", out);
    }
    static byte[] envelope(byte[] text) throws Exception {
        var payload = new ByteArrayOutputStream(); var p = new DataOutputStream(payload);
        p.writeInt(1); p.writeByte('t'); p.writeInt(1); p.writeInt(text.length); p.write(text); p.writeInt(0); p.flush();
        byte[] raw = payload.toByteArray();
        var all = new ByteArrayOutputStream(); var a = new DataOutputStream(all);
        a.writeBytes("ACGNCERT"); a.writeShort(1); a.writeLong(raw.length); a.write(raw);
        a.write(MessageDigest.getInstance("SHA-256").digest(raw)); a.flush();
        return all.toByteArray();
    }
    public static void main(String[] args) throws Exception {
        int[] cps = {0, 1, 127, 128, 255, 2047, 2048, 4095, 55295, 57344, 65535, 65536, 65537, 1114111};
        List<String> values = new ArrayList<>();
        for (int cp : cps) values.add(new String(Character.toChars(cp)));
        values.addAll(List.of("", "prefix", "prefix-more", "same", "a\u0000b", "\ud800\udc00\ue000", "\ue000\ud800\udc00", "e\u0301"));
        Bundle.parse(Codec.decode(Codec.encode(root(List.of("baseline"))), Limits.defaults()));
        for (int i = 0; i < values.size(); i++) {
            String s = values.get(i);
            System.out.println("units\t" + i + "\t" + bytes(s.getBytes(StandardCharsets.UTF_8)) + "\t" + s.chars().mapToObj(Integer::toString).reduce((a,b) -> a + "," + b).orElse(""));
            for (int j = 0; j < values.size(); j++) {
                String t = values.get(j), outcome = "ACCEPT";
                try { Bundle.parse(Codec.decode(Codec.encode(root(List.of(s, t))), Limits.defaults())); }
                catch (FormatException e) { outcome = e.code().toString(); }
                System.out.println("order\t" + i + "\t" + j + "\t" + (s.compareTo(t) < 0) + "\t" + outcome);
            }
        }
        List<byte[]> texts = new ArrayList<>();
        for (int b = 0; b < 256; b++) texts.add(new byte[]{(byte)b});
        for (String hex : List.of("", "c080", "c180", "c280", "dfbf", "e08080", "e09f80", "e0a080", "ed9fbf", "eda080", "edbfbf", "ee8080", "efbfbf", "f0808080", "f08fbfbf", "f0908080", "f48fbfbf", "f4908080", "f5808080", "f09080", "c2", "e0a0", "00c280", "c28000", "e09f00", "c2ff")) texts.add(HexFormat.of().parseHex(hex));
        for (int i = 0; i < texts.size(); i++) {
            byte[] text = texts.get(i); String result = "ACCEPT";
            try { Codec.decode(envelope(text), Limits.defaults()); }
            catch (FormatException e) { result = e.code().toString(); }
            System.out.println("utf8\t" + i + "\t" + bytes(text) + "\t" + result);
        }
    }
}
