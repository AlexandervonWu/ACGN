import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base / 'source'
sys.path.insert(0, str(source / 'scripts'))
import fifth_law_record_replays as law
import fifth_wire_tables_replays as wire

results = []
for area, plugin in [('wire', wire), ('law', law)]:
    for label, file, old, new, extractor in plugin.source_mutations():
        path = source / file
        raw = path.read_bytes()
        original = raw.decode('utf8')
        assert original.count(old) == 1, label
        log_path = base / ('source-' + area + '-' + label + '.log')
        try:
            path.write_text(original.replace(old, new))
            start = time.monotonic()
            with log_path.open('w') as log:
                proc = subprocess.run(['java', '-Xmx1g', '-cp', str(base / 'classes'), extractor,
                                       str(source), str(base / 'rejected-source.tsv')], cwd=source,
                                      env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                      stdout=log, stderr=subprocess.STDOUT, timeout=120)
            text = log_path.read_text()
            expected = ('Exception in thread "main" java.lang.IllegalArgumentException: UNMODELED_SOURCE:' +
                        ('wire' if area == 'wire' else 'law-record') + ' shape/binding mismatch')
            assert proc.returncode == 1 and expected in text and 'compiler diagnostics' not in text, text
            results.append(dict(area=area, label=label, exitCode=1,
                                reason='compiler-resolved shape/binding mismatch',
                                seconds=round(time.monotonic()-start, 3),
                                logSha256=hashlib.sha256(log_path.read_bytes()).hexdigest()))
            (base / 'source-control-results.json').write_text(json.dumps(results, indent=2) + '\n')
            print(area, label, 'PASS', flush=True)
        finally:
            path.write_bytes(raw)
        assert path.read_bytes() == raw
print('DONE', len(results), flush=True)
