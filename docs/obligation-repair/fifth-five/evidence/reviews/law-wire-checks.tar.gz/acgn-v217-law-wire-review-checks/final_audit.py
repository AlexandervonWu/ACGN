import collections
import hashlib
import json
from pathlib import Path
import re
import sys

base = Path(__file__).resolve().parent
root = Path('/home/augustus/ACGN')
sys.path.insert(0, str(base / 'source/scripts'))
from run_fifth_obligation_repairs import check_rejection

rejections = []
for area, pattern, count in [('law', 'law-current-negative-*.log', 60), ('wire', 'wire-negative-*.log', 13)]:
    files = sorted(base.glob(pattern))
    assert len(files) == count, (area, len(files))
    for file in files:
        label = 'review-reject-' + area + '-' + file.stem
        check_rejection(label, file.read_text())
        rejections.append(label)
sources = json.loads((base / 'source-control-results.json').read_text())
assert len(sources) == 30
for row in sources:
    label = 'review-source-reject-' + row['area'] + '-' + row['label']
    check_rejection(label, (base / ('source-' + row['area'] + '-' + row['label'] + '.log')).read_text())
    rejections.append(label)

audit_counts = {}
for name, count in [('LawRecordWire-current-proof', 27), ('CanonicalWireTables-proof', 17),
                    ('law-current-replay', 246), ('wire-replay', 66), ('independent-probe-lean', 1294)]:
    text = (base / (name + '.log')).read_text()
    names = re.findall(r"'([^']+)' (?:does not depend on any axioms|depends on axioms:)", text)
    assert len(names) == len(set(names)) == count, (name, len(names))
    assert 'error:' not in text and 'warning:' not in text, name
    for block in re.findall(r'depends on axioms:\s*\[([^]]*)\]', text, re.S):
        assert set(x.strip() for x in block.split(',')) <= {'propext', 'Classical.choice', 'Quot.sound'}, block
    audit_counts[name] = count

files = [
    'docs/section3-repair-audit/formal/LawRecordWire.lean',
    'docs/section3-repair-audit/formal/CanonicalWireTables.lean',
    'scripts/fifth_law_record_replays.py', 'scripts/fifth_wire_tables_replays.py',
    'src/is/fivefivefive/CanDis/theory/LawRecordWireRegressionTest.java',
    'src/is/fivefivefive/CanDis/theory/CanonicalWireTablesRegressionTest.java',
    'scripts/java/LawRecordWireExtractor.java', 'scripts/java/CanonicalWireTablesExtractor.java',
    'scripts/test_fifth_law_record_replays.py', 'scripts/test_fifth_wire_tables_replays.py',
    'docs/obligation-repair/fifth-five/closure-config.json',
    'docs/obligation-repair/fifth-five/law-record-notes.md',
    'docs/obligation-repair/fifth-five/wire-tables-notes.md',
]
hashes = {file: hashlib.sha256((root / file).read_bytes()).hexdigest() for file in files}
compiled = json.loads((base / 'input-hashes.json').read_text())
overlays = {
    'docs/section3-repair-audit/formal/LawRecordWire.lean': base / 'formal/LawRecordWire-current.lean',
    'scripts/fifth_law_record_replays.py': base / 'fifth_law_record_replays-current.py',
    'scripts/test_fifth_law_record_replays.py': base / 'test_fifth_law_record_replays-current.py',
}
for file in files:
    if file.endswith('-notes.md'): continue
    expected = hashlib.sha256(overlays[file].read_bytes()).hexdigest() if file in overlays else compiled[file]
    assert expected == hashes[file], ('reviewed file changed', file, expected, hashes[file])

result = dict(kind='bounded-adversarial-review-not-package-closure', status='PASS',
              scopedDefects=[], audits=audit_counts, strictRejections=len(rejections),
              javaObservations={'law': 152, 'wire': 66}, javaChecks={'law':360, 'wire':34},
              sourceObjects={'law':10, 'wire':4}, unitTests={'law':18, 'wire':14},
              reviewedFiles=hashes,
              boundedNote='Only the named scopes and revisions; no universal Java/parser or publication authority claim.')
(base / 'review-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k != 'reviewedFiles'}, indent=2))
