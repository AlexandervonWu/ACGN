import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
SNAP = OUT / 'source'
formal = OUT / 'formal'
LEAN = Path('/tmp/acgn-v215-cold-elan424/toolchains/leanprover--lean4---v4.33.0/bin/lean')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', LEAN_PATH=str(formal))
records = []

def run(label, argv, cwd=SNAP, expected=0):
    start = time.monotonic()
    with (OUT / (label + '.log')).open('w') as log:
        proc = subprocess.run(list(map(str, argv)), cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    rec = dict(label=label, argv=list(map(str, argv)), code=proc.returncode, seconds=round(time.monotonic()-start, 3))
    records.append(rec)
    (OUT / 'remaining-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(rec['label'], rec['code'], rec['seconds'], flush=True)
    if proc.returncode != expected: raise RuntimeError(rec)

sys.path.insert(0, str(SNAP / 'scripts'))
import fifth_law_record_replays as law
import fifth_wire_tables_replays as wire
for area, plugin in [('wire', wire), ('law', law)]:
    for name, text, count in plugin.generate(OUT, formal):
        (formal / name).write_text(text)
        run(area + '-replay', [LEAN, '--root=' + str(formal), formal / name], formal)
        print(area, 'replay-theorems', count, flush=True)
    for index, (label, name, text) in enumerate(plugin.negatives(OUT, formal)):
        (formal / name).write_text(text)
        command = area + '-negative-' + str(index)
        run(command, [LEAN, '--root=' + str(formal), formal / name], formal, expected=1)
        log = (OUT / (command + '.log')).read_text()
        if not ('decide' in log and ('false' in log or 'False' in log)):
            raise RuntimeError('Non-semantic negative failure: ' + command)
    tests = SNAP / ('scripts/test_fifth_' + ('wire_tables' if area == 'wire' else 'law_record') + '_replays.py')
    if tests.is_file():
        run(area + '-plugin-tests', [sys.executable, '-B', tests])
    else:
        print(area, 'unit-test file absent at snapshot; authors still finalizing', flush=True)
print('DONE', flush=True)
