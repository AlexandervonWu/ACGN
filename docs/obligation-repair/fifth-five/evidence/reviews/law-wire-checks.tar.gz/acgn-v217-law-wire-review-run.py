import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/augustus/ACGN')
OUT = Path('/tmp/acgn-v217-law-wire-review-checks')
SNAP = OUT / 'source'
LEAN = Path('/tmp/acgn-v215-cold-elan424/toolchains/leanprover--lean4---v4.33.0/bin/lean')
OUT.mkdir(exist_ok=False)
SNAP.mkdir()
for directory in ('src', 'certificate-verifier', 'scripts', 'lib'):
    shutil.copytree(ROOT / directory, SNAP / directory, ignore=shutil.ignore_patterns('__pycache__', '*.class'))
for directory in ('docs/section3-repair-audit/formal', 'docs/obligation-repair/fifth-five'):
    shutil.copytree(ROOT / directory, SNAP / directory, ignore=shutil.ignore_patterns('evidence', '*.olean', '*.ilean'))
shutil.copy2(ROOT / 'lean-toolchain', SNAP / 'lean-toolchain')
manifest = {p.relative_to(SNAP).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(SNAP.rglob('*')) if p.is_file()}
(OUT / 'input-hashes.json').write_text(json.dumps(manifest, indent=2) + '\n')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', LEAN_PATH=str(OUT / 'formal'),
           ELAN_TOOLCHAIN='leanprover/lean4:v4.33.0')
records = []

def run(label, argv, cwd=SNAP, expected=0):
    started = time.monotonic()
    with (OUT / (label + '.log')).open('w') as log:
        proc = subprocess.run(list(map(str, argv)), cwd=cwd, env=env, stdout=log,
                              stderr=subprocess.STDOUT, timeout=900)
    record = dict(label=label, argv=list(map(str, argv)), code=proc.returncode,
                  seconds=round(time.monotonic() - started, 3))
    records.append(record)
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, proc.returncode, record['seconds'], flush=True)
    if proc.returncode != expected:
        raise RuntimeError(record)

run('git-init', ['git', 'init', '-q'])
run('git-add', ['git', 'add', '.'])
run('git-commit', ['git', '-c', 'user.name=Bounded Review Fixture', '-c', 'user.email=fixture@example.invalid',
                   '-c', 'commit.gpgsign=false', 'commit', '-qm', 'TEST_ONLY bounded review snapshot'])
classes = OUT / 'classes'; classes.mkdir()
sources = sorted(str(p) for base in ('src', 'certificate-verifier/src') for p in (SNAP / base).rglob('*.java'))
run('javac', ['javac', '-J-Xmx1g', '--release', '17', '-proc:none', '-encoding', 'UTF-8',
              '-cp', SNAP / 'lib/*', '-d', classes, *sources])
run('extractor-compile', ['javac', '--release', '17', '-proc:none', '-encoding', 'UTF-8', '-d', classes,
                        SNAP / 'scripts/java/LawRecordWireExtractor.java', SNAP / 'scripts/java/CanonicalWireTablesExtractor.java'])
cp = str(classes) + ':' + str(SNAP / 'lib/*')
for area, test, trace, extractor, source_trace in (
        ('law', 'LawRecordWireRegressionTest', 'law-record-wire.tsv', 'LawRecordWireExtractor', 'law-record-wire-source.tsv'),
        ('wire', 'CanonicalWireTablesRegressionTest', 'canonical-wire-tables.tsv', 'CanonicalWireTablesExtractor', 'canonical-wire-tables-source.tsv')):
    run(area + '-regression', ['java', '-Xmx1g', '-cp', cp, 'is.fivefivefive.CanDis.theory.' + test, OUT / trace])
    run(area + '-extractor', ['java', '-Xmx1g', '-cp', cp, extractor, SNAP, OUT / source_trace])
formal = OUT / 'formal'; formal.mkdir()
for name in ('LawRecordWire', 'CanonicalWireTables'):
    shutil.copy2(SNAP / ('docs/section3-repair-audit/formal/' + name + '.lean'), formal)
    run(name + '-proof', [LEAN, '--root=' + str(formal), '-o', formal / (name + '.olean'), formal / (name + '.lean')], formal)
sys.path.insert(0, str(SNAP / 'scripts'))
import fifth_law_record_replays as law
import fifth_wire_tables_replays as wire
for area, plugin in [('law', law), ('wire', wire)]:
    for name, text, count in plugin.generate(OUT, formal):
        (formal / name).write_text(text)
        run(area + '-replay', [LEAN, '--root=' + str(formal), formal / name], formal)
        print(area, 'replay-theorems', count, flush=True)
    selected = plugin.negatives(OUT, formal)
    # Every registered negative is finite; each must be false by kernel decision,
    # never merely malformed or failing to import.
    for index, (label, name, text) in enumerate(selected):
        (formal / name).write_text(text)
        command = area + '-negative-' + str(index)
        run(command, [LEAN, '--root=' + str(formal), formal / name], formal, expected=1)
        log = (OUT / (command + '.log')).read_text()
        if not ('decide' in log and ('false' in log or 'False' in log)):
            raise RuntimeError('Non-semantic negative failure: ' + command)
    print(area, 'negatives', len(selected), flush=True)
run('wire-plugin-tests', [sys.executable, '-B', SNAP / 'scripts/test_fifth_wire_tables_replays.py'])
test = SNAP / 'scripts/test_fifth_law_record_replays.py'
if test.is_file():
    run('law-plugin-tests', [sys.executable, '-B', test])
else:
    print('law plugin tests absent at snapshot; authors finalizing', flush=True)
print('DONE', flush=True)
