#!/usr/bin/env python3
"""Bounded read-only delta audit using the registered strict classifier."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path('/home/augustus/ACGN')
BASE=Path('/tmp/acgn-v217-records-source-checks-final')
OUT=Path('/tmp/acgn-v217-records-source-delta-checks')
ORIGINAL=Path('/tmp/acgn-v217-records-source-review.md')
ORIGINAL_HASH='74436fe6b165cd6088b53d7f72d28809f14fa05adc4d779d509113ff40550349'
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(ORIGINAL)==ORIGINAL_HASH
OUT.mkdir(exist_ok=False)
SNAP=OUT/'snapshot'
shutil.copytree(BASE/'snapshot',SNAP)
for rel in ('scripts/fifth_flat_container_replays.py','scripts/test_fifth_flat_container_replays.py',
            'docs/obligation-repair/fifth-five/flat-container-notes.md'):
    shutil.copyfile(ROOT/rel,SNAP/rel)
for directory in ('src','certificate-verifier/src','docs/section3-repair-audit/formal'):
    for old in (BASE/'snapshot'/directory).rglob('*'):
        if old.is_file():
            assert sha(old)==sha(ROOT/old.relative_to(BASE/'snapshot')), old
for rel in ('scripts/run_fifth_obligation_repairs.py','scripts/fifth_obligation_replays.py',
            'scripts/fifth_source_bindings_replays.py','scripts/test_fifth_source_bindings_replays.py',
            'scripts/java/FlatContainerRecordsExtractor.java','scripts/java/SourceOccurrenceBindingsExtractor.java'):
    assert sha(ROOT/rel)==sha(SNAP/rel), rel

def declarations(path):
    module=ast.parse(path.read_text())
    return {node.name:ast.dump(node,include_attributes=False) for node in module.body
            if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
old_defs=declarations(BASE/'snapshot/scripts/fifth_flat_container_replays.py')
new_defs=declarations(SNAP/'scripts/fifth_flat_container_replays.py')
assert old_defs.keys()==new_defs.keys()
changed_defs=[k for k in old_defs if old_defs[k]!=new_defs[k]]
assert changed_defs==['negatives'],changed_defs

manifest=[]
for directory in ('scripts','docs/section3-repair-audit/formal'):
    for path in sorted((SNAP/directory).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            manifest.append({'path':str(path.relative_to(SNAP)),'sha256':sha(path)})
for name in ('flat-container-records.tsv','flat-container-records-source.tsv',
             'source-occurrence-bindings.tsv','source-occurrence-bindings-source.tsv'):
    shutil.copyfile(BASE/name,OUT/name)
    manifest.append({'path':name,'sha256':sha(OUT/name)})
(OUT/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
sys.path.insert(0,str(SNAP/'scripts'))
sys.dont_write_bytecode=True
from run_fifth_obligation_repairs import check_rejection,load_runner
from run_submission_container_closure import Blocked
registered=load_runner()
old_log=Path('/tmp/acgn-v217-fifth-final/build1-reject-records-records-acceptance.log')
shutil.copyfile(old_log,OUT/'old-integration-rejection.log')
try:
    check_rejection('build1-reject-records-records-acceptance',old_log.read_text())
except Blocked as error:
    (OUT/'old-classifier-result.txt').write_text(str(error)+'\n')
else:
    raise AssertionError('old multiline diagnostic unexpectedly accepted')
env=dict(os.environ,ELAN_TOOLCHAIN='leanprover/lean4:v4.33.0',PYTHONDONTWRITEBYTECODE='1')
env.pop('LEAN_PATH',None)
FORMAL=OUT/'formal'; FORMAL.mkdir()
commands=[]
def run(label,args,cwd=SNAP,extra=None,reject=False):
    result=subprocess.run(list(map(str,args)),cwd=cwd,env={**env,**(extra or {})},
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    logfile=OUT/(label+'.log'); logfile.write_bytes(result.stdout)
    item={'label':label,'exit':result.returncode,'logSha256':sha(logfile)}
    commands.append(item)
    assert result.returncode==(1 if reject else 0), (label,result.returncode)
    if reject:
        check_rejection(label,result.stdout.decode())
        item['strictClassifier']='PASS'
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(label,'PASS',flush=True)
    return logfile

counts=[]
for area,plugin_name,prefix,trace,count in (
    ('records','flat_container','FlatContainerRecords','flat-container-records',7),
    ('source','source_bindings','SourceOccurrenceBindings','source-occurrence-bindings',16)):
    spec=importlib.util.spec_from_file_location('delta_'+area,SNAP/f'scripts/fifth_{plugin_name}_replays.py')
    plugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)
    run(area+'-unit',[sys.executable,'-B',SNAP/f'scripts/test_fifth_{plugin_name}_replays.py'])
    shutil.copyfile(SNAP/f'docs/section3-repair-audit/formal/{prefix}.lean',FORMAL/f'{prefix}.lean')
    log=run(area+'-model',['/tmp/acgn-v215-cold-elan424/bin/lean','-o',prefix+'.olean',prefix+'.lean'],
        cwd=FORMAL,extra={'LEAN_PATH':str(FORMAL)})
    registered.check_proof_log(log,registered.proof_inventory(FORMAL/f'{prefix}.lean'))
    replay_name,text,theorems=plugin.generate(OUT,FORMAL)[0]
    assert text==(BASE/'formal'/replay_name).read_text(), 'positive replay changed'
    (FORMAL/replay_name).write_text(text)
    controls=plugin.negatives(OUT,FORMAL)
    assert len(controls)==count
    for i,(label,name,code) in enumerate(controls):
        folder=OUT/f'{area}-negative-{i}'; folder.mkdir(); (folder/name).write_text(code)
        if area=='records':
            assert 'example :' in code and '#print axioms' not in code
        run('delta-reject-'+area+'-'+label,['/tmp/acgn-v215-cold-elan424/bin/lean',name],
            cwd=folder,extra={'LEAN_PATH':str(FORMAL)},reject=True)
    source_results=[]
    for label,_,_,_,_ in plugin.source_mutations():
        old=BASE/(plugin_name+'-source-'+label+'.log')
        dst=OUT/('prior-source-'+area+'-'+label+'.log'); shutil.copyfile(old,dst)
        check_rejection('delta-source-reject-'+area+'-'+label,dst.read_text())
        source_results.append({'label':label,'strictClassifier':'PASS','sha256':sha(dst)})
    counts.append({'area':area,'freshLeanNegatives':len(controls),'strictReclassifiedSourceLogs':source_results,
                   'unchangedPositiveReplay':replay_name,'theorems':theorems})
assert sha(ORIGINAL)==ORIGINAL_HASH
for rel in ('scripts/fifth_flat_container_replays.py','scripts/test_fifth_flat_container_replays.py',
            'scripts/run_fifth_obligation_repairs.py','scripts/fifth_source_bindings_replays.py'):
    assert sha(ROOT/rel)==sha(SNAP/rel), 'input changed during delta: '+rel
result={'status':'PASS','scope':'bounded negative-emitter and strict diagnostic integration delta',
        'originalReviewPreservedSha256':sha(ORIGINAL),'changedRecordsFunctions':changed_defs,
        'productionAndGeneralProofsByteUnchanged':True,'oldDiagnosticStrictlyRejected':True,
        'areas':counts,'classifierSha256':sha(SNAP/'scripts/run_fifth_obligation_repairs.py'),
        'recordsPluginSha256':sha(SNAP/'scripts/fifth_flat_container_replays.py'),
        'recordsStandaloneSha256':sha(SNAP/'scripts/test_fifth_flat_container_replays.py'),
        'limitations':['No aggregate closure verdict','Prior Java TSVs reused after unchanged-source checks',
                       '24 source logs strictly reclassified, source mutants not reexecuted in this delta']}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS 23 fresh Lean negatives, 24 strict source-log reclassifications',flush=True)
