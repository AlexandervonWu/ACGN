namespace InventoryWitness
mutual
def left : Nat -> Nat
  | 0 => 0
  | n + 1 => right n
def right : Nat -> Nat
  | 0 => 0
  | n + 1 => left n
end
theorem zero : left 0 = 0 := rfl
#print axioms zero
end InventoryWitness
