#!/usr/bin/env python3
"""Read-only repository audit runner; generated evidence stays below /tmp."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/augustus/ACGN')
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else '/tmp/acgn-v217-records-source-checks')
OUT.mkdir(exist_ok=False)
SNAP = OUT / 'snapshot'
SNAP.mkdir()
files = []
for directory in ('src', 'certificate-verifier/src', 'lib', 'scripts',
                  'docs/section3-repair-audit/formal', 'docs/obligation-repair/fifth-five'):
    for path in sorted((ROOT / directory).rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or 'evidence' in path.parts:
            continue
        rel = path.relative_to(ROOT)
        dest = SNAP / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
        files.append({'path': str(rel), 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest()})
shutil.copyfile(ROOT / 'lean-toolchain', SNAP / 'lean-toolchain')
files.append({'path': 'lean-toolchain', 'sha256': hashlib.sha256((SNAP / 'lean-toolchain').read_bytes()).hexdigest()})
(OUT / 'inputs.json').write_text(json.dumps(files, indent=2) + '\n')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           ELAN_TOOLCHAIN=(ROOT/'lean-toolchain').read_text().strip())
for key in ('JAVA_TOOL_OPTIONS', 'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS', 'LEAN_PATH', 'CLASSPATH'):
    env.pop(key, None)
commands = []

def run(label, args, cwd=SNAP, extra=None, reject=False):
    start = time.monotonic()
    r = subprocess.run(list(map(str, args)), cwd=cwd, env={**env, **(extra or {})},
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
    (OUT / (label+'.log')).write_bytes(r.stdout)
    commands.append({'label': label, 'args': list(map(str,args)), 'exit': r.returncode,
                     'seconds': round(time.monotonic()-start,3)})
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(label, 'exit', r.returncode, flush=True)
    if r.returncode != (1 if reject else 0):
        raise RuntimeError(label + ': unexpected exit; see retained log')
    return r.stdout.decode()

run('java-version', ['java','-version'])
run('lean-version', ['/tmp/acgn-v215-cold-elan424/bin/lean','--version'])
CLASSES = OUT/'classes'
CLASSES.mkdir()
sources = sorted(p for d in ('src','certificate-verifier/src') for p in (SNAP/d).rglob('*.java'))
run('javac', ['javac','-J-Xmx1g','--release','17','-proc:none','-encoding','UTF-8',
              '-cp',str(SNAP/'lib/*'),'-d',CLASSES,*sources])
extractors = ['FlatContainerRecords', 'SourceOccurrenceBindings']
run('extractor-compile', ['javac','--release','17','-d',CLASSES,
                         *[SNAP/f'scripts/java/{e}Extractor.java' for e in extractors]])
FORMAL = OUT/'formal'
FORMAL.mkdir()
sys.path.insert(0,str(SNAP/'scripts'))
sys.dont_write_bytecode = True
from run_fifth_obligation_repairs import load_runner
registered = load_runner()
check_proof_log = registered.check_proof_log
proof_inventory = registered.proof_inventory
summaries = []
for area, prefix, trace in [('flat_container','FlatContainerRecords','flat-container-records'),
                           ('source_bindings','SourceOccurrenceBindings','source-occurrence-bindings')]:
    run(area+'-extractor', ['java','-Xmx1g','-cp',CLASSES,prefix+'Extractor',SNAP,OUT/(trace+'-source.tsv')])
    run(area+'-java', ['java','-ea','-Xmx1g','-cp',str(CLASSES)+os.pathsep+str(SNAP/'lib/*'),
                      'is.fivefivefive.CanDis.theory.'+prefix+'RegressionTest',OUT/(trace+'.tsv')],cwd=ROOT)
    run(area+'-unit', [sys.executable,'-B',SNAP/f'scripts/test_fifth_{area}_replays.py'])
    spec=importlib.util.spec_from_file_location('review_'+area,SNAP/f'scripts/fifth_{area}_replays.py')
    plugin=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plugin)
    shutil.copyfile(SNAP/f'docs/section3-repair-audit/formal/{prefix}.lean',FORMAL/f'{prefix}.lean')
    generated=plugin.generate(OUT,FORMAL)
    for name,text,count in generated:
        (FORMAL/name).write_text(text)
    for name in (prefix+'.lean',prefix+'Replay.lean'):
        run(area+'-'+Path(name).stem, ['/tmp/acgn-v215-cold-elan424/bin/lean','-o',Path(name).with_suffix('.olean'),name],
            cwd=FORMAL,extra={'LEAN_PATH':str(FORMAL)})
        check_proof_log(OUT/(area+'-'+Path(name).stem+'.log'), proof_inventory(FORMAL/name))
    negatives=plugin.negatives(OUT,FORMAL)
    for i,(label,name,text) in enumerate(negatives):
        folder=OUT/f'{area}-negative-{i}'
        folder.mkdir()
        (folder/name).write_text(text)
        log=run(area+'-negative-'+label, ['/tmp/acgn-v215-cold-elan424/bin/lean',name],
                cwd=folder,extra={'LEAN_PATH':str(FORMAL)},reject=True)
        if 'Tactic `decide` proved that the proposition' not in log:
            raise RuntimeError('not a kernel counterexample: '+label)
    for label,path,old,new,extractor in plugin.source_mutations():
        target=SNAP/path
        original=target.read_text()
        assert original.count(old)==1
        stale=OUT/(area+'-'+label+'.tsv')
        stale.write_text('stale\n')
        try:
            target.write_text(original.replace(old,new))
            log=run(area+'-source-'+label,['java','-Xmx1g','-cp',CLASSES,extractor,SNAP,stale],reject=True)
            if 'UNMODELED_SOURCE:' not in log or 'JAVAC_RESOLUTION_FAILURE' in log or 'compiler diagnostics' in log or stale.exists():
                raise RuntimeError('source control not genuine: '+label)
        finally:
            target.write_text(original)
    summaries.append({'area':area,'replayTheorems':generated[0][2],
                      'modelTheorems':len(proof_inventory(FORMAL/(prefix+'.lean'))),
                      'negativeControls':len(negatives),'sourceControls':len(plugin.source_mutations())})
changed=[]
for item in files:
    original=ROOT/item['path']
    if not original.exists() or hashlib.sha256(original.read_bytes()).hexdigest()!=item['sha256']:
        changed.append(item['path'])
(OUT/'result.json').write_text(json.dumps({'boundedTests':'PASS','areas':summaries,
                  'workspaceChangesSinceSnapshot':changed,
                  'boundary':'Independent bounded review, not the registered two-build closure'},indent=2)+'\n')
print(json.dumps(summaries),flush=True)
print('changed inputs:',changed,flush=True)
