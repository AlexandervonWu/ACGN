import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import is.fivefivefive.CanDis.theory.*;
import is.fivefivefive.CanDis.core.*;
import is.fivefivefive.CanDis.ir.IRAgent;
import is.fivefivefive.ACGN.util.GlobalVariables;
import is.fivefivefive.ACGN.visitor.MASGVisitor;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.parser.CompUtil;
import parser.ast.nodes.ModelUnit;

public final class IndependentBoundaryProbe {
    static int checks, traceCases, sourceCases, bindings;
    static final List<String> lines = new ArrayList<>();
    static void check(boolean condition, String label) {
        checks++;
        if (!condition) throw new AssertionError(label);
    }
    static void words(List<Integer> word, List<OnePort> atoms, TypedSlotContext context) {
        for (int carrier=0; carrier<3; carrier++) {
            var element = new OnePortSchema(GraphType.BOOL);
            PortSchema schema = carrier==0 ? new SeqPortSchema(ArityPolicy.atLeast(0),element)
                : carrier==1 ? new BagPortSchema(ArityPolicy.atLeast(0),element)
                : new SetPortSchema(ArityPolicy.atLeast(0),element);
            List<OnePort> input = word.stream().map(atoms::get).toList();
            PortValue target = carrier==0 ? new SeqPort((SeqPortSchema)schema,context,input)
                : carrier==1 ? new BagPort((BagPortSchema)schema,context,input)
                : new SetPort((SetPortSchema)schema,context,input);
            var trace = ContainerApplicationTrace.of(schema,context,input,target);
            List<Integer> expected = new ArrayList<>();
            List<List<Integer>> fibers = new ArrayList<>();
            if (carrier==0) {
                for(int i=0;i<word.size();i++) { expected.add(word.get(i)); fibers.add(List.of(i)); }
            } else {
                for(int value=0;value<3;value++) {
                    List<Integer> group = new ArrayList<>();
                    for(int i=0;i<word.size();i++) if(word.get(i)==value) group.add(i);
                    if(carrier==1) for(int i:group) { expected.add(value); fibers.add(List.of(i)); }
                    else if(!group.isEmpty()) { expected.add(value); fibers.add(group); }
                }
            }
            check(trace.inputOccurrences().equals(input),"raw inputs");
            check(trace.outputOccurrences().stream().map(atoms::indexOf).toList().equals(expected),"output sequence "+word);
            check(trace.outputFibers().equals(fibers),"fibers "+carrier+":"+word);
            int[] covered = new int[word.size()];
            for(int j=0;j<fibers.size();j++) for(int i:fibers.get(j)) {
                check(word.get(i).equals(expected.get(j)),"fiber target identity"); covered[i]++;
            }
            for(int c:covered) check(c==1,"exact partition");
            traceCases++;
        }
        if(word.size()<5) for(int value=0;value<3;value++) {
            List<Integer> next = new ArrayList<>(word); next.add(value); words(next,atoms,context);
        }
    }
    static void index(EGraphNode n,String path,int phase,Map<String,EGraphNode> source,
                      IdentityHashMap<EGraphNode,Integer> repair) {
        if(n==null) return;
        if(source!=null) check(source.put(path,n)==null,"unique path");
        if(repair!=null) {
            Integer old=repair.put(n,phase);
            check(old==null || old==phase,"repair phase ownership");
        }
        int i=0;
        for(EGraphNode child:n.getChildren()) index(child,path+"/child/"+(i++),phase,source,repair);
    }
    static void parsed(String body) throws Exception {
        var module = CompUtil.parseEverything_fromString(A4Reporter.NOP,
            "sig A { r: set A } pred p { "+body+" }");
        MASGVisitor visitor = new MASGVisitor(new GlobalVariables(),module);
        visitor.visit(new ModelUnit(null,module),null);
        IRAgent ir = new IRAgent(visitor.getForest().get(visitor.getForestId("p")),
            SemanticProfile.alloyOverflowForbidding());
        ir.computeNormalForm();
        var forms=ir.normalForms();
        var result=TheoryAlloyAdapter.adapt(forms,SemanticProfile.alloyOverflowForbidding());
        result.requireRepairProjectionSources(forms);
        Map<String,EGraphNode> source=new HashMap<>();
        IdentityHashMap<EGraphNode,Integer> repair=new IdentityHashMap<>();
        for(int phase=0;phase<forms.size();phase++) {
            index(forms.get(phase).getCertificationMatrixEGraph(),"phase/"+phase+"/matrix",phase,source,null);
            index(forms.get(phase).getMatrixEGraph(),"phase/"+phase+"/matrix",phase,null,repair);
        }
        for(var e:result.dependentChainSourceBindings().entrySet()) {
            var node=e.getKey(); var binding=e.getValue();
            binding.requireMatches(node);
            var retained=source.get(binding.sourceOccurrencePath());
            check(retained!=null,"actual retained path");
            check(binding.sourceOccurrencePath().startsWith("phase/"+repair.get(node)+"/matrix"),"same phase");
            check(retained.getSourceOccurrenceLineage()==node.getSourceOccurrenceLineage(),"preserved lineage");
            var commitment=binding.sourceOccurrenceCommitment();
            check(commitment.equals(binding.certificate().sourceOccurrenceCommitment()),"certificate commitment");
            check(commitment.children().get(0).children().get(0).equals(binding.certificate().source().structuralKey()),"typed source");
            check(commitment.children().get(1).scalars().get(0).equals(retained.dependentChainSourceContentCommitment()),"retained content");
            check(retained.dependentChainTransferContentCommitment().equals(node.dependentChainTransferContentCommitment()),"transfer content");
            bindings++;
        }
        check(!result.dependentChainSourceBindings().isEmpty(),"nonvacuous parsed binding");
        sourceCases++;
        lines.add("parsed PASS phases="+forms.size()+" bindings="+result.dependentChainSourceBindings().size()+" body="+body);
    }
    public static void main(String[] args) throws Exception {
        var slots=List.of(TypedSlot.source(GraphType.BOOL,100),TypedSlot.source(GraphType.BOOL,101),TypedSlot.source(GraphType.BOOL,102));
        var context=TypedSlotContext.of(slots);
        var atoms=slots.stream().map(s->OnePort.slot(context,s)).sorted(Comparator.comparing(OnePort::structuralKey)).toList();
        words(List.of(),atoms,context);
        check(traceCases==1092,"fixed trace census");
        for(String body:List.of("some (r.r)","some ((r+r).r)","some (r.(r+r))",
            "some ((r+r).(r+r))","some (r.r) and after some (r.r)",
            "once some (r.r) implies always some (r.r)",
            "all x:A | once some (x.r) implies always some (x.r)",
            "all x:A | some (x.r) iff after some (x.r)",
            "some ((r.r).r)","some (r.(r.r))","some (A->A)","some ((A+A)->A)",
            "some ((r.r)->A)","some ((A->A).r)")) parsed(body);
        check(sourceCases==14,"fixed source census");
        lines.add("PASS checks="+checks+" traceCases="+traceCases+" sourceCases="+sourceCases+" bindings="+bindings);
        Files.write(Path.of(args[0]),lines,StandardCharsets.UTF_8);
        for(String line:lines) System.out.println(line);
    }
}
