namespace V217HarnessReview
mutual
  def left : Nat := 0
  def right : Nat := 1
end
theorem valid : left = 0 := by rfl
#print axioms valid
end V217HarnessReview
