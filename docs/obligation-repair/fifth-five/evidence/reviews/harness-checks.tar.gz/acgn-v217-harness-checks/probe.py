"""Finite harness boundary probes; no area evidence or closure discharge."""

import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path("/home/augustus/ACGN")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import run_fifth_obligation_repairs as profile

runner = profile.load_runner()
FILES = [
    "scripts/run_fifth_obligation_repairs.py",
    "scripts/fifth_obligation_replays.py",
    "scripts/test_fifth_obligation_repairs.py",
    str(profile.CONFIG),
    "docs/obligation-repair/fifth-five/harness-notes.md",
]
REFERENCES = [
    "scripts/run_fourth_obligation_repairs.py",
    "scripts/fourth_obligation_replays.py",
    "scripts/run_next_obligation_repairs.py",
    "scripts/third_obligation_replays.py",
    "docs/obligation-repair/fourth-five/closure-config.json",
]


def hashes(paths):
    return {p: runner.digest(ROOT / p) for p in paths}


before = hashes(FILES)
reference_before = hashes(REFERENCES)
output = Path(tempfile.mkdtemp(prefix="run-", dir=HERE))
config = runner.read_config(ROOT / profile.CONFIG)
checks = []
report = {
    "closureId": "REVIEW-ONLY-NOT-A-CLOSURE",
    "inputRootHash": hashlib.sha256(runner.canonical_bytes(before)).hexdigest(),
    "verifierSetHash": hashlib.sha256(runner.canonical_bytes(reference_before)).hexdigest(),
    "environment": {"python": sys.version},
    "commands": [],
}
environment = dict(os.environ, LC_ALL="C", TZ="UTC", PYTHONDONTWRITEBYTECODE="1")
for key in ("LEAN_PATH", "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH"):
    environment.pop(key, None)
commands = runner.Commands(output, report, environment, 120)


def check(label, function, expected="PASS"):
    try:
        function()
        actual, error = "PASS", None
    except runner.Blocked as exc:
        actual, error = "BLOCKED", str(exc)
    except OSError as exc:
        actual, error = "INFRASTRUCTURE_FAILURE", str(exc)
    checks.append({"id": label, "expected": expected, "observed": actual, "error": error})
    assert actual == expected, checks[-1]


def changed_config(label, edit):
    value = copy.deepcopy(config)
    edit(value)
    check(label, lambda: runner.validate_config(value), "BLOCKED")


check("unchanged-config", lambda: runner.validate_config(config))
for index, phase in enumerate(config["phases"]):
    for field, replacement in (
        ("id", "FOREIGN"), ("parent", "P1-19"), ("claimSha256", "0" * 64),
        ("scope", "Universal implementation correctness"), ("proof", "Foreign.lean"),
        ("replays", ["ForeignReplay.lean"]), ("tests", []),
        ("passCondition", {"type": "all", "checks": []}), ("blockConditions", []),
    ):
        changed_config(phase["id"] + "-" + field,
                       lambda c, i=index, k=field, v=replacement: c["phases"][i].update({k: v}))
for index, area in enumerate(config["extractors"]):
    for field, replacement in (("source", "scripts/java/Foreign.java"),
                               ("class", "ForeignExtractor"), ("output", "foreign.tsv")):
        changed_config("extractor-" + area["id"] + "-" + field,
                       lambda c, i=index, k=field, v=replacement: c["extractors"][i].update({k: v}))
for relative in sorted(profile.REQUIRED_INPUTS):
    changed_config("omit-" + relative, lambda c, p=relative: c["inputs"].remove(p))
for label, edit in (
    ("one-build", lambda c: c.update(requiredCleanBuilds=1)),
    ("foreign-plugin", lambda c: c.update(replayPlugin="scripts/next_obligation_replays.py")),
    ("omit-extractor", lambda c: c["extractors"].pop()),
    ("missing-proof-dependencies", lambda c: c.pop("proofDependencies")),
):
    changed_config(label, edit)

unit_log = commands.run("driver-tests", [sys.executable, "-B", ROOT / "scripts/test_fifth_obligation_repairs.py", "-v"], ROOT)
assert "Ran 17 tests" in unit_log.read_text() and "\nOK\n" in unit_log.read_text()

lean = Path.home() / ".elan/toolchains/leanprover--lean4---v4.33.0/bin/lean"
assert lean.is_file(), "Offline Lean toolchain unavailable"
commands.run("lean-version", [lean, "--version"], output)
commands.run("java-version", ["java", "-version"], output)
commands.run("javac-version", ["javac", "-version"], output)
for filename, label, expected in (
    ("FalseControl.lean", "build1-reject-source-false", "PASS"),
    ("MixedControl.lean", "build1-reject-source-mixed", "BLOCKED"),
    ("AcceptedControl.lean", "build1-reject-law-accepted", "BLOCKED"),
):
    check(label, lambda f=filename, l=label: commands.run(l, [lean, HERE / f], output, reject=True), expected)
    assert report["commands"][-1]["status"] == expected

names = runner.proof_inventory(HERE / "MutualAudit.lean")
assert names == ["V217HarnessReview.valid"]
log = commands.run("mutual-audit", [lean, "-o", output / "MutualAudit.olean", "MutualAudit.lean"], HERE)
check("qualified-mutual-audit", lambda: runner.check_proof_log(log, names))
check("misbound-axiom-audit", lambda: runner.check_proof_log(log, ["Foreign.valid"]), "BLOCKED")

classes = output / "extractor"
classes.mkdir()
commands.run("review-extractor-compile", ["javac", "--release", "17", "-proc:none", "-d", classes,
                                         HERE / "ReviewExtractor.java"], output)
snapshot = output / "snapshot"
source = snapshot / "src/Example.java"
source.parent.mkdir(parents=True)
source.write_text("// ORIGINAL\n", encoding="utf-8")
manifest = {"src/Example.java": runner.digest(source)}
check("original-snapshot", lambda: runner.check_snapshot(snapshot, manifest))
check("source-positive-extraction", lambda: commands.run("source-positive-extraction",
      ["java", "-cp", classes, "ReviewExtractor", snapshot, output / "observed.tsv"], output))
spec = ("source-review", "src/Example.java", "ORIGINAL", "MUTATED", "ReviewExtractor")
runner.mutation_spec(spec, {"ReviewExtractor"})
with runner.mutated_source(snapshot, spec, manifest):
    check("changed-snapshot", lambda: runner.check_snapshot(snapshot, manifest), "BLOCKED")
    check("build1-source-reject-source-review", lambda: commands.run("build1-source-reject-source-review",
          ["java", "-cp", classes, "ReviewExtractor", snapshot, output / "rejected.tsv"], output, reject=True))
check("restored-snapshot", lambda: runner.check_snapshot(snapshot, manifest))
try:
    with runner.mutated_source(snapshot, spec, manifest):
        raise runner.Blocked("REVIEW_CONTROL: deliberate body failure")
except runner.Blocked:
    pass
check("restored-after-failure", lambda: runner.check_snapshot(snapshot, manifest))
check("foreign-extractor-binding", lambda: runner.mutation_spec(spec, {"LawRecordWireExtractor"}), "BLOCKED")

trace = output / "exact.tsv"
trace.write_text("id\tvalue\nfirst\ttrue\n", encoding="utf-8")
check("missing-fixed-row", lambda: runner.read_tsv(trace, ["id", "value"], ["id"],
      [("first",), ("second",)]), "BLOCKED")
check("foreign-replay-mapping", lambda: runner.replay_specs(
      [("Foreign.lean", "example : True := by trivial", 1)], ["LawRecordWireReplay.lean"]), "BLOCKED")

assert hashes(FILES) == before
assert hashes(REFERENCES) == reference_before
for record in report["commands"]:
    assert runner.digest(output / record["log"]) == record["sha256"]
result = {
    "verdict": "PASS/no bounded counterexample in these checks",
    "kind": "bounded-harness-review-not-a-closure",
    "affectedClaimIds": [p["id"] for p in config["phases"]],
    "possibleClaimTransition": "PASS to BLOCK",
    "reviewManifest": before,
    "reviewManifestHash": report["inputRootHash"],
    "referenceManifest": reference_before,
    "probeHash": runner.digest(Path(__file__)),
    "fixtureHashes": {p.name: runner.digest(p) for p in HERE.iterdir() if p.suffix in (".lean", ".java")},
    "checks": checks,
    "commands": report["commands"],
    "existingUnitTests": {"ran": 17, "status": "PASS"},
    "reviewedFilesUnchanged": True,
    "referenceFilesUnchanged": True,
    "claimsDischarged": 0,
    "fullCleanBuildsExecuted": 0,
    "interpretation": "Finite fixture checks under Python, Lean, JDK, hashes, OS and hardware trust. Not universal correctness or target evidence verification.",
}
runner.write_json(output / "review-checks.json", result)
print(json.dumps({"result": str(output / "review-checks.json"), "checks": len(checks),
                  "commands": len(report["commands"]), "unitTests": 17, "verdict": result["verdict"]}))
