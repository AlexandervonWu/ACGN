example : False := by decide
example : True := by unregistered_review_tactic
