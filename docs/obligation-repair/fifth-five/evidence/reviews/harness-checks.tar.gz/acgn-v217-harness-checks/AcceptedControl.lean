example : True := by trivial
