import java.nio.file.Files;
import java.nio.file.Path;

public final class ReviewExtractor {
    public static void main(String[] args) throws Exception {
        String text = Files.readString(Path.of(args[0], "src/Example.java"));
        if (!text.contains("ORIGINAL")) {
            throw new IllegalArgumentException("UNMODELED_SOURCE: review fixture");
        }
        Files.writeString(Path.of(args[1]), "site\tshape\nfixture\toriginal\n");
    }
}
