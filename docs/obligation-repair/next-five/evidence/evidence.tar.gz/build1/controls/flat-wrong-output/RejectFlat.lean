import FlatTypeSubstitution
open ACGN.NextFive.FlatTypeSubstitution
def sites : SubstitutionSites := ⟨"typeArguments", "typeArguments"⟩
theorem same_sites : sites.elementField = sites.resultField := by decide
theorem source_type_preservation {T U : Type} (env : String -> T -> U)
    (s : Schema T) (r : T) (h : element? s = some (.one r)) :
    element? (substitute (env sites.elementField) s) =
      some (.one (env sites.resultField r)) :=
  extracted_shared_substitution sites same_sites env s r h
#print axioms same_sites
#print axioms source_type_preservation
theorem flat0 : replay (Observation.mk "1[-;]" "different-exact-type" "1[-;]") = true := by decide
#print axioms flat0
