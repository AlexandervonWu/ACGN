import DependentChainSequence
open ACGN.Section3.DependentChainSequence
def tree0 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 0))
def target0 : Target Nat := ⟨.seq, [0, 0]⟩
theorem chain0 : accepts tree0 target0 = true ∧
    sourceLeaves tree0 = [0, 0] ∧
    target0.elements.length = 2 ∧
    [target0.elements.count 0, target0.elements.count 1,
      target0.elements.count 2] = [2, 0, 0] := by decide
#print axioms chain0
def tree1 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def target1 : Target Nat := ⟨.seq, [1, 0]⟩
theorem chain1 : accepts tree1 target1 = true ∧
    sourceLeaves tree1 = [0, 1] ∧
    target1.elements.length = 2 ∧
    [target1.elements.count 0, target1.elements.count 1,
      target1.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1
