import DependentChainSequence
open ACGN.Section3.DependentChainSequence
def tree0 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 0))
def target0 : Target Nat := ⟨.bag, [0, 0]⟩
theorem chain0 : accepts tree0 target0 = true ∧
    sourceLeaves tree0 = [0, 0] ∧
    target0.elements.length = 2 ∧
    [target0.elements.count 0, target0.elements.count 1,
      target0.elements.count 2] = [2, 0, 0] := by decide
#print axioms chain0
