import OrderedCallValidation
open ACGN.NextFive.OrderedCallValidation
theorem control0 : ([0, 0, 0] : List Nat) = [0, 0, 0] := by decide
#print axioms control0
theorem control1 : ([1, 1, 1] : List Nat) = [1, 1, 1] := by decide
#print axioms control1
theorem control2 : ([2, 0, 1] : List Nat) = [2, 0, 1] := by decide
#print axioms control2
def call0 : Observation := Observation.mk (Capture.mk 11 1 7 0) [(Edge.mk 11 1 1 (.callee 7)), (Edge.mk 11 1 2 .terminator)] [] [] []
theorem call_replay0 : checkObservation call0 = true := by decide
#print axioms call_replay0
def call1 : Observation := Observation.mk (Capture.mk 13 1 0 0) [(Edge.mk 13 1 1 (.callee 0)), (Edge.mk 13 1 2 .terminator)] [] [] []
theorem call_replay1 : checkObservation call1 = true := by decide
#print axioms call_replay1
def call2 : Observation := Observation.mk (Capture.mk 16 1 7 0) [(Edge.mk 16 1 1 (.callee 7)), (Edge.mk 16 1 2 .terminator)] [] [] []
theorem call_replay2 : checkObservation call2 = true := by decide
#print axioms call_replay2
def call3 : Observation := Observation.mk (Capture.mk 18 1 0 0) [(Edge.mk 18 1 1 (.callee 0)), (Edge.mk 18 1 2 .terminator)] [] [] []
theorem call_replay3 : checkObservation call3 = true := by decide
#print axioms call_replay3
def call4 : Observation := Observation.mk (Capture.mk 20 1 7 0) [(Edge.mk 20 1 1 (.callee 7)), (Edge.mk 20 1 2 .terminator)] [] [] []
theorem call_replay4 : checkObservation call4 = true := by decide
#print axioms call_replay4
def call5 : Observation := Observation.mk (Capture.mk 22 1 0 0) [(Edge.mk 22 1 1 (.callee 0)), (Edge.mk 22 1 2 .terminator)] [] [] []
theorem call_replay5 : checkObservation call5 = true := by decide
#print axioms call_replay5
def call6 : Observation := Observation.mk (Capture.mk 24 1 7 0) [(Edge.mk 24 1 1 (.callee 7)), (Edge.mk 24 1 2 .terminator)] [] [] []
theorem call_replay6 : checkObservation call6 = true := by decide
#print axioms call_replay6
def call7 : Observation := Observation.mk (Capture.mk 26 1 0 0) [(Edge.mk 26 1 1 (.callee 0)), (Edge.mk 26 1 2 .terminator)] [] [] []
theorem call_replay7 : checkObservation call7 = true := by decide
#print axioms call_replay7
def call8 : Observation := Observation.mk (Capture.mk 13 1 8 1) [(Edge.mk 13 1 1 (.callee 8)), (Edge.mk 13 1 2 (.argument 1)), (Edge.mk 13 1 3 .terminator)] [1] [1] [1]
theorem call_replay8 : checkObservation call8 = true := by decide
#print axioms call_replay8
def call9 : Observation := Observation.mk (Capture.mk 16 1 1 1) [(Edge.mk 16 1 1 (.callee 1)), (Edge.mk 16 1 2 (.argument 1)), (Edge.mk 16 1 3 .terminator)] [1] [1] [1]
theorem call_replay9 : checkObservation call9 = true := by decide
#print axioms call_replay9
def call10 : Observation := Observation.mk (Capture.mk 19 1 8 1) [(Edge.mk 19 1 1 (.callee 8)), (Edge.mk 19 1 2 (.argument 1)), (Edge.mk 19 1 3 .terminator)] [1] [1] [1]
theorem call_replay10 : checkObservation call10 = true := by decide
#print axioms call_replay10
def call11 : Observation := Observation.mk (Capture.mk 21 1 1 1) [(Edge.mk 21 1 1 (.callee 1)), (Edge.mk 21 1 2 (.argument 1)), (Edge.mk 21 1 3 .terminator)] [1] [1] [1]
theorem call_replay11 : checkObservation call11 = true := by decide
#print axioms call_replay11
def call12 : Observation := Observation.mk (Capture.mk 23 1 8 1) [(Edge.mk 23 1 1 (.callee 8)), (Edge.mk 23 1 2 (.argument 2)), (Edge.mk 23 1 3 .terminator)] [2] [2] [2]
theorem call_replay12 : checkObservation call12 = true := by decide
#print axioms call_replay12
def call13 : Observation := Observation.mk (Capture.mk 26 1 1 1) [(Edge.mk 26 1 1 (.callee 1)), (Edge.mk 26 1 2 (.argument 2)), (Edge.mk 26 1 3 .terminator)] [2] [2] [2]
theorem call_replay13 : checkObservation call13 = true := by decide
#print axioms call_replay13
def call14 : Observation := Observation.mk (Capture.mk 28 1 8 1) [(Edge.mk 28 1 1 (.callee 8)), (Edge.mk 28 1 2 (.argument 1)), (Edge.mk 28 1 3 .terminator)] [1] [1] [1]
theorem call_replay14 : checkObservation call14 = true := by decide
#print axioms call_replay14
def call15 : Observation := Observation.mk (Capture.mk 30 1 1 1) [(Edge.mk 30 1 1 (.callee 1)), (Edge.mk 30 1 2 (.argument 1)), (Edge.mk 30 1 3 .terminator)] [1] [1] [1]
theorem call_replay15 : checkObservation call15 = true := by decide
#print axioms call_replay15
def call16 : Observation := Observation.mk (Capture.mk 14 1 10 2) [(Edge.mk 14 1 1 (.callee 10)), (Edge.mk 14 1 2 (.argument 1)), (Edge.mk 14 1 3 (.argument 2)), (Edge.mk 14 1 4 .terminator)] [1, 2] [1, 2] [2, 1]
theorem call_replay16 : checkObservation call16 = true := by decide
#print axioms call_replay16
