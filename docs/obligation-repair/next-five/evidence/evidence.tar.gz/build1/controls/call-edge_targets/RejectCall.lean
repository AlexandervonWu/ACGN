import OrderedCallValidation
open ACGN.NextFive.OrderedCallValidation
theorem control0 : ([0, 0, 0] : List Nat) = [0, 0, 0] := by decide
#print axioms control0
theorem control1 : ([1, 1, 1] : List Nat) = [1, 1, 1] := by decide
#print axioms control1
theorem control2 : ([2, 0, 1] : List Nat) = [2, 0, 1] := by decide
#print axioms control2
def call0 : Observation := Observation.mk (Capture.mk 11 1 7 0) [(Edge.mk 11 1 1 (.callee 7)), (Edge.mk 11 1 2 (.argument 1))] [] [] []
theorem call_replay0 : checkObservation call0 = true := by decide
#print axioms call_replay0
