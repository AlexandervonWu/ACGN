import OrderedCallValidation
open ACGN.NextFive.OrderedCallValidation
theorem control0 : ([0, 0, 0] : List Nat) = [0, 0, 0] := by decide
#print axioms control0
theorem control1 : ([1, 1, 1] : List Nat) = [1, 1, 1] := by decide
#print axioms control1
theorem control2 : ([2, 0, 1] : List Nat) = [2, 0, 1] := by decide
#print axioms control2
def call0 : Observation := Observation.mk (Capture.mk 11 1 7 0) [(Edge.mk 11 1 1 (.callee 7)), (Edge.mk 11 1 2 .terminator)] [] [] []
theorem call_replay0 : checkObservation call0 = true := by decide
#print axioms call_replay0
def call1 : Observation := Observation.mk (Capture.mk 13 1 0 0) [(Edge.mk 13 1 1 (.callee 0)), (Edge.mk 13 1 2 .terminator)] [] [] []
theorem call_replay1 : checkObservation call1 = true := by decide
#print axioms call_replay1
def call2 : Observation := Observation.mk (Capture.mk 16 1 7 0) [(Edge.mk 16 1 1 (.callee 7)), (Edge.mk 16 1 2 .terminator)] [] [] []
theorem call_replay2 : checkObservation call2 = true := by decide
#print axioms call_replay2
def call3 : Observation := Observation.mk (Capture.mk 18 1 0 0) [(Edge.mk 18 1 1 (.callee 0)), (Edge.mk 18 1 2 .terminator)] [] [] []
theorem call_replay3 : checkObservation call3 = true := by decide
#print axioms call_replay3
def call4 : Observation := Observation.mk (Capture.mk 20 1 7 0) [(Edge.mk 20 1 1 (.callee 7)), (Edge.mk 20 1 2 .terminator)] [] [] []
theorem call_replay4 : checkObservation call4 = true := by decide
#print axioms call_replay4
def call5 : Observation := Observation.mk (Capture.mk 22 1 0 0) [(Edge.mk 22 1 1 (.callee 0)), (Edge.mk 22 1 2 .terminator)] [] [] []
theorem call_replay5 : checkObservation call5 = true := by decide
#print axioms call_replay5
def call6 : Observation := Observation.mk (Capture.mk 24 1 7 0) [(Edge.mk 24 1 1 (.callee 7)), (Edge.mk 24 1 2 .terminator)] [] [] []
theorem call_replay6 : checkObservation call6 = true := by decide
#print axioms call_replay6
def call7 : Observation := Observation.mk (Capture.mk 26 1 0 0) [(Edge.mk 26 1 1 (.callee 0)), (Edge.mk 26 1 2 .terminator)] [] [] []
theorem call_replay7 : checkObservation call7 = true := by decide
#print axioms call_replay7
def call8 : Observation := Observation.mk (Capture.mk 13 1 8 1) [(Edge.mk 13 1 1 (.callee 8)), (Edge.mk 13 1 2 (.argument 1)), (Edge.mk 13 1 3 .terminator)] [1] [1] [1]
theorem call_replay8 : checkObservation call8 = true := by decide
#print axioms call_replay8
def call9 : Observation := Observation.mk (Capture.mk 16 1 1 1) [(Edge.mk 16 1 1 (.callee 1)), (Edge.mk 16 1 2 (.argument 1)), (Edge.mk 16 1 3 .terminator)] [1] [1] [1]
theorem call_replay9 : checkObservation call9 = true := by decide
#print axioms call_replay9
def call10 : Observation := Observation.mk (Capture.mk 19 1 8 1) [(Edge.mk 19 1 1 (.callee 8)), (Edge.mk 19 1 2 (.argument 1)), (Edge.mk 19 1 3 .terminator)] [1] [1] [1]
theorem call_replay10 : checkObservation call10 = true := by decide
#print axioms call_replay10
def call11 : Observation := Observation.mk (Capture.mk 21 1 1 1) [(Edge.mk 21 1 1 (.callee 1)), (Edge.mk 21 1 2 (.argument 1)), (Edge.mk 21 1 3 .terminator)] [1] [1] [1]
theorem call_replay11 : checkObservation call11 = true := by decide
#print axioms call_replay11
def call12 : Observation := Observation.mk (Capture.mk 23 1 8 1) [(Edge.mk 23 1 1 (.callee 8)), (Edge.mk 23 1 2 (.argument 2)), (Edge.mk 23 1 3 .terminator)] [2] [2] [2]
theorem call_replay12 : checkObservation call12 = true := by decide
#print axioms call_replay12
def call13 : Observation := Observation.mk (Capture.mk 26 1 1 1) [(Edge.mk 26 1 1 (.callee 1)), (Edge.mk 26 1 2 (.argument 2)), (Edge.mk 26 1 3 .terminator)] [2] [2] [2]
theorem call_replay13 : checkObservation call13 = true := by decide
#print axioms call_replay13
def call14 : Observation := Observation.mk (Capture.mk 28 1 8 1) [(Edge.mk 28 1 1 (.callee 8)), (Edge.mk 28 1 2 (.argument 1)), (Edge.mk 28 1 3 .terminator)] [1] [1] [1]
theorem call_replay14 : checkObservation call14 = true := by decide
#print axioms call_replay14
def call15 : Observation := Observation.mk (Capture.mk 30 1 1 1) [(Edge.mk 30 1 1 (.callee 1)), (Edge.mk 30 1 2 (.argument 1)), (Edge.mk 30 1 3 .terminator)] [1] [1] [1]
theorem call_replay15 : checkObservation call15 = true := by decide
#print axioms call_replay15
def call16 : Observation := Observation.mk (Capture.mk 14 1 10 2) [(Edge.mk 14 1 1 (.callee 10)), (Edge.mk 14 1 2 (.argument 1)), (Edge.mk 14 1 3 (.argument 2)), (Edge.mk 14 1 4 .terminator)] [1, 2] [1, 2] [1, 2]
theorem call_replay16 : checkObservation call16 = true := by decide
#print axioms call_replay16
def call17 : Observation := Observation.mk (Capture.mk 18 1 3 2) [(Edge.mk 18 1 1 (.callee 3)), (Edge.mk 18 1 2 (.argument 1)), (Edge.mk 18 1 3 (.argument 2)), (Edge.mk 18 1 4 .terminator)] [1, 2] [1, 2] [1, 2]
theorem call_replay17 : checkObservation call17 = true := by decide
#print axioms call_replay17
def call18 : Observation := Observation.mk (Capture.mk 21 1 10 2) [(Edge.mk 21 1 1 (.callee 10)), (Edge.mk 21 1 2 (.argument 2)), (Edge.mk 21 1 3 (.argument 1)), (Edge.mk 21 1 4 .terminator)] [2, 1] [2, 1] [2, 1]
theorem call_replay18 : checkObservation call18 = true := by decide
#print axioms call_replay18
def call19 : Observation := Observation.mk (Capture.mk 23 1 3 2) [(Edge.mk 23 1 1 (.callee 3)), (Edge.mk 23 1 2 (.argument 2)), (Edge.mk 23 1 3 (.argument 1)), (Edge.mk 23 1 4 .terminator)] [2, 1] [2, 1] [2, 1]
theorem call_replay19 : checkObservation call19 = true := by decide
#print axioms call_replay19
def call20 : Observation := Observation.mk (Capture.mk 25 1 10 2) [(Edge.mk 25 1 1 (.callee 10)), (Edge.mk 25 1 2 (.argument 2)), (Edge.mk 25 1 3 (.argument 2)), (Edge.mk 25 1 4 .terminator)] [2, 2] [2, 2] [2, 2]
theorem call_replay20 : checkObservation call20 = true := by decide
#print axioms call_replay20
def call21 : Observation := Observation.mk (Capture.mk 27 1 3 2) [(Edge.mk 27 1 1 (.callee 3)), (Edge.mk 27 1 2 (.argument 2)), (Edge.mk 27 1 3 (.argument 2)), (Edge.mk 27 1 4 .terminator)] [2, 2] [2, 2] [2, 2]
theorem call_replay21 : checkObservation call21 = true := by decide
#print axioms call_replay21
def call22 : Observation := Observation.mk (Capture.mk 29 1 10 2) [(Edge.mk 29 1 1 (.callee 10)), (Edge.mk 29 1 2 (.argument 1)), (Edge.mk 29 1 3 (.argument 2)), (Edge.mk 29 1 4 .terminator)] [1, 2] [1, 2] [1, 2]
theorem call_replay22 : checkObservation call22 = true := by decide
#print axioms call_replay22
def call23 : Observation := Observation.mk (Capture.mk 31 1 3 2) [(Edge.mk 31 1 1 (.callee 3)), (Edge.mk 31 1 2 (.argument 1)), (Edge.mk 31 1 3 (.argument 2)), (Edge.mk 31 1 4 .terminator)] [1, 2] [1, 2] [1, 2]
theorem call_replay23 : checkObservation call23 = true := by decide
#print axioms call_replay23
def call24 : Observation := Observation.mk (Capture.mk 15 1 11 3) [(Edge.mk 15 1 1 (.callee 11)), (Edge.mk 15 1 2 (.argument 1)), (Edge.mk 15 1 3 (.argument 2)), (Edge.mk 15 1 4 (.argument 3)), (Edge.mk 15 1 5 .terminator)] [1, 2, 3] [1, 2, 3] [1, 2, 3]
theorem call_replay24 : checkObservation call24 = true := by decide
#print axioms call_replay24
def call25 : Observation := Observation.mk (Capture.mk 20 1 4 3) [(Edge.mk 20 1 1 (.callee 4)), (Edge.mk 20 1 2 (.argument 1)), (Edge.mk 20 1 3 (.argument 2)), (Edge.mk 20 1 4 (.argument 3)), (Edge.mk 20 1 5 .terminator)] [1, 2, 3] [1, 2, 3] [1, 2, 3]
theorem call_replay25 : checkObservation call25 = true := by decide
#print axioms call_replay25
def call26 : Observation := Observation.mk (Capture.mk 23 1 11 3) [(Edge.mk 23 1 1 (.callee 11)), (Edge.mk 23 1 2 (.argument 3)), (Edge.mk 23 1 3 (.argument 2)), (Edge.mk 23 1 4 (.argument 1)), (Edge.mk 23 1 5 .terminator)] [3, 2, 1] [3, 2, 1] [3, 2, 1]
theorem call_replay26 : checkObservation call26 = true := by decide
#print axioms call_replay26
def call27 : Observation := Observation.mk (Capture.mk 25 1 4 3) [(Edge.mk 25 1 1 (.callee 4)), (Edge.mk 25 1 2 (.argument 3)), (Edge.mk 25 1 3 (.argument 2)), (Edge.mk 25 1 4 (.argument 1)), (Edge.mk 25 1 5 .terminator)] [3, 2, 1] [3, 2, 1] [3, 2, 1]
theorem call_replay27 : checkObservation call27 = true := by decide
#print axioms call_replay27
def call28 : Observation := Observation.mk (Capture.mk 27 1 11 3) [(Edge.mk 27 1 1 (.callee 11)), (Edge.mk 27 1 2 (.argument 2)), (Edge.mk 27 1 3 (.argument 2)), (Edge.mk 27 1 4 (.argument 2)), (Edge.mk 27 1 5 .terminator)] [2, 2, 2] [2, 2, 2] [2, 2, 2]
theorem call_replay28 : checkObservation call28 = true := by decide
#print axioms call_replay28
def call29 : Observation := Observation.mk (Capture.mk 29 1 4 3) [(Edge.mk 29 1 1 (.callee 4)), (Edge.mk 29 1 2 (.argument 2)), (Edge.mk 29 1 3 (.argument 2)), (Edge.mk 29 1 4 (.argument 2)), (Edge.mk 29 1 5 .terminator)] [2, 2, 2] [2, 2, 2] [2, 2, 2]
theorem call_replay29 : checkObservation call29 = true := by decide
#print axioms call_replay29
def call30 : Observation := Observation.mk (Capture.mk 31 1 11 3) [(Edge.mk 31 1 1 (.callee 11)), (Edge.mk 31 1 2 (.argument 1)), (Edge.mk 31 1 3 (.argument 2)), (Edge.mk 31 1 4 (.argument 3)), (Edge.mk 31 1 5 .terminator)] [1, 2, 3] [1, 2, 3] [1, 2, 3]
theorem call_replay30 : checkObservation call30 = true := by decide
#print axioms call_replay30
def call31 : Observation := Observation.mk (Capture.mk 33 1 4 3) [(Edge.mk 33 1 1 (.callee 4)), (Edge.mk 33 1 2 (.argument 1)), (Edge.mk 33 1 3 (.argument 2)), (Edge.mk 33 1 4 (.argument 3)), (Edge.mk 33 1 5 .terminator)] [1, 2, 3] [1, 2, 3] [1, 2, 3]
theorem call_replay31 : checkObservation call31 = true := by decide
#print axioms call_replay31
def call32 : Observation := Observation.mk (Capture.mk 17 1 12 5) [(Edge.mk 17 1 1 (.callee 12)), (Edge.mk 17 1 2 (.argument 1)), (Edge.mk 17 1 3 (.argument 2)), (Edge.mk 17 1 4 (.argument 3)), (Edge.mk 17 1 5 (.argument 1)), (Edge.mk 17 1 6 (.argument 2)), (Edge.mk 17 1 7 .terminator)] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2]
theorem call_replay32 : checkObservation call32 = true := by decide
#print axioms call_replay32
def call33 : Observation := Observation.mk (Capture.mk 22 1 5 5) [(Edge.mk 22 1 1 (.callee 5)), (Edge.mk 22 1 2 (.argument 1)), (Edge.mk 22 1 3 (.argument 2)), (Edge.mk 22 1 4 (.argument 3)), (Edge.mk 22 1 5 (.argument 1)), (Edge.mk 22 1 6 (.argument 2)), (Edge.mk 22 1 7 .terminator)] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2]
theorem call_replay33 : checkObservation call33 = true := by decide
#print axioms call_replay33
def call34 : Observation := Observation.mk (Capture.mk 25 1 12 5) [(Edge.mk 25 1 1 (.callee 12)), (Edge.mk 25 1 2 (.argument 2)), (Edge.mk 25 1 3 (.argument 1)), (Edge.mk 25 1 4 (.argument 3)), (Edge.mk 25 1 5 (.argument 2)), (Edge.mk 25 1 6 (.argument 1)), (Edge.mk 25 1 7 .terminator)] [2, 1, 3, 2, 1] [2, 1, 3, 2, 1] [2, 1, 3, 2, 1]
theorem call_replay34 : checkObservation call34 = true := by decide
#print axioms call_replay34
def call35 : Observation := Observation.mk (Capture.mk 27 1 5 5) [(Edge.mk 27 1 1 (.callee 5)), (Edge.mk 27 1 2 (.argument 2)), (Edge.mk 27 1 3 (.argument 1)), (Edge.mk 27 1 4 (.argument 3)), (Edge.mk 27 1 5 (.argument 2)), (Edge.mk 27 1 6 (.argument 1)), (Edge.mk 27 1 7 .terminator)] [2, 1, 3, 2, 1] [2, 1, 3, 2, 1] [2, 1, 3, 2, 1]
theorem call_replay35 : checkObservation call35 = true := by decide
#print axioms call_replay35
def call36 : Observation := Observation.mk (Capture.mk 29 1 12 5) [(Edge.mk 29 1 1 (.callee 12)), (Edge.mk 29 1 2 (.argument 2)), (Edge.mk 29 1 3 (.argument 2)), (Edge.mk 29 1 4 (.argument 2)), (Edge.mk 29 1 5 (.argument 2)), (Edge.mk 29 1 6 (.argument 2)), (Edge.mk 29 1 7 .terminator)] [2, 2, 2, 2, 2] [2, 2, 2, 2, 2] [2, 2, 2, 2, 2]
theorem call_replay36 : checkObservation call36 = true := by decide
#print axioms call_replay36
def call37 : Observation := Observation.mk (Capture.mk 31 1 5 5) [(Edge.mk 31 1 1 (.callee 5)), (Edge.mk 31 1 2 (.argument 2)), (Edge.mk 31 1 3 (.argument 2)), (Edge.mk 31 1 4 (.argument 2)), (Edge.mk 31 1 5 (.argument 2)), (Edge.mk 31 1 6 (.argument 2)), (Edge.mk 31 1 7 .terminator)] [2, 2, 2, 2, 2] [2, 2, 2, 2, 2] [2, 2, 2, 2, 2]
theorem call_replay37 : checkObservation call37 = true := by decide
#print axioms call_replay37
def call38 : Observation := Observation.mk (Capture.mk 33 1 12 5) [(Edge.mk 33 1 1 (.callee 12)), (Edge.mk 33 1 2 (.argument 1)), (Edge.mk 33 1 3 (.argument 2)), (Edge.mk 33 1 4 (.argument 3)), (Edge.mk 33 1 5 (.argument 1)), (Edge.mk 33 1 6 (.argument 2)), (Edge.mk 33 1 7 .terminator)] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2]
theorem call_replay38 : checkObservation call38 = true := by decide
#print axioms call_replay38
def call39 : Observation := Observation.mk (Capture.mk 35 1 5 5) [(Edge.mk 35 1 1 (.callee 5)), (Edge.mk 35 1 2 (.argument 1)), (Edge.mk 35 1 3 (.argument 2)), (Edge.mk 35 1 4 (.argument 3)), (Edge.mk 35 1 5 (.argument 1)), (Edge.mk 35 1 6 (.argument 2)), (Edge.mk 35 1 7 .terminator)] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2] [1, 2, 3, 1, 2]
theorem call_replay39 : checkObservation call39 = true := by decide
#print axioms call_replay39
def call40 : Observation := Observation.mk (Capture.mk 20 1 13 8) [(Edge.mk 20 1 1 (.callee 13)), (Edge.mk 20 1 2 (.argument 1)), (Edge.mk 20 1 3 (.argument 2)), (Edge.mk 20 1 4 (.argument 3)), (Edge.mk 20 1 5 (.argument 1)), (Edge.mk 20 1 6 (.argument 2)), (Edge.mk 20 1 7 (.argument 3)), (Edge.mk 20 1 8 (.argument 1)), (Edge.mk 20 1 9 (.argument 2)), (Edge.mk 20 1 10 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2]
theorem call_replay40 : checkObservation call40 = true := by decide
#print axioms call_replay40
def call41 : Observation := Observation.mk (Capture.mk 25 1 6 8) [(Edge.mk 25 1 1 (.callee 6)), (Edge.mk 25 1 2 (.argument 1)), (Edge.mk 25 1 3 (.argument 2)), (Edge.mk 25 1 4 (.argument 3)), (Edge.mk 25 1 5 (.argument 1)), (Edge.mk 25 1 6 (.argument 2)), (Edge.mk 25 1 7 (.argument 3)), (Edge.mk 25 1 8 (.argument 1)), (Edge.mk 25 1 9 (.argument 2)), (Edge.mk 25 1 10 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2]
theorem call_replay41 : checkObservation call41 = true := by decide
#print axioms call_replay41
def call42 : Observation := Observation.mk (Capture.mk 28 1 13 8) [(Edge.mk 28 1 1 (.callee 13)), (Edge.mk 28 1 2 (.argument 2)), (Edge.mk 28 1 3 (.argument 1)), (Edge.mk 28 1 4 (.argument 3)), (Edge.mk 28 1 5 (.argument 2)), (Edge.mk 28 1 6 (.argument 1)), (Edge.mk 28 1 7 (.argument 3)), (Edge.mk 28 1 8 (.argument 2)), (Edge.mk 28 1 9 (.argument 1)), (Edge.mk 28 1 10 .terminator)] [2, 1, 3, 2, 1, 3, 2, 1] [2, 1, 3, 2, 1, 3, 2, 1] [2, 1, 3, 2, 1, 3, 2, 1]
theorem call_replay42 : checkObservation call42 = true := by decide
#print axioms call_replay42
def call43 : Observation := Observation.mk (Capture.mk 30 1 6 8) [(Edge.mk 30 1 1 (.callee 6)), (Edge.mk 30 1 2 (.argument 2)), (Edge.mk 30 1 3 (.argument 1)), (Edge.mk 30 1 4 (.argument 3)), (Edge.mk 30 1 5 (.argument 2)), (Edge.mk 30 1 6 (.argument 1)), (Edge.mk 30 1 7 (.argument 3)), (Edge.mk 30 1 8 (.argument 2)), (Edge.mk 30 1 9 (.argument 1)), (Edge.mk 30 1 10 .terminator)] [2, 1, 3, 2, 1, 3, 2, 1] [2, 1, 3, 2, 1, 3, 2, 1] [2, 1, 3, 2, 1, 3, 2, 1]
theorem call_replay43 : checkObservation call43 = true := by decide
#print axioms call_replay43
def call44 : Observation := Observation.mk (Capture.mk 32 1 13 8) [(Edge.mk 32 1 1 (.callee 13)), (Edge.mk 32 1 2 (.argument 2)), (Edge.mk 32 1 3 (.argument 2)), (Edge.mk 32 1 4 (.argument 2)), (Edge.mk 32 1 5 (.argument 2)), (Edge.mk 32 1 6 (.argument 2)), (Edge.mk 32 1 7 (.argument 2)), (Edge.mk 32 1 8 (.argument 2)), (Edge.mk 32 1 9 (.argument 2)), (Edge.mk 32 1 10 .terminator)] [2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2]
theorem call_replay44 : checkObservation call44 = true := by decide
#print axioms call_replay44
def call45 : Observation := Observation.mk (Capture.mk 34 1 6 8) [(Edge.mk 34 1 1 (.callee 6)), (Edge.mk 34 1 2 (.argument 2)), (Edge.mk 34 1 3 (.argument 2)), (Edge.mk 34 1 4 (.argument 2)), (Edge.mk 34 1 5 (.argument 2)), (Edge.mk 34 1 6 (.argument 2)), (Edge.mk 34 1 7 (.argument 2)), (Edge.mk 34 1 8 (.argument 2)), (Edge.mk 34 1 9 (.argument 2)), (Edge.mk 34 1 10 .terminator)] [2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2]
theorem call_replay45 : checkObservation call45 = true := by decide
#print axioms call_replay45
def call46 : Observation := Observation.mk (Capture.mk 36 1 13 8) [(Edge.mk 36 1 1 (.callee 13)), (Edge.mk 36 1 2 (.argument 1)), (Edge.mk 36 1 3 (.argument 2)), (Edge.mk 36 1 4 (.argument 3)), (Edge.mk 36 1 5 (.argument 1)), (Edge.mk 36 1 6 (.argument 2)), (Edge.mk 36 1 7 (.argument 3)), (Edge.mk 36 1 8 (.argument 1)), (Edge.mk 36 1 9 (.argument 2)), (Edge.mk 36 1 10 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2]
theorem call_replay46 : checkObservation call46 = true := by decide
#print axioms call_replay46
def call47 : Observation := Observation.mk (Capture.mk 38 1 6 8) [(Edge.mk 38 1 1 (.callee 6)), (Edge.mk 38 1 2 (.argument 1)), (Edge.mk 38 1 3 (.argument 2)), (Edge.mk 38 1 4 (.argument 3)), (Edge.mk 38 1 5 (.argument 1)), (Edge.mk 38 1 6 (.argument 2)), (Edge.mk 38 1 7 (.argument 3)), (Edge.mk 38 1 8 (.argument 1)), (Edge.mk 38 1 9 (.argument 2)), (Edge.mk 38 1 10 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2] [1, 2, 3, 1, 2, 3, 1, 2]
theorem call_replay47 : checkObservation call47 = true := by decide
#print axioms call_replay47
def call48 : Observation := Observation.mk (Capture.mk 28 1 9 16) [(Edge.mk 28 1 1 (.callee 9)), (Edge.mk 28 1 2 (.argument 1)), (Edge.mk 28 1 3 (.argument 2)), (Edge.mk 28 1 4 (.argument 3)), (Edge.mk 28 1 5 (.argument 1)), (Edge.mk 28 1 6 (.argument 2)), (Edge.mk 28 1 7 (.argument 3)), (Edge.mk 28 1 8 (.argument 1)), (Edge.mk 28 1 9 (.argument 2)), (Edge.mk 28 1 10 (.argument 3)), (Edge.mk 28 1 11 (.argument 1)), (Edge.mk 28 1 12 (.argument 2)), (Edge.mk 28 1 13 (.argument 3)), (Edge.mk 28 1 14 (.argument 1)), (Edge.mk 28 1 15 (.argument 2)), (Edge.mk 28 1 16 (.argument 3)), (Edge.mk 28 1 17 (.argument 1)), (Edge.mk 28 1 18 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1]
theorem call_replay48 : checkObservation call48 = true := by decide
#print axioms call_replay48
def call49 : Observation := Observation.mk (Capture.mk 33 1 2 16) [(Edge.mk 33 1 1 (.callee 2)), (Edge.mk 33 1 2 (.argument 1)), (Edge.mk 33 1 3 (.argument 2)), (Edge.mk 33 1 4 (.argument 3)), (Edge.mk 33 1 5 (.argument 1)), (Edge.mk 33 1 6 (.argument 2)), (Edge.mk 33 1 7 (.argument 3)), (Edge.mk 33 1 8 (.argument 1)), (Edge.mk 33 1 9 (.argument 2)), (Edge.mk 33 1 10 (.argument 3)), (Edge.mk 33 1 11 (.argument 1)), (Edge.mk 33 1 12 (.argument 2)), (Edge.mk 33 1 13 (.argument 3)), (Edge.mk 33 1 14 (.argument 1)), (Edge.mk 33 1 15 (.argument 2)), (Edge.mk 33 1 16 (.argument 3)), (Edge.mk 33 1 17 (.argument 1)), (Edge.mk 33 1 18 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1]
theorem call_replay49 : checkObservation call49 = true := by decide
#print axioms call_replay49
def call50 : Observation := Observation.mk (Capture.mk 36 1 9 16) [(Edge.mk 36 1 1 (.callee 9)), (Edge.mk 36 1 2 (.argument 1)), (Edge.mk 36 1 3 (.argument 3)), (Edge.mk 36 1 4 (.argument 2)), (Edge.mk 36 1 5 (.argument 1)), (Edge.mk 36 1 6 (.argument 3)), (Edge.mk 36 1 7 (.argument 2)), (Edge.mk 36 1 8 (.argument 1)), (Edge.mk 36 1 9 (.argument 3)), (Edge.mk 36 1 10 (.argument 2)), (Edge.mk 36 1 11 (.argument 1)), (Edge.mk 36 1 12 (.argument 3)), (Edge.mk 36 1 13 (.argument 2)), (Edge.mk 36 1 14 (.argument 1)), (Edge.mk 36 1 15 (.argument 3)), (Edge.mk 36 1 16 (.argument 2)), (Edge.mk 36 1 17 (.argument 1)), (Edge.mk 36 1 18 .terminator)] [1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1] [1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1] [1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1]
theorem call_replay50 : checkObservation call50 = true := by decide
#print axioms call_replay50
def call51 : Observation := Observation.mk (Capture.mk 38 1 2 16) [(Edge.mk 38 1 1 (.callee 2)), (Edge.mk 38 1 2 (.argument 1)), (Edge.mk 38 1 3 (.argument 3)), (Edge.mk 38 1 4 (.argument 2)), (Edge.mk 38 1 5 (.argument 1)), (Edge.mk 38 1 6 (.argument 3)), (Edge.mk 38 1 7 (.argument 2)), (Edge.mk 38 1 8 (.argument 1)), (Edge.mk 38 1 9 (.argument 3)), (Edge.mk 38 1 10 (.argument 2)), (Edge.mk 38 1 11 (.argument 1)), (Edge.mk 38 1 12 (.argument 3)), (Edge.mk 38 1 13 (.argument 2)), (Edge.mk 38 1 14 (.argument 1)), (Edge.mk 38 1 15 (.argument 3)), (Edge.mk 38 1 16 (.argument 2)), (Edge.mk 38 1 17 (.argument 1)), (Edge.mk 38 1 18 .terminator)] [1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1] [1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1] [1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1]
theorem call_replay51 : checkObservation call51 = true := by decide
#print axioms call_replay51
def call52 : Observation := Observation.mk (Capture.mk 40 1 9 16) [(Edge.mk 40 1 1 (.callee 9)), (Edge.mk 40 1 2 (.argument 2)), (Edge.mk 40 1 3 (.argument 2)), (Edge.mk 40 1 4 (.argument 2)), (Edge.mk 40 1 5 (.argument 2)), (Edge.mk 40 1 6 (.argument 2)), (Edge.mk 40 1 7 (.argument 2)), (Edge.mk 40 1 8 (.argument 2)), (Edge.mk 40 1 9 (.argument 2)), (Edge.mk 40 1 10 (.argument 2)), (Edge.mk 40 1 11 (.argument 2)), (Edge.mk 40 1 12 (.argument 2)), (Edge.mk 40 1 13 (.argument 2)), (Edge.mk 40 1 14 (.argument 2)), (Edge.mk 40 1 15 (.argument 2)), (Edge.mk 40 1 16 (.argument 2)), (Edge.mk 40 1 17 (.argument 2)), (Edge.mk 40 1 18 .terminator)] [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
theorem call_replay52 : checkObservation call52 = true := by decide
#print axioms call_replay52
def call53 : Observation := Observation.mk (Capture.mk 42 1 2 16) [(Edge.mk 42 1 1 (.callee 2)), (Edge.mk 42 1 2 (.argument 2)), (Edge.mk 42 1 3 (.argument 2)), (Edge.mk 42 1 4 (.argument 2)), (Edge.mk 42 1 5 (.argument 2)), (Edge.mk 42 1 6 (.argument 2)), (Edge.mk 42 1 7 (.argument 2)), (Edge.mk 42 1 8 (.argument 2)), (Edge.mk 42 1 9 (.argument 2)), (Edge.mk 42 1 10 (.argument 2)), (Edge.mk 42 1 11 (.argument 2)), (Edge.mk 42 1 12 (.argument 2)), (Edge.mk 42 1 13 (.argument 2)), (Edge.mk 42 1 14 (.argument 2)), (Edge.mk 42 1 15 (.argument 2)), (Edge.mk 42 1 16 (.argument 2)), (Edge.mk 42 1 17 (.argument 2)), (Edge.mk 42 1 18 .terminator)] [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
theorem call_replay53 : checkObservation call53 = true := by decide
#print axioms call_replay53
def call54 : Observation := Observation.mk (Capture.mk 44 1 9 16) [(Edge.mk 44 1 1 (.callee 9)), (Edge.mk 44 1 2 (.argument 1)), (Edge.mk 44 1 3 (.argument 2)), (Edge.mk 44 1 4 (.argument 3)), (Edge.mk 44 1 5 (.argument 1)), (Edge.mk 44 1 6 (.argument 2)), (Edge.mk 44 1 7 (.argument 3)), (Edge.mk 44 1 8 (.argument 1)), (Edge.mk 44 1 9 (.argument 2)), (Edge.mk 44 1 10 (.argument 3)), (Edge.mk 44 1 11 (.argument 1)), (Edge.mk 44 1 12 (.argument 2)), (Edge.mk 44 1 13 (.argument 3)), (Edge.mk 44 1 14 (.argument 1)), (Edge.mk 44 1 15 (.argument 2)), (Edge.mk 44 1 16 (.argument 3)), (Edge.mk 44 1 17 (.argument 1)), (Edge.mk 44 1 18 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1]
theorem call_replay54 : checkObservation call54 = true := by decide
#print axioms call_replay54
def call55 : Observation := Observation.mk (Capture.mk 46 1 2 16) [(Edge.mk 46 1 1 (.callee 2)), (Edge.mk 46 1 2 (.argument 1)), (Edge.mk 46 1 3 (.argument 2)), (Edge.mk 46 1 4 (.argument 3)), (Edge.mk 46 1 5 (.argument 1)), (Edge.mk 46 1 6 (.argument 2)), (Edge.mk 46 1 7 (.argument 3)), (Edge.mk 46 1 8 (.argument 1)), (Edge.mk 46 1 9 (.argument 2)), (Edge.mk 46 1 10 (.argument 3)), (Edge.mk 46 1 11 (.argument 1)), (Edge.mk 46 1 12 (.argument 2)), (Edge.mk 46 1 13 (.argument 3)), (Edge.mk 46 1 14 (.argument 1)), (Edge.mk 46 1 15 (.argument 2)), (Edge.mk 46 1 16 (.argument 3)), (Edge.mk 46 1 17 (.argument 1)), (Edge.mk 46 1 18 .terminator)] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1] [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1]
theorem call_replay55 : checkObservation call55 = true := by decide
#print axioms call_replay55
