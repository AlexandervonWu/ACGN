import FlatTypeSubstitution
open ACGN.NextFive.FlatTypeSubstitution
def sites : SubstitutionSites := ⟨"typeArguments", "typeArguments"⟩
theorem same_sites : sites.elementField = sites.resultField := by decide
theorem source_type_preservation {T U : Type} (env : String -> T -> U)
    (s : Schema T) (r : T) (h : element? s = some (.one r)) :
    element? (substitute (env sites.elementField) s) =
      some (.one (env sites.resultField r)) :=
  extracted_shared_substitution sites same_sites env s r h
#print axioms same_sites
#print axioms source_type_preservation
theorem flat0 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat0
theorem flat1 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat1
theorem flat2 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat2
theorem flat3 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat3
theorem flat4 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat4
theorem flat5 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat5
theorem flat6 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat6
theorem flat7 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat7
theorem flat8 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat8
theorem flat9 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat9
theorem flat10 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat10
theorem flat11 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat11
theorem flat12 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat12
theorem flat13 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat13
theorem flat14 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat14
theorem flat15 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat15
theorem flat16 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat16
theorem flat17 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat17
theorem flat18 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat18
theorem flat19 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat19
theorem flat20 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat20
theorem flat21 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat21
theorem flat22 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat22
theorem flat23 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat23
theorem flat24 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat24
theorem flat25 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat25
theorem flat26 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat26
theorem flat27 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat27
theorem flat28 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat28
theorem flat29 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat29
theorem flat30 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat30
theorem flat31 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat31
theorem flat32 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat32
theorem flat33 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat33
theorem flat34 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat34
theorem flat35 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat35
theorem flat36 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat36
theorem flat37 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat37
theorem flat38 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat38
theorem flat39 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat39
theorem flat40 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat40
theorem flat41 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat41
theorem flat42 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat42
theorem flat43 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat43
theorem flat44 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat44
theorem flat45 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat45
theorem flat46 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat46
theorem flat47 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat47
theorem flat48 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat48
theorem flat49 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat49
theorem flat50 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat50
theorem flat51 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat51
theorem flat52 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat52
theorem flat53 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat53
theorem flat54 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat54
theorem flat55 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat55
theorem flat56 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat56
theorem flat57 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat57
theorem flat58 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat58
theorem flat59 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat59
theorem flat60 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat60
theorem flat61 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat61
theorem flat62 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat62
theorem flat63 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat63
theorem flat64 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat64
theorem flat65 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat65
theorem flat66 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat66
theorem flat67 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat67
theorem flat68 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat68
theorem flat69 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat69
theorem flat70 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat70
theorem flat71 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat71
theorem flat72 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat72
theorem flat73 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat73
theorem flat74 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat74
theorem flat75 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat75
theorem flat76 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat76
theorem flat77 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat77
theorem flat78 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat78
theorem flat79 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat79
theorem flat80 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat80
theorem flat81 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat81
theorem flat82 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat82
theorem flat83 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat83
theorem flat84 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat84
theorem flat85 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat85
theorem flat86 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat86
theorem flat87 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat87
theorem flat88 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat88
theorem flat89 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat89
theorem flat90 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat90
theorem flat91 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat91
theorem flat92 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat92
theorem flat93 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat93
theorem flat94 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat94
theorem flat95 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat95
theorem flat96 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat96
theorem flat97 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat97
theorem flat98 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat98
theorem flat99 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat99
theorem flat100 : replay (Observation.mk "3[-;1[-;],1[-;]]" "3[-;1[-;],1[-;]]" "3[-;1[-;],1[-;]]") = true := by decide
#print axioms flat100
theorem flat101 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat101
theorem flat102 : replay (Observation.mk "3[-;1[-;],5[15:AlloySig:Person;]]" "3[-;1[-;],5[15:AlloySig:Person;]]" "3[-;1[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat102
theorem flat103 : replay (Observation.mk "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat103
theorem flat104 : replay (Observation.mk "3[-;1[-;],3[-;1[-;],2[-;]]]" "3[-;1[-;],3[-;1[-;],2[-;]]]" "3[-;1[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat104
theorem flat105 : replay (Observation.mk "3[-;2[-;],1[-;]]" "3[-;2[-;],1[-;]]" "3[-;2[-;],1[-;]]") = true := by decide
#print axioms flat105
theorem flat106 : replay (Observation.mk "3[-;2[-;],2[-;]]" "3[-;2[-;],2[-;]]" "3[-;2[-;],2[-;]]") = true := by decide
#print axioms flat106
theorem flat107 : replay (Observation.mk "3[-;2[-;],5[15:AlloySig:Person;]]" "3[-;2[-;],5[15:AlloySig:Person;]]" "3[-;2[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat107
theorem flat108 : replay (Observation.mk "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat108
theorem flat109 : replay (Observation.mk "3[-;2[-;],3[-;1[-;],2[-;]]]" "3[-;2[-;],3[-;1[-;],2[-;]]]" "3[-;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat109
theorem flat110 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],1[-;]]" "3[-;5[15:AlloySig:Person;],1[-;]]" "3[-;5[15:AlloySig:Person;],1[-;]]") = true := by decide
#print axioms flat110
theorem flat111 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],2[-;]]" "3[-;5[15:AlloySig:Person;],2[-;]]" "3[-;5[15:AlloySig:Person;],2[-;]]") = true := by decide
#print axioms flat111
theorem flat112 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat112
theorem flat113 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat113
theorem flat114 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat114
theorem flat115 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]") = true := by decide
#print axioms flat115
theorem flat116 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]") = true := by decide
#print axioms flat116
theorem flat117 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat117
theorem flat118 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat118
theorem flat119 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat119
theorem flat120 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],1[-;]]" "3[-;3[-;1[-;],2[-;]],1[-;]]" "3[-;3[-;1[-;],2[-;]],1[-;]]") = true := by decide
#print axioms flat120
theorem flat121 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],2[-;]]" "3[-;3[-;1[-;],2[-;]],2[-;]]" "3[-;3[-;1[-;],2[-;]],2[-;]]") = true := by decide
#print axioms flat121
theorem flat122 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat122
theorem flat123 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat123
theorem flat124 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat124
theorem flat125 : replay (Observation.mk "4[-;1[-;],1[-;]]" "4[-;1[-;],1[-;]]" "4[-;1[-;],1[-;]]") = true := by decide
#print axioms flat125
theorem flat126 : replay (Observation.mk "4[-;1[-;],2[-;]]" "4[-;1[-;],2[-;]]" "4[-;1[-;],2[-;]]") = true := by decide
#print axioms flat126
theorem flat127 : replay (Observation.mk "4[-;1[-;],5[15:AlloySig:Person;]]" "4[-;1[-;],5[15:AlloySig:Person;]]" "4[-;1[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat127
theorem flat128 : replay (Observation.mk "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat128
theorem flat129 : replay (Observation.mk "4[-;1[-;],3[-;1[-;],2[-;]]]" "4[-;1[-;],3[-;1[-;],2[-;]]]" "4[-;1[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat129
theorem flat130 : replay (Observation.mk "4[-;2[-;],1[-;]]" "4[-;2[-;],1[-;]]" "4[-;2[-;],1[-;]]") = true := by decide
#print axioms flat130
theorem flat131 : replay (Observation.mk "4[-;2[-;],2[-;]]" "4[-;2[-;],2[-;]]" "4[-;2[-;],2[-;]]") = true := by decide
#print axioms flat131
theorem flat132 : replay (Observation.mk "4[-;2[-;],5[15:AlloySig:Person;]]" "4[-;2[-;],5[15:AlloySig:Person;]]" "4[-;2[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat132
theorem flat133 : replay (Observation.mk "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat133
theorem flat134 : replay (Observation.mk "4[-;2[-;],3[-;1[-;],2[-;]]]" "4[-;2[-;],3[-;1[-;],2[-;]]]" "4[-;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat134
theorem flat135 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],1[-;]]" "4[-;5[15:AlloySig:Person;],1[-;]]" "4[-;5[15:AlloySig:Person;],1[-;]]") = true := by decide
#print axioms flat135
theorem flat136 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],2[-;]]" "4[-;5[15:AlloySig:Person;],2[-;]]" "4[-;5[15:AlloySig:Person;],2[-;]]") = true := by decide
#print axioms flat136
theorem flat137 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat137
theorem flat138 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat138
theorem flat139 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat139
theorem flat140 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]") = true := by decide
#print axioms flat140
theorem flat141 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]") = true := by decide
#print axioms flat141
theorem flat142 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat142
theorem flat143 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat143
theorem flat144 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat144
theorem flat145 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],1[-;]]" "4[-;3[-;1[-;],2[-;]],1[-;]]" "4[-;3[-;1[-;],2[-;]],1[-;]]") = true := by decide
#print axioms flat145
theorem flat146 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],2[-;]]" "4[-;3[-;1[-;],2[-;]],2[-;]]" "4[-;3[-;1[-;],2[-;]],2[-;]]") = true := by decide
#print axioms flat146
theorem flat147 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat147
theorem flat148 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat148
theorem flat149 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat149
theorem flat150 : replay (Observation.mk "5[3:Box;1[-;],3[-;1[-;],1[-;]]]" "5[3:Box;1[-;],3[-;1[-;],1[-;]]]" "5[3:Box;1[-;],3[-;1[-;],1[-;]]]") = true := by decide
#print axioms flat150
theorem flat151 : replay (Observation.mk "5[3:Box;1[-;],3[-;2[-;],1[-;]]]" "5[3:Box;1[-;],3[-;2[-;],1[-;]]]" "5[3:Box;1[-;],3[-;2[-;],1[-;]]]") = true := by decide
#print axioms flat151
theorem flat152 : replay (Observation.mk "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]" "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]" "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]") = true := by decide
#print axioms flat152
theorem flat153 : replay (Observation.mk "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]" "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]" "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]") = true := by decide
#print axioms flat153
theorem flat154 : replay (Observation.mk "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]" "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]" "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]") = true := by decide
#print axioms flat154
theorem flat155 : replay (Observation.mk "5[3:Box;2[-;],3[-;1[-;],2[-;]]]" "5[3:Box;2[-;],3[-;1[-;],2[-;]]]" "5[3:Box;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat155
theorem flat156 : replay (Observation.mk "5[3:Box;2[-;],3[-;2[-;],2[-;]]]" "5[3:Box;2[-;],3[-;2[-;],2[-;]]]" "5[3:Box;2[-;],3[-;2[-;],2[-;]]]") = true := by decide
#print axioms flat156
theorem flat157 : replay (Observation.mk "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]" "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]" "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]") = true := by decide
#print axioms flat157
theorem flat158 : replay (Observation.mk "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]" "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]" "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]") = true := by decide
#print axioms flat158
theorem flat159 : replay (Observation.mk "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]" "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]" "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]") = true := by decide
#print axioms flat159
theorem flat160 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat160
theorem flat161 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat161
theorem flat162 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat162
theorem flat163 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat163
theorem flat164 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat164
theorem flat165 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat165
theorem flat166 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat166
theorem flat167 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat167
theorem flat168 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat168
theorem flat169 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat169
theorem flat170 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat170
theorem flat171 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat171
theorem flat172 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat172
theorem flat173 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat173
theorem flat174 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat174
theorem flat175 : replay (Observation.mk "4[-;5[4:Pair;1[-;],1[-;]]]" "4[-;5[4:Pair;1[-;],1[-;]]]" "4[-;5[4:Pair;1[-;],1[-;]]]") = true := by decide
#print axioms flat175
theorem flat176 : replay (Observation.mk "4[-;5[4:Pair;1[-;],2[-;]]]" "4[-;5[4:Pair;1[-;],2[-;]]]" "4[-;5[4:Pair;1[-;],2[-;]]]") = true := by decide
#print axioms flat176
theorem flat177 : replay (Observation.mk "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat177
theorem flat178 : replay (Observation.mk "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat178
theorem flat179 : replay (Observation.mk "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat179
theorem flat180 : replay (Observation.mk "4[-;5[4:Pair;2[-;],1[-;]]]" "4[-;5[4:Pair;2[-;],1[-;]]]" "4[-;5[4:Pair;2[-;],1[-;]]]") = true := by decide
#print axioms flat180
theorem flat181 : replay (Observation.mk "4[-;5[4:Pair;2[-;],2[-;]]]" "4[-;5[4:Pair;2[-;],2[-;]]]" "4[-;5[4:Pair;2[-;],2[-;]]]") = true := by decide
#print axioms flat181
theorem flat182 : replay (Observation.mk "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat182
theorem flat183 : replay (Observation.mk "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat183
theorem flat184 : replay (Observation.mk "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat184
theorem flat185 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]") = true := by decide
#print axioms flat185
theorem flat186 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]") = true := by decide
#print axioms flat186
theorem flat187 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat187
theorem flat188 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat188
theorem flat189 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat189
theorem flat190 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]") = true := by decide
#print axioms flat190
theorem flat191 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]") = true := by decide
#print axioms flat191
theorem flat192 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat192
theorem flat193 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat193
theorem flat194 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat194
theorem flat195 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]") = true := by decide
#print axioms flat195
theorem flat196 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]") = true := by decide
#print axioms flat196
theorem flat197 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat197
theorem flat198 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat198
theorem flat199 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat199
theorem flat200 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat200
theorem flat201 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat201
theorem flat202 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat202
theorem flat203 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat203
theorem flat204 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat204
theorem flat205 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat205
theorem flat206 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat206
theorem flat207 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat207
theorem flat208 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat208
theorem flat209 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat209
theorem flat210 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat210
theorem flat211 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat211
theorem flat212 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat212
theorem flat213 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat213
theorem flat214 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat214
theorem flat215 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat215
theorem flat216 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat216
theorem flat217 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat217
theorem flat218 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat218
theorem flat219 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat219
theorem flat220 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat220
theorem flat221 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat221
theorem flat222 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat222
theorem flat223 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat223
theorem flat224 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat224
theorem flat225 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat225
theorem flat226 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat226
theorem flat227 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat227
theorem flat228 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat228
theorem flat229 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat229
theorem flat230 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat230
theorem flat231 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat231
theorem flat232 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat232
theorem flat233 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat233
theorem flat234 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat234
theorem flat235 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat235
theorem flat236 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat236
theorem flat237 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat237
theorem flat238 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat238
theorem flat239 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat239
theorem flat240 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat240
theorem flat241 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat241
theorem flat242 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat242
theorem flat243 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat243
theorem flat244 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat244
theorem flat245 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat245
theorem flat246 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat246
theorem flat247 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat247
theorem flat248 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat248
theorem flat249 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat249
theorem flat250 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat250
theorem flat251 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat251
theorem flat252 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat252
theorem flat253 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat253
theorem flat254 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat254
theorem flat255 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat255
theorem flat256 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat256
theorem flat257 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat257
theorem flat258 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat258
theorem flat259 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat259
theorem flat260 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat260
theorem flat261 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat261
theorem flat262 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat262
theorem flat263 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat263
theorem flat264 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat264
theorem flat265 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat265
theorem flat266 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat266
theorem flat267 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat267
theorem flat268 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat268
theorem flat269 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat269
theorem flat270 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat270
theorem flat271 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat271
theorem flat272 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat272
theorem flat273 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat273
theorem flat274 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat274
theorem flat275 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat275
theorem flat276 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat276
theorem flat277 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat277
theorem flat278 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat278
theorem flat279 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat279
theorem flat280 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat280
theorem flat281 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat281
theorem flat282 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat282
theorem flat283 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat283
theorem flat284 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat284
theorem flat285 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat285
theorem flat286 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat286
theorem flat287 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat287
theorem flat288 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat288
theorem flat289 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat289
theorem flat290 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat290
theorem flat291 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat291
theorem flat292 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat292
theorem flat293 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat293
theorem flat294 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat294
theorem flat295 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat295
theorem flat296 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat296
theorem flat297 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat297
theorem flat298 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat298
theorem flat299 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat299
theorem flat300 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat300
theorem flat301 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat301
theorem flat302 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat302
theorem flat303 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat303
theorem flat304 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat304
theorem flat305 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat305
theorem flat306 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat306
theorem flat307 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat307
theorem flat308 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat308
theorem flat309 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat309
theorem flat310 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat310
theorem flat311 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat311
theorem flat312 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat312
theorem flat313 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat313
theorem flat314 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat314
theorem flat315 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat315
theorem flat316 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat316
theorem flat317 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat317
theorem flat318 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat318
theorem flat319 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat319
theorem flat320 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat320
theorem flat321 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat321
theorem flat322 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat322
theorem flat323 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat323
theorem flat324 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat324
theorem flat325 : replay (Observation.mk "3[-;1[-;],1[-;]]" "3[-;1[-;],1[-;]]" "3[-;1[-;],1[-;]]") = true := by decide
#print axioms flat325
theorem flat326 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat326
theorem flat327 : replay (Observation.mk "3[-;1[-;],5[15:AlloySig:Person;]]" "3[-;1[-;],5[15:AlloySig:Person;]]" "3[-;1[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat327
theorem flat328 : replay (Observation.mk "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat328
theorem flat329 : replay (Observation.mk "3[-;1[-;],3[-;1[-;],2[-;]]]" "3[-;1[-;],3[-;1[-;],2[-;]]]" "3[-;1[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat329
theorem flat330 : replay (Observation.mk "3[-;2[-;],1[-;]]" "3[-;2[-;],1[-;]]" "3[-;2[-;],1[-;]]") = true := by decide
#print axioms flat330
theorem flat331 : replay (Observation.mk "3[-;2[-;],2[-;]]" "3[-;2[-;],2[-;]]" "3[-;2[-;],2[-;]]") = true := by decide
#print axioms flat331
theorem flat332 : replay (Observation.mk "3[-;2[-;],5[15:AlloySig:Person;]]" "3[-;2[-;],5[15:AlloySig:Person;]]" "3[-;2[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat332
theorem flat333 : replay (Observation.mk "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat333
theorem flat334 : replay (Observation.mk "3[-;2[-;],3[-;1[-;],2[-;]]]" "3[-;2[-;],3[-;1[-;],2[-;]]]" "3[-;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat334
theorem flat335 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],1[-;]]" "3[-;5[15:AlloySig:Person;],1[-;]]" "3[-;5[15:AlloySig:Person;],1[-;]]") = true := by decide
#print axioms flat335
theorem flat336 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],2[-;]]" "3[-;5[15:AlloySig:Person;],2[-;]]" "3[-;5[15:AlloySig:Person;],2[-;]]") = true := by decide
#print axioms flat336
theorem flat337 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat337
theorem flat338 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat338
theorem flat339 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat339
theorem flat340 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]") = true := by decide
#print axioms flat340
theorem flat341 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]") = true := by decide
#print axioms flat341
theorem flat342 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat342
theorem flat343 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat343
theorem flat344 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat344
theorem flat345 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],1[-;]]" "3[-;3[-;1[-;],2[-;]],1[-;]]" "3[-;3[-;1[-;],2[-;]],1[-;]]") = true := by decide
#print axioms flat345
theorem flat346 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],2[-;]]" "3[-;3[-;1[-;],2[-;]],2[-;]]" "3[-;3[-;1[-;],2[-;]],2[-;]]") = true := by decide
#print axioms flat346
theorem flat347 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat347
theorem flat348 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat348
theorem flat349 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat349
theorem flat350 : replay (Observation.mk "4[-;1[-;],1[-;]]" "4[-;1[-;],1[-;]]" "4[-;1[-;],1[-;]]") = true := by decide
#print axioms flat350
theorem flat351 : replay (Observation.mk "4[-;1[-;],2[-;]]" "4[-;1[-;],2[-;]]" "4[-;1[-;],2[-;]]") = true := by decide
#print axioms flat351
theorem flat352 : replay (Observation.mk "4[-;1[-;],5[15:AlloySig:Person;]]" "4[-;1[-;],5[15:AlloySig:Person;]]" "4[-;1[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat352
theorem flat353 : replay (Observation.mk "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat353
theorem flat354 : replay (Observation.mk "4[-;1[-;],3[-;1[-;],2[-;]]]" "4[-;1[-;],3[-;1[-;],2[-;]]]" "4[-;1[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat354
theorem flat355 : replay (Observation.mk "4[-;2[-;],1[-;]]" "4[-;2[-;],1[-;]]" "4[-;2[-;],1[-;]]") = true := by decide
#print axioms flat355
theorem flat356 : replay (Observation.mk "4[-;2[-;],2[-;]]" "4[-;2[-;],2[-;]]" "4[-;2[-;],2[-;]]") = true := by decide
#print axioms flat356
theorem flat357 : replay (Observation.mk "4[-;2[-;],5[15:AlloySig:Person;]]" "4[-;2[-;],5[15:AlloySig:Person;]]" "4[-;2[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat357
theorem flat358 : replay (Observation.mk "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat358
theorem flat359 : replay (Observation.mk "4[-;2[-;],3[-;1[-;],2[-;]]]" "4[-;2[-;],3[-;1[-;],2[-;]]]" "4[-;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat359
theorem flat360 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],1[-;]]" "4[-;5[15:AlloySig:Person;],1[-;]]" "4[-;5[15:AlloySig:Person;],1[-;]]") = true := by decide
#print axioms flat360
theorem flat361 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],2[-;]]" "4[-;5[15:AlloySig:Person;],2[-;]]" "4[-;5[15:AlloySig:Person;],2[-;]]") = true := by decide
#print axioms flat361
theorem flat362 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat362
theorem flat363 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat363
theorem flat364 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat364
theorem flat365 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]") = true := by decide
#print axioms flat365
theorem flat366 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]") = true := by decide
#print axioms flat366
theorem flat367 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat367
theorem flat368 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat368
theorem flat369 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat369
theorem flat370 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],1[-;]]" "4[-;3[-;1[-;],2[-;]],1[-;]]" "4[-;3[-;1[-;],2[-;]],1[-;]]") = true := by decide
#print axioms flat370
theorem flat371 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],2[-;]]" "4[-;3[-;1[-;],2[-;]],2[-;]]" "4[-;3[-;1[-;],2[-;]],2[-;]]") = true := by decide
#print axioms flat371
theorem flat372 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat372
theorem flat373 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat373
theorem flat374 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat374
theorem flat375 : replay (Observation.mk "5[3:Box;1[-;],3[-;1[-;],1[-;]]]" "5[3:Box;1[-;],3[-;1[-;],1[-;]]]" "5[3:Box;1[-;],3[-;1[-;],1[-;]]]") = true := by decide
#print axioms flat375
theorem flat376 : replay (Observation.mk "5[3:Box;1[-;],3[-;2[-;],1[-;]]]" "5[3:Box;1[-;],3[-;2[-;],1[-;]]]" "5[3:Box;1[-;],3[-;2[-;],1[-;]]]") = true := by decide
#print axioms flat376
theorem flat377 : replay (Observation.mk "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]" "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]" "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]") = true := by decide
#print axioms flat377
theorem flat378 : replay (Observation.mk "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]" "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]" "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]") = true := by decide
#print axioms flat378
theorem flat379 : replay (Observation.mk "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]" "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]" "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]") = true := by decide
#print axioms flat379
theorem flat380 : replay (Observation.mk "5[3:Box;2[-;],3[-;1[-;],2[-;]]]" "5[3:Box;2[-;],3[-;1[-;],2[-;]]]" "5[3:Box;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat380
theorem flat381 : replay (Observation.mk "5[3:Box;2[-;],3[-;2[-;],2[-;]]]" "5[3:Box;2[-;],3[-;2[-;],2[-;]]]" "5[3:Box;2[-;],3[-;2[-;],2[-;]]]") = true := by decide
#print axioms flat381
theorem flat382 : replay (Observation.mk "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]" "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]" "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]") = true := by decide
#print axioms flat382
theorem flat383 : replay (Observation.mk "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]" "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]" "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]") = true := by decide
#print axioms flat383
theorem flat384 : replay (Observation.mk "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]" "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]" "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]") = true := by decide
#print axioms flat384
theorem flat385 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat385
theorem flat386 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat386
theorem flat387 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat387
theorem flat388 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat388
theorem flat389 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat389
theorem flat390 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat390
theorem flat391 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat391
theorem flat392 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat392
theorem flat393 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat393
theorem flat394 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat394
theorem flat395 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat395
theorem flat396 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat396
theorem flat397 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat397
theorem flat398 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat398
theorem flat399 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat399
theorem flat400 : replay (Observation.mk "4[-;5[4:Pair;1[-;],1[-;]]]" "4[-;5[4:Pair;1[-;],1[-;]]]" "4[-;5[4:Pair;1[-;],1[-;]]]") = true := by decide
#print axioms flat400
theorem flat401 : replay (Observation.mk "4[-;5[4:Pair;1[-;],2[-;]]]" "4[-;5[4:Pair;1[-;],2[-;]]]" "4[-;5[4:Pair;1[-;],2[-;]]]") = true := by decide
#print axioms flat401
theorem flat402 : replay (Observation.mk "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat402
theorem flat403 : replay (Observation.mk "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat403
theorem flat404 : replay (Observation.mk "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat404
theorem flat405 : replay (Observation.mk "4[-;5[4:Pair;2[-;],1[-;]]]" "4[-;5[4:Pair;2[-;],1[-;]]]" "4[-;5[4:Pair;2[-;],1[-;]]]") = true := by decide
#print axioms flat405
theorem flat406 : replay (Observation.mk "4[-;5[4:Pair;2[-;],2[-;]]]" "4[-;5[4:Pair;2[-;],2[-;]]]" "4[-;5[4:Pair;2[-;],2[-;]]]") = true := by decide
#print axioms flat406
theorem flat407 : replay (Observation.mk "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat407
theorem flat408 : replay (Observation.mk "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat408
theorem flat409 : replay (Observation.mk "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat409
theorem flat410 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]") = true := by decide
#print axioms flat410
theorem flat411 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]") = true := by decide
#print axioms flat411
theorem flat412 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat412
theorem flat413 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat413
theorem flat414 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat414
theorem flat415 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]") = true := by decide
#print axioms flat415
theorem flat416 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]") = true := by decide
#print axioms flat416
theorem flat417 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat417
theorem flat418 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat418
theorem flat419 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat419
theorem flat420 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]") = true := by decide
#print axioms flat420
theorem flat421 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]") = true := by decide
#print axioms flat421
theorem flat422 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat422
theorem flat423 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat423
theorem flat424 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat424
theorem flat425 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat425
theorem flat426 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat426
theorem flat427 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat427
theorem flat428 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat428
theorem flat429 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat429
theorem flat430 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat430
theorem flat431 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat431
theorem flat432 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat432
theorem flat433 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat433
theorem flat434 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat434
theorem flat435 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat435
theorem flat436 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat436
theorem flat437 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat437
theorem flat438 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat438
theorem flat439 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat439
theorem flat440 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat440
theorem flat441 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat441
theorem flat442 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat442
theorem flat443 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat443
theorem flat444 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat444
theorem flat445 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat445
theorem flat446 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat446
theorem flat447 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat447
theorem flat448 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat448
theorem flat449 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat449
theorem flat450 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat450
theorem flat451 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat451
theorem flat452 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat452
theorem flat453 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat453
theorem flat454 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat454
theorem flat455 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat455
theorem flat456 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat456
theorem flat457 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat457
theorem flat458 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat458
theorem flat459 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat459
theorem flat460 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat460
theorem flat461 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat461
theorem flat462 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat462
theorem flat463 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat463
theorem flat464 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat464
theorem flat465 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat465
theorem flat466 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat466
theorem flat467 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat467
theorem flat468 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat468
theorem flat469 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat469
theorem flat470 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat470
theorem flat471 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat471
theorem flat472 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat472
theorem flat473 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat473
theorem flat474 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat474
theorem flat475 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat475
theorem flat476 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat476
theorem flat477 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat477
theorem flat478 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat478
theorem flat479 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat479
theorem flat480 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat480
theorem flat481 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat481
theorem flat482 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat482
theorem flat483 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat483
theorem flat484 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat484
theorem flat485 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat485
theorem flat486 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat486
theorem flat487 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat487
theorem flat488 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat488
theorem flat489 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat489
theorem flat490 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat490
theorem flat491 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat491
theorem flat492 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat492
theorem flat493 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat493
theorem flat494 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat494
theorem flat495 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat495
theorem flat496 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat496
theorem flat497 : replay (Observation.mk "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]" "5[15:AlloySig:Person;]") = true := by decide
#print axioms flat497
theorem flat498 : replay (Observation.mk "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat498
theorem flat499 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat499
theorem flat500 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat500
theorem flat501 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat501
theorem flat502 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat502
theorem flat503 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat503
theorem flat504 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat504
theorem flat505 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat505
theorem flat506 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat506
theorem flat507 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat507
theorem flat508 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat508
theorem flat509 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat509
theorem flat510 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat510
theorem flat511 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat511
theorem flat512 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat512
theorem flat513 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat513
theorem flat514 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat514
theorem flat515 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat515
theorem flat516 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat516
theorem flat517 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat517
theorem flat518 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat518
theorem flat519 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat519
theorem flat520 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat520
theorem flat521 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat521
theorem flat522 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat522
theorem flat523 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat523
theorem flat524 : replay (Observation.mk "1[-;]" "1[-;]" "1[-;]") = true := by decide
#print axioms flat524
theorem flat525 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat525
theorem flat526 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat526
theorem flat527 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat527
theorem flat528 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat528
theorem flat529 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat529
theorem flat530 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat530
theorem flat531 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat531
theorem flat532 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat532
theorem flat533 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat533
theorem flat534 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat534
theorem flat535 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat535
theorem flat536 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat536
theorem flat537 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat537
theorem flat538 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat538
theorem flat539 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat539
theorem flat540 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat540
theorem flat541 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat541
theorem flat542 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat542
theorem flat543 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat543
theorem flat544 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat544
theorem flat545 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat545
theorem flat546 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat546
theorem flat547 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat547
theorem flat548 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat548
theorem flat549 : replay (Observation.mk "2[-;]" "2[-;]" "2[-;]") = true := by decide
#print axioms flat549
theorem flat550 : replay (Observation.mk "3[-;1[-;],1[-;]]" "3[-;1[-;],1[-;]]" "3[-;1[-;],1[-;]]") = true := by decide
#print axioms flat550
theorem flat551 : replay (Observation.mk "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]" "3[-;1[-;],2[-;]]") = true := by decide
#print axioms flat551
theorem flat552 : replay (Observation.mk "3[-;1[-;],5[15:AlloySig:Person;]]" "3[-;1[-;],5[15:AlloySig:Person;]]" "3[-;1[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat552
theorem flat553 : replay (Observation.mk "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;1[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat553
theorem flat554 : replay (Observation.mk "3[-;1[-;],3[-;1[-;],2[-;]]]" "3[-;1[-;],3[-;1[-;],2[-;]]]" "3[-;1[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat554
theorem flat555 : replay (Observation.mk "3[-;2[-;],1[-;]]" "3[-;2[-;],1[-;]]" "3[-;2[-;],1[-;]]") = true := by decide
#print axioms flat555
theorem flat556 : replay (Observation.mk "3[-;2[-;],2[-;]]" "3[-;2[-;],2[-;]]" "3[-;2[-;],2[-;]]") = true := by decide
#print axioms flat556
theorem flat557 : replay (Observation.mk "3[-;2[-;],5[15:AlloySig:Person;]]" "3[-;2[-;],5[15:AlloySig:Person;]]" "3[-;2[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat557
theorem flat558 : replay (Observation.mk "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "3[-;2[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat558
theorem flat559 : replay (Observation.mk "3[-;2[-;],3[-;1[-;],2[-;]]]" "3[-;2[-;],3[-;1[-;],2[-;]]]" "3[-;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat559
theorem flat560 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],1[-;]]" "3[-;5[15:AlloySig:Person;],1[-;]]" "3[-;5[15:AlloySig:Person;],1[-;]]") = true := by decide
#print axioms flat560
theorem flat561 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],2[-;]]" "3[-;5[15:AlloySig:Person;],2[-;]]" "3[-;5[15:AlloySig:Person;],2[-;]]") = true := by decide
#print axioms flat561
theorem flat562 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat562
theorem flat563 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat563
theorem flat564 : replay (Observation.mk "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat564
theorem flat565 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],1[-;]]") = true := by decide
#print axioms flat565
theorem flat566 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "3[-;4[-;5[15:AlloySig:Person;]],2[-;]]") = true := by decide
#print axioms flat566
theorem flat567 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat567
theorem flat568 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat568
theorem flat569 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat569
theorem flat570 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],1[-;]]" "3[-;3[-;1[-;],2[-;]],1[-;]]" "3[-;3[-;1[-;],2[-;]],1[-;]]") = true := by decide
#print axioms flat570
theorem flat571 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],2[-;]]" "3[-;3[-;1[-;],2[-;]],2[-;]]" "3[-;3[-;1[-;],2[-;]],2[-;]]") = true := by decide
#print axioms flat571
theorem flat572 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat572
theorem flat573 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat573
theorem flat574 : replay (Observation.mk "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat574
theorem flat575 : replay (Observation.mk "4[-;1[-;],1[-;]]" "4[-;1[-;],1[-;]]" "4[-;1[-;],1[-;]]") = true := by decide
#print axioms flat575
theorem flat576 : replay (Observation.mk "4[-;1[-;],2[-;]]" "4[-;1[-;],2[-;]]" "4[-;1[-;],2[-;]]") = true := by decide
#print axioms flat576
theorem flat577 : replay (Observation.mk "4[-;1[-;],5[15:AlloySig:Person;]]" "4[-;1[-;],5[15:AlloySig:Person;]]" "4[-;1[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat577
theorem flat578 : replay (Observation.mk "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;1[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat578
theorem flat579 : replay (Observation.mk "4[-;1[-;],3[-;1[-;],2[-;]]]" "4[-;1[-;],3[-;1[-;],2[-;]]]" "4[-;1[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat579
theorem flat580 : replay (Observation.mk "4[-;2[-;],1[-;]]" "4[-;2[-;],1[-;]]" "4[-;2[-;],1[-;]]") = true := by decide
#print axioms flat580
theorem flat581 : replay (Observation.mk "4[-;2[-;],2[-;]]" "4[-;2[-;],2[-;]]" "4[-;2[-;],2[-;]]") = true := by decide
#print axioms flat581
theorem flat582 : replay (Observation.mk "4[-;2[-;],5[15:AlloySig:Person;]]" "4[-;2[-;],5[15:AlloySig:Person;]]" "4[-;2[-;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat582
theorem flat583 : replay (Observation.mk "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]" "4[-;2[-;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat583
theorem flat584 : replay (Observation.mk "4[-;2[-;],3[-;1[-;],2[-;]]]" "4[-;2[-;],3[-;1[-;],2[-;]]]" "4[-;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat584
theorem flat585 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],1[-;]]" "4[-;5[15:AlloySig:Person;],1[-;]]" "4[-;5[15:AlloySig:Person;],1[-;]]") = true := by decide
#print axioms flat585
theorem flat586 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],2[-;]]" "4[-;5[15:AlloySig:Person;],2[-;]]" "4[-;5[15:AlloySig:Person;],2[-;]]") = true := by decide
#print axioms flat586
theorem flat587 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]" "4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat587
theorem flat588 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]" "4[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat588
theorem flat589 : replay (Observation.mk "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]" "4[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat589
theorem flat590 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],1[-;]]") = true := by decide
#print axioms flat590
theorem flat591 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]" "4[-;4[-;5[15:AlloySig:Person;]],2[-;]]") = true := by decide
#print axioms flat591
theorem flat592 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]" "4[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat592
theorem flat593 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]" "4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat593
theorem flat594 : replay (Observation.mk "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]" "4[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat594
theorem flat595 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],1[-;]]" "4[-;3[-;1[-;],2[-;]],1[-;]]" "4[-;3[-;1[-;],2[-;]],1[-;]]") = true := by decide
#print axioms flat595
theorem flat596 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],2[-;]]" "4[-;3[-;1[-;],2[-;]],2[-;]]" "4[-;3[-;1[-;],2[-;]],2[-;]]") = true := by decide
#print axioms flat596
theorem flat597 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]" "4[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]") = true := by decide
#print axioms flat597
theorem flat598 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]" "4[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat598
theorem flat599 : replay (Observation.mk "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]" "4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat599
theorem flat600 : replay (Observation.mk "5[3:Box;1[-;],3[-;1[-;],1[-;]]]" "5[3:Box;1[-;],3[-;1[-;],1[-;]]]" "5[3:Box;1[-;],3[-;1[-;],1[-;]]]") = true := by decide
#print axioms flat600
theorem flat601 : replay (Observation.mk "5[3:Box;1[-;],3[-;2[-;],1[-;]]]" "5[3:Box;1[-;],3[-;2[-;],1[-;]]]" "5[3:Box;1[-;],3[-;2[-;],1[-;]]]") = true := by decide
#print axioms flat601
theorem flat602 : replay (Observation.mk "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]" "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]" "5[3:Box;1[-;],3[-;5[15:AlloySig:Person;],1[-;]]]") = true := by decide
#print axioms flat602
theorem flat603 : replay (Observation.mk "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]" "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]" "5[3:Box;1[-;],3[-;4[-;5[15:AlloySig:Person;]],1[-;]]]") = true := by decide
#print axioms flat603
theorem flat604 : replay (Observation.mk "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]" "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]" "5[3:Box;1[-;],3[-;3[-;1[-;],2[-;]],1[-;]]]") = true := by decide
#print axioms flat604
theorem flat605 : replay (Observation.mk "5[3:Box;2[-;],3[-;1[-;],2[-;]]]" "5[3:Box;2[-;],3[-;1[-;],2[-;]]]" "5[3:Box;2[-;],3[-;1[-;],2[-;]]]") = true := by decide
#print axioms flat605
theorem flat606 : replay (Observation.mk "5[3:Box;2[-;],3[-;2[-;],2[-;]]]" "5[3:Box;2[-;],3[-;2[-;],2[-;]]]" "5[3:Box;2[-;],3[-;2[-;],2[-;]]]") = true := by decide
#print axioms flat606
theorem flat607 : replay (Observation.mk "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]" "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]" "5[3:Box;2[-;],3[-;5[15:AlloySig:Person;],2[-;]]]") = true := by decide
#print axioms flat607
theorem flat608 : replay (Observation.mk "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]" "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]" "5[3:Box;2[-;],3[-;4[-;5[15:AlloySig:Person;]],2[-;]]]") = true := by decide
#print axioms flat608
theorem flat609 : replay (Observation.mk "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]" "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]" "5[3:Box;2[-;],3[-;3[-;1[-;],2[-;]],2[-;]]]") = true := by decide
#print axioms flat609
theorem flat610 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;1[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat610
theorem flat611 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;2[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat611
theorem flat612 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat612
theorem flat613 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat613
theorem flat614 : replay (Observation.mk "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "5[3:Box;5[15:AlloySig:Person;],3[-;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat614
theorem flat615 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;1[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat615
theorem flat616 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;2[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat616
theorem flat617 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat617
theorem flat618 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat618
theorem flat619 : replay (Observation.mk "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "5[3:Box;4[-;5[15:AlloySig:Person;]],3[-;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat619
theorem flat620 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;1[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat620
theorem flat621 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;2[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat621
theorem flat622 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat622
theorem flat623 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat623
theorem flat624 : replay (Observation.mk "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "5[3:Box;3[-;1[-;],2[-;]],3[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat624
theorem flat625 : replay (Observation.mk "4[-;5[4:Pair;1[-;],1[-;]]]" "4[-;5[4:Pair;1[-;],1[-;]]]" "4[-;5[4:Pair;1[-;],1[-;]]]") = true := by decide
#print axioms flat625
theorem flat626 : replay (Observation.mk "4[-;5[4:Pair;1[-;],2[-;]]]" "4[-;5[4:Pair;1[-;],2[-;]]]" "4[-;5[4:Pair;1[-;],2[-;]]]") = true := by decide
#print axioms flat626
theorem flat627 : replay (Observation.mk "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;1[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat627
theorem flat628 : replay (Observation.mk "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;1[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat628
theorem flat629 : replay (Observation.mk "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;1[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat629
theorem flat630 : replay (Observation.mk "4[-;5[4:Pair;2[-;],1[-;]]]" "4[-;5[4:Pair;2[-;],1[-;]]]" "4[-;5[4:Pair;2[-;],1[-;]]]") = true := by decide
#print axioms flat630
theorem flat631 : replay (Observation.mk "4[-;5[4:Pair;2[-;],2[-;]]]" "4[-;5[4:Pair;2[-;],2[-;]]]" "4[-;5[4:Pair;2[-;],2[-;]]]") = true := by decide
#print axioms flat631
theorem flat632 : replay (Observation.mk "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;2[-;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat632
theorem flat633 : replay (Observation.mk "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;2[-;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat633
theorem flat634 : replay (Observation.mk "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;2[-;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat634
theorem flat635 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],1[-;]]]") = true := by decide
#print axioms flat635
theorem flat636 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],2[-;]]]") = true := by decide
#print axioms flat636
theorem flat637 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat637
theorem flat638 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat638
theorem flat639 : replay (Observation.mk "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;5[15:AlloySig:Person;],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat639
theorem flat640 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],1[-;]]]") = true := by decide
#print axioms flat640
theorem flat641 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],2[-;]]]") = true := by decide
#print axioms flat641
theorem flat642 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat642
theorem flat643 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat643
theorem flat644 : replay (Observation.mk "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;4[-;5[15:AlloySig:Person;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat644
theorem flat645 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],1[-;]]]") = true := by decide
#print axioms flat645
theorem flat646 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],2[-;]]]") = true := by decide
#print axioms flat646
theorem flat647 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat647
theorem flat648 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat648
theorem flat649 : replay (Observation.mk "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]" "4[-;5[4:Pair;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat649
theorem flat650 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat650
theorem flat651 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat651
theorem flat652 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat652
theorem flat653 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat653
theorem flat654 : replay (Observation.mk "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;1[-;],1[-;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat654
theorem flat655 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat655
theorem flat656 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat656
theorem flat657 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat657
theorem flat658 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat658
theorem flat659 : replay (Observation.mk "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;2[-;],2[-;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat659
theorem flat660 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat660
theorem flat661 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat661
theorem flat662 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat662
theorem flat663 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat663
theorem flat664 : replay (Observation.mk "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;5[15:AlloySig:Person;],5[15:AlloySig:Person;]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat664
theorem flat665 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat665
theorem flat666 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat666
theorem flat667 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat667
theorem flat668 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat668
theorem flat669 : replay (Observation.mk "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;4[-;5[15:AlloySig:Person;]],4[-;5[15:AlloySig:Person;]]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat669
theorem flat670 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;1[-;]]]") = true := by decide
#print axioms flat670
theorem flat671 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;2[-;]]]") = true := by decide
#print axioms flat671
theorem flat672 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;5[15:AlloySig:Person;]]]") = true := by decide
#print axioms flat672
theorem flat673 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;4[-;5[15:AlloySig:Person;]]]]") = true := by decide
#print axioms flat673
theorem flat674 : replay (Observation.mk "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]" "3[-;4[-;3[-;1[-;],2[-;]],3[-;1[-;],2[-;]]],5[3:Box;3[-;1[-;],2[-;]]]]") = true := by decide
#print axioms flat674
