import DependentChainSequence
open ACGN.Section3.DependentChainSequence
def tree0 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 0))
def target0 : Target Nat := ⟨.seq, [0, 0]⟩
theorem chain0 : accepts tree0 target0 = true ∧
    sourceLeaves tree0 = [0, 0] ∧
    target0.elements.length = 2 ∧
    [target0.elements.count 0, target0.elements.count 1,
      target0.elements.count 2] = [2, 0, 0] := by decide
#print axioms chain0
def tree1 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def target1 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain1 : accepts tree1 target1 = true ∧
    sourceLeaves tree1 = [0, 1] ∧
    target1.elements.length = 2 ∧
    [target1.elements.count 0, target1.elements.count 1,
      target1.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1
def tree2 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 2))
def target2 : Target Nat := ⟨.seq, [0, 2]⟩
theorem chain2 : accepts tree2 target2 = true ∧
    sourceLeaves tree2 = [0, 2] ∧
    target2.elements.length = 2 ∧
    [target2.elements.count 0, target2.elements.count 1,
      target2.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain2
def tree3 : SourceTree Nat .join := (.app .join (.leaf 1) (.leaf 0))
def target3 : Target Nat := ⟨.seq, [1, 0]⟩
theorem chain3 : accepts tree3 target3 = true ∧
    sourceLeaves tree3 = [1, 0] ∧
    target3.elements.length = 2 ∧
    [target3.elements.count 0, target3.elements.count 1,
      target3.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain3
def tree4 : SourceTree Nat .join := (.app .join (.leaf 1) (.leaf 1))
def target4 : Target Nat := ⟨.seq, [1, 1]⟩
theorem chain4 : accepts tree4 target4 = true ∧
    sourceLeaves tree4 = [1, 1] ∧
    target4.elements.length = 2 ∧
    [target4.elements.count 0, target4.elements.count 1,
      target4.elements.count 2] = [0, 2, 0] := by decide
#print axioms chain4
def tree5 : SourceTree Nat .join := (.app .join (.leaf 1) (.leaf 2))
def target5 : Target Nat := ⟨.seq, [1, 2]⟩
theorem chain5 : accepts tree5 target5 = true ∧
    sourceLeaves tree5 = [1, 2] ∧
    target5.elements.length = 2 ∧
    [target5.elements.count 0, target5.elements.count 1,
      target5.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain5
def tree6 : SourceTree Nat .join := (.app .join (.leaf 2) (.leaf 0))
def target6 : Target Nat := ⟨.seq, [2, 0]⟩
theorem chain6 : accepts tree6 target6 = true ∧
    sourceLeaves tree6 = [2, 0] ∧
    target6.elements.length = 2 ∧
    [target6.elements.count 0, target6.elements.count 1,
      target6.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain6
def tree7 : SourceTree Nat .join := (.app .join (.leaf 2) (.leaf 1))
def target7 : Target Nat := ⟨.seq, [2, 1]⟩
theorem chain7 : accepts tree7 target7 = true ∧
    sourceLeaves tree7 = [2, 1] ∧
    target7.elements.length = 2 ∧
    [target7.elements.count 0, target7.elements.count 1,
      target7.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain7
def tree8 : SourceTree Nat .join := (.app .join (.leaf 2) (.leaf 2))
def target8 : Target Nat := ⟨.seq, [2, 2]⟩
theorem chain8 : accepts tree8 target8 = true ∧
    sourceLeaves tree8 = [2, 2] ∧
    target8.elements.length = 2 ∧
    [target8.elements.count 0, target8.elements.count 1,
      target8.elements.count 2] = [0, 0, 2] := by decide
#print axioms chain8
def tree9 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0)))
def target9 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain9 : accepts tree9 target9 = true ∧
    sourceLeaves tree9 = [0, 0, 0] ∧
    target9.elements.length = 3 ∧
    [target9.elements.count 0, target9.elements.count 1,
      target9.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain9
def tree10 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0))
def target10 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain10 : accepts tree10 target10 = true ∧
    sourceLeaves tree10 = [0, 0, 0] ∧
    target10.elements.length = 3 ∧
    [target10.elements.count 0, target10.elements.count 1,
      target10.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain10
def tree11 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1)))
def target11 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain11 : accepts tree11 target11 = true ∧
    sourceLeaves tree11 = [0, 0, 1] ∧
    target11.elements.length = 3 ∧
    [target11.elements.count 0, target11.elements.count 1,
      target11.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain11
def tree12 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1))
def target12 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain12 : accepts tree12 target12 = true ∧
    sourceLeaves tree12 = [0, 0, 1] ∧
    target12.elements.length = 3 ∧
    [target12.elements.count 0, target12.elements.count 1,
      target12.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain12
def tree13 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2)))
def target13 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain13 : accepts tree13 target13 = true ∧
    sourceLeaves tree13 = [0, 0, 2] ∧
    target13.elements.length = 3 ∧
    [target13.elements.count 0, target13.elements.count 1,
      target13.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain13
def tree14 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2))
def target14 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain14 : accepts tree14 target14 = true ∧
    sourceLeaves tree14 = [0, 0, 2] ∧
    target14.elements.length = 3 ∧
    [target14.elements.count 0, target14.elements.count 1,
      target14.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain14
def tree15 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0)))
def target15 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain15 : accepts tree15 target15 = true ∧
    sourceLeaves tree15 = [0, 1, 0] ∧
    target15.elements.length = 3 ∧
    [target15.elements.count 0, target15.elements.count 1,
      target15.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain15
def tree16 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0))
def target16 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain16 : accepts tree16 target16 = true ∧
    sourceLeaves tree16 = [0, 1, 0] ∧
    target16.elements.length = 3 ∧
    [target16.elements.count 0, target16.elements.count 1,
      target16.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain16
def tree17 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1)))
def target17 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain17 : accepts tree17 target17 = true ∧
    sourceLeaves tree17 = [0, 1, 1] ∧
    target17.elements.length = 3 ∧
    [target17.elements.count 0, target17.elements.count 1,
      target17.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain17
def tree18 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1))
def target18 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain18 : accepts tree18 target18 = true ∧
    sourceLeaves tree18 = [0, 1, 1] ∧
    target18.elements.length = 3 ∧
    [target18.elements.count 0, target18.elements.count 1,
      target18.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain18
def tree19 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def target19 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain19 : accepts tree19 target19 = true ∧
    sourceLeaves tree19 = [0, 1, 2] ∧
    target19.elements.length = 3 ∧
    [target19.elements.count 0, target19.elements.count 1,
      target19.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain19
def tree20 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def target20 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain20 : accepts tree20 target20 = true ∧
    sourceLeaves tree20 = [0, 1, 2] ∧
    target20.elements.length = 3 ∧
    [target20.elements.count 0, target20.elements.count 1,
      target20.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain20
def tree21 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0)))
def target21 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain21 : accepts tree21 target21 = true ∧
    sourceLeaves tree21 = [0, 2, 0] ∧
    target21.elements.length = 3 ∧
    [target21.elements.count 0, target21.elements.count 1,
      target21.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain21
def tree22 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0))
def target22 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain22 : accepts tree22 target22 = true ∧
    sourceLeaves tree22 = [0, 2, 0] ∧
    target22.elements.length = 3 ∧
    [target22.elements.count 0, target22.elements.count 1,
      target22.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain22
def tree23 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1)))
def target23 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain23 : accepts tree23 target23 = true ∧
    sourceLeaves tree23 = [0, 2, 1] ∧
    target23.elements.length = 3 ∧
    [target23.elements.count 0, target23.elements.count 1,
      target23.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain23
def tree24 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1))
def target24 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain24 : accepts tree24 target24 = true ∧
    sourceLeaves tree24 = [0, 2, 1] ∧
    target24.elements.length = 3 ∧
    [target24.elements.count 0, target24.elements.count 1,
      target24.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain24
def tree25 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2)))
def target25 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain25 : accepts tree25 target25 = true ∧
    sourceLeaves tree25 = [0, 2, 2] ∧
    target25.elements.length = 3 ∧
    [target25.elements.count 0, target25.elements.count 1,
      target25.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain25
def tree26 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2))
def target26 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain26 : accepts tree26 target26 = true ∧
    sourceLeaves tree26 = [0, 2, 2] ∧
    target26.elements.length = 3 ∧
    [target26.elements.count 0, target26.elements.count 1,
      target26.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain26
def tree27 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0)))
def target27 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain27 : accepts tree27 target27 = true ∧
    sourceLeaves tree27 = [1, 0, 0] ∧
    target27.elements.length = 3 ∧
    [target27.elements.count 0, target27.elements.count 1,
      target27.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain27
def tree28 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0))
def target28 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain28 : accepts tree28 target28 = true ∧
    sourceLeaves tree28 = [1, 0, 0] ∧
    target28.elements.length = 3 ∧
    [target28.elements.count 0, target28.elements.count 1,
      target28.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain28
def tree29 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1)))
def target29 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain29 : accepts tree29 target29 = true ∧
    sourceLeaves tree29 = [1, 0, 1] ∧
    target29.elements.length = 3 ∧
    [target29.elements.count 0, target29.elements.count 1,
      target29.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain29
def tree30 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1))
def target30 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain30 : accepts tree30 target30 = true ∧
    sourceLeaves tree30 = [1, 0, 1] ∧
    target30.elements.length = 3 ∧
    [target30.elements.count 0, target30.elements.count 1,
      target30.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain30
def tree31 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2)))
def target31 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain31 : accepts tree31 target31 = true ∧
    sourceLeaves tree31 = [1, 0, 2] ∧
    target31.elements.length = 3 ∧
    [target31.elements.count 0, target31.elements.count 1,
      target31.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain31
def tree32 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2))
def target32 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain32 : accepts tree32 target32 = true ∧
    sourceLeaves tree32 = [1, 0, 2] ∧
    target32.elements.length = 3 ∧
    [target32.elements.count 0, target32.elements.count 1,
      target32.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain32
def tree33 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0)))
def target33 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain33 : accepts tree33 target33 = true ∧
    sourceLeaves tree33 = [1, 1, 0] ∧
    target33.elements.length = 3 ∧
    [target33.elements.count 0, target33.elements.count 1,
      target33.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain33
def tree34 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0))
def target34 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain34 : accepts tree34 target34 = true ∧
    sourceLeaves tree34 = [1, 1, 0] ∧
    target34.elements.length = 3 ∧
    [target34.elements.count 0, target34.elements.count 1,
      target34.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain34
def tree35 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1)))
def target35 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain35 : accepts tree35 target35 = true ∧
    sourceLeaves tree35 = [1, 1, 1] ∧
    target35.elements.length = 3 ∧
    [target35.elements.count 0, target35.elements.count 1,
      target35.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain35
def tree36 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1))
def target36 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain36 : accepts tree36 target36 = true ∧
    sourceLeaves tree36 = [1, 1, 1] ∧
    target36.elements.length = 3 ∧
    [target36.elements.count 0, target36.elements.count 1,
      target36.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain36
def tree37 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2)))
def target37 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain37 : accepts tree37 target37 = true ∧
    sourceLeaves tree37 = [1, 1, 2] ∧
    target37.elements.length = 3 ∧
    [target37.elements.count 0, target37.elements.count 1,
      target37.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain37
def tree38 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2))
def target38 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain38 : accepts tree38 target38 = true ∧
    sourceLeaves tree38 = [1, 1, 2] ∧
    target38.elements.length = 3 ∧
    [target38.elements.count 0, target38.elements.count 1,
      target38.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain38
def tree39 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0)))
def target39 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain39 : accepts tree39 target39 = true ∧
    sourceLeaves tree39 = [1, 2, 0] ∧
    target39.elements.length = 3 ∧
    [target39.elements.count 0, target39.elements.count 1,
      target39.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain39
def tree40 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0))
def target40 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain40 : accepts tree40 target40 = true ∧
    sourceLeaves tree40 = [1, 2, 0] ∧
    target40.elements.length = 3 ∧
    [target40.elements.count 0, target40.elements.count 1,
      target40.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain40
def tree41 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1)))
def target41 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain41 : accepts tree41 target41 = true ∧
    sourceLeaves tree41 = [1, 2, 1] ∧
    target41.elements.length = 3 ∧
    [target41.elements.count 0, target41.elements.count 1,
      target41.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain41
def tree42 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1))
def target42 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain42 : accepts tree42 target42 = true ∧
    sourceLeaves tree42 = [1, 2, 1] ∧
    target42.elements.length = 3 ∧
    [target42.elements.count 0, target42.elements.count 1,
      target42.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain42
def tree43 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2)))
def target43 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain43 : accepts tree43 target43 = true ∧
    sourceLeaves tree43 = [1, 2, 2] ∧
    target43.elements.length = 3 ∧
    [target43.elements.count 0, target43.elements.count 1,
      target43.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain43
def tree44 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2))
def target44 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain44 : accepts tree44 target44 = true ∧
    sourceLeaves tree44 = [1, 2, 2] ∧
    target44.elements.length = 3 ∧
    [target44.elements.count 0, target44.elements.count 1,
      target44.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain44
def tree45 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0)))
def target45 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain45 : accepts tree45 target45 = true ∧
    sourceLeaves tree45 = [2, 0, 0] ∧
    target45.elements.length = 3 ∧
    [target45.elements.count 0, target45.elements.count 1,
      target45.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain45
def tree46 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0))
def target46 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain46 : accepts tree46 target46 = true ∧
    sourceLeaves tree46 = [2, 0, 0] ∧
    target46.elements.length = 3 ∧
    [target46.elements.count 0, target46.elements.count 1,
      target46.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain46
def tree47 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1)))
def target47 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain47 : accepts tree47 target47 = true ∧
    sourceLeaves tree47 = [2, 0, 1] ∧
    target47.elements.length = 3 ∧
    [target47.elements.count 0, target47.elements.count 1,
      target47.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain47
def tree48 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1))
def target48 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain48 : accepts tree48 target48 = true ∧
    sourceLeaves tree48 = [2, 0, 1] ∧
    target48.elements.length = 3 ∧
    [target48.elements.count 0, target48.elements.count 1,
      target48.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain48
def tree49 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2)))
def target49 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain49 : accepts tree49 target49 = true ∧
    sourceLeaves tree49 = [2, 0, 2] ∧
    target49.elements.length = 3 ∧
    [target49.elements.count 0, target49.elements.count 1,
      target49.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain49
def tree50 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2))
def target50 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain50 : accepts tree50 target50 = true ∧
    sourceLeaves tree50 = [2, 0, 2] ∧
    target50.elements.length = 3 ∧
    [target50.elements.count 0, target50.elements.count 1,
      target50.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain50
def tree51 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0)))
def target51 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain51 : accepts tree51 target51 = true ∧
    sourceLeaves tree51 = [2, 1, 0] ∧
    target51.elements.length = 3 ∧
    [target51.elements.count 0, target51.elements.count 1,
      target51.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain51
def tree52 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0))
def target52 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain52 : accepts tree52 target52 = true ∧
    sourceLeaves tree52 = [2, 1, 0] ∧
    target52.elements.length = 3 ∧
    [target52.elements.count 0, target52.elements.count 1,
      target52.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain52
def tree53 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1)))
def target53 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain53 : accepts tree53 target53 = true ∧
    sourceLeaves tree53 = [2, 1, 1] ∧
    target53.elements.length = 3 ∧
    [target53.elements.count 0, target53.elements.count 1,
      target53.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain53
def tree54 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1))
def target54 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain54 : accepts tree54 target54 = true ∧
    sourceLeaves tree54 = [2, 1, 1] ∧
    target54.elements.length = 3 ∧
    [target54.elements.count 0, target54.elements.count 1,
      target54.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain54
def tree55 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2)))
def target55 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain55 : accepts tree55 target55 = true ∧
    sourceLeaves tree55 = [2, 1, 2] ∧
    target55.elements.length = 3 ∧
    [target55.elements.count 0, target55.elements.count 1,
      target55.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain55
def tree56 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2))
def target56 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain56 : accepts tree56 target56 = true ∧
    sourceLeaves tree56 = [2, 1, 2] ∧
    target56.elements.length = 3 ∧
    [target56.elements.count 0, target56.elements.count 1,
      target56.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain56
def tree57 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0)))
def target57 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain57 : accepts tree57 target57 = true ∧
    sourceLeaves tree57 = [2, 2, 0] ∧
    target57.elements.length = 3 ∧
    [target57.elements.count 0, target57.elements.count 1,
      target57.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain57
def tree58 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0))
def target58 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain58 : accepts tree58 target58 = true ∧
    sourceLeaves tree58 = [2, 2, 0] ∧
    target58.elements.length = 3 ∧
    [target58.elements.count 0, target58.elements.count 1,
      target58.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain58
def tree59 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1)))
def target59 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain59 : accepts tree59 target59 = true ∧
    sourceLeaves tree59 = [2, 2, 1] ∧
    target59.elements.length = 3 ∧
    [target59.elements.count 0, target59.elements.count 1,
      target59.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain59
def tree60 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1))
def target60 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain60 : accepts tree60 target60 = true ∧
    sourceLeaves tree60 = [2, 2, 1] ∧
    target60.elements.length = 3 ∧
    [target60.elements.count 0, target60.elements.count 1,
      target60.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain60
def tree61 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2)))
def target61 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain61 : accepts tree61 target61 = true ∧
    sourceLeaves tree61 = [2, 2, 2] ∧
    target61.elements.length = 3 ∧
    [target61.elements.count 0, target61.elements.count 1,
      target61.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain61
def tree62 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2))
def target62 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain62 : accepts tree62 target62 = true ∧
    sourceLeaves tree62 = [2, 2, 2] ∧
    target62.elements.length = 3 ∧
    [target62.elements.count 0, target62.elements.count 1,
      target62.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain62
def tree63 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))))
def target63 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain63 : accepts tree63 target63 = true ∧
    sourceLeaves tree63 = [0, 0, 0, 0] ∧
    target63.elements.length = 4 ∧
    [target63.elements.count 0, target63.elements.count 1,
      target63.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain63
def tree64 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)))
def target64 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain64 : accepts tree64 target64 = true ∧
    sourceLeaves tree64 = [0, 0, 0, 0] ∧
    target64.elements.length = 4 ∧
    [target64.elements.count 0, target64.elements.count 1,
      target64.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain64
def tree65 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 0) (.leaf 0)))
def target65 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain65 : accepts tree65 target65 = true ∧
    sourceLeaves tree65 = [0, 0, 0, 0] ∧
    target65.elements.length = 4 ∧
    [target65.elements.count 0, target65.elements.count 1,
      target65.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain65
def tree66 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))) (.leaf 0))
def target66 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain66 : accepts tree66 target66 = true ∧
    sourceLeaves tree66 = [0, 0, 0, 0] ∧
    target66.elements.length = 4 ∧
    [target66.elements.count 0, target66.elements.count 1,
      target66.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain66
def tree67 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target67 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain67 : accepts tree67 target67 = true ∧
    sourceLeaves tree67 = [0, 0, 0, 0] ∧
    target67.elements.length = 4 ∧
    [target67.elements.count 0, target67.elements.count 1,
      target67.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain67
def tree68 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))))
def target68 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain68 : accepts tree68 target68 = true ∧
    sourceLeaves tree68 = [0, 0, 0, 1] ∧
    target68.elements.length = 4 ∧
    [target68.elements.count 0, target68.elements.count 1,
      target68.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain68
def tree69 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)))
def target69 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain69 : accepts tree69 target69 = true ∧
    sourceLeaves tree69 = [0, 0, 0, 1] ∧
    target69.elements.length = 4 ∧
    [target69.elements.count 0, target69.elements.count 1,
      target69.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain69
def tree70 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 0) (.leaf 1)))
def target70 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain70 : accepts tree70 target70 = true ∧
    sourceLeaves tree70 = [0, 0, 0, 1] ∧
    target70.elements.length = 4 ∧
    [target70.elements.count 0, target70.elements.count 1,
      target70.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain70
def tree71 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))) (.leaf 1))
def target71 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain71 : accepts tree71 target71 = true ∧
    sourceLeaves tree71 = [0, 0, 0, 1] ∧
    target71.elements.length = 4 ∧
    [target71.elements.count 0, target71.elements.count 1,
      target71.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain71
def tree72 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target72 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain72 : accepts tree72 target72 = true ∧
    sourceLeaves tree72 = [0, 0, 0, 1] ∧
    target72.elements.length = 4 ∧
    [target72.elements.count 0, target72.elements.count 1,
      target72.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain72
def tree73 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))))
def target73 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain73 : accepts tree73 target73 = true ∧
    sourceLeaves tree73 = [0, 0, 0, 2] ∧
    target73.elements.length = 4 ∧
    [target73.elements.count 0, target73.elements.count 1,
      target73.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain73
def tree74 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)))
def target74 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain74 : accepts tree74 target74 = true ∧
    sourceLeaves tree74 = [0, 0, 0, 2] ∧
    target74.elements.length = 4 ∧
    [target74.elements.count 0, target74.elements.count 1,
      target74.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain74
def tree75 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 0) (.leaf 2)))
def target75 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain75 : accepts tree75 target75 = true ∧
    sourceLeaves tree75 = [0, 0, 0, 2] ∧
    target75.elements.length = 4 ∧
    [target75.elements.count 0, target75.elements.count 1,
      target75.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain75
def tree76 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))) (.leaf 2))
def target76 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain76 : accepts tree76 target76 = true ∧
    sourceLeaves tree76 = [0, 0, 0, 2] ∧
    target76.elements.length = 4 ∧
    [target76.elements.count 0, target76.elements.count 1,
      target76.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain76
def tree77 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target77 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain77 : accepts tree77 target77 = true ∧
    sourceLeaves tree77 = [0, 0, 0, 2] ∧
    target77.elements.length = 4 ∧
    [target77.elements.count 0, target77.elements.count 1,
      target77.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain77
def tree78 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))))
def target78 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain78 : accepts tree78 target78 = true ∧
    sourceLeaves tree78 = [0, 0, 1, 0] ∧
    target78.elements.length = 4 ∧
    [target78.elements.count 0, target78.elements.count 1,
      target78.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain78
def tree79 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)))
def target79 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain79 : accepts tree79 target79 = true ∧
    sourceLeaves tree79 = [0, 0, 1, 0] ∧
    target79.elements.length = 4 ∧
    [target79.elements.count 0, target79.elements.count 1,
      target79.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain79
def tree80 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 1) (.leaf 0)))
def target80 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain80 : accepts tree80 target80 = true ∧
    sourceLeaves tree80 = [0, 0, 1, 0] ∧
    target80.elements.length = 4 ∧
    [target80.elements.count 0, target80.elements.count 1,
      target80.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain80
def tree81 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))) (.leaf 0))
def target81 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain81 : accepts tree81 target81 = true ∧
    sourceLeaves tree81 = [0, 0, 1, 0] ∧
    target81.elements.length = 4 ∧
    [target81.elements.count 0, target81.elements.count 1,
      target81.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain81
def tree82 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target82 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain82 : accepts tree82 target82 = true ∧
    sourceLeaves tree82 = [0, 0, 1, 0] ∧
    target82.elements.length = 4 ∧
    [target82.elements.count 0, target82.elements.count 1,
      target82.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain82
def tree83 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))))
def target83 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain83 : accepts tree83 target83 = true ∧
    sourceLeaves tree83 = [0, 0, 1, 1] ∧
    target83.elements.length = 4 ∧
    [target83.elements.count 0, target83.elements.count 1,
      target83.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain83
def tree84 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)))
def target84 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain84 : accepts tree84 target84 = true ∧
    sourceLeaves tree84 = [0, 0, 1, 1] ∧
    target84.elements.length = 4 ∧
    [target84.elements.count 0, target84.elements.count 1,
      target84.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain84
def tree85 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 1) (.leaf 1)))
def target85 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain85 : accepts tree85 target85 = true ∧
    sourceLeaves tree85 = [0, 0, 1, 1] ∧
    target85.elements.length = 4 ∧
    [target85.elements.count 0, target85.elements.count 1,
      target85.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain85
def tree86 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))) (.leaf 1))
def target86 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain86 : accepts tree86 target86 = true ∧
    sourceLeaves tree86 = [0, 0, 1, 1] ∧
    target86.elements.length = 4 ∧
    [target86.elements.count 0, target86.elements.count 1,
      target86.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain86
def tree87 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target87 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain87 : accepts tree87 target87 = true ∧
    sourceLeaves tree87 = [0, 0, 1, 1] ∧
    target87.elements.length = 4 ∧
    [target87.elements.count 0, target87.elements.count 1,
      target87.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain87
def tree88 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))))
def target88 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain88 : accepts tree88 target88 = true ∧
    sourceLeaves tree88 = [0, 0, 1, 2] ∧
    target88.elements.length = 4 ∧
    [target88.elements.count 0, target88.elements.count 1,
      target88.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain88
def tree89 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)))
def target89 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain89 : accepts tree89 target89 = true ∧
    sourceLeaves tree89 = [0, 0, 1, 2] ∧
    target89.elements.length = 4 ∧
    [target89.elements.count 0, target89.elements.count 1,
      target89.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain89
def tree90 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 1) (.leaf 2)))
def target90 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain90 : accepts tree90 target90 = true ∧
    sourceLeaves tree90 = [0, 0, 1, 2] ∧
    target90.elements.length = 4 ∧
    [target90.elements.count 0, target90.elements.count 1,
      target90.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain90
def tree91 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))) (.leaf 2))
def target91 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain91 : accepts tree91 target91 = true ∧
    sourceLeaves tree91 = [0, 0, 1, 2] ∧
    target91.elements.length = 4 ∧
    [target91.elements.count 0, target91.elements.count 1,
      target91.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain91
def tree92 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target92 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain92 : accepts tree92 target92 = true ∧
    sourceLeaves tree92 = [0, 0, 1, 2] ∧
    target92.elements.length = 4 ∧
    [target92.elements.count 0, target92.elements.count 1,
      target92.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain92
def tree93 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))))
def target93 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain93 : accepts tree93 target93 = true ∧
    sourceLeaves tree93 = [0, 0, 2, 0] ∧
    target93.elements.length = 4 ∧
    [target93.elements.count 0, target93.elements.count 1,
      target93.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain93
def tree94 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)))
def target94 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain94 : accepts tree94 target94 = true ∧
    sourceLeaves tree94 = [0, 0, 2, 0] ∧
    target94.elements.length = 4 ∧
    [target94.elements.count 0, target94.elements.count 1,
      target94.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain94
def tree95 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 2) (.leaf 0)))
def target95 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain95 : accepts tree95 target95 = true ∧
    sourceLeaves tree95 = [0, 0, 2, 0] ∧
    target95.elements.length = 4 ∧
    [target95.elements.count 0, target95.elements.count 1,
      target95.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain95
def tree96 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))) (.leaf 0))
def target96 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain96 : accepts tree96 target96 = true ∧
    sourceLeaves tree96 = [0, 0, 2, 0] ∧
    target96.elements.length = 4 ∧
    [target96.elements.count 0, target96.elements.count 1,
      target96.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain96
def tree97 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target97 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain97 : accepts tree97 target97 = true ∧
    sourceLeaves tree97 = [0, 0, 2, 0] ∧
    target97.elements.length = 4 ∧
    [target97.elements.count 0, target97.elements.count 1,
      target97.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain97
def tree98 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))))
def target98 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain98 : accepts tree98 target98 = true ∧
    sourceLeaves tree98 = [0, 0, 2, 1] ∧
    target98.elements.length = 4 ∧
    [target98.elements.count 0, target98.elements.count 1,
      target98.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain98
def tree99 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)))
def target99 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain99 : accepts tree99 target99 = true ∧
    sourceLeaves tree99 = [0, 0, 2, 1] ∧
    target99.elements.length = 4 ∧
    [target99.elements.count 0, target99.elements.count 1,
      target99.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain99
def tree100 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 2) (.leaf 1)))
def target100 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain100 : accepts tree100 target100 = true ∧
    sourceLeaves tree100 = [0, 0, 2, 1] ∧
    target100.elements.length = 4 ∧
    [target100.elements.count 0, target100.elements.count 1,
      target100.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain100
def tree101 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))) (.leaf 1))
def target101 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain101 : accepts tree101 target101 = true ∧
    sourceLeaves tree101 = [0, 0, 2, 1] ∧
    target101.elements.length = 4 ∧
    [target101.elements.count 0, target101.elements.count 1,
      target101.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain101
def tree102 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target102 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain102 : accepts tree102 target102 = true ∧
    sourceLeaves tree102 = [0, 0, 2, 1] ∧
    target102.elements.length = 4 ∧
    [target102.elements.count 0, target102.elements.count 1,
      target102.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain102
def tree103 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))))
def target103 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain103 : accepts tree103 target103 = true ∧
    sourceLeaves tree103 = [0, 0, 2, 2] ∧
    target103.elements.length = 4 ∧
    [target103.elements.count 0, target103.elements.count 1,
      target103.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain103
def tree104 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)))
def target104 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain104 : accepts tree104 target104 = true ∧
    sourceLeaves tree104 = [0, 0, 2, 2] ∧
    target104.elements.length = 4 ∧
    [target104.elements.count 0, target104.elements.count 1,
      target104.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain104
def tree105 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 2) (.leaf 2)))
def target105 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain105 : accepts tree105 target105 = true ∧
    sourceLeaves tree105 = [0, 0, 2, 2] ∧
    target105.elements.length = 4 ∧
    [target105.elements.count 0, target105.elements.count 1,
      target105.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain105
def tree106 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))) (.leaf 2))
def target106 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain106 : accepts tree106 target106 = true ∧
    sourceLeaves tree106 = [0, 0, 2, 2] ∧
    target106.elements.length = 4 ∧
    [target106.elements.count 0, target106.elements.count 1,
      target106.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain106
def tree107 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target107 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain107 : accepts tree107 target107 = true ∧
    sourceLeaves tree107 = [0, 0, 2, 2] ∧
    target107.elements.length = 4 ∧
    [target107.elements.count 0, target107.elements.count 1,
      target107.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain107
def tree108 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))))
def target108 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain108 : accepts tree108 target108 = true ∧
    sourceLeaves tree108 = [0, 1, 0, 0] ∧
    target108.elements.length = 4 ∧
    [target108.elements.count 0, target108.elements.count 1,
      target108.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain108
def tree109 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)))
def target109 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain109 : accepts tree109 target109 = true ∧
    sourceLeaves tree109 = [0, 1, 0, 0] ∧
    target109.elements.length = 4 ∧
    [target109.elements.count 0, target109.elements.count 1,
      target109.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain109
def tree110 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 0) (.leaf 0)))
def target110 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain110 : accepts tree110 target110 = true ∧
    sourceLeaves tree110 = [0, 1, 0, 0] ∧
    target110.elements.length = 4 ∧
    [target110.elements.count 0, target110.elements.count 1,
      target110.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain110
def tree111 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))) (.leaf 0))
def target111 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain111 : accepts tree111 target111 = true ∧
    sourceLeaves tree111 = [0, 1, 0, 0] ∧
    target111.elements.length = 4 ∧
    [target111.elements.count 0, target111.elements.count 1,
      target111.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain111
def tree112 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target112 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain112 : accepts tree112 target112 = true ∧
    sourceLeaves tree112 = [0, 1, 0, 0] ∧
    target112.elements.length = 4 ∧
    [target112.elements.count 0, target112.elements.count 1,
      target112.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain112
def tree113 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))))
def target113 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain113 : accepts tree113 target113 = true ∧
    sourceLeaves tree113 = [0, 1, 0, 1] ∧
    target113.elements.length = 4 ∧
    [target113.elements.count 0, target113.elements.count 1,
      target113.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain113
def tree114 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)))
def target114 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain114 : accepts tree114 target114 = true ∧
    sourceLeaves tree114 = [0, 1, 0, 1] ∧
    target114.elements.length = 4 ∧
    [target114.elements.count 0, target114.elements.count 1,
      target114.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain114
def tree115 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 0) (.leaf 1)))
def target115 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain115 : accepts tree115 target115 = true ∧
    sourceLeaves tree115 = [0, 1, 0, 1] ∧
    target115.elements.length = 4 ∧
    [target115.elements.count 0, target115.elements.count 1,
      target115.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain115
def tree116 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))) (.leaf 1))
def target116 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain116 : accepts tree116 target116 = true ∧
    sourceLeaves tree116 = [0, 1, 0, 1] ∧
    target116.elements.length = 4 ∧
    [target116.elements.count 0, target116.elements.count 1,
      target116.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain116
def tree117 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target117 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain117 : accepts tree117 target117 = true ∧
    sourceLeaves tree117 = [0, 1, 0, 1] ∧
    target117.elements.length = 4 ∧
    [target117.elements.count 0, target117.elements.count 1,
      target117.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain117
def tree118 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))))
def target118 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain118 : accepts tree118 target118 = true ∧
    sourceLeaves tree118 = [0, 1, 0, 2] ∧
    target118.elements.length = 4 ∧
    [target118.elements.count 0, target118.elements.count 1,
      target118.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain118
def tree119 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)))
def target119 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain119 : accepts tree119 target119 = true ∧
    sourceLeaves tree119 = [0, 1, 0, 2] ∧
    target119.elements.length = 4 ∧
    [target119.elements.count 0, target119.elements.count 1,
      target119.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain119
def tree120 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 0) (.leaf 2)))
def target120 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain120 : accepts tree120 target120 = true ∧
    sourceLeaves tree120 = [0, 1, 0, 2] ∧
    target120.elements.length = 4 ∧
    [target120.elements.count 0, target120.elements.count 1,
      target120.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain120
def tree121 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))) (.leaf 2))
def target121 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain121 : accepts tree121 target121 = true ∧
    sourceLeaves tree121 = [0, 1, 0, 2] ∧
    target121.elements.length = 4 ∧
    [target121.elements.count 0, target121.elements.count 1,
      target121.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain121
def tree122 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target122 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain122 : accepts tree122 target122 = true ∧
    sourceLeaves tree122 = [0, 1, 0, 2] ∧
    target122.elements.length = 4 ∧
    [target122.elements.count 0, target122.elements.count 1,
      target122.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain122
def tree123 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))))
def target123 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain123 : accepts tree123 target123 = true ∧
    sourceLeaves tree123 = [0, 1, 1, 0] ∧
    target123.elements.length = 4 ∧
    [target123.elements.count 0, target123.elements.count 1,
      target123.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain123
def tree124 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)))
def target124 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain124 : accepts tree124 target124 = true ∧
    sourceLeaves tree124 = [0, 1, 1, 0] ∧
    target124.elements.length = 4 ∧
    [target124.elements.count 0, target124.elements.count 1,
      target124.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain124
def tree125 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 1) (.leaf 0)))
def target125 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain125 : accepts tree125 target125 = true ∧
    sourceLeaves tree125 = [0, 1, 1, 0] ∧
    target125.elements.length = 4 ∧
    [target125.elements.count 0, target125.elements.count 1,
      target125.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain125
def tree126 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))) (.leaf 0))
def target126 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain126 : accepts tree126 target126 = true ∧
    sourceLeaves tree126 = [0, 1, 1, 0] ∧
    target126.elements.length = 4 ∧
    [target126.elements.count 0, target126.elements.count 1,
      target126.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain126
def tree127 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target127 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain127 : accepts tree127 target127 = true ∧
    sourceLeaves tree127 = [0, 1, 1, 0] ∧
    target127.elements.length = 4 ∧
    [target127.elements.count 0, target127.elements.count 1,
      target127.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain127
def tree128 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))))
def target128 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain128 : accepts tree128 target128 = true ∧
    sourceLeaves tree128 = [0, 1, 1, 1] ∧
    target128.elements.length = 4 ∧
    [target128.elements.count 0, target128.elements.count 1,
      target128.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain128
def tree129 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)))
def target129 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain129 : accepts tree129 target129 = true ∧
    sourceLeaves tree129 = [0, 1, 1, 1] ∧
    target129.elements.length = 4 ∧
    [target129.elements.count 0, target129.elements.count 1,
      target129.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain129
def tree130 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 1) (.leaf 1)))
def target130 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain130 : accepts tree130 target130 = true ∧
    sourceLeaves tree130 = [0, 1, 1, 1] ∧
    target130.elements.length = 4 ∧
    [target130.elements.count 0, target130.elements.count 1,
      target130.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain130
def tree131 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))) (.leaf 1))
def target131 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain131 : accepts tree131 target131 = true ∧
    sourceLeaves tree131 = [0, 1, 1, 1] ∧
    target131.elements.length = 4 ∧
    [target131.elements.count 0, target131.elements.count 1,
      target131.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain131
def tree132 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target132 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain132 : accepts tree132 target132 = true ∧
    sourceLeaves tree132 = [0, 1, 1, 1] ∧
    target132.elements.length = 4 ∧
    [target132.elements.count 0, target132.elements.count 1,
      target132.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain132
def tree133 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))))
def target133 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain133 : accepts tree133 target133 = true ∧
    sourceLeaves tree133 = [0, 1, 1, 2] ∧
    target133.elements.length = 4 ∧
    [target133.elements.count 0, target133.elements.count 1,
      target133.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain133
def tree134 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)))
def target134 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain134 : accepts tree134 target134 = true ∧
    sourceLeaves tree134 = [0, 1, 1, 2] ∧
    target134.elements.length = 4 ∧
    [target134.elements.count 0, target134.elements.count 1,
      target134.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain134
def tree135 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 1) (.leaf 2)))
def target135 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain135 : accepts tree135 target135 = true ∧
    sourceLeaves tree135 = [0, 1, 1, 2] ∧
    target135.elements.length = 4 ∧
    [target135.elements.count 0, target135.elements.count 1,
      target135.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain135
def tree136 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))) (.leaf 2))
def target136 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain136 : accepts tree136 target136 = true ∧
    sourceLeaves tree136 = [0, 1, 1, 2] ∧
    target136.elements.length = 4 ∧
    [target136.elements.count 0, target136.elements.count 1,
      target136.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain136
def tree137 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target137 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain137 : accepts tree137 target137 = true ∧
    sourceLeaves tree137 = [0, 1, 1, 2] ∧
    target137.elements.length = 4 ∧
    [target137.elements.count 0, target137.elements.count 1,
      target137.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain137
def tree138 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))))
def target138 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain138 : accepts tree138 target138 = true ∧
    sourceLeaves tree138 = [0, 1, 2, 0] ∧
    target138.elements.length = 4 ∧
    [target138.elements.count 0, target138.elements.count 1,
      target138.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain138
def tree139 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)))
def target139 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain139 : accepts tree139 target139 = true ∧
    sourceLeaves tree139 = [0, 1, 2, 0] ∧
    target139.elements.length = 4 ∧
    [target139.elements.count 0, target139.elements.count 1,
      target139.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain139
def tree140 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 0)))
def target140 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain140 : accepts tree140 target140 = true ∧
    sourceLeaves tree140 = [0, 1, 2, 0] ∧
    target140.elements.length = 4 ∧
    [target140.elements.count 0, target140.elements.count 1,
      target140.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain140
def tree141 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 0))
def target141 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain141 : accepts tree141 target141 = true ∧
    sourceLeaves tree141 = [0, 1, 2, 0] ∧
    target141.elements.length = 4 ∧
    [target141.elements.count 0, target141.elements.count 1,
      target141.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain141
def tree142 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target142 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain142 : accepts tree142 target142 = true ∧
    sourceLeaves tree142 = [0, 1, 2, 0] ∧
    target142.elements.length = 4 ∧
    [target142.elements.count 0, target142.elements.count 1,
      target142.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain142
def tree143 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))))
def target143 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain143 : accepts tree143 target143 = true ∧
    sourceLeaves tree143 = [0, 1, 2, 1] ∧
    target143.elements.length = 4 ∧
    [target143.elements.count 0, target143.elements.count 1,
      target143.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain143
def tree144 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)))
def target144 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain144 : accepts tree144 target144 = true ∧
    sourceLeaves tree144 = [0, 1, 2, 1] ∧
    target144.elements.length = 4 ∧
    [target144.elements.count 0, target144.elements.count 1,
      target144.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain144
def tree145 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 1)))
def target145 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain145 : accepts tree145 target145 = true ∧
    sourceLeaves tree145 = [0, 1, 2, 1] ∧
    target145.elements.length = 4 ∧
    [target145.elements.count 0, target145.elements.count 1,
      target145.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain145
def tree146 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 1))
def target146 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain146 : accepts tree146 target146 = true ∧
    sourceLeaves tree146 = [0, 1, 2, 1] ∧
    target146.elements.length = 4 ∧
    [target146.elements.count 0, target146.elements.count 1,
      target146.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain146
def tree147 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target147 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain147 : accepts tree147 target147 = true ∧
    sourceLeaves tree147 = [0, 1, 2, 1] ∧
    target147.elements.length = 4 ∧
    [target147.elements.count 0, target147.elements.count 1,
      target147.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain147
def tree148 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))))
def target148 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain148 : accepts tree148 target148 = true ∧
    sourceLeaves tree148 = [0, 1, 2, 2] ∧
    target148.elements.length = 4 ∧
    [target148.elements.count 0, target148.elements.count 1,
      target148.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain148
def tree149 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)))
def target149 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain149 : accepts tree149 target149 = true ∧
    sourceLeaves tree149 = [0, 1, 2, 2] ∧
    target149.elements.length = 4 ∧
    [target149.elements.count 0, target149.elements.count 1,
      target149.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain149
def tree150 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 2)))
def target150 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain150 : accepts tree150 target150 = true ∧
    sourceLeaves tree150 = [0, 1, 2, 2] ∧
    target150.elements.length = 4 ∧
    [target150.elements.count 0, target150.elements.count 1,
      target150.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain150
def tree151 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 2))
def target151 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain151 : accepts tree151 target151 = true ∧
    sourceLeaves tree151 = [0, 1, 2, 2] ∧
    target151.elements.length = 4 ∧
    [target151.elements.count 0, target151.elements.count 1,
      target151.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain151
def tree152 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target152 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain152 : accepts tree152 target152 = true ∧
    sourceLeaves tree152 = [0, 1, 2, 2] ∧
    target152.elements.length = 4 ∧
    [target152.elements.count 0, target152.elements.count 1,
      target152.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain152
def tree153 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))))
def target153 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain153 : accepts tree153 target153 = true ∧
    sourceLeaves tree153 = [0, 2, 0, 0] ∧
    target153.elements.length = 4 ∧
    [target153.elements.count 0, target153.elements.count 1,
      target153.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain153
def tree154 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)))
def target154 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain154 : accepts tree154 target154 = true ∧
    sourceLeaves tree154 = [0, 2, 0, 0] ∧
    target154.elements.length = 4 ∧
    [target154.elements.count 0, target154.elements.count 1,
      target154.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain154
def tree155 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 0) (.leaf 0)))
def target155 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain155 : accepts tree155 target155 = true ∧
    sourceLeaves tree155 = [0, 2, 0, 0] ∧
    target155.elements.length = 4 ∧
    [target155.elements.count 0, target155.elements.count 1,
      target155.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain155
def tree156 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))) (.leaf 0))
def target156 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain156 : accepts tree156 target156 = true ∧
    sourceLeaves tree156 = [0, 2, 0, 0] ∧
    target156.elements.length = 4 ∧
    [target156.elements.count 0, target156.elements.count 1,
      target156.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain156
def tree157 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target157 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain157 : accepts tree157 target157 = true ∧
    sourceLeaves tree157 = [0, 2, 0, 0] ∧
    target157.elements.length = 4 ∧
    [target157.elements.count 0, target157.elements.count 1,
      target157.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain157
def tree158 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))))
def target158 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain158 : accepts tree158 target158 = true ∧
    sourceLeaves tree158 = [0, 2, 0, 1] ∧
    target158.elements.length = 4 ∧
    [target158.elements.count 0, target158.elements.count 1,
      target158.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain158
def tree159 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)))
def target159 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain159 : accepts tree159 target159 = true ∧
    sourceLeaves tree159 = [0, 2, 0, 1] ∧
    target159.elements.length = 4 ∧
    [target159.elements.count 0, target159.elements.count 1,
      target159.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain159
def tree160 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 0) (.leaf 1)))
def target160 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain160 : accepts tree160 target160 = true ∧
    sourceLeaves tree160 = [0, 2, 0, 1] ∧
    target160.elements.length = 4 ∧
    [target160.elements.count 0, target160.elements.count 1,
      target160.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain160
def tree161 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))) (.leaf 1))
def target161 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain161 : accepts tree161 target161 = true ∧
    sourceLeaves tree161 = [0, 2, 0, 1] ∧
    target161.elements.length = 4 ∧
    [target161.elements.count 0, target161.elements.count 1,
      target161.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain161
def tree162 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target162 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain162 : accepts tree162 target162 = true ∧
    sourceLeaves tree162 = [0, 2, 0, 1] ∧
    target162.elements.length = 4 ∧
    [target162.elements.count 0, target162.elements.count 1,
      target162.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain162
def tree163 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))))
def target163 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain163 : accepts tree163 target163 = true ∧
    sourceLeaves tree163 = [0, 2, 0, 2] ∧
    target163.elements.length = 4 ∧
    [target163.elements.count 0, target163.elements.count 1,
      target163.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain163
def tree164 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)))
def target164 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain164 : accepts tree164 target164 = true ∧
    sourceLeaves tree164 = [0, 2, 0, 2] ∧
    target164.elements.length = 4 ∧
    [target164.elements.count 0, target164.elements.count 1,
      target164.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain164
def tree165 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 0) (.leaf 2)))
def target165 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain165 : accepts tree165 target165 = true ∧
    sourceLeaves tree165 = [0, 2, 0, 2] ∧
    target165.elements.length = 4 ∧
    [target165.elements.count 0, target165.elements.count 1,
      target165.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain165
def tree166 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))) (.leaf 2))
def target166 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain166 : accepts tree166 target166 = true ∧
    sourceLeaves tree166 = [0, 2, 0, 2] ∧
    target166.elements.length = 4 ∧
    [target166.elements.count 0, target166.elements.count 1,
      target166.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain166
def tree167 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target167 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain167 : accepts tree167 target167 = true ∧
    sourceLeaves tree167 = [0, 2, 0, 2] ∧
    target167.elements.length = 4 ∧
    [target167.elements.count 0, target167.elements.count 1,
      target167.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain167
def tree168 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))))
def target168 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain168 : accepts tree168 target168 = true ∧
    sourceLeaves tree168 = [0, 2, 1, 0] ∧
    target168.elements.length = 4 ∧
    [target168.elements.count 0, target168.elements.count 1,
      target168.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain168
def tree169 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)))
def target169 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain169 : accepts tree169 target169 = true ∧
    sourceLeaves tree169 = [0, 2, 1, 0] ∧
    target169.elements.length = 4 ∧
    [target169.elements.count 0, target169.elements.count 1,
      target169.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain169
def tree170 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 1) (.leaf 0)))
def target170 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain170 : accepts tree170 target170 = true ∧
    sourceLeaves tree170 = [0, 2, 1, 0] ∧
    target170.elements.length = 4 ∧
    [target170.elements.count 0, target170.elements.count 1,
      target170.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain170
def tree171 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))) (.leaf 0))
def target171 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain171 : accepts tree171 target171 = true ∧
    sourceLeaves tree171 = [0, 2, 1, 0] ∧
    target171.elements.length = 4 ∧
    [target171.elements.count 0, target171.elements.count 1,
      target171.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain171
def tree172 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target172 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain172 : accepts tree172 target172 = true ∧
    sourceLeaves tree172 = [0, 2, 1, 0] ∧
    target172.elements.length = 4 ∧
    [target172.elements.count 0, target172.elements.count 1,
      target172.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain172
def tree173 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))))
def target173 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain173 : accepts tree173 target173 = true ∧
    sourceLeaves tree173 = [0, 2, 1, 1] ∧
    target173.elements.length = 4 ∧
    [target173.elements.count 0, target173.elements.count 1,
      target173.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain173
def tree174 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)))
def target174 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain174 : accepts tree174 target174 = true ∧
    sourceLeaves tree174 = [0, 2, 1, 1] ∧
    target174.elements.length = 4 ∧
    [target174.elements.count 0, target174.elements.count 1,
      target174.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain174
def tree175 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 1) (.leaf 1)))
def target175 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain175 : accepts tree175 target175 = true ∧
    sourceLeaves tree175 = [0, 2, 1, 1] ∧
    target175.elements.length = 4 ∧
    [target175.elements.count 0, target175.elements.count 1,
      target175.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain175
def tree176 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))) (.leaf 1))
def target176 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain176 : accepts tree176 target176 = true ∧
    sourceLeaves tree176 = [0, 2, 1, 1] ∧
    target176.elements.length = 4 ∧
    [target176.elements.count 0, target176.elements.count 1,
      target176.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain176
def tree177 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target177 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain177 : accepts tree177 target177 = true ∧
    sourceLeaves tree177 = [0, 2, 1, 1] ∧
    target177.elements.length = 4 ∧
    [target177.elements.count 0, target177.elements.count 1,
      target177.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain177
def tree178 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))))
def target178 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain178 : accepts tree178 target178 = true ∧
    sourceLeaves tree178 = [0, 2, 1, 2] ∧
    target178.elements.length = 4 ∧
    [target178.elements.count 0, target178.elements.count 1,
      target178.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain178
def tree179 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)))
def target179 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain179 : accepts tree179 target179 = true ∧
    sourceLeaves tree179 = [0, 2, 1, 2] ∧
    target179.elements.length = 4 ∧
    [target179.elements.count 0, target179.elements.count 1,
      target179.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain179
def tree180 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 1) (.leaf 2)))
def target180 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain180 : accepts tree180 target180 = true ∧
    sourceLeaves tree180 = [0, 2, 1, 2] ∧
    target180.elements.length = 4 ∧
    [target180.elements.count 0, target180.elements.count 1,
      target180.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain180
def tree181 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))) (.leaf 2))
def target181 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain181 : accepts tree181 target181 = true ∧
    sourceLeaves tree181 = [0, 2, 1, 2] ∧
    target181.elements.length = 4 ∧
    [target181.elements.count 0, target181.elements.count 1,
      target181.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain181
def tree182 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target182 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain182 : accepts tree182 target182 = true ∧
    sourceLeaves tree182 = [0, 2, 1, 2] ∧
    target182.elements.length = 4 ∧
    [target182.elements.count 0, target182.elements.count 1,
      target182.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain182
def tree183 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))))
def target183 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain183 : accepts tree183 target183 = true ∧
    sourceLeaves tree183 = [0, 2, 2, 0] ∧
    target183.elements.length = 4 ∧
    [target183.elements.count 0, target183.elements.count 1,
      target183.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain183
def tree184 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)))
def target184 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain184 : accepts tree184 target184 = true ∧
    sourceLeaves tree184 = [0, 2, 2, 0] ∧
    target184.elements.length = 4 ∧
    [target184.elements.count 0, target184.elements.count 1,
      target184.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain184
def tree185 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 2) (.leaf 0)))
def target185 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain185 : accepts tree185 target185 = true ∧
    sourceLeaves tree185 = [0, 2, 2, 0] ∧
    target185.elements.length = 4 ∧
    [target185.elements.count 0, target185.elements.count 1,
      target185.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain185
def tree186 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))) (.leaf 0))
def target186 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain186 : accepts tree186 target186 = true ∧
    sourceLeaves tree186 = [0, 2, 2, 0] ∧
    target186.elements.length = 4 ∧
    [target186.elements.count 0, target186.elements.count 1,
      target186.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain186
def tree187 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target187 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain187 : accepts tree187 target187 = true ∧
    sourceLeaves tree187 = [0, 2, 2, 0] ∧
    target187.elements.length = 4 ∧
    [target187.elements.count 0, target187.elements.count 1,
      target187.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain187
def tree188 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))))
def target188 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain188 : accepts tree188 target188 = true ∧
    sourceLeaves tree188 = [0, 2, 2, 1] ∧
    target188.elements.length = 4 ∧
    [target188.elements.count 0, target188.elements.count 1,
      target188.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain188
def tree189 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)))
def target189 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain189 : accepts tree189 target189 = true ∧
    sourceLeaves tree189 = [0, 2, 2, 1] ∧
    target189.elements.length = 4 ∧
    [target189.elements.count 0, target189.elements.count 1,
      target189.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain189
def tree190 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 2) (.leaf 1)))
def target190 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain190 : accepts tree190 target190 = true ∧
    sourceLeaves tree190 = [0, 2, 2, 1] ∧
    target190.elements.length = 4 ∧
    [target190.elements.count 0, target190.elements.count 1,
      target190.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain190
def tree191 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))) (.leaf 1))
def target191 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain191 : accepts tree191 target191 = true ∧
    sourceLeaves tree191 = [0, 2, 2, 1] ∧
    target191.elements.length = 4 ∧
    [target191.elements.count 0, target191.elements.count 1,
      target191.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain191
def tree192 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target192 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain192 : accepts tree192 target192 = true ∧
    sourceLeaves tree192 = [0, 2, 2, 1] ∧
    target192.elements.length = 4 ∧
    [target192.elements.count 0, target192.elements.count 1,
      target192.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain192
def tree193 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))))
def target193 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain193 : accepts tree193 target193 = true ∧
    sourceLeaves tree193 = [0, 2, 2, 2] ∧
    target193.elements.length = 4 ∧
    [target193.elements.count 0, target193.elements.count 1,
      target193.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain193
def tree194 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)))
def target194 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain194 : accepts tree194 target194 = true ∧
    sourceLeaves tree194 = [0, 2, 2, 2] ∧
    target194.elements.length = 4 ∧
    [target194.elements.count 0, target194.elements.count 1,
      target194.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain194
def tree195 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 2) (.leaf 2)))
def target195 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain195 : accepts tree195 target195 = true ∧
    sourceLeaves tree195 = [0, 2, 2, 2] ∧
    target195.elements.length = 4 ∧
    [target195.elements.count 0, target195.elements.count 1,
      target195.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain195
def tree196 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))) (.leaf 2))
def target196 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain196 : accepts tree196 target196 = true ∧
    sourceLeaves tree196 = [0, 2, 2, 2] ∧
    target196.elements.length = 4 ∧
    [target196.elements.count 0, target196.elements.count 1,
      target196.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain196
def tree197 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target197 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain197 : accepts tree197 target197 = true ∧
    sourceLeaves tree197 = [0, 2, 2, 2] ∧
    target197.elements.length = 4 ∧
    [target197.elements.count 0, target197.elements.count 1,
      target197.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain197
def tree198 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))))
def target198 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain198 : accepts tree198 target198 = true ∧
    sourceLeaves tree198 = [1, 0, 0, 0] ∧
    target198.elements.length = 4 ∧
    [target198.elements.count 0, target198.elements.count 1,
      target198.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain198
def tree199 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)))
def target199 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain199 : accepts tree199 target199 = true ∧
    sourceLeaves tree199 = [1, 0, 0, 0] ∧
    target199.elements.length = 4 ∧
    [target199.elements.count 0, target199.elements.count 1,
      target199.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain199
def tree200 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 0) (.leaf 0)))
def target200 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain200 : accepts tree200 target200 = true ∧
    sourceLeaves tree200 = [1, 0, 0, 0] ∧
    target200.elements.length = 4 ∧
    [target200.elements.count 0, target200.elements.count 1,
      target200.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain200
def tree201 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))) (.leaf 0))
def target201 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain201 : accepts tree201 target201 = true ∧
    sourceLeaves tree201 = [1, 0, 0, 0] ∧
    target201.elements.length = 4 ∧
    [target201.elements.count 0, target201.elements.count 1,
      target201.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain201
def tree202 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target202 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain202 : accepts tree202 target202 = true ∧
    sourceLeaves tree202 = [1, 0, 0, 0] ∧
    target202.elements.length = 4 ∧
    [target202.elements.count 0, target202.elements.count 1,
      target202.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain202
def tree203 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))))
def target203 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain203 : accepts tree203 target203 = true ∧
    sourceLeaves tree203 = [1, 0, 0, 1] ∧
    target203.elements.length = 4 ∧
    [target203.elements.count 0, target203.elements.count 1,
      target203.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain203
def tree204 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)))
def target204 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain204 : accepts tree204 target204 = true ∧
    sourceLeaves tree204 = [1, 0, 0, 1] ∧
    target204.elements.length = 4 ∧
    [target204.elements.count 0, target204.elements.count 1,
      target204.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain204
def tree205 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 0) (.leaf 1)))
def target205 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain205 : accepts tree205 target205 = true ∧
    sourceLeaves tree205 = [1, 0, 0, 1] ∧
    target205.elements.length = 4 ∧
    [target205.elements.count 0, target205.elements.count 1,
      target205.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain205
def tree206 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))) (.leaf 1))
def target206 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain206 : accepts tree206 target206 = true ∧
    sourceLeaves tree206 = [1, 0, 0, 1] ∧
    target206.elements.length = 4 ∧
    [target206.elements.count 0, target206.elements.count 1,
      target206.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain206
def tree207 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target207 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain207 : accepts tree207 target207 = true ∧
    sourceLeaves tree207 = [1, 0, 0, 1] ∧
    target207.elements.length = 4 ∧
    [target207.elements.count 0, target207.elements.count 1,
      target207.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain207
def tree208 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))))
def target208 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain208 : accepts tree208 target208 = true ∧
    sourceLeaves tree208 = [1, 0, 0, 2] ∧
    target208.elements.length = 4 ∧
    [target208.elements.count 0, target208.elements.count 1,
      target208.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain208
def tree209 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)))
def target209 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain209 : accepts tree209 target209 = true ∧
    sourceLeaves tree209 = [1, 0, 0, 2] ∧
    target209.elements.length = 4 ∧
    [target209.elements.count 0, target209.elements.count 1,
      target209.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain209
def tree210 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 0) (.leaf 2)))
def target210 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain210 : accepts tree210 target210 = true ∧
    sourceLeaves tree210 = [1, 0, 0, 2] ∧
    target210.elements.length = 4 ∧
    [target210.elements.count 0, target210.elements.count 1,
      target210.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain210
def tree211 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))) (.leaf 2))
def target211 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain211 : accepts tree211 target211 = true ∧
    sourceLeaves tree211 = [1, 0, 0, 2] ∧
    target211.elements.length = 4 ∧
    [target211.elements.count 0, target211.elements.count 1,
      target211.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain211
def tree212 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target212 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain212 : accepts tree212 target212 = true ∧
    sourceLeaves tree212 = [1, 0, 0, 2] ∧
    target212.elements.length = 4 ∧
    [target212.elements.count 0, target212.elements.count 1,
      target212.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain212
def tree213 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))))
def target213 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain213 : accepts tree213 target213 = true ∧
    sourceLeaves tree213 = [1, 0, 1, 0] ∧
    target213.elements.length = 4 ∧
    [target213.elements.count 0, target213.elements.count 1,
      target213.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain213
def tree214 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)))
def target214 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain214 : accepts tree214 target214 = true ∧
    sourceLeaves tree214 = [1, 0, 1, 0] ∧
    target214.elements.length = 4 ∧
    [target214.elements.count 0, target214.elements.count 1,
      target214.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain214
def tree215 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 1) (.leaf 0)))
def target215 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain215 : accepts tree215 target215 = true ∧
    sourceLeaves tree215 = [1, 0, 1, 0] ∧
    target215.elements.length = 4 ∧
    [target215.elements.count 0, target215.elements.count 1,
      target215.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain215
def tree216 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))) (.leaf 0))
def target216 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain216 : accepts tree216 target216 = true ∧
    sourceLeaves tree216 = [1, 0, 1, 0] ∧
    target216.elements.length = 4 ∧
    [target216.elements.count 0, target216.elements.count 1,
      target216.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain216
def tree217 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target217 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain217 : accepts tree217 target217 = true ∧
    sourceLeaves tree217 = [1, 0, 1, 0] ∧
    target217.elements.length = 4 ∧
    [target217.elements.count 0, target217.elements.count 1,
      target217.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain217
def tree218 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))))
def target218 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain218 : accepts tree218 target218 = true ∧
    sourceLeaves tree218 = [1, 0, 1, 1] ∧
    target218.elements.length = 4 ∧
    [target218.elements.count 0, target218.elements.count 1,
      target218.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain218
def tree219 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)))
def target219 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain219 : accepts tree219 target219 = true ∧
    sourceLeaves tree219 = [1, 0, 1, 1] ∧
    target219.elements.length = 4 ∧
    [target219.elements.count 0, target219.elements.count 1,
      target219.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain219
def tree220 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 1) (.leaf 1)))
def target220 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain220 : accepts tree220 target220 = true ∧
    sourceLeaves tree220 = [1, 0, 1, 1] ∧
    target220.elements.length = 4 ∧
    [target220.elements.count 0, target220.elements.count 1,
      target220.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain220
def tree221 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))) (.leaf 1))
def target221 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain221 : accepts tree221 target221 = true ∧
    sourceLeaves tree221 = [1, 0, 1, 1] ∧
    target221.elements.length = 4 ∧
    [target221.elements.count 0, target221.elements.count 1,
      target221.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain221
def tree222 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target222 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain222 : accepts tree222 target222 = true ∧
    sourceLeaves tree222 = [1, 0, 1, 1] ∧
    target222.elements.length = 4 ∧
    [target222.elements.count 0, target222.elements.count 1,
      target222.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain222
def tree223 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))))
def target223 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain223 : accepts tree223 target223 = true ∧
    sourceLeaves tree223 = [1, 0, 1, 2] ∧
    target223.elements.length = 4 ∧
    [target223.elements.count 0, target223.elements.count 1,
      target223.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain223
def tree224 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)))
def target224 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain224 : accepts tree224 target224 = true ∧
    sourceLeaves tree224 = [1, 0, 1, 2] ∧
    target224.elements.length = 4 ∧
    [target224.elements.count 0, target224.elements.count 1,
      target224.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain224
def tree225 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 1) (.leaf 2)))
def target225 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain225 : accepts tree225 target225 = true ∧
    sourceLeaves tree225 = [1, 0, 1, 2] ∧
    target225.elements.length = 4 ∧
    [target225.elements.count 0, target225.elements.count 1,
      target225.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain225
def tree226 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))) (.leaf 2))
def target226 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain226 : accepts tree226 target226 = true ∧
    sourceLeaves tree226 = [1, 0, 1, 2] ∧
    target226.elements.length = 4 ∧
    [target226.elements.count 0, target226.elements.count 1,
      target226.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain226
def tree227 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target227 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain227 : accepts tree227 target227 = true ∧
    sourceLeaves tree227 = [1, 0, 1, 2] ∧
    target227.elements.length = 4 ∧
    [target227.elements.count 0, target227.elements.count 1,
      target227.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain227
def tree228 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))))
def target228 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain228 : accepts tree228 target228 = true ∧
    sourceLeaves tree228 = [1, 0, 2, 0] ∧
    target228.elements.length = 4 ∧
    [target228.elements.count 0, target228.elements.count 1,
      target228.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain228
def tree229 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)))
def target229 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain229 : accepts tree229 target229 = true ∧
    sourceLeaves tree229 = [1, 0, 2, 0] ∧
    target229.elements.length = 4 ∧
    [target229.elements.count 0, target229.elements.count 1,
      target229.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain229
def tree230 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 2) (.leaf 0)))
def target230 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain230 : accepts tree230 target230 = true ∧
    sourceLeaves tree230 = [1, 0, 2, 0] ∧
    target230.elements.length = 4 ∧
    [target230.elements.count 0, target230.elements.count 1,
      target230.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain230
def tree231 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))) (.leaf 0))
def target231 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain231 : accepts tree231 target231 = true ∧
    sourceLeaves tree231 = [1, 0, 2, 0] ∧
    target231.elements.length = 4 ∧
    [target231.elements.count 0, target231.elements.count 1,
      target231.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain231
def tree232 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target232 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain232 : accepts tree232 target232 = true ∧
    sourceLeaves tree232 = [1, 0, 2, 0] ∧
    target232.elements.length = 4 ∧
    [target232.elements.count 0, target232.elements.count 1,
      target232.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain232
def tree233 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))))
def target233 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain233 : accepts tree233 target233 = true ∧
    sourceLeaves tree233 = [1, 0, 2, 1] ∧
    target233.elements.length = 4 ∧
    [target233.elements.count 0, target233.elements.count 1,
      target233.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain233
def tree234 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)))
def target234 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain234 : accepts tree234 target234 = true ∧
    sourceLeaves tree234 = [1, 0, 2, 1] ∧
    target234.elements.length = 4 ∧
    [target234.elements.count 0, target234.elements.count 1,
      target234.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain234
def tree235 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 2) (.leaf 1)))
def target235 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain235 : accepts tree235 target235 = true ∧
    sourceLeaves tree235 = [1, 0, 2, 1] ∧
    target235.elements.length = 4 ∧
    [target235.elements.count 0, target235.elements.count 1,
      target235.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain235
def tree236 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))) (.leaf 1))
def target236 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain236 : accepts tree236 target236 = true ∧
    sourceLeaves tree236 = [1, 0, 2, 1] ∧
    target236.elements.length = 4 ∧
    [target236.elements.count 0, target236.elements.count 1,
      target236.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain236
def tree237 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target237 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain237 : accepts tree237 target237 = true ∧
    sourceLeaves tree237 = [1, 0, 2, 1] ∧
    target237.elements.length = 4 ∧
    [target237.elements.count 0, target237.elements.count 1,
      target237.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain237
def tree238 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))))
def target238 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain238 : accepts tree238 target238 = true ∧
    sourceLeaves tree238 = [1, 0, 2, 2] ∧
    target238.elements.length = 4 ∧
    [target238.elements.count 0, target238.elements.count 1,
      target238.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain238
def tree239 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)))
def target239 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain239 : accepts tree239 target239 = true ∧
    sourceLeaves tree239 = [1, 0, 2, 2] ∧
    target239.elements.length = 4 ∧
    [target239.elements.count 0, target239.elements.count 1,
      target239.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain239
def tree240 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 2) (.leaf 2)))
def target240 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain240 : accepts tree240 target240 = true ∧
    sourceLeaves tree240 = [1, 0, 2, 2] ∧
    target240.elements.length = 4 ∧
    [target240.elements.count 0, target240.elements.count 1,
      target240.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain240
def tree241 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))) (.leaf 2))
def target241 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain241 : accepts tree241 target241 = true ∧
    sourceLeaves tree241 = [1, 0, 2, 2] ∧
    target241.elements.length = 4 ∧
    [target241.elements.count 0, target241.elements.count 1,
      target241.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain241
def tree242 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target242 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain242 : accepts tree242 target242 = true ∧
    sourceLeaves tree242 = [1, 0, 2, 2] ∧
    target242.elements.length = 4 ∧
    [target242.elements.count 0, target242.elements.count 1,
      target242.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain242
def tree243 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))))
def target243 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain243 : accepts tree243 target243 = true ∧
    sourceLeaves tree243 = [1, 1, 0, 0] ∧
    target243.elements.length = 4 ∧
    [target243.elements.count 0, target243.elements.count 1,
      target243.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain243
def tree244 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)))
def target244 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain244 : accepts tree244 target244 = true ∧
    sourceLeaves tree244 = [1, 1, 0, 0] ∧
    target244.elements.length = 4 ∧
    [target244.elements.count 0, target244.elements.count 1,
      target244.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain244
def tree245 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 0) (.leaf 0)))
def target245 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain245 : accepts tree245 target245 = true ∧
    sourceLeaves tree245 = [1, 1, 0, 0] ∧
    target245.elements.length = 4 ∧
    [target245.elements.count 0, target245.elements.count 1,
      target245.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain245
def tree246 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))) (.leaf 0))
def target246 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain246 : accepts tree246 target246 = true ∧
    sourceLeaves tree246 = [1, 1, 0, 0] ∧
    target246.elements.length = 4 ∧
    [target246.elements.count 0, target246.elements.count 1,
      target246.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain246
def tree247 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target247 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain247 : accepts tree247 target247 = true ∧
    sourceLeaves tree247 = [1, 1, 0, 0] ∧
    target247.elements.length = 4 ∧
    [target247.elements.count 0, target247.elements.count 1,
      target247.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain247
def tree248 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))))
def target248 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain248 : accepts tree248 target248 = true ∧
    sourceLeaves tree248 = [1, 1, 0, 1] ∧
    target248.elements.length = 4 ∧
    [target248.elements.count 0, target248.elements.count 1,
      target248.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain248
def tree249 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)))
def target249 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain249 : accepts tree249 target249 = true ∧
    sourceLeaves tree249 = [1, 1, 0, 1] ∧
    target249.elements.length = 4 ∧
    [target249.elements.count 0, target249.elements.count 1,
      target249.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain249
def tree250 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 0) (.leaf 1)))
def target250 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain250 : accepts tree250 target250 = true ∧
    sourceLeaves tree250 = [1, 1, 0, 1] ∧
    target250.elements.length = 4 ∧
    [target250.elements.count 0, target250.elements.count 1,
      target250.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain250
def tree251 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))) (.leaf 1))
def target251 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain251 : accepts tree251 target251 = true ∧
    sourceLeaves tree251 = [1, 1, 0, 1] ∧
    target251.elements.length = 4 ∧
    [target251.elements.count 0, target251.elements.count 1,
      target251.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain251
def tree252 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target252 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain252 : accepts tree252 target252 = true ∧
    sourceLeaves tree252 = [1, 1, 0, 1] ∧
    target252.elements.length = 4 ∧
    [target252.elements.count 0, target252.elements.count 1,
      target252.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain252
def tree253 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))))
def target253 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain253 : accepts tree253 target253 = true ∧
    sourceLeaves tree253 = [1, 1, 0, 2] ∧
    target253.elements.length = 4 ∧
    [target253.elements.count 0, target253.elements.count 1,
      target253.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain253
def tree254 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)))
def target254 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain254 : accepts tree254 target254 = true ∧
    sourceLeaves tree254 = [1, 1, 0, 2] ∧
    target254.elements.length = 4 ∧
    [target254.elements.count 0, target254.elements.count 1,
      target254.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain254
def tree255 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 0) (.leaf 2)))
def target255 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain255 : accepts tree255 target255 = true ∧
    sourceLeaves tree255 = [1, 1, 0, 2] ∧
    target255.elements.length = 4 ∧
    [target255.elements.count 0, target255.elements.count 1,
      target255.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain255
def tree256 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))) (.leaf 2))
def target256 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain256 : accepts tree256 target256 = true ∧
    sourceLeaves tree256 = [1, 1, 0, 2] ∧
    target256.elements.length = 4 ∧
    [target256.elements.count 0, target256.elements.count 1,
      target256.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain256
def tree257 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target257 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain257 : accepts tree257 target257 = true ∧
    sourceLeaves tree257 = [1, 1, 0, 2] ∧
    target257.elements.length = 4 ∧
    [target257.elements.count 0, target257.elements.count 1,
      target257.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain257
def tree258 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))))
def target258 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain258 : accepts tree258 target258 = true ∧
    sourceLeaves tree258 = [1, 1, 1, 0] ∧
    target258.elements.length = 4 ∧
    [target258.elements.count 0, target258.elements.count 1,
      target258.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain258
def tree259 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)))
def target259 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain259 : accepts tree259 target259 = true ∧
    sourceLeaves tree259 = [1, 1, 1, 0] ∧
    target259.elements.length = 4 ∧
    [target259.elements.count 0, target259.elements.count 1,
      target259.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain259
def tree260 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 1) (.leaf 0)))
def target260 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain260 : accepts tree260 target260 = true ∧
    sourceLeaves tree260 = [1, 1, 1, 0] ∧
    target260.elements.length = 4 ∧
    [target260.elements.count 0, target260.elements.count 1,
      target260.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain260
def tree261 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))) (.leaf 0))
def target261 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain261 : accepts tree261 target261 = true ∧
    sourceLeaves tree261 = [1, 1, 1, 0] ∧
    target261.elements.length = 4 ∧
    [target261.elements.count 0, target261.elements.count 1,
      target261.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain261
def tree262 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target262 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain262 : accepts tree262 target262 = true ∧
    sourceLeaves tree262 = [1, 1, 1, 0] ∧
    target262.elements.length = 4 ∧
    [target262.elements.count 0, target262.elements.count 1,
      target262.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain262
def tree263 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))))
def target263 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain263 : accepts tree263 target263 = true ∧
    sourceLeaves tree263 = [1, 1, 1, 1] ∧
    target263.elements.length = 4 ∧
    [target263.elements.count 0, target263.elements.count 1,
      target263.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain263
def tree264 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)))
def target264 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain264 : accepts tree264 target264 = true ∧
    sourceLeaves tree264 = [1, 1, 1, 1] ∧
    target264.elements.length = 4 ∧
    [target264.elements.count 0, target264.elements.count 1,
      target264.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain264
def tree265 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 1) (.leaf 1)))
def target265 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain265 : accepts tree265 target265 = true ∧
    sourceLeaves tree265 = [1, 1, 1, 1] ∧
    target265.elements.length = 4 ∧
    [target265.elements.count 0, target265.elements.count 1,
      target265.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain265
def tree266 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))) (.leaf 1))
def target266 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain266 : accepts tree266 target266 = true ∧
    sourceLeaves tree266 = [1, 1, 1, 1] ∧
    target266.elements.length = 4 ∧
    [target266.elements.count 0, target266.elements.count 1,
      target266.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain266
def tree267 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target267 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain267 : accepts tree267 target267 = true ∧
    sourceLeaves tree267 = [1, 1, 1, 1] ∧
    target267.elements.length = 4 ∧
    [target267.elements.count 0, target267.elements.count 1,
      target267.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain267
def tree268 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))))
def target268 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain268 : accepts tree268 target268 = true ∧
    sourceLeaves tree268 = [1, 1, 1, 2] ∧
    target268.elements.length = 4 ∧
    [target268.elements.count 0, target268.elements.count 1,
      target268.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain268
def tree269 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)))
def target269 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain269 : accepts tree269 target269 = true ∧
    sourceLeaves tree269 = [1, 1, 1, 2] ∧
    target269.elements.length = 4 ∧
    [target269.elements.count 0, target269.elements.count 1,
      target269.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain269
def tree270 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 1) (.leaf 2)))
def target270 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain270 : accepts tree270 target270 = true ∧
    sourceLeaves tree270 = [1, 1, 1, 2] ∧
    target270.elements.length = 4 ∧
    [target270.elements.count 0, target270.elements.count 1,
      target270.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain270
def tree271 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))) (.leaf 2))
def target271 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain271 : accepts tree271 target271 = true ∧
    sourceLeaves tree271 = [1, 1, 1, 2] ∧
    target271.elements.length = 4 ∧
    [target271.elements.count 0, target271.elements.count 1,
      target271.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain271
def tree272 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target272 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain272 : accepts tree272 target272 = true ∧
    sourceLeaves tree272 = [1, 1, 1, 2] ∧
    target272.elements.length = 4 ∧
    [target272.elements.count 0, target272.elements.count 1,
      target272.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain272
def tree273 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))))
def target273 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain273 : accepts tree273 target273 = true ∧
    sourceLeaves tree273 = [1, 1, 2, 0] ∧
    target273.elements.length = 4 ∧
    [target273.elements.count 0, target273.elements.count 1,
      target273.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain273
def tree274 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)))
def target274 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain274 : accepts tree274 target274 = true ∧
    sourceLeaves tree274 = [1, 1, 2, 0] ∧
    target274.elements.length = 4 ∧
    [target274.elements.count 0, target274.elements.count 1,
      target274.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain274
def tree275 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 2) (.leaf 0)))
def target275 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain275 : accepts tree275 target275 = true ∧
    sourceLeaves tree275 = [1, 1, 2, 0] ∧
    target275.elements.length = 4 ∧
    [target275.elements.count 0, target275.elements.count 1,
      target275.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain275
def tree276 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))) (.leaf 0))
def target276 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain276 : accepts tree276 target276 = true ∧
    sourceLeaves tree276 = [1, 1, 2, 0] ∧
    target276.elements.length = 4 ∧
    [target276.elements.count 0, target276.elements.count 1,
      target276.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain276
def tree277 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target277 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain277 : accepts tree277 target277 = true ∧
    sourceLeaves tree277 = [1, 1, 2, 0] ∧
    target277.elements.length = 4 ∧
    [target277.elements.count 0, target277.elements.count 1,
      target277.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain277
def tree278 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))))
def target278 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain278 : accepts tree278 target278 = true ∧
    sourceLeaves tree278 = [1, 1, 2, 1] ∧
    target278.elements.length = 4 ∧
    [target278.elements.count 0, target278.elements.count 1,
      target278.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain278
def tree279 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)))
def target279 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain279 : accepts tree279 target279 = true ∧
    sourceLeaves tree279 = [1, 1, 2, 1] ∧
    target279.elements.length = 4 ∧
    [target279.elements.count 0, target279.elements.count 1,
      target279.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain279
def tree280 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 2) (.leaf 1)))
def target280 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain280 : accepts tree280 target280 = true ∧
    sourceLeaves tree280 = [1, 1, 2, 1] ∧
    target280.elements.length = 4 ∧
    [target280.elements.count 0, target280.elements.count 1,
      target280.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain280
def tree281 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))) (.leaf 1))
def target281 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain281 : accepts tree281 target281 = true ∧
    sourceLeaves tree281 = [1, 1, 2, 1] ∧
    target281.elements.length = 4 ∧
    [target281.elements.count 0, target281.elements.count 1,
      target281.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain281
def tree282 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target282 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain282 : accepts tree282 target282 = true ∧
    sourceLeaves tree282 = [1, 1, 2, 1] ∧
    target282.elements.length = 4 ∧
    [target282.elements.count 0, target282.elements.count 1,
      target282.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain282
def tree283 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))))
def target283 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain283 : accepts tree283 target283 = true ∧
    sourceLeaves tree283 = [1, 1, 2, 2] ∧
    target283.elements.length = 4 ∧
    [target283.elements.count 0, target283.elements.count 1,
      target283.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain283
def tree284 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)))
def target284 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain284 : accepts tree284 target284 = true ∧
    sourceLeaves tree284 = [1, 1, 2, 2] ∧
    target284.elements.length = 4 ∧
    [target284.elements.count 0, target284.elements.count 1,
      target284.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain284
def tree285 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 2) (.leaf 2)))
def target285 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain285 : accepts tree285 target285 = true ∧
    sourceLeaves tree285 = [1, 1, 2, 2] ∧
    target285.elements.length = 4 ∧
    [target285.elements.count 0, target285.elements.count 1,
      target285.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain285
def tree286 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))) (.leaf 2))
def target286 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain286 : accepts tree286 target286 = true ∧
    sourceLeaves tree286 = [1, 1, 2, 2] ∧
    target286.elements.length = 4 ∧
    [target286.elements.count 0, target286.elements.count 1,
      target286.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain286
def tree287 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target287 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain287 : accepts tree287 target287 = true ∧
    sourceLeaves tree287 = [1, 1, 2, 2] ∧
    target287.elements.length = 4 ∧
    [target287.elements.count 0, target287.elements.count 1,
      target287.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain287
def tree288 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))))
def target288 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain288 : accepts tree288 target288 = true ∧
    sourceLeaves tree288 = [1, 2, 0, 0] ∧
    target288.elements.length = 4 ∧
    [target288.elements.count 0, target288.elements.count 1,
      target288.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain288
def tree289 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)))
def target289 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain289 : accepts tree289 target289 = true ∧
    sourceLeaves tree289 = [1, 2, 0, 0] ∧
    target289.elements.length = 4 ∧
    [target289.elements.count 0, target289.elements.count 1,
      target289.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain289
def tree290 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 0) (.leaf 0)))
def target290 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain290 : accepts tree290 target290 = true ∧
    sourceLeaves tree290 = [1, 2, 0, 0] ∧
    target290.elements.length = 4 ∧
    [target290.elements.count 0, target290.elements.count 1,
      target290.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain290
def tree291 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))) (.leaf 0))
def target291 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain291 : accepts tree291 target291 = true ∧
    sourceLeaves tree291 = [1, 2, 0, 0] ∧
    target291.elements.length = 4 ∧
    [target291.elements.count 0, target291.elements.count 1,
      target291.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain291
def tree292 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target292 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain292 : accepts tree292 target292 = true ∧
    sourceLeaves tree292 = [1, 2, 0, 0] ∧
    target292.elements.length = 4 ∧
    [target292.elements.count 0, target292.elements.count 1,
      target292.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain292
def tree293 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))))
def target293 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain293 : accepts tree293 target293 = true ∧
    sourceLeaves tree293 = [1, 2, 0, 1] ∧
    target293.elements.length = 4 ∧
    [target293.elements.count 0, target293.elements.count 1,
      target293.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain293
def tree294 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)))
def target294 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain294 : accepts tree294 target294 = true ∧
    sourceLeaves tree294 = [1, 2, 0, 1] ∧
    target294.elements.length = 4 ∧
    [target294.elements.count 0, target294.elements.count 1,
      target294.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain294
def tree295 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 0) (.leaf 1)))
def target295 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain295 : accepts tree295 target295 = true ∧
    sourceLeaves tree295 = [1, 2, 0, 1] ∧
    target295.elements.length = 4 ∧
    [target295.elements.count 0, target295.elements.count 1,
      target295.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain295
def tree296 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))) (.leaf 1))
def target296 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain296 : accepts tree296 target296 = true ∧
    sourceLeaves tree296 = [1, 2, 0, 1] ∧
    target296.elements.length = 4 ∧
    [target296.elements.count 0, target296.elements.count 1,
      target296.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain296
def tree297 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target297 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain297 : accepts tree297 target297 = true ∧
    sourceLeaves tree297 = [1, 2, 0, 1] ∧
    target297.elements.length = 4 ∧
    [target297.elements.count 0, target297.elements.count 1,
      target297.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain297
def tree298 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))))
def target298 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain298 : accepts tree298 target298 = true ∧
    sourceLeaves tree298 = [1, 2, 0, 2] ∧
    target298.elements.length = 4 ∧
    [target298.elements.count 0, target298.elements.count 1,
      target298.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain298
def tree299 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)))
def target299 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain299 : accepts tree299 target299 = true ∧
    sourceLeaves tree299 = [1, 2, 0, 2] ∧
    target299.elements.length = 4 ∧
    [target299.elements.count 0, target299.elements.count 1,
      target299.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain299
def tree300 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 0) (.leaf 2)))
def target300 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain300 : accepts tree300 target300 = true ∧
    sourceLeaves tree300 = [1, 2, 0, 2] ∧
    target300.elements.length = 4 ∧
    [target300.elements.count 0, target300.elements.count 1,
      target300.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain300
def tree301 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))) (.leaf 2))
def target301 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain301 : accepts tree301 target301 = true ∧
    sourceLeaves tree301 = [1, 2, 0, 2] ∧
    target301.elements.length = 4 ∧
    [target301.elements.count 0, target301.elements.count 1,
      target301.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain301
def tree302 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target302 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain302 : accepts tree302 target302 = true ∧
    sourceLeaves tree302 = [1, 2, 0, 2] ∧
    target302.elements.length = 4 ∧
    [target302.elements.count 0, target302.elements.count 1,
      target302.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain302
def tree303 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))))
def target303 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain303 : accepts tree303 target303 = true ∧
    sourceLeaves tree303 = [1, 2, 1, 0] ∧
    target303.elements.length = 4 ∧
    [target303.elements.count 0, target303.elements.count 1,
      target303.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain303
def tree304 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)))
def target304 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain304 : accepts tree304 target304 = true ∧
    sourceLeaves tree304 = [1, 2, 1, 0] ∧
    target304.elements.length = 4 ∧
    [target304.elements.count 0, target304.elements.count 1,
      target304.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain304
def tree305 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 1) (.leaf 0)))
def target305 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain305 : accepts tree305 target305 = true ∧
    sourceLeaves tree305 = [1, 2, 1, 0] ∧
    target305.elements.length = 4 ∧
    [target305.elements.count 0, target305.elements.count 1,
      target305.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain305
def tree306 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))) (.leaf 0))
def target306 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain306 : accepts tree306 target306 = true ∧
    sourceLeaves tree306 = [1, 2, 1, 0] ∧
    target306.elements.length = 4 ∧
    [target306.elements.count 0, target306.elements.count 1,
      target306.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain306
def tree307 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target307 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain307 : accepts tree307 target307 = true ∧
    sourceLeaves tree307 = [1, 2, 1, 0] ∧
    target307.elements.length = 4 ∧
    [target307.elements.count 0, target307.elements.count 1,
      target307.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain307
def tree308 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))))
def target308 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain308 : accepts tree308 target308 = true ∧
    sourceLeaves tree308 = [1, 2, 1, 1] ∧
    target308.elements.length = 4 ∧
    [target308.elements.count 0, target308.elements.count 1,
      target308.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain308
def tree309 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)))
def target309 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain309 : accepts tree309 target309 = true ∧
    sourceLeaves tree309 = [1, 2, 1, 1] ∧
    target309.elements.length = 4 ∧
    [target309.elements.count 0, target309.elements.count 1,
      target309.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain309
def tree310 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 1) (.leaf 1)))
def target310 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain310 : accepts tree310 target310 = true ∧
    sourceLeaves tree310 = [1, 2, 1, 1] ∧
    target310.elements.length = 4 ∧
    [target310.elements.count 0, target310.elements.count 1,
      target310.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain310
def tree311 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))) (.leaf 1))
def target311 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain311 : accepts tree311 target311 = true ∧
    sourceLeaves tree311 = [1, 2, 1, 1] ∧
    target311.elements.length = 4 ∧
    [target311.elements.count 0, target311.elements.count 1,
      target311.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain311
def tree312 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target312 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain312 : accepts tree312 target312 = true ∧
    sourceLeaves tree312 = [1, 2, 1, 1] ∧
    target312.elements.length = 4 ∧
    [target312.elements.count 0, target312.elements.count 1,
      target312.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain312
def tree313 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))))
def target313 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain313 : accepts tree313 target313 = true ∧
    sourceLeaves tree313 = [1, 2, 1, 2] ∧
    target313.elements.length = 4 ∧
    [target313.elements.count 0, target313.elements.count 1,
      target313.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain313
def tree314 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)))
def target314 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain314 : accepts tree314 target314 = true ∧
    sourceLeaves tree314 = [1, 2, 1, 2] ∧
    target314.elements.length = 4 ∧
    [target314.elements.count 0, target314.elements.count 1,
      target314.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain314
def tree315 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 1) (.leaf 2)))
def target315 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain315 : accepts tree315 target315 = true ∧
    sourceLeaves tree315 = [1, 2, 1, 2] ∧
    target315.elements.length = 4 ∧
    [target315.elements.count 0, target315.elements.count 1,
      target315.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain315
def tree316 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))) (.leaf 2))
def target316 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain316 : accepts tree316 target316 = true ∧
    sourceLeaves tree316 = [1, 2, 1, 2] ∧
    target316.elements.length = 4 ∧
    [target316.elements.count 0, target316.elements.count 1,
      target316.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain316
def tree317 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target317 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain317 : accepts tree317 target317 = true ∧
    sourceLeaves tree317 = [1, 2, 1, 2] ∧
    target317.elements.length = 4 ∧
    [target317.elements.count 0, target317.elements.count 1,
      target317.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain317
def tree318 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))))
def target318 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain318 : accepts tree318 target318 = true ∧
    sourceLeaves tree318 = [1, 2, 2, 0] ∧
    target318.elements.length = 4 ∧
    [target318.elements.count 0, target318.elements.count 1,
      target318.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain318
def tree319 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)))
def target319 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain319 : accepts tree319 target319 = true ∧
    sourceLeaves tree319 = [1, 2, 2, 0] ∧
    target319.elements.length = 4 ∧
    [target319.elements.count 0, target319.elements.count 1,
      target319.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain319
def tree320 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 2) (.leaf 0)))
def target320 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain320 : accepts tree320 target320 = true ∧
    sourceLeaves tree320 = [1, 2, 2, 0] ∧
    target320.elements.length = 4 ∧
    [target320.elements.count 0, target320.elements.count 1,
      target320.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain320
def tree321 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))) (.leaf 0))
def target321 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain321 : accepts tree321 target321 = true ∧
    sourceLeaves tree321 = [1, 2, 2, 0] ∧
    target321.elements.length = 4 ∧
    [target321.elements.count 0, target321.elements.count 1,
      target321.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain321
def tree322 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target322 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain322 : accepts tree322 target322 = true ∧
    sourceLeaves tree322 = [1, 2, 2, 0] ∧
    target322.elements.length = 4 ∧
    [target322.elements.count 0, target322.elements.count 1,
      target322.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain322
def tree323 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))))
def target323 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain323 : accepts tree323 target323 = true ∧
    sourceLeaves tree323 = [1, 2, 2, 1] ∧
    target323.elements.length = 4 ∧
    [target323.elements.count 0, target323.elements.count 1,
      target323.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain323
def tree324 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)))
def target324 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain324 : accepts tree324 target324 = true ∧
    sourceLeaves tree324 = [1, 2, 2, 1] ∧
    target324.elements.length = 4 ∧
    [target324.elements.count 0, target324.elements.count 1,
      target324.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain324
def tree325 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 2) (.leaf 1)))
def target325 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain325 : accepts tree325 target325 = true ∧
    sourceLeaves tree325 = [1, 2, 2, 1] ∧
    target325.elements.length = 4 ∧
    [target325.elements.count 0, target325.elements.count 1,
      target325.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain325
def tree326 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))) (.leaf 1))
def target326 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain326 : accepts tree326 target326 = true ∧
    sourceLeaves tree326 = [1, 2, 2, 1] ∧
    target326.elements.length = 4 ∧
    [target326.elements.count 0, target326.elements.count 1,
      target326.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain326
def tree327 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target327 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain327 : accepts tree327 target327 = true ∧
    sourceLeaves tree327 = [1, 2, 2, 1] ∧
    target327.elements.length = 4 ∧
    [target327.elements.count 0, target327.elements.count 1,
      target327.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain327
def tree328 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))))
def target328 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain328 : accepts tree328 target328 = true ∧
    sourceLeaves tree328 = [1, 2, 2, 2] ∧
    target328.elements.length = 4 ∧
    [target328.elements.count 0, target328.elements.count 1,
      target328.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain328
def tree329 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)))
def target329 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain329 : accepts tree329 target329 = true ∧
    sourceLeaves tree329 = [1, 2, 2, 2] ∧
    target329.elements.length = 4 ∧
    [target329.elements.count 0, target329.elements.count 1,
      target329.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain329
def tree330 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 2) (.leaf 2)))
def target330 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain330 : accepts tree330 target330 = true ∧
    sourceLeaves tree330 = [1, 2, 2, 2] ∧
    target330.elements.length = 4 ∧
    [target330.elements.count 0, target330.elements.count 1,
      target330.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain330
def tree331 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))) (.leaf 2))
def target331 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain331 : accepts tree331 target331 = true ∧
    sourceLeaves tree331 = [1, 2, 2, 2] ∧
    target331.elements.length = 4 ∧
    [target331.elements.count 0, target331.elements.count 1,
      target331.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain331
def tree332 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target332 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain332 : accepts tree332 target332 = true ∧
    sourceLeaves tree332 = [1, 2, 2, 2] ∧
    target332.elements.length = 4 ∧
    [target332.elements.count 0, target332.elements.count 1,
      target332.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain332
def tree333 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))))
def target333 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain333 : accepts tree333 target333 = true ∧
    sourceLeaves tree333 = [2, 0, 0, 0] ∧
    target333.elements.length = 4 ∧
    [target333.elements.count 0, target333.elements.count 1,
      target333.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain333
def tree334 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)))
def target334 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain334 : accepts tree334 target334 = true ∧
    sourceLeaves tree334 = [2, 0, 0, 0] ∧
    target334.elements.length = 4 ∧
    [target334.elements.count 0, target334.elements.count 1,
      target334.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain334
def tree335 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 0) (.leaf 0)))
def target335 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain335 : accepts tree335 target335 = true ∧
    sourceLeaves tree335 = [2, 0, 0, 0] ∧
    target335.elements.length = 4 ∧
    [target335.elements.count 0, target335.elements.count 1,
      target335.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain335
def tree336 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))) (.leaf 0))
def target336 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain336 : accepts tree336 target336 = true ∧
    sourceLeaves tree336 = [2, 0, 0, 0] ∧
    target336.elements.length = 4 ∧
    [target336.elements.count 0, target336.elements.count 1,
      target336.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain336
def tree337 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target337 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain337 : accepts tree337 target337 = true ∧
    sourceLeaves tree337 = [2, 0, 0, 0] ∧
    target337.elements.length = 4 ∧
    [target337.elements.count 0, target337.elements.count 1,
      target337.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain337
def tree338 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))))
def target338 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain338 : accepts tree338 target338 = true ∧
    sourceLeaves tree338 = [2, 0, 0, 1] ∧
    target338.elements.length = 4 ∧
    [target338.elements.count 0, target338.elements.count 1,
      target338.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain338
def tree339 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)))
def target339 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain339 : accepts tree339 target339 = true ∧
    sourceLeaves tree339 = [2, 0, 0, 1] ∧
    target339.elements.length = 4 ∧
    [target339.elements.count 0, target339.elements.count 1,
      target339.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain339
def tree340 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 0) (.leaf 1)))
def target340 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain340 : accepts tree340 target340 = true ∧
    sourceLeaves tree340 = [2, 0, 0, 1] ∧
    target340.elements.length = 4 ∧
    [target340.elements.count 0, target340.elements.count 1,
      target340.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain340
def tree341 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))) (.leaf 1))
def target341 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain341 : accepts tree341 target341 = true ∧
    sourceLeaves tree341 = [2, 0, 0, 1] ∧
    target341.elements.length = 4 ∧
    [target341.elements.count 0, target341.elements.count 1,
      target341.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain341
def tree342 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target342 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain342 : accepts tree342 target342 = true ∧
    sourceLeaves tree342 = [2, 0, 0, 1] ∧
    target342.elements.length = 4 ∧
    [target342.elements.count 0, target342.elements.count 1,
      target342.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain342
def tree343 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))))
def target343 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain343 : accepts tree343 target343 = true ∧
    sourceLeaves tree343 = [2, 0, 0, 2] ∧
    target343.elements.length = 4 ∧
    [target343.elements.count 0, target343.elements.count 1,
      target343.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain343
def tree344 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)))
def target344 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain344 : accepts tree344 target344 = true ∧
    sourceLeaves tree344 = [2, 0, 0, 2] ∧
    target344.elements.length = 4 ∧
    [target344.elements.count 0, target344.elements.count 1,
      target344.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain344
def tree345 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 0) (.leaf 2)))
def target345 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain345 : accepts tree345 target345 = true ∧
    sourceLeaves tree345 = [2, 0, 0, 2] ∧
    target345.elements.length = 4 ∧
    [target345.elements.count 0, target345.elements.count 1,
      target345.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain345
def tree346 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))) (.leaf 2))
def target346 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain346 : accepts tree346 target346 = true ∧
    sourceLeaves tree346 = [2, 0, 0, 2] ∧
    target346.elements.length = 4 ∧
    [target346.elements.count 0, target346.elements.count 1,
      target346.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain346
def tree347 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target347 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain347 : accepts tree347 target347 = true ∧
    sourceLeaves tree347 = [2, 0, 0, 2] ∧
    target347.elements.length = 4 ∧
    [target347.elements.count 0, target347.elements.count 1,
      target347.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain347
def tree348 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))))
def target348 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain348 : accepts tree348 target348 = true ∧
    sourceLeaves tree348 = [2, 0, 1, 0] ∧
    target348.elements.length = 4 ∧
    [target348.elements.count 0, target348.elements.count 1,
      target348.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain348
def tree349 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)))
def target349 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain349 : accepts tree349 target349 = true ∧
    sourceLeaves tree349 = [2, 0, 1, 0] ∧
    target349.elements.length = 4 ∧
    [target349.elements.count 0, target349.elements.count 1,
      target349.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain349
def tree350 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 1) (.leaf 0)))
def target350 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain350 : accepts tree350 target350 = true ∧
    sourceLeaves tree350 = [2, 0, 1, 0] ∧
    target350.elements.length = 4 ∧
    [target350.elements.count 0, target350.elements.count 1,
      target350.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain350
def tree351 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))) (.leaf 0))
def target351 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain351 : accepts tree351 target351 = true ∧
    sourceLeaves tree351 = [2, 0, 1, 0] ∧
    target351.elements.length = 4 ∧
    [target351.elements.count 0, target351.elements.count 1,
      target351.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain351
def tree352 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target352 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain352 : accepts tree352 target352 = true ∧
    sourceLeaves tree352 = [2, 0, 1, 0] ∧
    target352.elements.length = 4 ∧
    [target352.elements.count 0, target352.elements.count 1,
      target352.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain352
def tree353 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))))
def target353 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain353 : accepts tree353 target353 = true ∧
    sourceLeaves tree353 = [2, 0, 1, 1] ∧
    target353.elements.length = 4 ∧
    [target353.elements.count 0, target353.elements.count 1,
      target353.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain353
def tree354 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)))
def target354 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain354 : accepts tree354 target354 = true ∧
    sourceLeaves tree354 = [2, 0, 1, 1] ∧
    target354.elements.length = 4 ∧
    [target354.elements.count 0, target354.elements.count 1,
      target354.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain354
def tree355 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 1) (.leaf 1)))
def target355 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain355 : accepts tree355 target355 = true ∧
    sourceLeaves tree355 = [2, 0, 1, 1] ∧
    target355.elements.length = 4 ∧
    [target355.elements.count 0, target355.elements.count 1,
      target355.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain355
def tree356 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))) (.leaf 1))
def target356 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain356 : accepts tree356 target356 = true ∧
    sourceLeaves tree356 = [2, 0, 1, 1] ∧
    target356.elements.length = 4 ∧
    [target356.elements.count 0, target356.elements.count 1,
      target356.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain356
def tree357 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target357 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain357 : accepts tree357 target357 = true ∧
    sourceLeaves tree357 = [2, 0, 1, 1] ∧
    target357.elements.length = 4 ∧
    [target357.elements.count 0, target357.elements.count 1,
      target357.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain357
def tree358 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))))
def target358 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain358 : accepts tree358 target358 = true ∧
    sourceLeaves tree358 = [2, 0, 1, 2] ∧
    target358.elements.length = 4 ∧
    [target358.elements.count 0, target358.elements.count 1,
      target358.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain358
def tree359 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)))
def target359 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain359 : accepts tree359 target359 = true ∧
    sourceLeaves tree359 = [2, 0, 1, 2] ∧
    target359.elements.length = 4 ∧
    [target359.elements.count 0, target359.elements.count 1,
      target359.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain359
def tree360 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 1) (.leaf 2)))
def target360 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain360 : accepts tree360 target360 = true ∧
    sourceLeaves tree360 = [2, 0, 1, 2] ∧
    target360.elements.length = 4 ∧
    [target360.elements.count 0, target360.elements.count 1,
      target360.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain360
def tree361 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))) (.leaf 2))
def target361 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain361 : accepts tree361 target361 = true ∧
    sourceLeaves tree361 = [2, 0, 1, 2] ∧
    target361.elements.length = 4 ∧
    [target361.elements.count 0, target361.elements.count 1,
      target361.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain361
def tree362 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target362 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain362 : accepts tree362 target362 = true ∧
    sourceLeaves tree362 = [2, 0, 1, 2] ∧
    target362.elements.length = 4 ∧
    [target362.elements.count 0, target362.elements.count 1,
      target362.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain362
def tree363 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))))
def target363 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain363 : accepts tree363 target363 = true ∧
    sourceLeaves tree363 = [2, 0, 2, 0] ∧
    target363.elements.length = 4 ∧
    [target363.elements.count 0, target363.elements.count 1,
      target363.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain363
def tree364 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)))
def target364 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain364 : accepts tree364 target364 = true ∧
    sourceLeaves tree364 = [2, 0, 2, 0] ∧
    target364.elements.length = 4 ∧
    [target364.elements.count 0, target364.elements.count 1,
      target364.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain364
def tree365 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 2) (.leaf 0)))
def target365 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain365 : accepts tree365 target365 = true ∧
    sourceLeaves tree365 = [2, 0, 2, 0] ∧
    target365.elements.length = 4 ∧
    [target365.elements.count 0, target365.elements.count 1,
      target365.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain365
def tree366 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))) (.leaf 0))
def target366 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain366 : accepts tree366 target366 = true ∧
    sourceLeaves tree366 = [2, 0, 2, 0] ∧
    target366.elements.length = 4 ∧
    [target366.elements.count 0, target366.elements.count 1,
      target366.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain366
def tree367 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target367 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain367 : accepts tree367 target367 = true ∧
    sourceLeaves tree367 = [2, 0, 2, 0] ∧
    target367.elements.length = 4 ∧
    [target367.elements.count 0, target367.elements.count 1,
      target367.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain367
def tree368 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))))
def target368 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain368 : accepts tree368 target368 = true ∧
    sourceLeaves tree368 = [2, 0, 2, 1] ∧
    target368.elements.length = 4 ∧
    [target368.elements.count 0, target368.elements.count 1,
      target368.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain368
def tree369 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)))
def target369 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain369 : accepts tree369 target369 = true ∧
    sourceLeaves tree369 = [2, 0, 2, 1] ∧
    target369.elements.length = 4 ∧
    [target369.elements.count 0, target369.elements.count 1,
      target369.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain369
def tree370 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 2) (.leaf 1)))
def target370 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain370 : accepts tree370 target370 = true ∧
    sourceLeaves tree370 = [2, 0, 2, 1] ∧
    target370.elements.length = 4 ∧
    [target370.elements.count 0, target370.elements.count 1,
      target370.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain370
def tree371 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))) (.leaf 1))
def target371 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain371 : accepts tree371 target371 = true ∧
    sourceLeaves tree371 = [2, 0, 2, 1] ∧
    target371.elements.length = 4 ∧
    [target371.elements.count 0, target371.elements.count 1,
      target371.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain371
def tree372 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target372 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain372 : accepts tree372 target372 = true ∧
    sourceLeaves tree372 = [2, 0, 2, 1] ∧
    target372.elements.length = 4 ∧
    [target372.elements.count 0, target372.elements.count 1,
      target372.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain372
def tree373 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))))
def target373 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain373 : accepts tree373 target373 = true ∧
    sourceLeaves tree373 = [2, 0, 2, 2] ∧
    target373.elements.length = 4 ∧
    [target373.elements.count 0, target373.elements.count 1,
      target373.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain373
def tree374 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)))
def target374 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain374 : accepts tree374 target374 = true ∧
    sourceLeaves tree374 = [2, 0, 2, 2] ∧
    target374.elements.length = 4 ∧
    [target374.elements.count 0, target374.elements.count 1,
      target374.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain374
def tree375 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 2) (.leaf 2)))
def target375 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain375 : accepts tree375 target375 = true ∧
    sourceLeaves tree375 = [2, 0, 2, 2] ∧
    target375.elements.length = 4 ∧
    [target375.elements.count 0, target375.elements.count 1,
      target375.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain375
def tree376 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))) (.leaf 2))
def target376 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain376 : accepts tree376 target376 = true ∧
    sourceLeaves tree376 = [2, 0, 2, 2] ∧
    target376.elements.length = 4 ∧
    [target376.elements.count 0, target376.elements.count 1,
      target376.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain376
def tree377 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target377 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain377 : accepts tree377 target377 = true ∧
    sourceLeaves tree377 = [2, 0, 2, 2] ∧
    target377.elements.length = 4 ∧
    [target377.elements.count 0, target377.elements.count 1,
      target377.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain377
def tree378 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))))
def target378 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain378 : accepts tree378 target378 = true ∧
    sourceLeaves tree378 = [2, 1, 0, 0] ∧
    target378.elements.length = 4 ∧
    [target378.elements.count 0, target378.elements.count 1,
      target378.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain378
def tree379 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)))
def target379 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain379 : accepts tree379 target379 = true ∧
    sourceLeaves tree379 = [2, 1, 0, 0] ∧
    target379.elements.length = 4 ∧
    [target379.elements.count 0, target379.elements.count 1,
      target379.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain379
def tree380 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 0) (.leaf 0)))
def target380 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain380 : accepts tree380 target380 = true ∧
    sourceLeaves tree380 = [2, 1, 0, 0] ∧
    target380.elements.length = 4 ∧
    [target380.elements.count 0, target380.elements.count 1,
      target380.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain380
def tree381 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))) (.leaf 0))
def target381 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain381 : accepts tree381 target381 = true ∧
    sourceLeaves tree381 = [2, 1, 0, 0] ∧
    target381.elements.length = 4 ∧
    [target381.elements.count 0, target381.elements.count 1,
      target381.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain381
def tree382 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target382 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain382 : accepts tree382 target382 = true ∧
    sourceLeaves tree382 = [2, 1, 0, 0] ∧
    target382.elements.length = 4 ∧
    [target382.elements.count 0, target382.elements.count 1,
      target382.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain382
def tree383 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))))
def target383 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain383 : accepts tree383 target383 = true ∧
    sourceLeaves tree383 = [2, 1, 0, 1] ∧
    target383.elements.length = 4 ∧
    [target383.elements.count 0, target383.elements.count 1,
      target383.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain383
def tree384 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)))
def target384 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain384 : accepts tree384 target384 = true ∧
    sourceLeaves tree384 = [2, 1, 0, 1] ∧
    target384.elements.length = 4 ∧
    [target384.elements.count 0, target384.elements.count 1,
      target384.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain384
def tree385 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 0) (.leaf 1)))
def target385 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain385 : accepts tree385 target385 = true ∧
    sourceLeaves tree385 = [2, 1, 0, 1] ∧
    target385.elements.length = 4 ∧
    [target385.elements.count 0, target385.elements.count 1,
      target385.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain385
def tree386 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))) (.leaf 1))
def target386 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain386 : accepts tree386 target386 = true ∧
    sourceLeaves tree386 = [2, 1, 0, 1] ∧
    target386.elements.length = 4 ∧
    [target386.elements.count 0, target386.elements.count 1,
      target386.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain386
def tree387 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target387 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain387 : accepts tree387 target387 = true ∧
    sourceLeaves tree387 = [2, 1, 0, 1] ∧
    target387.elements.length = 4 ∧
    [target387.elements.count 0, target387.elements.count 1,
      target387.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain387
def tree388 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))))
def target388 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain388 : accepts tree388 target388 = true ∧
    sourceLeaves tree388 = [2, 1, 0, 2] ∧
    target388.elements.length = 4 ∧
    [target388.elements.count 0, target388.elements.count 1,
      target388.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain388
def tree389 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)))
def target389 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain389 : accepts tree389 target389 = true ∧
    sourceLeaves tree389 = [2, 1, 0, 2] ∧
    target389.elements.length = 4 ∧
    [target389.elements.count 0, target389.elements.count 1,
      target389.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain389
def tree390 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 0) (.leaf 2)))
def target390 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain390 : accepts tree390 target390 = true ∧
    sourceLeaves tree390 = [2, 1, 0, 2] ∧
    target390.elements.length = 4 ∧
    [target390.elements.count 0, target390.elements.count 1,
      target390.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain390
def tree391 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))) (.leaf 2))
def target391 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain391 : accepts tree391 target391 = true ∧
    sourceLeaves tree391 = [2, 1, 0, 2] ∧
    target391.elements.length = 4 ∧
    [target391.elements.count 0, target391.elements.count 1,
      target391.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain391
def tree392 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target392 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain392 : accepts tree392 target392 = true ∧
    sourceLeaves tree392 = [2, 1, 0, 2] ∧
    target392.elements.length = 4 ∧
    [target392.elements.count 0, target392.elements.count 1,
      target392.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain392
def tree393 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))))
def target393 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain393 : accepts tree393 target393 = true ∧
    sourceLeaves tree393 = [2, 1, 1, 0] ∧
    target393.elements.length = 4 ∧
    [target393.elements.count 0, target393.elements.count 1,
      target393.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain393
def tree394 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)))
def target394 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain394 : accepts tree394 target394 = true ∧
    sourceLeaves tree394 = [2, 1, 1, 0] ∧
    target394.elements.length = 4 ∧
    [target394.elements.count 0, target394.elements.count 1,
      target394.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain394
def tree395 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 1) (.leaf 0)))
def target395 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain395 : accepts tree395 target395 = true ∧
    sourceLeaves tree395 = [2, 1, 1, 0] ∧
    target395.elements.length = 4 ∧
    [target395.elements.count 0, target395.elements.count 1,
      target395.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain395
def tree396 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))) (.leaf 0))
def target396 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain396 : accepts tree396 target396 = true ∧
    sourceLeaves tree396 = [2, 1, 1, 0] ∧
    target396.elements.length = 4 ∧
    [target396.elements.count 0, target396.elements.count 1,
      target396.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain396
def tree397 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target397 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain397 : accepts tree397 target397 = true ∧
    sourceLeaves tree397 = [2, 1, 1, 0] ∧
    target397.elements.length = 4 ∧
    [target397.elements.count 0, target397.elements.count 1,
      target397.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain397
def tree398 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))))
def target398 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain398 : accepts tree398 target398 = true ∧
    sourceLeaves tree398 = [2, 1, 1, 1] ∧
    target398.elements.length = 4 ∧
    [target398.elements.count 0, target398.elements.count 1,
      target398.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain398
def tree399 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)))
def target399 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain399 : accepts tree399 target399 = true ∧
    sourceLeaves tree399 = [2, 1, 1, 1] ∧
    target399.elements.length = 4 ∧
    [target399.elements.count 0, target399.elements.count 1,
      target399.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain399
def tree400 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 1) (.leaf 1)))
def target400 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain400 : accepts tree400 target400 = true ∧
    sourceLeaves tree400 = [2, 1, 1, 1] ∧
    target400.elements.length = 4 ∧
    [target400.elements.count 0, target400.elements.count 1,
      target400.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain400
def tree401 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))) (.leaf 1))
def target401 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain401 : accepts tree401 target401 = true ∧
    sourceLeaves tree401 = [2, 1, 1, 1] ∧
    target401.elements.length = 4 ∧
    [target401.elements.count 0, target401.elements.count 1,
      target401.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain401
def tree402 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target402 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain402 : accepts tree402 target402 = true ∧
    sourceLeaves tree402 = [2, 1, 1, 1] ∧
    target402.elements.length = 4 ∧
    [target402.elements.count 0, target402.elements.count 1,
      target402.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain402
def tree403 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))))
def target403 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain403 : accepts tree403 target403 = true ∧
    sourceLeaves tree403 = [2, 1, 1, 2] ∧
    target403.elements.length = 4 ∧
    [target403.elements.count 0, target403.elements.count 1,
      target403.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain403
def tree404 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)))
def target404 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain404 : accepts tree404 target404 = true ∧
    sourceLeaves tree404 = [2, 1, 1, 2] ∧
    target404.elements.length = 4 ∧
    [target404.elements.count 0, target404.elements.count 1,
      target404.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain404
def tree405 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 1) (.leaf 2)))
def target405 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain405 : accepts tree405 target405 = true ∧
    sourceLeaves tree405 = [2, 1, 1, 2] ∧
    target405.elements.length = 4 ∧
    [target405.elements.count 0, target405.elements.count 1,
      target405.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain405
def tree406 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))) (.leaf 2))
def target406 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain406 : accepts tree406 target406 = true ∧
    sourceLeaves tree406 = [2, 1, 1, 2] ∧
    target406.elements.length = 4 ∧
    [target406.elements.count 0, target406.elements.count 1,
      target406.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain406
def tree407 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target407 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain407 : accepts tree407 target407 = true ∧
    sourceLeaves tree407 = [2, 1, 1, 2] ∧
    target407.elements.length = 4 ∧
    [target407.elements.count 0, target407.elements.count 1,
      target407.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain407
def tree408 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))))
def target408 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain408 : accepts tree408 target408 = true ∧
    sourceLeaves tree408 = [2, 1, 2, 0] ∧
    target408.elements.length = 4 ∧
    [target408.elements.count 0, target408.elements.count 1,
      target408.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain408
def tree409 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)))
def target409 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain409 : accepts tree409 target409 = true ∧
    sourceLeaves tree409 = [2, 1, 2, 0] ∧
    target409.elements.length = 4 ∧
    [target409.elements.count 0, target409.elements.count 1,
      target409.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain409
def tree410 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 2) (.leaf 0)))
def target410 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain410 : accepts tree410 target410 = true ∧
    sourceLeaves tree410 = [2, 1, 2, 0] ∧
    target410.elements.length = 4 ∧
    [target410.elements.count 0, target410.elements.count 1,
      target410.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain410
def tree411 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))) (.leaf 0))
def target411 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain411 : accepts tree411 target411 = true ∧
    sourceLeaves tree411 = [2, 1, 2, 0] ∧
    target411.elements.length = 4 ∧
    [target411.elements.count 0, target411.elements.count 1,
      target411.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain411
def tree412 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target412 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain412 : accepts tree412 target412 = true ∧
    sourceLeaves tree412 = [2, 1, 2, 0] ∧
    target412.elements.length = 4 ∧
    [target412.elements.count 0, target412.elements.count 1,
      target412.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain412
def tree413 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))))
def target413 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain413 : accepts tree413 target413 = true ∧
    sourceLeaves tree413 = [2, 1, 2, 1] ∧
    target413.elements.length = 4 ∧
    [target413.elements.count 0, target413.elements.count 1,
      target413.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain413
def tree414 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)))
def target414 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain414 : accepts tree414 target414 = true ∧
    sourceLeaves tree414 = [2, 1, 2, 1] ∧
    target414.elements.length = 4 ∧
    [target414.elements.count 0, target414.elements.count 1,
      target414.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain414
def tree415 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 2) (.leaf 1)))
def target415 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain415 : accepts tree415 target415 = true ∧
    sourceLeaves tree415 = [2, 1, 2, 1] ∧
    target415.elements.length = 4 ∧
    [target415.elements.count 0, target415.elements.count 1,
      target415.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain415
def tree416 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))) (.leaf 1))
def target416 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain416 : accepts tree416 target416 = true ∧
    sourceLeaves tree416 = [2, 1, 2, 1] ∧
    target416.elements.length = 4 ∧
    [target416.elements.count 0, target416.elements.count 1,
      target416.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain416
def tree417 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target417 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain417 : accepts tree417 target417 = true ∧
    sourceLeaves tree417 = [2, 1, 2, 1] ∧
    target417.elements.length = 4 ∧
    [target417.elements.count 0, target417.elements.count 1,
      target417.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain417
def tree418 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))))
def target418 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain418 : accepts tree418 target418 = true ∧
    sourceLeaves tree418 = [2, 1, 2, 2] ∧
    target418.elements.length = 4 ∧
    [target418.elements.count 0, target418.elements.count 1,
      target418.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain418
def tree419 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)))
def target419 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain419 : accepts tree419 target419 = true ∧
    sourceLeaves tree419 = [2, 1, 2, 2] ∧
    target419.elements.length = 4 ∧
    [target419.elements.count 0, target419.elements.count 1,
      target419.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain419
def tree420 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 2) (.leaf 2)))
def target420 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain420 : accepts tree420 target420 = true ∧
    sourceLeaves tree420 = [2, 1, 2, 2] ∧
    target420.elements.length = 4 ∧
    [target420.elements.count 0, target420.elements.count 1,
      target420.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain420
def tree421 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))) (.leaf 2))
def target421 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain421 : accepts tree421 target421 = true ∧
    sourceLeaves tree421 = [2, 1, 2, 2] ∧
    target421.elements.length = 4 ∧
    [target421.elements.count 0, target421.elements.count 1,
      target421.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain421
def tree422 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target422 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain422 : accepts tree422 target422 = true ∧
    sourceLeaves tree422 = [2, 1, 2, 2] ∧
    target422.elements.length = 4 ∧
    [target422.elements.count 0, target422.elements.count 1,
      target422.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain422
def tree423 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))))
def target423 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain423 : accepts tree423 target423 = true ∧
    sourceLeaves tree423 = [2, 2, 0, 0] ∧
    target423.elements.length = 4 ∧
    [target423.elements.count 0, target423.elements.count 1,
      target423.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain423
def tree424 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)))
def target424 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain424 : accepts tree424 target424 = true ∧
    sourceLeaves tree424 = [2, 2, 0, 0] ∧
    target424.elements.length = 4 ∧
    [target424.elements.count 0, target424.elements.count 1,
      target424.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain424
def tree425 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 0) (.leaf 0)))
def target425 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain425 : accepts tree425 target425 = true ∧
    sourceLeaves tree425 = [2, 2, 0, 0] ∧
    target425.elements.length = 4 ∧
    [target425.elements.count 0, target425.elements.count 1,
      target425.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain425
def tree426 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))) (.leaf 0))
def target426 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain426 : accepts tree426 target426 = true ∧
    sourceLeaves tree426 = [2, 2, 0, 0] ∧
    target426.elements.length = 4 ∧
    [target426.elements.count 0, target426.elements.count 1,
      target426.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain426
def tree427 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target427 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain427 : accepts tree427 target427 = true ∧
    sourceLeaves tree427 = [2, 2, 0, 0] ∧
    target427.elements.length = 4 ∧
    [target427.elements.count 0, target427.elements.count 1,
      target427.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain427
def tree428 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))))
def target428 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain428 : accepts tree428 target428 = true ∧
    sourceLeaves tree428 = [2, 2, 0, 1] ∧
    target428.elements.length = 4 ∧
    [target428.elements.count 0, target428.elements.count 1,
      target428.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain428
def tree429 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)))
def target429 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain429 : accepts tree429 target429 = true ∧
    sourceLeaves tree429 = [2, 2, 0, 1] ∧
    target429.elements.length = 4 ∧
    [target429.elements.count 0, target429.elements.count 1,
      target429.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain429
def tree430 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 0) (.leaf 1)))
def target430 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain430 : accepts tree430 target430 = true ∧
    sourceLeaves tree430 = [2, 2, 0, 1] ∧
    target430.elements.length = 4 ∧
    [target430.elements.count 0, target430.elements.count 1,
      target430.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain430
def tree431 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))) (.leaf 1))
def target431 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain431 : accepts tree431 target431 = true ∧
    sourceLeaves tree431 = [2, 2, 0, 1] ∧
    target431.elements.length = 4 ∧
    [target431.elements.count 0, target431.elements.count 1,
      target431.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain431
def tree432 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target432 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain432 : accepts tree432 target432 = true ∧
    sourceLeaves tree432 = [2, 2, 0, 1] ∧
    target432.elements.length = 4 ∧
    [target432.elements.count 0, target432.elements.count 1,
      target432.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain432
def tree433 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))))
def target433 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain433 : accepts tree433 target433 = true ∧
    sourceLeaves tree433 = [2, 2, 0, 2] ∧
    target433.elements.length = 4 ∧
    [target433.elements.count 0, target433.elements.count 1,
      target433.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain433
def tree434 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)))
def target434 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain434 : accepts tree434 target434 = true ∧
    sourceLeaves tree434 = [2, 2, 0, 2] ∧
    target434.elements.length = 4 ∧
    [target434.elements.count 0, target434.elements.count 1,
      target434.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain434
def tree435 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 0) (.leaf 2)))
def target435 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain435 : accepts tree435 target435 = true ∧
    sourceLeaves tree435 = [2, 2, 0, 2] ∧
    target435.elements.length = 4 ∧
    [target435.elements.count 0, target435.elements.count 1,
      target435.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain435
def tree436 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))) (.leaf 2))
def target436 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain436 : accepts tree436 target436 = true ∧
    sourceLeaves tree436 = [2, 2, 0, 2] ∧
    target436.elements.length = 4 ∧
    [target436.elements.count 0, target436.elements.count 1,
      target436.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain436
def tree437 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target437 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain437 : accepts tree437 target437 = true ∧
    sourceLeaves tree437 = [2, 2, 0, 2] ∧
    target437.elements.length = 4 ∧
    [target437.elements.count 0, target437.elements.count 1,
      target437.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain437
def tree438 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))))
def target438 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain438 : accepts tree438 target438 = true ∧
    sourceLeaves tree438 = [2, 2, 1, 0] ∧
    target438.elements.length = 4 ∧
    [target438.elements.count 0, target438.elements.count 1,
      target438.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain438
def tree439 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)))
def target439 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain439 : accepts tree439 target439 = true ∧
    sourceLeaves tree439 = [2, 2, 1, 0] ∧
    target439.elements.length = 4 ∧
    [target439.elements.count 0, target439.elements.count 1,
      target439.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain439
def tree440 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 1) (.leaf 0)))
def target440 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain440 : accepts tree440 target440 = true ∧
    sourceLeaves tree440 = [2, 2, 1, 0] ∧
    target440.elements.length = 4 ∧
    [target440.elements.count 0, target440.elements.count 1,
      target440.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain440
def tree441 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))) (.leaf 0))
def target441 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain441 : accepts tree441 target441 = true ∧
    sourceLeaves tree441 = [2, 2, 1, 0] ∧
    target441.elements.length = 4 ∧
    [target441.elements.count 0, target441.elements.count 1,
      target441.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain441
def tree442 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target442 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain442 : accepts tree442 target442 = true ∧
    sourceLeaves tree442 = [2, 2, 1, 0] ∧
    target442.elements.length = 4 ∧
    [target442.elements.count 0, target442.elements.count 1,
      target442.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain442
def tree443 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))))
def target443 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain443 : accepts tree443 target443 = true ∧
    sourceLeaves tree443 = [2, 2, 1, 1] ∧
    target443.elements.length = 4 ∧
    [target443.elements.count 0, target443.elements.count 1,
      target443.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain443
def tree444 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)))
def target444 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain444 : accepts tree444 target444 = true ∧
    sourceLeaves tree444 = [2, 2, 1, 1] ∧
    target444.elements.length = 4 ∧
    [target444.elements.count 0, target444.elements.count 1,
      target444.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain444
def tree445 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 1) (.leaf 1)))
def target445 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain445 : accepts tree445 target445 = true ∧
    sourceLeaves tree445 = [2, 2, 1, 1] ∧
    target445.elements.length = 4 ∧
    [target445.elements.count 0, target445.elements.count 1,
      target445.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain445
def tree446 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))) (.leaf 1))
def target446 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain446 : accepts tree446 target446 = true ∧
    sourceLeaves tree446 = [2, 2, 1, 1] ∧
    target446.elements.length = 4 ∧
    [target446.elements.count 0, target446.elements.count 1,
      target446.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain446
def tree447 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target447 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain447 : accepts tree447 target447 = true ∧
    sourceLeaves tree447 = [2, 2, 1, 1] ∧
    target447.elements.length = 4 ∧
    [target447.elements.count 0, target447.elements.count 1,
      target447.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain447
def tree448 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))))
def target448 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain448 : accepts tree448 target448 = true ∧
    sourceLeaves tree448 = [2, 2, 1, 2] ∧
    target448.elements.length = 4 ∧
    [target448.elements.count 0, target448.elements.count 1,
      target448.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain448
def tree449 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)))
def target449 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain449 : accepts tree449 target449 = true ∧
    sourceLeaves tree449 = [2, 2, 1, 2] ∧
    target449.elements.length = 4 ∧
    [target449.elements.count 0, target449.elements.count 1,
      target449.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain449
def tree450 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 1) (.leaf 2)))
def target450 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain450 : accepts tree450 target450 = true ∧
    sourceLeaves tree450 = [2, 2, 1, 2] ∧
    target450.elements.length = 4 ∧
    [target450.elements.count 0, target450.elements.count 1,
      target450.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain450
def tree451 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))) (.leaf 2))
def target451 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain451 : accepts tree451 target451 = true ∧
    sourceLeaves tree451 = [2, 2, 1, 2] ∧
    target451.elements.length = 4 ∧
    [target451.elements.count 0, target451.elements.count 1,
      target451.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain451
def tree452 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target452 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain452 : accepts tree452 target452 = true ∧
    sourceLeaves tree452 = [2, 2, 1, 2] ∧
    target452.elements.length = 4 ∧
    [target452.elements.count 0, target452.elements.count 1,
      target452.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain452
def tree453 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))))
def target453 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain453 : accepts tree453 target453 = true ∧
    sourceLeaves tree453 = [2, 2, 2, 0] ∧
    target453.elements.length = 4 ∧
    [target453.elements.count 0, target453.elements.count 1,
      target453.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain453
def tree454 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)))
def target454 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain454 : accepts tree454 target454 = true ∧
    sourceLeaves tree454 = [2, 2, 2, 0] ∧
    target454.elements.length = 4 ∧
    [target454.elements.count 0, target454.elements.count 1,
      target454.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain454
def tree455 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 2) (.leaf 0)))
def target455 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain455 : accepts tree455 target455 = true ∧
    sourceLeaves tree455 = [2, 2, 2, 0] ∧
    target455.elements.length = 4 ∧
    [target455.elements.count 0, target455.elements.count 1,
      target455.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain455
def tree456 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))) (.leaf 0))
def target456 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain456 : accepts tree456 target456 = true ∧
    sourceLeaves tree456 = [2, 2, 2, 0] ∧
    target456.elements.length = 4 ∧
    [target456.elements.count 0, target456.elements.count 1,
      target456.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain456
def tree457 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target457 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain457 : accepts tree457 target457 = true ∧
    sourceLeaves tree457 = [2, 2, 2, 0] ∧
    target457.elements.length = 4 ∧
    [target457.elements.count 0, target457.elements.count 1,
      target457.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain457
def tree458 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))))
def target458 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain458 : accepts tree458 target458 = true ∧
    sourceLeaves tree458 = [2, 2, 2, 1] ∧
    target458.elements.length = 4 ∧
    [target458.elements.count 0, target458.elements.count 1,
      target458.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain458
def tree459 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)))
def target459 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain459 : accepts tree459 target459 = true ∧
    sourceLeaves tree459 = [2, 2, 2, 1] ∧
    target459.elements.length = 4 ∧
    [target459.elements.count 0, target459.elements.count 1,
      target459.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain459
def tree460 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 2) (.leaf 1)))
def target460 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain460 : accepts tree460 target460 = true ∧
    sourceLeaves tree460 = [2, 2, 2, 1] ∧
    target460.elements.length = 4 ∧
    [target460.elements.count 0, target460.elements.count 1,
      target460.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain460
def tree461 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))) (.leaf 1))
def target461 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain461 : accepts tree461 target461 = true ∧
    sourceLeaves tree461 = [2, 2, 2, 1] ∧
    target461.elements.length = 4 ∧
    [target461.elements.count 0, target461.elements.count 1,
      target461.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain461
def tree462 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target462 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain462 : accepts tree462 target462 = true ∧
    sourceLeaves tree462 = [2, 2, 2, 1] ∧
    target462.elements.length = 4 ∧
    [target462.elements.count 0, target462.elements.count 1,
      target462.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain462
def tree463 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))))
def target463 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain463 : accepts tree463 target463 = true ∧
    sourceLeaves tree463 = [2, 2, 2, 2] ∧
    target463.elements.length = 4 ∧
    [target463.elements.count 0, target463.elements.count 1,
      target463.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain463
def tree464 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)))
def target464 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain464 : accepts tree464 target464 = true ∧
    sourceLeaves tree464 = [2, 2, 2, 2] ∧
    target464.elements.length = 4 ∧
    [target464.elements.count 0, target464.elements.count 1,
      target464.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain464
def tree465 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 2) (.leaf 2)))
def target465 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain465 : accepts tree465 target465 = true ∧
    sourceLeaves tree465 = [2, 2, 2, 2] ∧
    target465.elements.length = 4 ∧
    [target465.elements.count 0, target465.elements.count 1,
      target465.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain465
def tree466 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))) (.leaf 2))
def target466 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain466 : accepts tree466 target466 = true ∧
    sourceLeaves tree466 = [2, 2, 2, 2] ∧
    target466.elements.length = 4 ∧
    [target466.elements.count 0, target466.elements.count 1,
      target466.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain466
def tree467 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target467 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain467 : accepts tree467 target467 = true ∧
    sourceLeaves tree467 = [2, 2, 2, 2] ∧
    target467.elements.length = 4 ∧
    [target467.elements.count 0, target467.elements.count 1,
      target467.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain467
def tree468 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 0))
def target468 : Target Nat := ⟨.seq, [0, 0]⟩
theorem chain468 : accepts tree468 target468 = true ∧
    sourceLeaves tree468 = [0, 0] ∧
    target468.elements.length = 2 ∧
    [target468.elements.count 0, target468.elements.count 1,
      target468.elements.count 2] = [2, 0, 0] := by decide
#print axioms chain468
def tree469 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 1))
def target469 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain469 : accepts tree469 target469 = true ∧
    sourceLeaves tree469 = [0, 1] ∧
    target469.elements.length = 2 ∧
    [target469.elements.count 0, target469.elements.count 1,
      target469.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain469
def tree470 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 2))
def target470 : Target Nat := ⟨.seq, [0, 2]⟩
theorem chain470 : accepts tree470 target470 = true ∧
    sourceLeaves tree470 = [0, 2] ∧
    target470.elements.length = 2 ∧
    [target470.elements.count 0, target470.elements.count 1,
      target470.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain470
def tree471 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.leaf 0))
def target471 : Target Nat := ⟨.seq, [1, 0]⟩
theorem chain471 : accepts tree471 target471 = true ∧
    sourceLeaves tree471 = [1, 0] ∧
    target471.elements.length = 2 ∧
    [target471.elements.count 0, target471.elements.count 1,
      target471.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain471
def tree472 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.leaf 1))
def target472 : Target Nat := ⟨.seq, [1, 1]⟩
theorem chain472 : accepts tree472 target472 = true ∧
    sourceLeaves tree472 = [1, 1] ∧
    target472.elements.length = 2 ∧
    [target472.elements.count 0, target472.elements.count 1,
      target472.elements.count 2] = [0, 2, 0] := by decide
#print axioms chain472
def tree473 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.leaf 2))
def target473 : Target Nat := ⟨.seq, [1, 2]⟩
theorem chain473 : accepts tree473 target473 = true ∧
    sourceLeaves tree473 = [1, 2] ∧
    target473.elements.length = 2 ∧
    [target473.elements.count 0, target473.elements.count 1,
      target473.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain473
def tree474 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.leaf 0))
def target474 : Target Nat := ⟨.seq, [2, 0]⟩
theorem chain474 : accepts tree474 target474 = true ∧
    sourceLeaves tree474 = [2, 0] ∧
    target474.elements.length = 2 ∧
    [target474.elements.count 0, target474.elements.count 1,
      target474.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain474
def tree475 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.leaf 1))
def target475 : Target Nat := ⟨.seq, [2, 1]⟩
theorem chain475 : accepts tree475 target475 = true ∧
    sourceLeaves tree475 = [2, 1] ∧
    target475.elements.length = 2 ∧
    [target475.elements.count 0, target475.elements.count 1,
      target475.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain475
def tree476 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.leaf 2))
def target476 : Target Nat := ⟨.seq, [2, 2]⟩
theorem chain476 : accepts tree476 target476 = true ∧
    sourceLeaves tree476 = [2, 2] ∧
    target476.elements.length = 2 ∧
    [target476.elements.count 0, target476.elements.count 1,
      target476.elements.count 2] = [0, 0, 2] := by decide
#print axioms chain476
def tree477 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0)))
def target477 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain477 : accepts tree477 target477 = true ∧
    sourceLeaves tree477 = [0, 0, 0] ∧
    target477.elements.length = 3 ∧
    [target477.elements.count 0, target477.elements.count 1,
      target477.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain477
def tree478 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0))
def target478 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain478 : accepts tree478 target478 = true ∧
    sourceLeaves tree478 = [0, 0, 0] ∧
    target478.elements.length = 3 ∧
    [target478.elements.count 0, target478.elements.count 1,
      target478.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain478
def tree479 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1)))
def target479 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain479 : accepts tree479 target479 = true ∧
    sourceLeaves tree479 = [0, 0, 1] ∧
    target479.elements.length = 3 ∧
    [target479.elements.count 0, target479.elements.count 1,
      target479.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain479
def tree480 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1))
def target480 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain480 : accepts tree480 target480 = true ∧
    sourceLeaves tree480 = [0, 0, 1] ∧
    target480.elements.length = 3 ∧
    [target480.elements.count 0, target480.elements.count 1,
      target480.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain480
def tree481 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2)))
def target481 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain481 : accepts tree481 target481 = true ∧
    sourceLeaves tree481 = [0, 0, 2] ∧
    target481.elements.length = 3 ∧
    [target481.elements.count 0, target481.elements.count 1,
      target481.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain481
def tree482 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2))
def target482 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain482 : accepts tree482 target482 = true ∧
    sourceLeaves tree482 = [0, 0, 2] ∧
    target482.elements.length = 3 ∧
    [target482.elements.count 0, target482.elements.count 1,
      target482.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain482
def tree483 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0)))
def target483 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain483 : accepts tree483 target483 = true ∧
    sourceLeaves tree483 = [0, 1, 0] ∧
    target483.elements.length = 3 ∧
    [target483.elements.count 0, target483.elements.count 1,
      target483.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain483
def tree484 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0))
def target484 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain484 : accepts tree484 target484 = true ∧
    sourceLeaves tree484 = [0, 1, 0] ∧
    target484.elements.length = 3 ∧
    [target484.elements.count 0, target484.elements.count 1,
      target484.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain484
def tree485 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1)))
def target485 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain485 : accepts tree485 target485 = true ∧
    sourceLeaves tree485 = [0, 1, 1] ∧
    target485.elements.length = 3 ∧
    [target485.elements.count 0, target485.elements.count 1,
      target485.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain485
def tree486 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1))
def target486 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain486 : accepts tree486 target486 = true ∧
    sourceLeaves tree486 = [0, 1, 1] ∧
    target486.elements.length = 3 ∧
    [target486.elements.count 0, target486.elements.count 1,
      target486.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain486
def tree487 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2)))
def target487 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain487 : accepts tree487 target487 = true ∧
    sourceLeaves tree487 = [0, 1, 2] ∧
    target487.elements.length = 3 ∧
    [target487.elements.count 0, target487.elements.count 1,
      target487.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain487
def tree488 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2))
def target488 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain488 : accepts tree488 target488 = true ∧
    sourceLeaves tree488 = [0, 1, 2] ∧
    target488.elements.length = 3 ∧
    [target488.elements.count 0, target488.elements.count 1,
      target488.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain488
def tree489 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0)))
def target489 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain489 : accepts tree489 target489 = true ∧
    sourceLeaves tree489 = [0, 2, 0] ∧
    target489.elements.length = 3 ∧
    [target489.elements.count 0, target489.elements.count 1,
      target489.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain489
def tree490 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0))
def target490 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain490 : accepts tree490 target490 = true ∧
    sourceLeaves tree490 = [0, 2, 0] ∧
    target490.elements.length = 3 ∧
    [target490.elements.count 0, target490.elements.count 1,
      target490.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain490
def tree491 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1)))
def target491 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain491 : accepts tree491 target491 = true ∧
    sourceLeaves tree491 = [0, 2, 1] ∧
    target491.elements.length = 3 ∧
    [target491.elements.count 0, target491.elements.count 1,
      target491.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain491
def tree492 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1))
def target492 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain492 : accepts tree492 target492 = true ∧
    sourceLeaves tree492 = [0, 2, 1] ∧
    target492.elements.length = 3 ∧
    [target492.elements.count 0, target492.elements.count 1,
      target492.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain492
def tree493 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2)))
def target493 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain493 : accepts tree493 target493 = true ∧
    sourceLeaves tree493 = [0, 2, 2] ∧
    target493.elements.length = 3 ∧
    [target493.elements.count 0, target493.elements.count 1,
      target493.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain493
def tree494 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2))
def target494 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain494 : accepts tree494 target494 = true ∧
    sourceLeaves tree494 = [0, 2, 2] ∧
    target494.elements.length = 3 ∧
    [target494.elements.count 0, target494.elements.count 1,
      target494.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain494
def tree495 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0)))
def target495 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain495 : accepts tree495 target495 = true ∧
    sourceLeaves tree495 = [1, 0, 0] ∧
    target495.elements.length = 3 ∧
    [target495.elements.count 0, target495.elements.count 1,
      target495.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain495
def tree496 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0))
def target496 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain496 : accepts tree496 target496 = true ∧
    sourceLeaves tree496 = [1, 0, 0] ∧
    target496.elements.length = 3 ∧
    [target496.elements.count 0, target496.elements.count 1,
      target496.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain496
def tree497 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1)))
def target497 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain497 : accepts tree497 target497 = true ∧
    sourceLeaves tree497 = [1, 0, 1] ∧
    target497.elements.length = 3 ∧
    [target497.elements.count 0, target497.elements.count 1,
      target497.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain497
def tree498 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1))
def target498 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain498 : accepts tree498 target498 = true ∧
    sourceLeaves tree498 = [1, 0, 1] ∧
    target498.elements.length = 3 ∧
    [target498.elements.count 0, target498.elements.count 1,
      target498.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain498
def tree499 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2)))
def target499 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain499 : accepts tree499 target499 = true ∧
    sourceLeaves tree499 = [1, 0, 2] ∧
    target499.elements.length = 3 ∧
    [target499.elements.count 0, target499.elements.count 1,
      target499.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain499
def tree500 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2))
def target500 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain500 : accepts tree500 target500 = true ∧
    sourceLeaves tree500 = [1, 0, 2] ∧
    target500.elements.length = 3 ∧
    [target500.elements.count 0, target500.elements.count 1,
      target500.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain500
def tree501 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0)))
def target501 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain501 : accepts tree501 target501 = true ∧
    sourceLeaves tree501 = [1, 1, 0] ∧
    target501.elements.length = 3 ∧
    [target501.elements.count 0, target501.elements.count 1,
      target501.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain501
def tree502 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0))
def target502 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain502 : accepts tree502 target502 = true ∧
    sourceLeaves tree502 = [1, 1, 0] ∧
    target502.elements.length = 3 ∧
    [target502.elements.count 0, target502.elements.count 1,
      target502.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain502
def tree503 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1)))
def target503 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain503 : accepts tree503 target503 = true ∧
    sourceLeaves tree503 = [1, 1, 1] ∧
    target503.elements.length = 3 ∧
    [target503.elements.count 0, target503.elements.count 1,
      target503.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain503
def tree504 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1))
def target504 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain504 : accepts tree504 target504 = true ∧
    sourceLeaves tree504 = [1, 1, 1] ∧
    target504.elements.length = 3 ∧
    [target504.elements.count 0, target504.elements.count 1,
      target504.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain504
def tree505 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2)))
def target505 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain505 : accepts tree505 target505 = true ∧
    sourceLeaves tree505 = [1, 1, 2] ∧
    target505.elements.length = 3 ∧
    [target505.elements.count 0, target505.elements.count 1,
      target505.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain505
def tree506 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2))
def target506 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain506 : accepts tree506 target506 = true ∧
    sourceLeaves tree506 = [1, 1, 2] ∧
    target506.elements.length = 3 ∧
    [target506.elements.count 0, target506.elements.count 1,
      target506.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain506
def tree507 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0)))
def target507 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain507 : accepts tree507 target507 = true ∧
    sourceLeaves tree507 = [1, 2, 0] ∧
    target507.elements.length = 3 ∧
    [target507.elements.count 0, target507.elements.count 1,
      target507.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain507
def tree508 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0))
def target508 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain508 : accepts tree508 target508 = true ∧
    sourceLeaves tree508 = [1, 2, 0] ∧
    target508.elements.length = 3 ∧
    [target508.elements.count 0, target508.elements.count 1,
      target508.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain508
def tree509 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1)))
def target509 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain509 : accepts tree509 target509 = true ∧
    sourceLeaves tree509 = [1, 2, 1] ∧
    target509.elements.length = 3 ∧
    [target509.elements.count 0, target509.elements.count 1,
      target509.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain509
def tree510 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1))
def target510 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain510 : accepts tree510 target510 = true ∧
    sourceLeaves tree510 = [1, 2, 1] ∧
    target510.elements.length = 3 ∧
    [target510.elements.count 0, target510.elements.count 1,
      target510.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain510
def tree511 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2)))
def target511 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain511 : accepts tree511 target511 = true ∧
    sourceLeaves tree511 = [1, 2, 2] ∧
    target511.elements.length = 3 ∧
    [target511.elements.count 0, target511.elements.count 1,
      target511.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain511
def tree512 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2))
def target512 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain512 : accepts tree512 target512 = true ∧
    sourceLeaves tree512 = [1, 2, 2] ∧
    target512.elements.length = 3 ∧
    [target512.elements.count 0, target512.elements.count 1,
      target512.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain512
def tree513 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0)))
def target513 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain513 : accepts tree513 target513 = true ∧
    sourceLeaves tree513 = [2, 0, 0] ∧
    target513.elements.length = 3 ∧
    [target513.elements.count 0, target513.elements.count 1,
      target513.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain513
def tree514 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0))
def target514 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain514 : accepts tree514 target514 = true ∧
    sourceLeaves tree514 = [2, 0, 0] ∧
    target514.elements.length = 3 ∧
    [target514.elements.count 0, target514.elements.count 1,
      target514.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain514
def tree515 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1)))
def target515 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain515 : accepts tree515 target515 = true ∧
    sourceLeaves tree515 = [2, 0, 1] ∧
    target515.elements.length = 3 ∧
    [target515.elements.count 0, target515.elements.count 1,
      target515.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain515
def tree516 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1))
def target516 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain516 : accepts tree516 target516 = true ∧
    sourceLeaves tree516 = [2, 0, 1] ∧
    target516.elements.length = 3 ∧
    [target516.elements.count 0, target516.elements.count 1,
      target516.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain516
def tree517 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2)))
def target517 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain517 : accepts tree517 target517 = true ∧
    sourceLeaves tree517 = [2, 0, 2] ∧
    target517.elements.length = 3 ∧
    [target517.elements.count 0, target517.elements.count 1,
      target517.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain517
def tree518 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2))
def target518 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain518 : accepts tree518 target518 = true ∧
    sourceLeaves tree518 = [2, 0, 2] ∧
    target518.elements.length = 3 ∧
    [target518.elements.count 0, target518.elements.count 1,
      target518.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain518
def tree519 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0)))
def target519 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain519 : accepts tree519 target519 = true ∧
    sourceLeaves tree519 = [2, 1, 0] ∧
    target519.elements.length = 3 ∧
    [target519.elements.count 0, target519.elements.count 1,
      target519.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain519
def tree520 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0))
def target520 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain520 : accepts tree520 target520 = true ∧
    sourceLeaves tree520 = [2, 1, 0] ∧
    target520.elements.length = 3 ∧
    [target520.elements.count 0, target520.elements.count 1,
      target520.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain520
def tree521 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1)))
def target521 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain521 : accepts tree521 target521 = true ∧
    sourceLeaves tree521 = [2, 1, 1] ∧
    target521.elements.length = 3 ∧
    [target521.elements.count 0, target521.elements.count 1,
      target521.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain521
def tree522 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1))
def target522 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain522 : accepts tree522 target522 = true ∧
    sourceLeaves tree522 = [2, 1, 1] ∧
    target522.elements.length = 3 ∧
    [target522.elements.count 0, target522.elements.count 1,
      target522.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain522
def tree523 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2)))
def target523 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain523 : accepts tree523 target523 = true ∧
    sourceLeaves tree523 = [2, 1, 2] ∧
    target523.elements.length = 3 ∧
    [target523.elements.count 0, target523.elements.count 1,
      target523.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain523
def tree524 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2))
def target524 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain524 : accepts tree524 target524 = true ∧
    sourceLeaves tree524 = [2, 1, 2] ∧
    target524.elements.length = 3 ∧
    [target524.elements.count 0, target524.elements.count 1,
      target524.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain524
def tree525 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0)))
def target525 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain525 : accepts tree525 target525 = true ∧
    sourceLeaves tree525 = [2, 2, 0] ∧
    target525.elements.length = 3 ∧
    [target525.elements.count 0, target525.elements.count 1,
      target525.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain525
def tree526 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0))
def target526 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain526 : accepts tree526 target526 = true ∧
    sourceLeaves tree526 = [2, 2, 0] ∧
    target526.elements.length = 3 ∧
    [target526.elements.count 0, target526.elements.count 1,
      target526.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain526
def tree527 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1)))
def target527 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain527 : accepts tree527 target527 = true ∧
    sourceLeaves tree527 = [2, 2, 1] ∧
    target527.elements.length = 3 ∧
    [target527.elements.count 0, target527.elements.count 1,
      target527.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain527
def tree528 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1))
def target528 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain528 : accepts tree528 target528 = true ∧
    sourceLeaves tree528 = [2, 2, 1] ∧
    target528.elements.length = 3 ∧
    [target528.elements.count 0, target528.elements.count 1,
      target528.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain528
def tree529 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2)))
def target529 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain529 : accepts tree529 target529 = true ∧
    sourceLeaves tree529 = [2, 2, 2] ∧
    target529.elements.length = 3 ∧
    [target529.elements.count 0, target529.elements.count 1,
      target529.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain529
def tree530 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2))
def target530 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain530 : accepts tree530 target530 = true ∧
    sourceLeaves tree530 = [2, 2, 2] ∧
    target530.elements.length = 3 ∧
    [target530.elements.count 0, target530.elements.count 1,
      target530.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain530
def tree531 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))))
def target531 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain531 : accepts tree531 target531 = true ∧
    sourceLeaves tree531 = [0, 0, 0, 0] ∧
    target531.elements.length = 4 ∧
    [target531.elements.count 0, target531.elements.count 1,
      target531.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain531
def tree532 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)))
def target532 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain532 : accepts tree532 target532 = true ∧
    sourceLeaves tree532 = [0, 0, 0, 0] ∧
    target532.elements.length = 4 ∧
    [target532.elements.count 0, target532.elements.count 1,
      target532.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain532
def tree533 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 0)))
def target533 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain533 : accepts tree533 target533 = true ∧
    sourceLeaves tree533 = [0, 0, 0, 0] ∧
    target533.elements.length = 4 ∧
    [target533.elements.count 0, target533.elements.count 1,
      target533.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain533
def tree534 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 0))
def target534 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain534 : accepts tree534 target534 = true ∧
    sourceLeaves tree534 = [0, 0, 0, 0] ∧
    target534.elements.length = 4 ∧
    [target534.elements.count 0, target534.elements.count 1,
      target534.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain534
def tree535 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target535 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain535 : accepts tree535 target535 = true ∧
    sourceLeaves tree535 = [0, 0, 0, 0] ∧
    target535.elements.length = 4 ∧
    [target535.elements.count 0, target535.elements.count 1,
      target535.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain535
def tree536 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))))
def target536 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain536 : accepts tree536 target536 = true ∧
    sourceLeaves tree536 = [0, 0, 0, 1] ∧
    target536.elements.length = 4 ∧
    [target536.elements.count 0, target536.elements.count 1,
      target536.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain536
def tree537 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)))
def target537 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain537 : accepts tree537 target537 = true ∧
    sourceLeaves tree537 = [0, 0, 0, 1] ∧
    target537.elements.length = 4 ∧
    [target537.elements.count 0, target537.elements.count 1,
      target537.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain537
def tree538 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 1)))
def target538 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain538 : accepts tree538 target538 = true ∧
    sourceLeaves tree538 = [0, 0, 0, 1] ∧
    target538.elements.length = 4 ∧
    [target538.elements.count 0, target538.elements.count 1,
      target538.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain538
def tree539 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 1))
def target539 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain539 : accepts tree539 target539 = true ∧
    sourceLeaves tree539 = [0, 0, 0, 1] ∧
    target539.elements.length = 4 ∧
    [target539.elements.count 0, target539.elements.count 1,
      target539.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain539
def tree540 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target540 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain540 : accepts tree540 target540 = true ∧
    sourceLeaves tree540 = [0, 0, 0, 1] ∧
    target540.elements.length = 4 ∧
    [target540.elements.count 0, target540.elements.count 1,
      target540.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain540
def tree541 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))))
def target541 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain541 : accepts tree541 target541 = true ∧
    sourceLeaves tree541 = [0, 0, 0, 2] ∧
    target541.elements.length = 4 ∧
    [target541.elements.count 0, target541.elements.count 1,
      target541.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain541
def tree542 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)))
def target542 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain542 : accepts tree542 target542 = true ∧
    sourceLeaves tree542 = [0, 0, 0, 2] ∧
    target542.elements.length = 4 ∧
    [target542.elements.count 0, target542.elements.count 1,
      target542.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain542
def tree543 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 2)))
def target543 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain543 : accepts tree543 target543 = true ∧
    sourceLeaves tree543 = [0, 0, 0, 2] ∧
    target543.elements.length = 4 ∧
    [target543.elements.count 0, target543.elements.count 1,
      target543.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain543
def tree544 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 2))
def target544 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain544 : accepts tree544 target544 = true ∧
    sourceLeaves tree544 = [0, 0, 0, 2] ∧
    target544.elements.length = 4 ∧
    [target544.elements.count 0, target544.elements.count 1,
      target544.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain544
def tree545 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target545 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain545 : accepts tree545 target545 = true ∧
    sourceLeaves tree545 = [0, 0, 0, 2] ∧
    target545.elements.length = 4 ∧
    [target545.elements.count 0, target545.elements.count 1,
      target545.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain545
def tree546 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))))
def target546 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain546 : accepts tree546 target546 = true ∧
    sourceLeaves tree546 = [0, 0, 1, 0] ∧
    target546.elements.length = 4 ∧
    [target546.elements.count 0, target546.elements.count 1,
      target546.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain546
def tree547 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)))
def target547 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain547 : accepts tree547 target547 = true ∧
    sourceLeaves tree547 = [0, 0, 1, 0] ∧
    target547.elements.length = 4 ∧
    [target547.elements.count 0, target547.elements.count 1,
      target547.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain547
def tree548 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 0)))
def target548 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain548 : accepts tree548 target548 = true ∧
    sourceLeaves tree548 = [0, 0, 1, 0] ∧
    target548.elements.length = 4 ∧
    [target548.elements.count 0, target548.elements.count 1,
      target548.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain548
def tree549 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 0))
def target549 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain549 : accepts tree549 target549 = true ∧
    sourceLeaves tree549 = [0, 0, 1, 0] ∧
    target549.elements.length = 4 ∧
    [target549.elements.count 0, target549.elements.count 1,
      target549.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain549
def tree550 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target550 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain550 : accepts tree550 target550 = true ∧
    sourceLeaves tree550 = [0, 0, 1, 0] ∧
    target550.elements.length = 4 ∧
    [target550.elements.count 0, target550.elements.count 1,
      target550.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain550
def tree551 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))))
def target551 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain551 : accepts tree551 target551 = true ∧
    sourceLeaves tree551 = [0, 0, 1, 1] ∧
    target551.elements.length = 4 ∧
    [target551.elements.count 0, target551.elements.count 1,
      target551.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain551
def tree552 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)))
def target552 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain552 : accepts tree552 target552 = true ∧
    sourceLeaves tree552 = [0, 0, 1, 1] ∧
    target552.elements.length = 4 ∧
    [target552.elements.count 0, target552.elements.count 1,
      target552.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain552
def tree553 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 1)))
def target553 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain553 : accepts tree553 target553 = true ∧
    sourceLeaves tree553 = [0, 0, 1, 1] ∧
    target553.elements.length = 4 ∧
    [target553.elements.count 0, target553.elements.count 1,
      target553.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain553
def tree554 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 1))
def target554 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain554 : accepts tree554 target554 = true ∧
    sourceLeaves tree554 = [0, 0, 1, 1] ∧
    target554.elements.length = 4 ∧
    [target554.elements.count 0, target554.elements.count 1,
      target554.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain554
def tree555 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target555 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain555 : accepts tree555 target555 = true ∧
    sourceLeaves tree555 = [0, 0, 1, 1] ∧
    target555.elements.length = 4 ∧
    [target555.elements.count 0, target555.elements.count 1,
      target555.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain555
def tree556 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))))
def target556 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain556 : accepts tree556 target556 = true ∧
    sourceLeaves tree556 = [0, 0, 1, 2] ∧
    target556.elements.length = 4 ∧
    [target556.elements.count 0, target556.elements.count 1,
      target556.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain556
def tree557 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)))
def target557 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain557 : accepts tree557 target557 = true ∧
    sourceLeaves tree557 = [0, 0, 1, 2] ∧
    target557.elements.length = 4 ∧
    [target557.elements.count 0, target557.elements.count 1,
      target557.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain557
def tree558 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 2)))
def target558 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain558 : accepts tree558 target558 = true ∧
    sourceLeaves tree558 = [0, 0, 1, 2] ∧
    target558.elements.length = 4 ∧
    [target558.elements.count 0, target558.elements.count 1,
      target558.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain558
def tree559 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 2))
def target559 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain559 : accepts tree559 target559 = true ∧
    sourceLeaves tree559 = [0, 0, 1, 2] ∧
    target559.elements.length = 4 ∧
    [target559.elements.count 0, target559.elements.count 1,
      target559.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain559
def tree560 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target560 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain560 : accepts tree560 target560 = true ∧
    sourceLeaves tree560 = [0, 0, 1, 2] ∧
    target560.elements.length = 4 ∧
    [target560.elements.count 0, target560.elements.count 1,
      target560.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain560
def tree561 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))))
def target561 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain561 : accepts tree561 target561 = true ∧
    sourceLeaves tree561 = [0, 0, 2, 0] ∧
    target561.elements.length = 4 ∧
    [target561.elements.count 0, target561.elements.count 1,
      target561.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain561
def tree562 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)))
def target562 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain562 : accepts tree562 target562 = true ∧
    sourceLeaves tree562 = [0, 0, 2, 0] ∧
    target562.elements.length = 4 ∧
    [target562.elements.count 0, target562.elements.count 1,
      target562.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain562
def tree563 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 0)))
def target563 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain563 : accepts tree563 target563 = true ∧
    sourceLeaves tree563 = [0, 0, 2, 0] ∧
    target563.elements.length = 4 ∧
    [target563.elements.count 0, target563.elements.count 1,
      target563.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain563
def tree564 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 0))
def target564 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain564 : accepts tree564 target564 = true ∧
    sourceLeaves tree564 = [0, 0, 2, 0] ∧
    target564.elements.length = 4 ∧
    [target564.elements.count 0, target564.elements.count 1,
      target564.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain564
def tree565 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target565 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain565 : accepts tree565 target565 = true ∧
    sourceLeaves tree565 = [0, 0, 2, 0] ∧
    target565.elements.length = 4 ∧
    [target565.elements.count 0, target565.elements.count 1,
      target565.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain565
def tree566 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))))
def target566 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain566 : accepts tree566 target566 = true ∧
    sourceLeaves tree566 = [0, 0, 2, 1] ∧
    target566.elements.length = 4 ∧
    [target566.elements.count 0, target566.elements.count 1,
      target566.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain566
def tree567 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)))
def target567 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain567 : accepts tree567 target567 = true ∧
    sourceLeaves tree567 = [0, 0, 2, 1] ∧
    target567.elements.length = 4 ∧
    [target567.elements.count 0, target567.elements.count 1,
      target567.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain567
def tree568 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 1)))
def target568 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain568 : accepts tree568 target568 = true ∧
    sourceLeaves tree568 = [0, 0, 2, 1] ∧
    target568.elements.length = 4 ∧
    [target568.elements.count 0, target568.elements.count 1,
      target568.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain568
def tree569 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 1))
def target569 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain569 : accepts tree569 target569 = true ∧
    sourceLeaves tree569 = [0, 0, 2, 1] ∧
    target569.elements.length = 4 ∧
    [target569.elements.count 0, target569.elements.count 1,
      target569.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain569
def tree570 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target570 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain570 : accepts tree570 target570 = true ∧
    sourceLeaves tree570 = [0, 0, 2, 1] ∧
    target570.elements.length = 4 ∧
    [target570.elements.count 0, target570.elements.count 1,
      target570.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain570
def tree571 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))))
def target571 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain571 : accepts tree571 target571 = true ∧
    sourceLeaves tree571 = [0, 0, 2, 2] ∧
    target571.elements.length = 4 ∧
    [target571.elements.count 0, target571.elements.count 1,
      target571.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain571
def tree572 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)))
def target572 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain572 : accepts tree572 target572 = true ∧
    sourceLeaves tree572 = [0, 0, 2, 2] ∧
    target572.elements.length = 4 ∧
    [target572.elements.count 0, target572.elements.count 1,
      target572.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain572
def tree573 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 2)))
def target573 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain573 : accepts tree573 target573 = true ∧
    sourceLeaves tree573 = [0, 0, 2, 2] ∧
    target573.elements.length = 4 ∧
    [target573.elements.count 0, target573.elements.count 1,
      target573.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain573
def tree574 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 2))
def target574 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain574 : accepts tree574 target574 = true ∧
    sourceLeaves tree574 = [0, 0, 2, 2] ∧
    target574.elements.length = 4 ∧
    [target574.elements.count 0, target574.elements.count 1,
      target574.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain574
def tree575 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target575 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain575 : accepts tree575 target575 = true ∧
    sourceLeaves tree575 = [0, 0, 2, 2] ∧
    target575.elements.length = 4 ∧
    [target575.elements.count 0, target575.elements.count 1,
      target575.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain575
def tree576 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))))
def target576 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain576 : accepts tree576 target576 = true ∧
    sourceLeaves tree576 = [0, 1, 0, 0] ∧
    target576.elements.length = 4 ∧
    [target576.elements.count 0, target576.elements.count 1,
      target576.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain576
def tree577 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)))
def target577 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain577 : accepts tree577 target577 = true ∧
    sourceLeaves tree577 = [0, 1, 0, 0] ∧
    target577.elements.length = 4 ∧
    [target577.elements.count 0, target577.elements.count 1,
      target577.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain577
def tree578 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 0)))
def target578 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain578 : accepts tree578 target578 = true ∧
    sourceLeaves tree578 = [0, 1, 0, 0] ∧
    target578.elements.length = 4 ∧
    [target578.elements.count 0, target578.elements.count 1,
      target578.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain578
def tree579 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 0))
def target579 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain579 : accepts tree579 target579 = true ∧
    sourceLeaves tree579 = [0, 1, 0, 0] ∧
    target579.elements.length = 4 ∧
    [target579.elements.count 0, target579.elements.count 1,
      target579.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain579
def tree580 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target580 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain580 : accepts tree580 target580 = true ∧
    sourceLeaves tree580 = [0, 1, 0, 0] ∧
    target580.elements.length = 4 ∧
    [target580.elements.count 0, target580.elements.count 1,
      target580.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain580
def tree581 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))))
def target581 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain581 : accepts tree581 target581 = true ∧
    sourceLeaves tree581 = [0, 1, 0, 1] ∧
    target581.elements.length = 4 ∧
    [target581.elements.count 0, target581.elements.count 1,
      target581.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain581
def tree582 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)))
def target582 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain582 : accepts tree582 target582 = true ∧
    sourceLeaves tree582 = [0, 1, 0, 1] ∧
    target582.elements.length = 4 ∧
    [target582.elements.count 0, target582.elements.count 1,
      target582.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain582
def tree583 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 1)))
def target583 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain583 : accepts tree583 target583 = true ∧
    sourceLeaves tree583 = [0, 1, 0, 1] ∧
    target583.elements.length = 4 ∧
    [target583.elements.count 0, target583.elements.count 1,
      target583.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain583
def tree584 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 1))
def target584 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain584 : accepts tree584 target584 = true ∧
    sourceLeaves tree584 = [0, 1, 0, 1] ∧
    target584.elements.length = 4 ∧
    [target584.elements.count 0, target584.elements.count 1,
      target584.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain584
def tree585 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target585 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain585 : accepts tree585 target585 = true ∧
    sourceLeaves tree585 = [0, 1, 0, 1] ∧
    target585.elements.length = 4 ∧
    [target585.elements.count 0, target585.elements.count 1,
      target585.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain585
def tree586 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))))
def target586 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain586 : accepts tree586 target586 = true ∧
    sourceLeaves tree586 = [0, 1, 0, 2] ∧
    target586.elements.length = 4 ∧
    [target586.elements.count 0, target586.elements.count 1,
      target586.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain586
def tree587 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)))
def target587 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain587 : accepts tree587 target587 = true ∧
    sourceLeaves tree587 = [0, 1, 0, 2] ∧
    target587.elements.length = 4 ∧
    [target587.elements.count 0, target587.elements.count 1,
      target587.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain587
def tree588 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 2)))
def target588 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain588 : accepts tree588 target588 = true ∧
    sourceLeaves tree588 = [0, 1, 0, 2] ∧
    target588.elements.length = 4 ∧
    [target588.elements.count 0, target588.elements.count 1,
      target588.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain588
def tree589 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 2))
def target589 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain589 : accepts tree589 target589 = true ∧
    sourceLeaves tree589 = [0, 1, 0, 2] ∧
    target589.elements.length = 4 ∧
    [target589.elements.count 0, target589.elements.count 1,
      target589.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain589
def tree590 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target590 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain590 : accepts tree590 target590 = true ∧
    sourceLeaves tree590 = [0, 1, 0, 2] ∧
    target590.elements.length = 4 ∧
    [target590.elements.count 0, target590.elements.count 1,
      target590.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain590
def tree591 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))))
def target591 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain591 : accepts tree591 target591 = true ∧
    sourceLeaves tree591 = [0, 1, 1, 0] ∧
    target591.elements.length = 4 ∧
    [target591.elements.count 0, target591.elements.count 1,
      target591.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain591
def tree592 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)))
def target592 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain592 : accepts tree592 target592 = true ∧
    sourceLeaves tree592 = [0, 1, 1, 0] ∧
    target592.elements.length = 4 ∧
    [target592.elements.count 0, target592.elements.count 1,
      target592.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain592
def tree593 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 0)))
def target593 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain593 : accepts tree593 target593 = true ∧
    sourceLeaves tree593 = [0, 1, 1, 0] ∧
    target593.elements.length = 4 ∧
    [target593.elements.count 0, target593.elements.count 1,
      target593.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain593
def tree594 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 0))
def target594 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain594 : accepts tree594 target594 = true ∧
    sourceLeaves tree594 = [0, 1, 1, 0] ∧
    target594.elements.length = 4 ∧
    [target594.elements.count 0, target594.elements.count 1,
      target594.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain594
def tree595 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target595 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain595 : accepts tree595 target595 = true ∧
    sourceLeaves tree595 = [0, 1, 1, 0] ∧
    target595.elements.length = 4 ∧
    [target595.elements.count 0, target595.elements.count 1,
      target595.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain595
def tree596 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))))
def target596 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain596 : accepts tree596 target596 = true ∧
    sourceLeaves tree596 = [0, 1, 1, 1] ∧
    target596.elements.length = 4 ∧
    [target596.elements.count 0, target596.elements.count 1,
      target596.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain596
def tree597 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)))
def target597 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain597 : accepts tree597 target597 = true ∧
    sourceLeaves tree597 = [0, 1, 1, 1] ∧
    target597.elements.length = 4 ∧
    [target597.elements.count 0, target597.elements.count 1,
      target597.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain597
def tree598 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 1)))
def target598 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain598 : accepts tree598 target598 = true ∧
    sourceLeaves tree598 = [0, 1, 1, 1] ∧
    target598.elements.length = 4 ∧
    [target598.elements.count 0, target598.elements.count 1,
      target598.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain598
def tree599 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 1))
def target599 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain599 : accepts tree599 target599 = true ∧
    sourceLeaves tree599 = [0, 1, 1, 1] ∧
    target599.elements.length = 4 ∧
    [target599.elements.count 0, target599.elements.count 1,
      target599.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain599
def tree600 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target600 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain600 : accepts tree600 target600 = true ∧
    sourceLeaves tree600 = [0, 1, 1, 1] ∧
    target600.elements.length = 4 ∧
    [target600.elements.count 0, target600.elements.count 1,
      target600.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain600
def tree601 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))))
def target601 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain601 : accepts tree601 target601 = true ∧
    sourceLeaves tree601 = [0, 1, 1, 2] ∧
    target601.elements.length = 4 ∧
    [target601.elements.count 0, target601.elements.count 1,
      target601.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain601
def tree602 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)))
def target602 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain602 : accepts tree602 target602 = true ∧
    sourceLeaves tree602 = [0, 1, 1, 2] ∧
    target602.elements.length = 4 ∧
    [target602.elements.count 0, target602.elements.count 1,
      target602.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain602
def tree603 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 2)))
def target603 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain603 : accepts tree603 target603 = true ∧
    sourceLeaves tree603 = [0, 1, 1, 2] ∧
    target603.elements.length = 4 ∧
    [target603.elements.count 0, target603.elements.count 1,
      target603.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain603
def tree604 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 2))
def target604 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain604 : accepts tree604 target604 = true ∧
    sourceLeaves tree604 = [0, 1, 1, 2] ∧
    target604.elements.length = 4 ∧
    [target604.elements.count 0, target604.elements.count 1,
      target604.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain604
def tree605 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target605 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain605 : accepts tree605 target605 = true ∧
    sourceLeaves tree605 = [0, 1, 1, 2] ∧
    target605.elements.length = 4 ∧
    [target605.elements.count 0, target605.elements.count 1,
      target605.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain605
def tree606 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))))
def target606 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain606 : accepts tree606 target606 = true ∧
    sourceLeaves tree606 = [0, 1, 2, 0] ∧
    target606.elements.length = 4 ∧
    [target606.elements.count 0, target606.elements.count 1,
      target606.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain606
def tree607 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)))
def target607 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain607 : accepts tree607 target607 = true ∧
    sourceLeaves tree607 = [0, 1, 2, 0] ∧
    target607.elements.length = 4 ∧
    [target607.elements.count 0, target607.elements.count 1,
      target607.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain607
def tree608 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 0)))
def target608 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain608 : accepts tree608 target608 = true ∧
    sourceLeaves tree608 = [0, 1, 2, 0] ∧
    target608.elements.length = 4 ∧
    [target608.elements.count 0, target608.elements.count 1,
      target608.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain608
def tree609 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 0))
def target609 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain609 : accepts tree609 target609 = true ∧
    sourceLeaves tree609 = [0, 1, 2, 0] ∧
    target609.elements.length = 4 ∧
    [target609.elements.count 0, target609.elements.count 1,
      target609.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain609
def tree610 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target610 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain610 : accepts tree610 target610 = true ∧
    sourceLeaves tree610 = [0, 1, 2, 0] ∧
    target610.elements.length = 4 ∧
    [target610.elements.count 0, target610.elements.count 1,
      target610.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain610
def tree611 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))))
def target611 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain611 : accepts tree611 target611 = true ∧
    sourceLeaves tree611 = [0, 1, 2, 1] ∧
    target611.elements.length = 4 ∧
    [target611.elements.count 0, target611.elements.count 1,
      target611.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain611
def tree612 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)))
def target612 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain612 : accepts tree612 target612 = true ∧
    sourceLeaves tree612 = [0, 1, 2, 1] ∧
    target612.elements.length = 4 ∧
    [target612.elements.count 0, target612.elements.count 1,
      target612.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain612
def tree613 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 1)))
def target613 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain613 : accepts tree613 target613 = true ∧
    sourceLeaves tree613 = [0, 1, 2, 1] ∧
    target613.elements.length = 4 ∧
    [target613.elements.count 0, target613.elements.count 1,
      target613.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain613
def tree614 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 1))
def target614 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain614 : accepts tree614 target614 = true ∧
    sourceLeaves tree614 = [0, 1, 2, 1] ∧
    target614.elements.length = 4 ∧
    [target614.elements.count 0, target614.elements.count 1,
      target614.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain614
def tree615 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target615 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain615 : accepts tree615 target615 = true ∧
    sourceLeaves tree615 = [0, 1, 2, 1] ∧
    target615.elements.length = 4 ∧
    [target615.elements.count 0, target615.elements.count 1,
      target615.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain615
def tree616 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))))
def target616 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain616 : accepts tree616 target616 = true ∧
    sourceLeaves tree616 = [0, 1, 2, 2] ∧
    target616.elements.length = 4 ∧
    [target616.elements.count 0, target616.elements.count 1,
      target616.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain616
def tree617 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)))
def target617 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain617 : accepts tree617 target617 = true ∧
    sourceLeaves tree617 = [0, 1, 2, 2] ∧
    target617.elements.length = 4 ∧
    [target617.elements.count 0, target617.elements.count 1,
      target617.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain617
def tree618 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 2)))
def target618 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain618 : accepts tree618 target618 = true ∧
    sourceLeaves tree618 = [0, 1, 2, 2] ∧
    target618.elements.length = 4 ∧
    [target618.elements.count 0, target618.elements.count 1,
      target618.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain618
def tree619 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 2))
def target619 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain619 : accepts tree619 target619 = true ∧
    sourceLeaves tree619 = [0, 1, 2, 2] ∧
    target619.elements.length = 4 ∧
    [target619.elements.count 0, target619.elements.count 1,
      target619.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain619
def tree620 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target620 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain620 : accepts tree620 target620 = true ∧
    sourceLeaves tree620 = [0, 1, 2, 2] ∧
    target620.elements.length = 4 ∧
    [target620.elements.count 0, target620.elements.count 1,
      target620.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain620
def tree621 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))))
def target621 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain621 : accepts tree621 target621 = true ∧
    sourceLeaves tree621 = [0, 2, 0, 0] ∧
    target621.elements.length = 4 ∧
    [target621.elements.count 0, target621.elements.count 1,
      target621.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain621
def tree622 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)))
def target622 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain622 : accepts tree622 target622 = true ∧
    sourceLeaves tree622 = [0, 2, 0, 0] ∧
    target622.elements.length = 4 ∧
    [target622.elements.count 0, target622.elements.count 1,
      target622.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain622
def tree623 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 0)))
def target623 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain623 : accepts tree623 target623 = true ∧
    sourceLeaves tree623 = [0, 2, 0, 0] ∧
    target623.elements.length = 4 ∧
    [target623.elements.count 0, target623.elements.count 1,
      target623.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain623
def tree624 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 0))
def target624 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain624 : accepts tree624 target624 = true ∧
    sourceLeaves tree624 = [0, 2, 0, 0] ∧
    target624.elements.length = 4 ∧
    [target624.elements.count 0, target624.elements.count 1,
      target624.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain624
def tree625 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target625 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain625 : accepts tree625 target625 = true ∧
    sourceLeaves tree625 = [0, 2, 0, 0] ∧
    target625.elements.length = 4 ∧
    [target625.elements.count 0, target625.elements.count 1,
      target625.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain625
def tree626 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))))
def target626 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain626 : accepts tree626 target626 = true ∧
    sourceLeaves tree626 = [0, 2, 0, 1] ∧
    target626.elements.length = 4 ∧
    [target626.elements.count 0, target626.elements.count 1,
      target626.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain626
def tree627 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)))
def target627 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain627 : accepts tree627 target627 = true ∧
    sourceLeaves tree627 = [0, 2, 0, 1] ∧
    target627.elements.length = 4 ∧
    [target627.elements.count 0, target627.elements.count 1,
      target627.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain627
def tree628 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 1)))
def target628 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain628 : accepts tree628 target628 = true ∧
    sourceLeaves tree628 = [0, 2, 0, 1] ∧
    target628.elements.length = 4 ∧
    [target628.elements.count 0, target628.elements.count 1,
      target628.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain628
def tree629 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 1))
def target629 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain629 : accepts tree629 target629 = true ∧
    sourceLeaves tree629 = [0, 2, 0, 1] ∧
    target629.elements.length = 4 ∧
    [target629.elements.count 0, target629.elements.count 1,
      target629.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain629
def tree630 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target630 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain630 : accepts tree630 target630 = true ∧
    sourceLeaves tree630 = [0, 2, 0, 1] ∧
    target630.elements.length = 4 ∧
    [target630.elements.count 0, target630.elements.count 1,
      target630.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain630
def tree631 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))))
def target631 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain631 : accepts tree631 target631 = true ∧
    sourceLeaves tree631 = [0, 2, 0, 2] ∧
    target631.elements.length = 4 ∧
    [target631.elements.count 0, target631.elements.count 1,
      target631.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain631
def tree632 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)))
def target632 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain632 : accepts tree632 target632 = true ∧
    sourceLeaves tree632 = [0, 2, 0, 2] ∧
    target632.elements.length = 4 ∧
    [target632.elements.count 0, target632.elements.count 1,
      target632.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain632
def tree633 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 2)))
def target633 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain633 : accepts tree633 target633 = true ∧
    sourceLeaves tree633 = [0, 2, 0, 2] ∧
    target633.elements.length = 4 ∧
    [target633.elements.count 0, target633.elements.count 1,
      target633.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain633
def tree634 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 2))
def target634 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain634 : accepts tree634 target634 = true ∧
    sourceLeaves tree634 = [0, 2, 0, 2] ∧
    target634.elements.length = 4 ∧
    [target634.elements.count 0, target634.elements.count 1,
      target634.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain634
def tree635 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target635 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain635 : accepts tree635 target635 = true ∧
    sourceLeaves tree635 = [0, 2, 0, 2] ∧
    target635.elements.length = 4 ∧
    [target635.elements.count 0, target635.elements.count 1,
      target635.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain635
def tree636 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))))
def target636 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain636 : accepts tree636 target636 = true ∧
    sourceLeaves tree636 = [0, 2, 1, 0] ∧
    target636.elements.length = 4 ∧
    [target636.elements.count 0, target636.elements.count 1,
      target636.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain636
def tree637 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)))
def target637 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain637 : accepts tree637 target637 = true ∧
    sourceLeaves tree637 = [0, 2, 1, 0] ∧
    target637.elements.length = 4 ∧
    [target637.elements.count 0, target637.elements.count 1,
      target637.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain637
def tree638 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 0)))
def target638 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain638 : accepts tree638 target638 = true ∧
    sourceLeaves tree638 = [0, 2, 1, 0] ∧
    target638.elements.length = 4 ∧
    [target638.elements.count 0, target638.elements.count 1,
      target638.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain638
def tree639 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 0))
def target639 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain639 : accepts tree639 target639 = true ∧
    sourceLeaves tree639 = [0, 2, 1, 0] ∧
    target639.elements.length = 4 ∧
    [target639.elements.count 0, target639.elements.count 1,
      target639.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain639
def tree640 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target640 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain640 : accepts tree640 target640 = true ∧
    sourceLeaves tree640 = [0, 2, 1, 0] ∧
    target640.elements.length = 4 ∧
    [target640.elements.count 0, target640.elements.count 1,
      target640.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain640
def tree641 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))))
def target641 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain641 : accepts tree641 target641 = true ∧
    sourceLeaves tree641 = [0, 2, 1, 1] ∧
    target641.elements.length = 4 ∧
    [target641.elements.count 0, target641.elements.count 1,
      target641.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain641
def tree642 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)))
def target642 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain642 : accepts tree642 target642 = true ∧
    sourceLeaves tree642 = [0, 2, 1, 1] ∧
    target642.elements.length = 4 ∧
    [target642.elements.count 0, target642.elements.count 1,
      target642.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain642
def tree643 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 1)))
def target643 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain643 : accepts tree643 target643 = true ∧
    sourceLeaves tree643 = [0, 2, 1, 1] ∧
    target643.elements.length = 4 ∧
    [target643.elements.count 0, target643.elements.count 1,
      target643.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain643
def tree644 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 1))
def target644 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain644 : accepts tree644 target644 = true ∧
    sourceLeaves tree644 = [0, 2, 1, 1] ∧
    target644.elements.length = 4 ∧
    [target644.elements.count 0, target644.elements.count 1,
      target644.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain644
def tree645 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target645 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain645 : accepts tree645 target645 = true ∧
    sourceLeaves tree645 = [0, 2, 1, 1] ∧
    target645.elements.length = 4 ∧
    [target645.elements.count 0, target645.elements.count 1,
      target645.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain645
def tree646 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))))
def target646 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain646 : accepts tree646 target646 = true ∧
    sourceLeaves tree646 = [0, 2, 1, 2] ∧
    target646.elements.length = 4 ∧
    [target646.elements.count 0, target646.elements.count 1,
      target646.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain646
def tree647 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)))
def target647 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain647 : accepts tree647 target647 = true ∧
    sourceLeaves tree647 = [0, 2, 1, 2] ∧
    target647.elements.length = 4 ∧
    [target647.elements.count 0, target647.elements.count 1,
      target647.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain647
def tree648 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 2)))
def target648 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain648 : accepts tree648 target648 = true ∧
    sourceLeaves tree648 = [0, 2, 1, 2] ∧
    target648.elements.length = 4 ∧
    [target648.elements.count 0, target648.elements.count 1,
      target648.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain648
def tree649 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 2))
def target649 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain649 : accepts tree649 target649 = true ∧
    sourceLeaves tree649 = [0, 2, 1, 2] ∧
    target649.elements.length = 4 ∧
    [target649.elements.count 0, target649.elements.count 1,
      target649.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain649
def tree650 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target650 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain650 : accepts tree650 target650 = true ∧
    sourceLeaves tree650 = [0, 2, 1, 2] ∧
    target650.elements.length = 4 ∧
    [target650.elements.count 0, target650.elements.count 1,
      target650.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain650
def tree651 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))))
def target651 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain651 : accepts tree651 target651 = true ∧
    sourceLeaves tree651 = [0, 2, 2, 0] ∧
    target651.elements.length = 4 ∧
    [target651.elements.count 0, target651.elements.count 1,
      target651.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain651
def tree652 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)))
def target652 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain652 : accepts tree652 target652 = true ∧
    sourceLeaves tree652 = [0, 2, 2, 0] ∧
    target652.elements.length = 4 ∧
    [target652.elements.count 0, target652.elements.count 1,
      target652.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain652
def tree653 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 0)))
def target653 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain653 : accepts tree653 target653 = true ∧
    sourceLeaves tree653 = [0, 2, 2, 0] ∧
    target653.elements.length = 4 ∧
    [target653.elements.count 0, target653.elements.count 1,
      target653.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain653
def tree654 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 0))
def target654 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain654 : accepts tree654 target654 = true ∧
    sourceLeaves tree654 = [0, 2, 2, 0] ∧
    target654.elements.length = 4 ∧
    [target654.elements.count 0, target654.elements.count 1,
      target654.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain654
def tree655 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target655 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain655 : accepts tree655 target655 = true ∧
    sourceLeaves tree655 = [0, 2, 2, 0] ∧
    target655.elements.length = 4 ∧
    [target655.elements.count 0, target655.elements.count 1,
      target655.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain655
def tree656 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))))
def target656 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain656 : accepts tree656 target656 = true ∧
    sourceLeaves tree656 = [0, 2, 2, 1] ∧
    target656.elements.length = 4 ∧
    [target656.elements.count 0, target656.elements.count 1,
      target656.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain656
def tree657 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)))
def target657 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain657 : accepts tree657 target657 = true ∧
    sourceLeaves tree657 = [0, 2, 2, 1] ∧
    target657.elements.length = 4 ∧
    [target657.elements.count 0, target657.elements.count 1,
      target657.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain657
def tree658 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 1)))
def target658 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain658 : accepts tree658 target658 = true ∧
    sourceLeaves tree658 = [0, 2, 2, 1] ∧
    target658.elements.length = 4 ∧
    [target658.elements.count 0, target658.elements.count 1,
      target658.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain658
def tree659 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 1))
def target659 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain659 : accepts tree659 target659 = true ∧
    sourceLeaves tree659 = [0, 2, 2, 1] ∧
    target659.elements.length = 4 ∧
    [target659.elements.count 0, target659.elements.count 1,
      target659.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain659
def tree660 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target660 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain660 : accepts tree660 target660 = true ∧
    sourceLeaves tree660 = [0, 2, 2, 1] ∧
    target660.elements.length = 4 ∧
    [target660.elements.count 0, target660.elements.count 1,
      target660.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain660
def tree661 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))))
def target661 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain661 : accepts tree661 target661 = true ∧
    sourceLeaves tree661 = [0, 2, 2, 2] ∧
    target661.elements.length = 4 ∧
    [target661.elements.count 0, target661.elements.count 1,
      target661.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain661
def tree662 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)))
def target662 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain662 : accepts tree662 target662 = true ∧
    sourceLeaves tree662 = [0, 2, 2, 2] ∧
    target662.elements.length = 4 ∧
    [target662.elements.count 0, target662.elements.count 1,
      target662.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain662
def tree663 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 2)))
def target663 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain663 : accepts tree663 target663 = true ∧
    sourceLeaves tree663 = [0, 2, 2, 2] ∧
    target663.elements.length = 4 ∧
    [target663.elements.count 0, target663.elements.count 1,
      target663.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain663
def tree664 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 2))
def target664 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain664 : accepts tree664 target664 = true ∧
    sourceLeaves tree664 = [0, 2, 2, 2] ∧
    target664.elements.length = 4 ∧
    [target664.elements.count 0, target664.elements.count 1,
      target664.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain664
def tree665 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target665 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain665 : accepts tree665 target665 = true ∧
    sourceLeaves tree665 = [0, 2, 2, 2] ∧
    target665.elements.length = 4 ∧
    [target665.elements.count 0, target665.elements.count 1,
      target665.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain665
def tree666 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))))
def target666 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain666 : accepts tree666 target666 = true ∧
    sourceLeaves tree666 = [1, 0, 0, 0] ∧
    target666.elements.length = 4 ∧
    [target666.elements.count 0, target666.elements.count 1,
      target666.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain666
def tree667 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)))
def target667 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain667 : accepts tree667 target667 = true ∧
    sourceLeaves tree667 = [1, 0, 0, 0] ∧
    target667.elements.length = 4 ∧
    [target667.elements.count 0, target667.elements.count 1,
      target667.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain667
def tree668 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 0)))
def target668 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain668 : accepts tree668 target668 = true ∧
    sourceLeaves tree668 = [1, 0, 0, 0] ∧
    target668.elements.length = 4 ∧
    [target668.elements.count 0, target668.elements.count 1,
      target668.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain668
def tree669 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 0))
def target669 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain669 : accepts tree669 target669 = true ∧
    sourceLeaves tree669 = [1, 0, 0, 0] ∧
    target669.elements.length = 4 ∧
    [target669.elements.count 0, target669.elements.count 1,
      target669.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain669
def tree670 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target670 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain670 : accepts tree670 target670 = true ∧
    sourceLeaves tree670 = [1, 0, 0, 0] ∧
    target670.elements.length = 4 ∧
    [target670.elements.count 0, target670.elements.count 1,
      target670.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain670
def tree671 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))))
def target671 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain671 : accepts tree671 target671 = true ∧
    sourceLeaves tree671 = [1, 0, 0, 1] ∧
    target671.elements.length = 4 ∧
    [target671.elements.count 0, target671.elements.count 1,
      target671.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain671
def tree672 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)))
def target672 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain672 : accepts tree672 target672 = true ∧
    sourceLeaves tree672 = [1, 0, 0, 1] ∧
    target672.elements.length = 4 ∧
    [target672.elements.count 0, target672.elements.count 1,
      target672.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain672
def tree673 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 1)))
def target673 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain673 : accepts tree673 target673 = true ∧
    sourceLeaves tree673 = [1, 0, 0, 1] ∧
    target673.elements.length = 4 ∧
    [target673.elements.count 0, target673.elements.count 1,
      target673.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain673
def tree674 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 1))
def target674 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain674 : accepts tree674 target674 = true ∧
    sourceLeaves tree674 = [1, 0, 0, 1] ∧
    target674.elements.length = 4 ∧
    [target674.elements.count 0, target674.elements.count 1,
      target674.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain674
def tree675 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target675 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain675 : accepts tree675 target675 = true ∧
    sourceLeaves tree675 = [1, 0, 0, 1] ∧
    target675.elements.length = 4 ∧
    [target675.elements.count 0, target675.elements.count 1,
      target675.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain675
def tree676 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))))
def target676 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain676 : accepts tree676 target676 = true ∧
    sourceLeaves tree676 = [1, 0, 0, 2] ∧
    target676.elements.length = 4 ∧
    [target676.elements.count 0, target676.elements.count 1,
      target676.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain676
def tree677 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)))
def target677 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain677 : accepts tree677 target677 = true ∧
    sourceLeaves tree677 = [1, 0, 0, 2] ∧
    target677.elements.length = 4 ∧
    [target677.elements.count 0, target677.elements.count 1,
      target677.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain677
def tree678 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 2)))
def target678 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain678 : accepts tree678 target678 = true ∧
    sourceLeaves tree678 = [1, 0, 0, 2] ∧
    target678.elements.length = 4 ∧
    [target678.elements.count 0, target678.elements.count 1,
      target678.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain678
def tree679 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 2))
def target679 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain679 : accepts tree679 target679 = true ∧
    sourceLeaves tree679 = [1, 0, 0, 2] ∧
    target679.elements.length = 4 ∧
    [target679.elements.count 0, target679.elements.count 1,
      target679.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain679
def tree680 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target680 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain680 : accepts tree680 target680 = true ∧
    sourceLeaves tree680 = [1, 0, 0, 2] ∧
    target680.elements.length = 4 ∧
    [target680.elements.count 0, target680.elements.count 1,
      target680.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain680
def tree681 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))))
def target681 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain681 : accepts tree681 target681 = true ∧
    sourceLeaves tree681 = [1, 0, 1, 0] ∧
    target681.elements.length = 4 ∧
    [target681.elements.count 0, target681.elements.count 1,
      target681.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain681
def tree682 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)))
def target682 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain682 : accepts tree682 target682 = true ∧
    sourceLeaves tree682 = [1, 0, 1, 0] ∧
    target682.elements.length = 4 ∧
    [target682.elements.count 0, target682.elements.count 1,
      target682.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain682
def tree683 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 0)))
def target683 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain683 : accepts tree683 target683 = true ∧
    sourceLeaves tree683 = [1, 0, 1, 0] ∧
    target683.elements.length = 4 ∧
    [target683.elements.count 0, target683.elements.count 1,
      target683.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain683
def tree684 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 0))
def target684 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain684 : accepts tree684 target684 = true ∧
    sourceLeaves tree684 = [1, 0, 1, 0] ∧
    target684.elements.length = 4 ∧
    [target684.elements.count 0, target684.elements.count 1,
      target684.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain684
def tree685 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target685 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain685 : accepts tree685 target685 = true ∧
    sourceLeaves tree685 = [1, 0, 1, 0] ∧
    target685.elements.length = 4 ∧
    [target685.elements.count 0, target685.elements.count 1,
      target685.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain685
def tree686 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))))
def target686 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain686 : accepts tree686 target686 = true ∧
    sourceLeaves tree686 = [1, 0, 1, 1] ∧
    target686.elements.length = 4 ∧
    [target686.elements.count 0, target686.elements.count 1,
      target686.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain686
def tree687 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)))
def target687 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain687 : accepts tree687 target687 = true ∧
    sourceLeaves tree687 = [1, 0, 1, 1] ∧
    target687.elements.length = 4 ∧
    [target687.elements.count 0, target687.elements.count 1,
      target687.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain687
def tree688 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 1)))
def target688 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain688 : accepts tree688 target688 = true ∧
    sourceLeaves tree688 = [1, 0, 1, 1] ∧
    target688.elements.length = 4 ∧
    [target688.elements.count 0, target688.elements.count 1,
      target688.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain688
def tree689 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 1))
def target689 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain689 : accepts tree689 target689 = true ∧
    sourceLeaves tree689 = [1, 0, 1, 1] ∧
    target689.elements.length = 4 ∧
    [target689.elements.count 0, target689.elements.count 1,
      target689.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain689
def tree690 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target690 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain690 : accepts tree690 target690 = true ∧
    sourceLeaves tree690 = [1, 0, 1, 1] ∧
    target690.elements.length = 4 ∧
    [target690.elements.count 0, target690.elements.count 1,
      target690.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain690
def tree691 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))))
def target691 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain691 : accepts tree691 target691 = true ∧
    sourceLeaves tree691 = [1, 0, 1, 2] ∧
    target691.elements.length = 4 ∧
    [target691.elements.count 0, target691.elements.count 1,
      target691.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain691
def tree692 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)))
def target692 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain692 : accepts tree692 target692 = true ∧
    sourceLeaves tree692 = [1, 0, 1, 2] ∧
    target692.elements.length = 4 ∧
    [target692.elements.count 0, target692.elements.count 1,
      target692.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain692
def tree693 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 2)))
def target693 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain693 : accepts tree693 target693 = true ∧
    sourceLeaves tree693 = [1, 0, 1, 2] ∧
    target693.elements.length = 4 ∧
    [target693.elements.count 0, target693.elements.count 1,
      target693.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain693
def tree694 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 2))
def target694 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain694 : accepts tree694 target694 = true ∧
    sourceLeaves tree694 = [1, 0, 1, 2] ∧
    target694.elements.length = 4 ∧
    [target694.elements.count 0, target694.elements.count 1,
      target694.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain694
def tree695 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target695 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain695 : accepts tree695 target695 = true ∧
    sourceLeaves tree695 = [1, 0, 1, 2] ∧
    target695.elements.length = 4 ∧
    [target695.elements.count 0, target695.elements.count 1,
      target695.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain695
def tree696 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))))
def target696 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain696 : accepts tree696 target696 = true ∧
    sourceLeaves tree696 = [1, 0, 2, 0] ∧
    target696.elements.length = 4 ∧
    [target696.elements.count 0, target696.elements.count 1,
      target696.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain696
def tree697 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)))
def target697 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain697 : accepts tree697 target697 = true ∧
    sourceLeaves tree697 = [1, 0, 2, 0] ∧
    target697.elements.length = 4 ∧
    [target697.elements.count 0, target697.elements.count 1,
      target697.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain697
def tree698 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 0)))
def target698 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain698 : accepts tree698 target698 = true ∧
    sourceLeaves tree698 = [1, 0, 2, 0] ∧
    target698.elements.length = 4 ∧
    [target698.elements.count 0, target698.elements.count 1,
      target698.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain698
def tree699 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 0))
def target699 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain699 : accepts tree699 target699 = true ∧
    sourceLeaves tree699 = [1, 0, 2, 0] ∧
    target699.elements.length = 4 ∧
    [target699.elements.count 0, target699.elements.count 1,
      target699.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain699
def tree700 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target700 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain700 : accepts tree700 target700 = true ∧
    sourceLeaves tree700 = [1, 0, 2, 0] ∧
    target700.elements.length = 4 ∧
    [target700.elements.count 0, target700.elements.count 1,
      target700.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain700
def tree701 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))))
def target701 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain701 : accepts tree701 target701 = true ∧
    sourceLeaves tree701 = [1, 0, 2, 1] ∧
    target701.elements.length = 4 ∧
    [target701.elements.count 0, target701.elements.count 1,
      target701.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain701
def tree702 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)))
def target702 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain702 : accepts tree702 target702 = true ∧
    sourceLeaves tree702 = [1, 0, 2, 1] ∧
    target702.elements.length = 4 ∧
    [target702.elements.count 0, target702.elements.count 1,
      target702.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain702
def tree703 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 1)))
def target703 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain703 : accepts tree703 target703 = true ∧
    sourceLeaves tree703 = [1, 0, 2, 1] ∧
    target703.elements.length = 4 ∧
    [target703.elements.count 0, target703.elements.count 1,
      target703.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain703
def tree704 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 1))
def target704 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain704 : accepts tree704 target704 = true ∧
    sourceLeaves tree704 = [1, 0, 2, 1] ∧
    target704.elements.length = 4 ∧
    [target704.elements.count 0, target704.elements.count 1,
      target704.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain704
def tree705 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target705 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain705 : accepts tree705 target705 = true ∧
    sourceLeaves tree705 = [1, 0, 2, 1] ∧
    target705.elements.length = 4 ∧
    [target705.elements.count 0, target705.elements.count 1,
      target705.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain705
def tree706 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))))
def target706 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain706 : accepts tree706 target706 = true ∧
    sourceLeaves tree706 = [1, 0, 2, 2] ∧
    target706.elements.length = 4 ∧
    [target706.elements.count 0, target706.elements.count 1,
      target706.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain706
def tree707 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)))
def target707 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain707 : accepts tree707 target707 = true ∧
    sourceLeaves tree707 = [1, 0, 2, 2] ∧
    target707.elements.length = 4 ∧
    [target707.elements.count 0, target707.elements.count 1,
      target707.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain707
def tree708 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 2)))
def target708 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain708 : accepts tree708 target708 = true ∧
    sourceLeaves tree708 = [1, 0, 2, 2] ∧
    target708.elements.length = 4 ∧
    [target708.elements.count 0, target708.elements.count 1,
      target708.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain708
def tree709 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 2))
def target709 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain709 : accepts tree709 target709 = true ∧
    sourceLeaves tree709 = [1, 0, 2, 2] ∧
    target709.elements.length = 4 ∧
    [target709.elements.count 0, target709.elements.count 1,
      target709.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain709
def tree710 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target710 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain710 : accepts tree710 target710 = true ∧
    sourceLeaves tree710 = [1, 0, 2, 2] ∧
    target710.elements.length = 4 ∧
    [target710.elements.count 0, target710.elements.count 1,
      target710.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain710
def tree711 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))))
def target711 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain711 : accepts tree711 target711 = true ∧
    sourceLeaves tree711 = [1, 1, 0, 0] ∧
    target711.elements.length = 4 ∧
    [target711.elements.count 0, target711.elements.count 1,
      target711.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain711
def tree712 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)))
def target712 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain712 : accepts tree712 target712 = true ∧
    sourceLeaves tree712 = [1, 1, 0, 0] ∧
    target712.elements.length = 4 ∧
    [target712.elements.count 0, target712.elements.count 1,
      target712.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain712
def tree713 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 0)))
def target713 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain713 : accepts tree713 target713 = true ∧
    sourceLeaves tree713 = [1, 1, 0, 0] ∧
    target713.elements.length = 4 ∧
    [target713.elements.count 0, target713.elements.count 1,
      target713.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain713
def tree714 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 0))
def target714 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain714 : accepts tree714 target714 = true ∧
    sourceLeaves tree714 = [1, 1, 0, 0] ∧
    target714.elements.length = 4 ∧
    [target714.elements.count 0, target714.elements.count 1,
      target714.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain714
def tree715 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target715 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain715 : accepts tree715 target715 = true ∧
    sourceLeaves tree715 = [1, 1, 0, 0] ∧
    target715.elements.length = 4 ∧
    [target715.elements.count 0, target715.elements.count 1,
      target715.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain715
def tree716 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))))
def target716 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain716 : accepts tree716 target716 = true ∧
    sourceLeaves tree716 = [1, 1, 0, 1] ∧
    target716.elements.length = 4 ∧
    [target716.elements.count 0, target716.elements.count 1,
      target716.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain716
def tree717 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)))
def target717 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain717 : accepts tree717 target717 = true ∧
    sourceLeaves tree717 = [1, 1, 0, 1] ∧
    target717.elements.length = 4 ∧
    [target717.elements.count 0, target717.elements.count 1,
      target717.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain717
def tree718 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 1)))
def target718 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain718 : accepts tree718 target718 = true ∧
    sourceLeaves tree718 = [1, 1, 0, 1] ∧
    target718.elements.length = 4 ∧
    [target718.elements.count 0, target718.elements.count 1,
      target718.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain718
def tree719 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 1))
def target719 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain719 : accepts tree719 target719 = true ∧
    sourceLeaves tree719 = [1, 1, 0, 1] ∧
    target719.elements.length = 4 ∧
    [target719.elements.count 0, target719.elements.count 1,
      target719.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain719
def tree720 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target720 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain720 : accepts tree720 target720 = true ∧
    sourceLeaves tree720 = [1, 1, 0, 1] ∧
    target720.elements.length = 4 ∧
    [target720.elements.count 0, target720.elements.count 1,
      target720.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain720
def tree721 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))))
def target721 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain721 : accepts tree721 target721 = true ∧
    sourceLeaves tree721 = [1, 1, 0, 2] ∧
    target721.elements.length = 4 ∧
    [target721.elements.count 0, target721.elements.count 1,
      target721.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain721
def tree722 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)))
def target722 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain722 : accepts tree722 target722 = true ∧
    sourceLeaves tree722 = [1, 1, 0, 2] ∧
    target722.elements.length = 4 ∧
    [target722.elements.count 0, target722.elements.count 1,
      target722.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain722
def tree723 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 2)))
def target723 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain723 : accepts tree723 target723 = true ∧
    sourceLeaves tree723 = [1, 1, 0, 2] ∧
    target723.elements.length = 4 ∧
    [target723.elements.count 0, target723.elements.count 1,
      target723.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain723
def tree724 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 2))
def target724 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain724 : accepts tree724 target724 = true ∧
    sourceLeaves tree724 = [1, 1, 0, 2] ∧
    target724.elements.length = 4 ∧
    [target724.elements.count 0, target724.elements.count 1,
      target724.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain724
def tree725 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target725 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain725 : accepts tree725 target725 = true ∧
    sourceLeaves tree725 = [1, 1, 0, 2] ∧
    target725.elements.length = 4 ∧
    [target725.elements.count 0, target725.elements.count 1,
      target725.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain725
def tree726 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))))
def target726 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain726 : accepts tree726 target726 = true ∧
    sourceLeaves tree726 = [1, 1, 1, 0] ∧
    target726.elements.length = 4 ∧
    [target726.elements.count 0, target726.elements.count 1,
      target726.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain726
def tree727 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)))
def target727 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain727 : accepts tree727 target727 = true ∧
    sourceLeaves tree727 = [1, 1, 1, 0] ∧
    target727.elements.length = 4 ∧
    [target727.elements.count 0, target727.elements.count 1,
      target727.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain727
def tree728 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 0)))
def target728 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain728 : accepts tree728 target728 = true ∧
    sourceLeaves tree728 = [1, 1, 1, 0] ∧
    target728.elements.length = 4 ∧
    [target728.elements.count 0, target728.elements.count 1,
      target728.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain728
def tree729 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 0))
def target729 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain729 : accepts tree729 target729 = true ∧
    sourceLeaves tree729 = [1, 1, 1, 0] ∧
    target729.elements.length = 4 ∧
    [target729.elements.count 0, target729.elements.count 1,
      target729.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain729
def tree730 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target730 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain730 : accepts tree730 target730 = true ∧
    sourceLeaves tree730 = [1, 1, 1, 0] ∧
    target730.elements.length = 4 ∧
    [target730.elements.count 0, target730.elements.count 1,
      target730.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain730
def tree731 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))))
def target731 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain731 : accepts tree731 target731 = true ∧
    sourceLeaves tree731 = [1, 1, 1, 1] ∧
    target731.elements.length = 4 ∧
    [target731.elements.count 0, target731.elements.count 1,
      target731.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain731
def tree732 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)))
def target732 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain732 : accepts tree732 target732 = true ∧
    sourceLeaves tree732 = [1, 1, 1, 1] ∧
    target732.elements.length = 4 ∧
    [target732.elements.count 0, target732.elements.count 1,
      target732.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain732
def tree733 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 1)))
def target733 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain733 : accepts tree733 target733 = true ∧
    sourceLeaves tree733 = [1, 1, 1, 1] ∧
    target733.elements.length = 4 ∧
    [target733.elements.count 0, target733.elements.count 1,
      target733.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain733
def tree734 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 1))
def target734 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain734 : accepts tree734 target734 = true ∧
    sourceLeaves tree734 = [1, 1, 1, 1] ∧
    target734.elements.length = 4 ∧
    [target734.elements.count 0, target734.elements.count 1,
      target734.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain734
def tree735 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target735 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain735 : accepts tree735 target735 = true ∧
    sourceLeaves tree735 = [1, 1, 1, 1] ∧
    target735.elements.length = 4 ∧
    [target735.elements.count 0, target735.elements.count 1,
      target735.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain735
def tree736 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))))
def target736 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain736 : accepts tree736 target736 = true ∧
    sourceLeaves tree736 = [1, 1, 1, 2] ∧
    target736.elements.length = 4 ∧
    [target736.elements.count 0, target736.elements.count 1,
      target736.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain736
def tree737 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)))
def target737 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain737 : accepts tree737 target737 = true ∧
    sourceLeaves tree737 = [1, 1, 1, 2] ∧
    target737.elements.length = 4 ∧
    [target737.elements.count 0, target737.elements.count 1,
      target737.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain737
def tree738 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 2)))
def target738 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain738 : accepts tree738 target738 = true ∧
    sourceLeaves tree738 = [1, 1, 1, 2] ∧
    target738.elements.length = 4 ∧
    [target738.elements.count 0, target738.elements.count 1,
      target738.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain738
def tree739 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 2))
def target739 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain739 : accepts tree739 target739 = true ∧
    sourceLeaves tree739 = [1, 1, 1, 2] ∧
    target739.elements.length = 4 ∧
    [target739.elements.count 0, target739.elements.count 1,
      target739.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain739
def tree740 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target740 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain740 : accepts tree740 target740 = true ∧
    sourceLeaves tree740 = [1, 1, 1, 2] ∧
    target740.elements.length = 4 ∧
    [target740.elements.count 0, target740.elements.count 1,
      target740.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain740
def tree741 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))))
def target741 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain741 : accepts tree741 target741 = true ∧
    sourceLeaves tree741 = [1, 1, 2, 0] ∧
    target741.elements.length = 4 ∧
    [target741.elements.count 0, target741.elements.count 1,
      target741.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain741
def tree742 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)))
def target742 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain742 : accepts tree742 target742 = true ∧
    sourceLeaves tree742 = [1, 1, 2, 0] ∧
    target742.elements.length = 4 ∧
    [target742.elements.count 0, target742.elements.count 1,
      target742.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain742
def tree743 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 0)))
def target743 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain743 : accepts tree743 target743 = true ∧
    sourceLeaves tree743 = [1, 1, 2, 0] ∧
    target743.elements.length = 4 ∧
    [target743.elements.count 0, target743.elements.count 1,
      target743.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain743
def tree744 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 0))
def target744 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain744 : accepts tree744 target744 = true ∧
    sourceLeaves tree744 = [1, 1, 2, 0] ∧
    target744.elements.length = 4 ∧
    [target744.elements.count 0, target744.elements.count 1,
      target744.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain744
def tree745 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target745 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain745 : accepts tree745 target745 = true ∧
    sourceLeaves tree745 = [1, 1, 2, 0] ∧
    target745.elements.length = 4 ∧
    [target745.elements.count 0, target745.elements.count 1,
      target745.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain745
def tree746 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))))
def target746 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain746 : accepts tree746 target746 = true ∧
    sourceLeaves tree746 = [1, 1, 2, 1] ∧
    target746.elements.length = 4 ∧
    [target746.elements.count 0, target746.elements.count 1,
      target746.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain746
def tree747 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)))
def target747 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain747 : accepts tree747 target747 = true ∧
    sourceLeaves tree747 = [1, 1, 2, 1] ∧
    target747.elements.length = 4 ∧
    [target747.elements.count 0, target747.elements.count 1,
      target747.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain747
def tree748 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 1)))
def target748 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain748 : accepts tree748 target748 = true ∧
    sourceLeaves tree748 = [1, 1, 2, 1] ∧
    target748.elements.length = 4 ∧
    [target748.elements.count 0, target748.elements.count 1,
      target748.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain748
def tree749 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 1))
def target749 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain749 : accepts tree749 target749 = true ∧
    sourceLeaves tree749 = [1, 1, 2, 1] ∧
    target749.elements.length = 4 ∧
    [target749.elements.count 0, target749.elements.count 1,
      target749.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain749
def tree750 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target750 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain750 : accepts tree750 target750 = true ∧
    sourceLeaves tree750 = [1, 1, 2, 1] ∧
    target750.elements.length = 4 ∧
    [target750.elements.count 0, target750.elements.count 1,
      target750.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain750
def tree751 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))))
def target751 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain751 : accepts tree751 target751 = true ∧
    sourceLeaves tree751 = [1, 1, 2, 2] ∧
    target751.elements.length = 4 ∧
    [target751.elements.count 0, target751.elements.count 1,
      target751.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain751
def tree752 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)))
def target752 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain752 : accepts tree752 target752 = true ∧
    sourceLeaves tree752 = [1, 1, 2, 2] ∧
    target752.elements.length = 4 ∧
    [target752.elements.count 0, target752.elements.count 1,
      target752.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain752
def tree753 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 2)))
def target753 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain753 : accepts tree753 target753 = true ∧
    sourceLeaves tree753 = [1, 1, 2, 2] ∧
    target753.elements.length = 4 ∧
    [target753.elements.count 0, target753.elements.count 1,
      target753.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain753
def tree754 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 2))
def target754 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain754 : accepts tree754 target754 = true ∧
    sourceLeaves tree754 = [1, 1, 2, 2] ∧
    target754.elements.length = 4 ∧
    [target754.elements.count 0, target754.elements.count 1,
      target754.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain754
def tree755 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target755 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain755 : accepts tree755 target755 = true ∧
    sourceLeaves tree755 = [1, 1, 2, 2] ∧
    target755.elements.length = 4 ∧
    [target755.elements.count 0, target755.elements.count 1,
      target755.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain755
def tree756 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))))
def target756 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain756 : accepts tree756 target756 = true ∧
    sourceLeaves tree756 = [1, 2, 0, 0] ∧
    target756.elements.length = 4 ∧
    [target756.elements.count 0, target756.elements.count 1,
      target756.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain756
def tree757 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)))
def target757 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain757 : accepts tree757 target757 = true ∧
    sourceLeaves tree757 = [1, 2, 0, 0] ∧
    target757.elements.length = 4 ∧
    [target757.elements.count 0, target757.elements.count 1,
      target757.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain757
def tree758 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 0)))
def target758 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain758 : accepts tree758 target758 = true ∧
    sourceLeaves tree758 = [1, 2, 0, 0] ∧
    target758.elements.length = 4 ∧
    [target758.elements.count 0, target758.elements.count 1,
      target758.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain758
def tree759 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 0))
def target759 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain759 : accepts tree759 target759 = true ∧
    sourceLeaves tree759 = [1, 2, 0, 0] ∧
    target759.elements.length = 4 ∧
    [target759.elements.count 0, target759.elements.count 1,
      target759.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain759
def tree760 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target760 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain760 : accepts tree760 target760 = true ∧
    sourceLeaves tree760 = [1, 2, 0, 0] ∧
    target760.elements.length = 4 ∧
    [target760.elements.count 0, target760.elements.count 1,
      target760.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain760
def tree761 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))))
def target761 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain761 : accepts tree761 target761 = true ∧
    sourceLeaves tree761 = [1, 2, 0, 1] ∧
    target761.elements.length = 4 ∧
    [target761.elements.count 0, target761.elements.count 1,
      target761.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain761
def tree762 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)))
def target762 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain762 : accepts tree762 target762 = true ∧
    sourceLeaves tree762 = [1, 2, 0, 1] ∧
    target762.elements.length = 4 ∧
    [target762.elements.count 0, target762.elements.count 1,
      target762.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain762
def tree763 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 1)))
def target763 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain763 : accepts tree763 target763 = true ∧
    sourceLeaves tree763 = [1, 2, 0, 1] ∧
    target763.elements.length = 4 ∧
    [target763.elements.count 0, target763.elements.count 1,
      target763.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain763
def tree764 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 1))
def target764 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain764 : accepts tree764 target764 = true ∧
    sourceLeaves tree764 = [1, 2, 0, 1] ∧
    target764.elements.length = 4 ∧
    [target764.elements.count 0, target764.elements.count 1,
      target764.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain764
def tree765 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target765 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain765 : accepts tree765 target765 = true ∧
    sourceLeaves tree765 = [1, 2, 0, 1] ∧
    target765.elements.length = 4 ∧
    [target765.elements.count 0, target765.elements.count 1,
      target765.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain765
def tree766 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))))
def target766 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain766 : accepts tree766 target766 = true ∧
    sourceLeaves tree766 = [1, 2, 0, 2] ∧
    target766.elements.length = 4 ∧
    [target766.elements.count 0, target766.elements.count 1,
      target766.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain766
def tree767 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)))
def target767 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain767 : accepts tree767 target767 = true ∧
    sourceLeaves tree767 = [1, 2, 0, 2] ∧
    target767.elements.length = 4 ∧
    [target767.elements.count 0, target767.elements.count 1,
      target767.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain767
def tree768 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 2)))
def target768 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain768 : accepts tree768 target768 = true ∧
    sourceLeaves tree768 = [1, 2, 0, 2] ∧
    target768.elements.length = 4 ∧
    [target768.elements.count 0, target768.elements.count 1,
      target768.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain768
def tree769 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 2))
def target769 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain769 : accepts tree769 target769 = true ∧
    sourceLeaves tree769 = [1, 2, 0, 2] ∧
    target769.elements.length = 4 ∧
    [target769.elements.count 0, target769.elements.count 1,
      target769.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain769
def tree770 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target770 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain770 : accepts tree770 target770 = true ∧
    sourceLeaves tree770 = [1, 2, 0, 2] ∧
    target770.elements.length = 4 ∧
    [target770.elements.count 0, target770.elements.count 1,
      target770.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain770
def tree771 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))))
def target771 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain771 : accepts tree771 target771 = true ∧
    sourceLeaves tree771 = [1, 2, 1, 0] ∧
    target771.elements.length = 4 ∧
    [target771.elements.count 0, target771.elements.count 1,
      target771.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain771
def tree772 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)))
def target772 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain772 : accepts tree772 target772 = true ∧
    sourceLeaves tree772 = [1, 2, 1, 0] ∧
    target772.elements.length = 4 ∧
    [target772.elements.count 0, target772.elements.count 1,
      target772.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain772
def tree773 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 0)))
def target773 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain773 : accepts tree773 target773 = true ∧
    sourceLeaves tree773 = [1, 2, 1, 0] ∧
    target773.elements.length = 4 ∧
    [target773.elements.count 0, target773.elements.count 1,
      target773.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain773
def tree774 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 0))
def target774 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain774 : accepts tree774 target774 = true ∧
    sourceLeaves tree774 = [1, 2, 1, 0] ∧
    target774.elements.length = 4 ∧
    [target774.elements.count 0, target774.elements.count 1,
      target774.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain774
def tree775 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target775 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain775 : accepts tree775 target775 = true ∧
    sourceLeaves tree775 = [1, 2, 1, 0] ∧
    target775.elements.length = 4 ∧
    [target775.elements.count 0, target775.elements.count 1,
      target775.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain775
def tree776 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))))
def target776 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain776 : accepts tree776 target776 = true ∧
    sourceLeaves tree776 = [1, 2, 1, 1] ∧
    target776.elements.length = 4 ∧
    [target776.elements.count 0, target776.elements.count 1,
      target776.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain776
def tree777 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)))
def target777 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain777 : accepts tree777 target777 = true ∧
    sourceLeaves tree777 = [1, 2, 1, 1] ∧
    target777.elements.length = 4 ∧
    [target777.elements.count 0, target777.elements.count 1,
      target777.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain777
def tree778 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 1)))
def target778 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain778 : accepts tree778 target778 = true ∧
    sourceLeaves tree778 = [1, 2, 1, 1] ∧
    target778.elements.length = 4 ∧
    [target778.elements.count 0, target778.elements.count 1,
      target778.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain778
def tree779 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 1))
def target779 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain779 : accepts tree779 target779 = true ∧
    sourceLeaves tree779 = [1, 2, 1, 1] ∧
    target779.elements.length = 4 ∧
    [target779.elements.count 0, target779.elements.count 1,
      target779.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain779
def tree780 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target780 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain780 : accepts tree780 target780 = true ∧
    sourceLeaves tree780 = [1, 2, 1, 1] ∧
    target780.elements.length = 4 ∧
    [target780.elements.count 0, target780.elements.count 1,
      target780.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain780
def tree781 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))))
def target781 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain781 : accepts tree781 target781 = true ∧
    sourceLeaves tree781 = [1, 2, 1, 2] ∧
    target781.elements.length = 4 ∧
    [target781.elements.count 0, target781.elements.count 1,
      target781.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain781
def tree782 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)))
def target782 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain782 : accepts tree782 target782 = true ∧
    sourceLeaves tree782 = [1, 2, 1, 2] ∧
    target782.elements.length = 4 ∧
    [target782.elements.count 0, target782.elements.count 1,
      target782.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain782
def tree783 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 2)))
def target783 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain783 : accepts tree783 target783 = true ∧
    sourceLeaves tree783 = [1, 2, 1, 2] ∧
    target783.elements.length = 4 ∧
    [target783.elements.count 0, target783.elements.count 1,
      target783.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain783
def tree784 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 2))
def target784 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain784 : accepts tree784 target784 = true ∧
    sourceLeaves tree784 = [1, 2, 1, 2] ∧
    target784.elements.length = 4 ∧
    [target784.elements.count 0, target784.elements.count 1,
      target784.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain784
def tree785 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target785 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain785 : accepts tree785 target785 = true ∧
    sourceLeaves tree785 = [1, 2, 1, 2] ∧
    target785.elements.length = 4 ∧
    [target785.elements.count 0, target785.elements.count 1,
      target785.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain785
def tree786 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))))
def target786 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain786 : accepts tree786 target786 = true ∧
    sourceLeaves tree786 = [1, 2, 2, 0] ∧
    target786.elements.length = 4 ∧
    [target786.elements.count 0, target786.elements.count 1,
      target786.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain786
def tree787 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)))
def target787 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain787 : accepts tree787 target787 = true ∧
    sourceLeaves tree787 = [1, 2, 2, 0] ∧
    target787.elements.length = 4 ∧
    [target787.elements.count 0, target787.elements.count 1,
      target787.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain787
def tree788 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 0)))
def target788 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain788 : accepts tree788 target788 = true ∧
    sourceLeaves tree788 = [1, 2, 2, 0] ∧
    target788.elements.length = 4 ∧
    [target788.elements.count 0, target788.elements.count 1,
      target788.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain788
def tree789 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 0))
def target789 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain789 : accepts tree789 target789 = true ∧
    sourceLeaves tree789 = [1, 2, 2, 0] ∧
    target789.elements.length = 4 ∧
    [target789.elements.count 0, target789.elements.count 1,
      target789.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain789
def tree790 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target790 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain790 : accepts tree790 target790 = true ∧
    sourceLeaves tree790 = [1, 2, 2, 0] ∧
    target790.elements.length = 4 ∧
    [target790.elements.count 0, target790.elements.count 1,
      target790.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain790
def tree791 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))))
def target791 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain791 : accepts tree791 target791 = true ∧
    sourceLeaves tree791 = [1, 2, 2, 1] ∧
    target791.elements.length = 4 ∧
    [target791.elements.count 0, target791.elements.count 1,
      target791.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain791
def tree792 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)))
def target792 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain792 : accepts tree792 target792 = true ∧
    sourceLeaves tree792 = [1, 2, 2, 1] ∧
    target792.elements.length = 4 ∧
    [target792.elements.count 0, target792.elements.count 1,
      target792.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain792
def tree793 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 1)))
def target793 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain793 : accepts tree793 target793 = true ∧
    sourceLeaves tree793 = [1, 2, 2, 1] ∧
    target793.elements.length = 4 ∧
    [target793.elements.count 0, target793.elements.count 1,
      target793.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain793
def tree794 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 1))
def target794 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain794 : accepts tree794 target794 = true ∧
    sourceLeaves tree794 = [1, 2, 2, 1] ∧
    target794.elements.length = 4 ∧
    [target794.elements.count 0, target794.elements.count 1,
      target794.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain794
def tree795 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target795 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain795 : accepts tree795 target795 = true ∧
    sourceLeaves tree795 = [1, 2, 2, 1] ∧
    target795.elements.length = 4 ∧
    [target795.elements.count 0, target795.elements.count 1,
      target795.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain795
def tree796 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))))
def target796 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain796 : accepts tree796 target796 = true ∧
    sourceLeaves tree796 = [1, 2, 2, 2] ∧
    target796.elements.length = 4 ∧
    [target796.elements.count 0, target796.elements.count 1,
      target796.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain796
def tree797 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)))
def target797 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain797 : accepts tree797 target797 = true ∧
    sourceLeaves tree797 = [1, 2, 2, 2] ∧
    target797.elements.length = 4 ∧
    [target797.elements.count 0, target797.elements.count 1,
      target797.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain797
def tree798 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 2)))
def target798 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain798 : accepts tree798 target798 = true ∧
    sourceLeaves tree798 = [1, 2, 2, 2] ∧
    target798.elements.length = 4 ∧
    [target798.elements.count 0, target798.elements.count 1,
      target798.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain798
def tree799 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 2))
def target799 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain799 : accepts tree799 target799 = true ∧
    sourceLeaves tree799 = [1, 2, 2, 2] ∧
    target799.elements.length = 4 ∧
    [target799.elements.count 0, target799.elements.count 1,
      target799.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain799
def tree800 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target800 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain800 : accepts tree800 target800 = true ∧
    sourceLeaves tree800 = [1, 2, 2, 2] ∧
    target800.elements.length = 4 ∧
    [target800.elements.count 0, target800.elements.count 1,
      target800.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain800
def tree801 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))))
def target801 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain801 : accepts tree801 target801 = true ∧
    sourceLeaves tree801 = [2, 0, 0, 0] ∧
    target801.elements.length = 4 ∧
    [target801.elements.count 0, target801.elements.count 1,
      target801.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain801
def tree802 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)))
def target802 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain802 : accepts tree802 target802 = true ∧
    sourceLeaves tree802 = [2, 0, 0, 0] ∧
    target802.elements.length = 4 ∧
    [target802.elements.count 0, target802.elements.count 1,
      target802.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain802
def tree803 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 0)))
def target803 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain803 : accepts tree803 target803 = true ∧
    sourceLeaves tree803 = [2, 0, 0, 0] ∧
    target803.elements.length = 4 ∧
    [target803.elements.count 0, target803.elements.count 1,
      target803.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain803
def tree804 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 0))
def target804 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain804 : accepts tree804 target804 = true ∧
    sourceLeaves tree804 = [2, 0, 0, 0] ∧
    target804.elements.length = 4 ∧
    [target804.elements.count 0, target804.elements.count 1,
      target804.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain804
def tree805 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target805 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain805 : accepts tree805 target805 = true ∧
    sourceLeaves tree805 = [2, 0, 0, 0] ∧
    target805.elements.length = 4 ∧
    [target805.elements.count 0, target805.elements.count 1,
      target805.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain805
def tree806 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))))
def target806 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain806 : accepts tree806 target806 = true ∧
    sourceLeaves tree806 = [2, 0, 0, 1] ∧
    target806.elements.length = 4 ∧
    [target806.elements.count 0, target806.elements.count 1,
      target806.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain806
def tree807 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)))
def target807 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain807 : accepts tree807 target807 = true ∧
    sourceLeaves tree807 = [2, 0, 0, 1] ∧
    target807.elements.length = 4 ∧
    [target807.elements.count 0, target807.elements.count 1,
      target807.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain807
def tree808 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 1)))
def target808 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain808 : accepts tree808 target808 = true ∧
    sourceLeaves tree808 = [2, 0, 0, 1] ∧
    target808.elements.length = 4 ∧
    [target808.elements.count 0, target808.elements.count 1,
      target808.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain808
def tree809 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 1))
def target809 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain809 : accepts tree809 target809 = true ∧
    sourceLeaves tree809 = [2, 0, 0, 1] ∧
    target809.elements.length = 4 ∧
    [target809.elements.count 0, target809.elements.count 1,
      target809.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain809
def tree810 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target810 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain810 : accepts tree810 target810 = true ∧
    sourceLeaves tree810 = [2, 0, 0, 1] ∧
    target810.elements.length = 4 ∧
    [target810.elements.count 0, target810.elements.count 1,
      target810.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain810
def tree811 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))))
def target811 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain811 : accepts tree811 target811 = true ∧
    sourceLeaves tree811 = [2, 0, 0, 2] ∧
    target811.elements.length = 4 ∧
    [target811.elements.count 0, target811.elements.count 1,
      target811.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain811
def tree812 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)))
def target812 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain812 : accepts tree812 target812 = true ∧
    sourceLeaves tree812 = [2, 0, 0, 2] ∧
    target812.elements.length = 4 ∧
    [target812.elements.count 0, target812.elements.count 1,
      target812.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain812
def tree813 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 2)))
def target813 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain813 : accepts tree813 target813 = true ∧
    sourceLeaves tree813 = [2, 0, 0, 2] ∧
    target813.elements.length = 4 ∧
    [target813.elements.count 0, target813.elements.count 1,
      target813.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain813
def tree814 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 2))
def target814 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain814 : accepts tree814 target814 = true ∧
    sourceLeaves tree814 = [2, 0, 0, 2] ∧
    target814.elements.length = 4 ∧
    [target814.elements.count 0, target814.elements.count 1,
      target814.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain814
def tree815 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target815 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain815 : accepts tree815 target815 = true ∧
    sourceLeaves tree815 = [2, 0, 0, 2] ∧
    target815.elements.length = 4 ∧
    [target815.elements.count 0, target815.elements.count 1,
      target815.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain815
def tree816 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))))
def target816 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain816 : accepts tree816 target816 = true ∧
    sourceLeaves tree816 = [2, 0, 1, 0] ∧
    target816.elements.length = 4 ∧
    [target816.elements.count 0, target816.elements.count 1,
      target816.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain816
def tree817 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)))
def target817 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain817 : accepts tree817 target817 = true ∧
    sourceLeaves tree817 = [2, 0, 1, 0] ∧
    target817.elements.length = 4 ∧
    [target817.elements.count 0, target817.elements.count 1,
      target817.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain817
def tree818 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 0)))
def target818 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain818 : accepts tree818 target818 = true ∧
    sourceLeaves tree818 = [2, 0, 1, 0] ∧
    target818.elements.length = 4 ∧
    [target818.elements.count 0, target818.elements.count 1,
      target818.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain818
def tree819 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 0))
def target819 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain819 : accepts tree819 target819 = true ∧
    sourceLeaves tree819 = [2, 0, 1, 0] ∧
    target819.elements.length = 4 ∧
    [target819.elements.count 0, target819.elements.count 1,
      target819.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain819
def tree820 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target820 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain820 : accepts tree820 target820 = true ∧
    sourceLeaves tree820 = [2, 0, 1, 0] ∧
    target820.elements.length = 4 ∧
    [target820.elements.count 0, target820.elements.count 1,
      target820.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain820
def tree821 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))))
def target821 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain821 : accepts tree821 target821 = true ∧
    sourceLeaves tree821 = [2, 0, 1, 1] ∧
    target821.elements.length = 4 ∧
    [target821.elements.count 0, target821.elements.count 1,
      target821.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain821
def tree822 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)))
def target822 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain822 : accepts tree822 target822 = true ∧
    sourceLeaves tree822 = [2, 0, 1, 1] ∧
    target822.elements.length = 4 ∧
    [target822.elements.count 0, target822.elements.count 1,
      target822.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain822
def tree823 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 1)))
def target823 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain823 : accepts tree823 target823 = true ∧
    sourceLeaves tree823 = [2, 0, 1, 1] ∧
    target823.elements.length = 4 ∧
    [target823.elements.count 0, target823.elements.count 1,
      target823.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain823
def tree824 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 1))
def target824 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain824 : accepts tree824 target824 = true ∧
    sourceLeaves tree824 = [2, 0, 1, 1] ∧
    target824.elements.length = 4 ∧
    [target824.elements.count 0, target824.elements.count 1,
      target824.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain824
def tree825 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target825 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain825 : accepts tree825 target825 = true ∧
    sourceLeaves tree825 = [2, 0, 1, 1] ∧
    target825.elements.length = 4 ∧
    [target825.elements.count 0, target825.elements.count 1,
      target825.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain825
def tree826 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))))
def target826 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain826 : accepts tree826 target826 = true ∧
    sourceLeaves tree826 = [2, 0, 1, 2] ∧
    target826.elements.length = 4 ∧
    [target826.elements.count 0, target826.elements.count 1,
      target826.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain826
def tree827 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)))
def target827 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain827 : accepts tree827 target827 = true ∧
    sourceLeaves tree827 = [2, 0, 1, 2] ∧
    target827.elements.length = 4 ∧
    [target827.elements.count 0, target827.elements.count 1,
      target827.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain827
def tree828 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 2)))
def target828 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain828 : accepts tree828 target828 = true ∧
    sourceLeaves tree828 = [2, 0, 1, 2] ∧
    target828.elements.length = 4 ∧
    [target828.elements.count 0, target828.elements.count 1,
      target828.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain828
def tree829 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 2))
def target829 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain829 : accepts tree829 target829 = true ∧
    sourceLeaves tree829 = [2, 0, 1, 2] ∧
    target829.elements.length = 4 ∧
    [target829.elements.count 0, target829.elements.count 1,
      target829.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain829
def tree830 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target830 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain830 : accepts tree830 target830 = true ∧
    sourceLeaves tree830 = [2, 0, 1, 2] ∧
    target830.elements.length = 4 ∧
    [target830.elements.count 0, target830.elements.count 1,
      target830.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain830
def tree831 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))))
def target831 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain831 : accepts tree831 target831 = true ∧
    sourceLeaves tree831 = [2, 0, 2, 0] ∧
    target831.elements.length = 4 ∧
    [target831.elements.count 0, target831.elements.count 1,
      target831.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain831
def tree832 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)))
def target832 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain832 : accepts tree832 target832 = true ∧
    sourceLeaves tree832 = [2, 0, 2, 0] ∧
    target832.elements.length = 4 ∧
    [target832.elements.count 0, target832.elements.count 1,
      target832.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain832
def tree833 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 0)))
def target833 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain833 : accepts tree833 target833 = true ∧
    sourceLeaves tree833 = [2, 0, 2, 0] ∧
    target833.elements.length = 4 ∧
    [target833.elements.count 0, target833.elements.count 1,
      target833.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain833
def tree834 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 0))
def target834 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain834 : accepts tree834 target834 = true ∧
    sourceLeaves tree834 = [2, 0, 2, 0] ∧
    target834.elements.length = 4 ∧
    [target834.elements.count 0, target834.elements.count 1,
      target834.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain834
def tree835 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target835 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain835 : accepts tree835 target835 = true ∧
    sourceLeaves tree835 = [2, 0, 2, 0] ∧
    target835.elements.length = 4 ∧
    [target835.elements.count 0, target835.elements.count 1,
      target835.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain835
def tree836 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))))
def target836 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain836 : accepts tree836 target836 = true ∧
    sourceLeaves tree836 = [2, 0, 2, 1] ∧
    target836.elements.length = 4 ∧
    [target836.elements.count 0, target836.elements.count 1,
      target836.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain836
def tree837 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)))
def target837 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain837 : accepts tree837 target837 = true ∧
    sourceLeaves tree837 = [2, 0, 2, 1] ∧
    target837.elements.length = 4 ∧
    [target837.elements.count 0, target837.elements.count 1,
      target837.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain837
def tree838 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 1)))
def target838 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain838 : accepts tree838 target838 = true ∧
    sourceLeaves tree838 = [2, 0, 2, 1] ∧
    target838.elements.length = 4 ∧
    [target838.elements.count 0, target838.elements.count 1,
      target838.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain838
def tree839 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 1))
def target839 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain839 : accepts tree839 target839 = true ∧
    sourceLeaves tree839 = [2, 0, 2, 1] ∧
    target839.elements.length = 4 ∧
    [target839.elements.count 0, target839.elements.count 1,
      target839.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain839
def tree840 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target840 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain840 : accepts tree840 target840 = true ∧
    sourceLeaves tree840 = [2, 0, 2, 1] ∧
    target840.elements.length = 4 ∧
    [target840.elements.count 0, target840.elements.count 1,
      target840.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain840
def tree841 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))))
def target841 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain841 : accepts tree841 target841 = true ∧
    sourceLeaves tree841 = [2, 0, 2, 2] ∧
    target841.elements.length = 4 ∧
    [target841.elements.count 0, target841.elements.count 1,
      target841.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain841
def tree842 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)))
def target842 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain842 : accepts tree842 target842 = true ∧
    sourceLeaves tree842 = [2, 0, 2, 2] ∧
    target842.elements.length = 4 ∧
    [target842.elements.count 0, target842.elements.count 1,
      target842.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain842
def tree843 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 2)))
def target843 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain843 : accepts tree843 target843 = true ∧
    sourceLeaves tree843 = [2, 0, 2, 2] ∧
    target843.elements.length = 4 ∧
    [target843.elements.count 0, target843.elements.count 1,
      target843.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain843
def tree844 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 2))
def target844 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain844 : accepts tree844 target844 = true ∧
    sourceLeaves tree844 = [2, 0, 2, 2] ∧
    target844.elements.length = 4 ∧
    [target844.elements.count 0, target844.elements.count 1,
      target844.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain844
def tree845 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target845 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain845 : accepts tree845 target845 = true ∧
    sourceLeaves tree845 = [2, 0, 2, 2] ∧
    target845.elements.length = 4 ∧
    [target845.elements.count 0, target845.elements.count 1,
      target845.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain845
def tree846 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))))
def target846 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain846 : accepts tree846 target846 = true ∧
    sourceLeaves tree846 = [2, 1, 0, 0] ∧
    target846.elements.length = 4 ∧
    [target846.elements.count 0, target846.elements.count 1,
      target846.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain846
def tree847 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)))
def target847 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain847 : accepts tree847 target847 = true ∧
    sourceLeaves tree847 = [2, 1, 0, 0] ∧
    target847.elements.length = 4 ∧
    [target847.elements.count 0, target847.elements.count 1,
      target847.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain847
def tree848 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 0)))
def target848 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain848 : accepts tree848 target848 = true ∧
    sourceLeaves tree848 = [2, 1, 0, 0] ∧
    target848.elements.length = 4 ∧
    [target848.elements.count 0, target848.elements.count 1,
      target848.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain848
def tree849 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 0))
def target849 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain849 : accepts tree849 target849 = true ∧
    sourceLeaves tree849 = [2, 1, 0, 0] ∧
    target849.elements.length = 4 ∧
    [target849.elements.count 0, target849.elements.count 1,
      target849.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain849
def tree850 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target850 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain850 : accepts tree850 target850 = true ∧
    sourceLeaves tree850 = [2, 1, 0, 0] ∧
    target850.elements.length = 4 ∧
    [target850.elements.count 0, target850.elements.count 1,
      target850.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain850
def tree851 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))))
def target851 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain851 : accepts tree851 target851 = true ∧
    sourceLeaves tree851 = [2, 1, 0, 1] ∧
    target851.elements.length = 4 ∧
    [target851.elements.count 0, target851.elements.count 1,
      target851.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain851
def tree852 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)))
def target852 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain852 : accepts tree852 target852 = true ∧
    sourceLeaves tree852 = [2, 1, 0, 1] ∧
    target852.elements.length = 4 ∧
    [target852.elements.count 0, target852.elements.count 1,
      target852.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain852
def tree853 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 1)))
def target853 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain853 : accepts tree853 target853 = true ∧
    sourceLeaves tree853 = [2, 1, 0, 1] ∧
    target853.elements.length = 4 ∧
    [target853.elements.count 0, target853.elements.count 1,
      target853.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain853
def tree854 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 1))
def target854 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain854 : accepts tree854 target854 = true ∧
    sourceLeaves tree854 = [2, 1, 0, 1] ∧
    target854.elements.length = 4 ∧
    [target854.elements.count 0, target854.elements.count 1,
      target854.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain854
def tree855 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target855 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain855 : accepts tree855 target855 = true ∧
    sourceLeaves tree855 = [2, 1, 0, 1] ∧
    target855.elements.length = 4 ∧
    [target855.elements.count 0, target855.elements.count 1,
      target855.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain855
def tree856 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))))
def target856 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain856 : accepts tree856 target856 = true ∧
    sourceLeaves tree856 = [2, 1, 0, 2] ∧
    target856.elements.length = 4 ∧
    [target856.elements.count 0, target856.elements.count 1,
      target856.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain856
def tree857 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)))
def target857 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain857 : accepts tree857 target857 = true ∧
    sourceLeaves tree857 = [2, 1, 0, 2] ∧
    target857.elements.length = 4 ∧
    [target857.elements.count 0, target857.elements.count 1,
      target857.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain857
def tree858 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 2)))
def target858 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain858 : accepts tree858 target858 = true ∧
    sourceLeaves tree858 = [2, 1, 0, 2] ∧
    target858.elements.length = 4 ∧
    [target858.elements.count 0, target858.elements.count 1,
      target858.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain858
def tree859 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 2))
def target859 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain859 : accepts tree859 target859 = true ∧
    sourceLeaves tree859 = [2, 1, 0, 2] ∧
    target859.elements.length = 4 ∧
    [target859.elements.count 0, target859.elements.count 1,
      target859.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain859
def tree860 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target860 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain860 : accepts tree860 target860 = true ∧
    sourceLeaves tree860 = [2, 1, 0, 2] ∧
    target860.elements.length = 4 ∧
    [target860.elements.count 0, target860.elements.count 1,
      target860.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain860
def tree861 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))))
def target861 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain861 : accepts tree861 target861 = true ∧
    sourceLeaves tree861 = [2, 1, 1, 0] ∧
    target861.elements.length = 4 ∧
    [target861.elements.count 0, target861.elements.count 1,
      target861.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain861
def tree862 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)))
def target862 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain862 : accepts tree862 target862 = true ∧
    sourceLeaves tree862 = [2, 1, 1, 0] ∧
    target862.elements.length = 4 ∧
    [target862.elements.count 0, target862.elements.count 1,
      target862.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain862
def tree863 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 0)))
def target863 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain863 : accepts tree863 target863 = true ∧
    sourceLeaves tree863 = [2, 1, 1, 0] ∧
    target863.elements.length = 4 ∧
    [target863.elements.count 0, target863.elements.count 1,
      target863.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain863
def tree864 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 0))
def target864 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain864 : accepts tree864 target864 = true ∧
    sourceLeaves tree864 = [2, 1, 1, 0] ∧
    target864.elements.length = 4 ∧
    [target864.elements.count 0, target864.elements.count 1,
      target864.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain864
def tree865 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target865 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain865 : accepts tree865 target865 = true ∧
    sourceLeaves tree865 = [2, 1, 1, 0] ∧
    target865.elements.length = 4 ∧
    [target865.elements.count 0, target865.elements.count 1,
      target865.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain865
def tree866 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))))
def target866 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain866 : accepts tree866 target866 = true ∧
    sourceLeaves tree866 = [2, 1, 1, 1] ∧
    target866.elements.length = 4 ∧
    [target866.elements.count 0, target866.elements.count 1,
      target866.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain866
def tree867 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)))
def target867 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain867 : accepts tree867 target867 = true ∧
    sourceLeaves tree867 = [2, 1, 1, 1] ∧
    target867.elements.length = 4 ∧
    [target867.elements.count 0, target867.elements.count 1,
      target867.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain867
def tree868 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 1)))
def target868 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain868 : accepts tree868 target868 = true ∧
    sourceLeaves tree868 = [2, 1, 1, 1] ∧
    target868.elements.length = 4 ∧
    [target868.elements.count 0, target868.elements.count 1,
      target868.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain868
def tree869 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 1))
def target869 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain869 : accepts tree869 target869 = true ∧
    sourceLeaves tree869 = [2, 1, 1, 1] ∧
    target869.elements.length = 4 ∧
    [target869.elements.count 0, target869.elements.count 1,
      target869.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain869
def tree870 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target870 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain870 : accepts tree870 target870 = true ∧
    sourceLeaves tree870 = [2, 1, 1, 1] ∧
    target870.elements.length = 4 ∧
    [target870.elements.count 0, target870.elements.count 1,
      target870.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain870
def tree871 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))))
def target871 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain871 : accepts tree871 target871 = true ∧
    sourceLeaves tree871 = [2, 1, 1, 2] ∧
    target871.elements.length = 4 ∧
    [target871.elements.count 0, target871.elements.count 1,
      target871.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain871
def tree872 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)))
def target872 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain872 : accepts tree872 target872 = true ∧
    sourceLeaves tree872 = [2, 1, 1, 2] ∧
    target872.elements.length = 4 ∧
    [target872.elements.count 0, target872.elements.count 1,
      target872.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain872
def tree873 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 2)))
def target873 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain873 : accepts tree873 target873 = true ∧
    sourceLeaves tree873 = [2, 1, 1, 2] ∧
    target873.elements.length = 4 ∧
    [target873.elements.count 0, target873.elements.count 1,
      target873.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain873
def tree874 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 2))
def target874 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain874 : accepts tree874 target874 = true ∧
    sourceLeaves tree874 = [2, 1, 1, 2] ∧
    target874.elements.length = 4 ∧
    [target874.elements.count 0, target874.elements.count 1,
      target874.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain874
def tree875 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target875 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain875 : accepts tree875 target875 = true ∧
    sourceLeaves tree875 = [2, 1, 1, 2] ∧
    target875.elements.length = 4 ∧
    [target875.elements.count 0, target875.elements.count 1,
      target875.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain875
def tree876 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))))
def target876 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain876 : accepts tree876 target876 = true ∧
    sourceLeaves tree876 = [2, 1, 2, 0] ∧
    target876.elements.length = 4 ∧
    [target876.elements.count 0, target876.elements.count 1,
      target876.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain876
def tree877 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)))
def target877 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain877 : accepts tree877 target877 = true ∧
    sourceLeaves tree877 = [2, 1, 2, 0] ∧
    target877.elements.length = 4 ∧
    [target877.elements.count 0, target877.elements.count 1,
      target877.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain877
def tree878 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 0)))
def target878 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain878 : accepts tree878 target878 = true ∧
    sourceLeaves tree878 = [2, 1, 2, 0] ∧
    target878.elements.length = 4 ∧
    [target878.elements.count 0, target878.elements.count 1,
      target878.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain878
def tree879 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 0))
def target879 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain879 : accepts tree879 target879 = true ∧
    sourceLeaves tree879 = [2, 1, 2, 0] ∧
    target879.elements.length = 4 ∧
    [target879.elements.count 0, target879.elements.count 1,
      target879.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain879
def tree880 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target880 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain880 : accepts tree880 target880 = true ∧
    sourceLeaves tree880 = [2, 1, 2, 0] ∧
    target880.elements.length = 4 ∧
    [target880.elements.count 0, target880.elements.count 1,
      target880.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain880
def tree881 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))))
def target881 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain881 : accepts tree881 target881 = true ∧
    sourceLeaves tree881 = [2, 1, 2, 1] ∧
    target881.elements.length = 4 ∧
    [target881.elements.count 0, target881.elements.count 1,
      target881.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain881
def tree882 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)))
def target882 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain882 : accepts tree882 target882 = true ∧
    sourceLeaves tree882 = [2, 1, 2, 1] ∧
    target882.elements.length = 4 ∧
    [target882.elements.count 0, target882.elements.count 1,
      target882.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain882
def tree883 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 1)))
def target883 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain883 : accepts tree883 target883 = true ∧
    sourceLeaves tree883 = [2, 1, 2, 1] ∧
    target883.elements.length = 4 ∧
    [target883.elements.count 0, target883.elements.count 1,
      target883.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain883
def tree884 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 1))
def target884 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain884 : accepts tree884 target884 = true ∧
    sourceLeaves tree884 = [2, 1, 2, 1] ∧
    target884.elements.length = 4 ∧
    [target884.elements.count 0, target884.elements.count 1,
      target884.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain884
def tree885 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target885 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain885 : accepts tree885 target885 = true ∧
    sourceLeaves tree885 = [2, 1, 2, 1] ∧
    target885.elements.length = 4 ∧
    [target885.elements.count 0, target885.elements.count 1,
      target885.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain885
def tree886 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))))
def target886 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain886 : accepts tree886 target886 = true ∧
    sourceLeaves tree886 = [2, 1, 2, 2] ∧
    target886.elements.length = 4 ∧
    [target886.elements.count 0, target886.elements.count 1,
      target886.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain886
def tree887 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)))
def target887 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain887 : accepts tree887 target887 = true ∧
    sourceLeaves tree887 = [2, 1, 2, 2] ∧
    target887.elements.length = 4 ∧
    [target887.elements.count 0, target887.elements.count 1,
      target887.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain887
def tree888 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 2)))
def target888 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain888 : accepts tree888 target888 = true ∧
    sourceLeaves tree888 = [2, 1, 2, 2] ∧
    target888.elements.length = 4 ∧
    [target888.elements.count 0, target888.elements.count 1,
      target888.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain888
def tree889 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 2))
def target889 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain889 : accepts tree889 target889 = true ∧
    sourceLeaves tree889 = [2, 1, 2, 2] ∧
    target889.elements.length = 4 ∧
    [target889.elements.count 0, target889.elements.count 1,
      target889.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain889
def tree890 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target890 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain890 : accepts tree890 target890 = true ∧
    sourceLeaves tree890 = [2, 1, 2, 2] ∧
    target890.elements.length = 4 ∧
    [target890.elements.count 0, target890.elements.count 1,
      target890.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain890
def tree891 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))))
def target891 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain891 : accepts tree891 target891 = true ∧
    sourceLeaves tree891 = [2, 2, 0, 0] ∧
    target891.elements.length = 4 ∧
    [target891.elements.count 0, target891.elements.count 1,
      target891.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain891
def tree892 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)))
def target892 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain892 : accepts tree892 target892 = true ∧
    sourceLeaves tree892 = [2, 2, 0, 0] ∧
    target892.elements.length = 4 ∧
    [target892.elements.count 0, target892.elements.count 1,
      target892.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain892
def tree893 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 0)))
def target893 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain893 : accepts tree893 target893 = true ∧
    sourceLeaves tree893 = [2, 2, 0, 0] ∧
    target893.elements.length = 4 ∧
    [target893.elements.count 0, target893.elements.count 1,
      target893.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain893
def tree894 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 0))
def target894 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain894 : accepts tree894 target894 = true ∧
    sourceLeaves tree894 = [2, 2, 0, 0] ∧
    target894.elements.length = 4 ∧
    [target894.elements.count 0, target894.elements.count 1,
      target894.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain894
def tree895 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target895 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain895 : accepts tree895 target895 = true ∧
    sourceLeaves tree895 = [2, 2, 0, 0] ∧
    target895.elements.length = 4 ∧
    [target895.elements.count 0, target895.elements.count 1,
      target895.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain895
def tree896 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))))
def target896 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain896 : accepts tree896 target896 = true ∧
    sourceLeaves tree896 = [2, 2, 0, 1] ∧
    target896.elements.length = 4 ∧
    [target896.elements.count 0, target896.elements.count 1,
      target896.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain896
def tree897 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)))
def target897 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain897 : accepts tree897 target897 = true ∧
    sourceLeaves tree897 = [2, 2, 0, 1] ∧
    target897.elements.length = 4 ∧
    [target897.elements.count 0, target897.elements.count 1,
      target897.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain897
def tree898 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 1)))
def target898 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain898 : accepts tree898 target898 = true ∧
    sourceLeaves tree898 = [2, 2, 0, 1] ∧
    target898.elements.length = 4 ∧
    [target898.elements.count 0, target898.elements.count 1,
      target898.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain898
def tree899 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 1))
def target899 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain899 : accepts tree899 target899 = true ∧
    sourceLeaves tree899 = [2, 2, 0, 1] ∧
    target899.elements.length = 4 ∧
    [target899.elements.count 0, target899.elements.count 1,
      target899.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain899
def tree900 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target900 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain900 : accepts tree900 target900 = true ∧
    sourceLeaves tree900 = [2, 2, 0, 1] ∧
    target900.elements.length = 4 ∧
    [target900.elements.count 0, target900.elements.count 1,
      target900.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain900
def tree901 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))))
def target901 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain901 : accepts tree901 target901 = true ∧
    sourceLeaves tree901 = [2, 2, 0, 2] ∧
    target901.elements.length = 4 ∧
    [target901.elements.count 0, target901.elements.count 1,
      target901.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain901
def tree902 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)))
def target902 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain902 : accepts tree902 target902 = true ∧
    sourceLeaves tree902 = [2, 2, 0, 2] ∧
    target902.elements.length = 4 ∧
    [target902.elements.count 0, target902.elements.count 1,
      target902.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain902
def tree903 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 2)))
def target903 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain903 : accepts tree903 target903 = true ∧
    sourceLeaves tree903 = [2, 2, 0, 2] ∧
    target903.elements.length = 4 ∧
    [target903.elements.count 0, target903.elements.count 1,
      target903.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain903
def tree904 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 2))
def target904 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain904 : accepts tree904 target904 = true ∧
    sourceLeaves tree904 = [2, 2, 0, 2] ∧
    target904.elements.length = 4 ∧
    [target904.elements.count 0, target904.elements.count 1,
      target904.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain904
def tree905 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target905 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain905 : accepts tree905 target905 = true ∧
    sourceLeaves tree905 = [2, 2, 0, 2] ∧
    target905.elements.length = 4 ∧
    [target905.elements.count 0, target905.elements.count 1,
      target905.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain905
def tree906 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))))
def target906 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain906 : accepts tree906 target906 = true ∧
    sourceLeaves tree906 = [2, 2, 1, 0] ∧
    target906.elements.length = 4 ∧
    [target906.elements.count 0, target906.elements.count 1,
      target906.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain906
def tree907 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)))
def target907 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain907 : accepts tree907 target907 = true ∧
    sourceLeaves tree907 = [2, 2, 1, 0] ∧
    target907.elements.length = 4 ∧
    [target907.elements.count 0, target907.elements.count 1,
      target907.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain907
def tree908 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 0)))
def target908 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain908 : accepts tree908 target908 = true ∧
    sourceLeaves tree908 = [2, 2, 1, 0] ∧
    target908.elements.length = 4 ∧
    [target908.elements.count 0, target908.elements.count 1,
      target908.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain908
def tree909 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 0))
def target909 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain909 : accepts tree909 target909 = true ∧
    sourceLeaves tree909 = [2, 2, 1, 0] ∧
    target909.elements.length = 4 ∧
    [target909.elements.count 0, target909.elements.count 1,
      target909.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain909
def tree910 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target910 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain910 : accepts tree910 target910 = true ∧
    sourceLeaves tree910 = [2, 2, 1, 0] ∧
    target910.elements.length = 4 ∧
    [target910.elements.count 0, target910.elements.count 1,
      target910.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain910
def tree911 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))))
def target911 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain911 : accepts tree911 target911 = true ∧
    sourceLeaves tree911 = [2, 2, 1, 1] ∧
    target911.elements.length = 4 ∧
    [target911.elements.count 0, target911.elements.count 1,
      target911.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain911
def tree912 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)))
def target912 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain912 : accepts tree912 target912 = true ∧
    sourceLeaves tree912 = [2, 2, 1, 1] ∧
    target912.elements.length = 4 ∧
    [target912.elements.count 0, target912.elements.count 1,
      target912.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain912
def tree913 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 1)))
def target913 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain913 : accepts tree913 target913 = true ∧
    sourceLeaves tree913 = [2, 2, 1, 1] ∧
    target913.elements.length = 4 ∧
    [target913.elements.count 0, target913.elements.count 1,
      target913.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain913
def tree914 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 1))
def target914 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain914 : accepts tree914 target914 = true ∧
    sourceLeaves tree914 = [2, 2, 1, 1] ∧
    target914.elements.length = 4 ∧
    [target914.elements.count 0, target914.elements.count 1,
      target914.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain914
def tree915 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target915 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain915 : accepts tree915 target915 = true ∧
    sourceLeaves tree915 = [2, 2, 1, 1] ∧
    target915.elements.length = 4 ∧
    [target915.elements.count 0, target915.elements.count 1,
      target915.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain915
def tree916 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))))
def target916 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain916 : accepts tree916 target916 = true ∧
    sourceLeaves tree916 = [2, 2, 1, 2] ∧
    target916.elements.length = 4 ∧
    [target916.elements.count 0, target916.elements.count 1,
      target916.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain916
def tree917 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)))
def target917 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain917 : accepts tree917 target917 = true ∧
    sourceLeaves tree917 = [2, 2, 1, 2] ∧
    target917.elements.length = 4 ∧
    [target917.elements.count 0, target917.elements.count 1,
      target917.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain917
def tree918 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 2)))
def target918 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain918 : accepts tree918 target918 = true ∧
    sourceLeaves tree918 = [2, 2, 1, 2] ∧
    target918.elements.length = 4 ∧
    [target918.elements.count 0, target918.elements.count 1,
      target918.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain918
def tree919 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 2))
def target919 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain919 : accepts tree919 target919 = true ∧
    sourceLeaves tree919 = [2, 2, 1, 2] ∧
    target919.elements.length = 4 ∧
    [target919.elements.count 0, target919.elements.count 1,
      target919.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain919
def tree920 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target920 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain920 : accepts tree920 target920 = true ∧
    sourceLeaves tree920 = [2, 2, 1, 2] ∧
    target920.elements.length = 4 ∧
    [target920.elements.count 0, target920.elements.count 1,
      target920.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain920
def tree921 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))))
def target921 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain921 : accepts tree921 target921 = true ∧
    sourceLeaves tree921 = [2, 2, 2, 0] ∧
    target921.elements.length = 4 ∧
    [target921.elements.count 0, target921.elements.count 1,
      target921.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain921
def tree922 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)))
def target922 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain922 : accepts tree922 target922 = true ∧
    sourceLeaves tree922 = [2, 2, 2, 0] ∧
    target922.elements.length = 4 ∧
    [target922.elements.count 0, target922.elements.count 1,
      target922.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain922
def tree923 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 0)))
def target923 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain923 : accepts tree923 target923 = true ∧
    sourceLeaves tree923 = [2, 2, 2, 0] ∧
    target923.elements.length = 4 ∧
    [target923.elements.count 0, target923.elements.count 1,
      target923.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain923
def tree924 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 0))
def target924 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain924 : accepts tree924 target924 = true ∧
    sourceLeaves tree924 = [2, 2, 2, 0] ∧
    target924.elements.length = 4 ∧
    [target924.elements.count 0, target924.elements.count 1,
      target924.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain924
def tree925 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target925 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain925 : accepts tree925 target925 = true ∧
    sourceLeaves tree925 = [2, 2, 2, 0] ∧
    target925.elements.length = 4 ∧
    [target925.elements.count 0, target925.elements.count 1,
      target925.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain925
def tree926 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))))
def target926 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain926 : accepts tree926 target926 = true ∧
    sourceLeaves tree926 = [2, 2, 2, 1] ∧
    target926.elements.length = 4 ∧
    [target926.elements.count 0, target926.elements.count 1,
      target926.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain926
def tree927 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)))
def target927 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain927 : accepts tree927 target927 = true ∧
    sourceLeaves tree927 = [2, 2, 2, 1] ∧
    target927.elements.length = 4 ∧
    [target927.elements.count 0, target927.elements.count 1,
      target927.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain927
def tree928 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 1)))
def target928 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain928 : accepts tree928 target928 = true ∧
    sourceLeaves tree928 = [2, 2, 2, 1] ∧
    target928.elements.length = 4 ∧
    [target928.elements.count 0, target928.elements.count 1,
      target928.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain928
def tree929 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 1))
def target929 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain929 : accepts tree929 target929 = true ∧
    sourceLeaves tree929 = [2, 2, 2, 1] ∧
    target929.elements.length = 4 ∧
    [target929.elements.count 0, target929.elements.count 1,
      target929.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain929
def tree930 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target930 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain930 : accepts tree930 target930 = true ∧
    sourceLeaves tree930 = [2, 2, 2, 1] ∧
    target930.elements.length = 4 ∧
    [target930.elements.count 0, target930.elements.count 1,
      target930.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain930
def tree931 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))))
def target931 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain931 : accepts tree931 target931 = true ∧
    sourceLeaves tree931 = [2, 2, 2, 2] ∧
    target931.elements.length = 4 ∧
    [target931.elements.count 0, target931.elements.count 1,
      target931.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain931
def tree932 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)))
def target932 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain932 : accepts tree932 target932 = true ∧
    sourceLeaves tree932 = [2, 2, 2, 2] ∧
    target932.elements.length = 4 ∧
    [target932.elements.count 0, target932.elements.count 1,
      target932.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain932
def tree933 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 2)))
def target933 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain933 : accepts tree933 target933 = true ∧
    sourceLeaves tree933 = [2, 2, 2, 2] ∧
    target933.elements.length = 4 ∧
    [target933.elements.count 0, target933.elements.count 1,
      target933.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain933
def tree934 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 2))
def target934 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain934 : accepts tree934 target934 = true ∧
    sourceLeaves tree934 = [2, 2, 2, 2] ∧
    target934.elements.length = 4 ∧
    [target934.elements.count 0, target934.elements.count 1,
      target934.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain934
def tree935 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target935 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain935 : accepts tree935 target935 = true ∧
    sourceLeaves tree935 = [2, 2, 2, 2] ∧
    target935.elements.length = 4 ∧
    [target935.elements.count 0, target935.elements.count 1,
      target935.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain935
def tree936 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 0))
def target936 : Target Nat := ⟨.seq, [0, 0]⟩
theorem chain936 : accepts tree936 target936 = true ∧
    sourceLeaves tree936 = [0, 0] ∧
    target936.elements.length = 2 ∧
    [target936.elements.count 0, target936.elements.count 1,
      target936.elements.count 2] = [2, 0, 0] := by decide
#print axioms chain936
def tree937 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def target937 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain937 : accepts tree937 target937 = true ∧
    sourceLeaves tree937 = [0, 1] ∧
    target937.elements.length = 2 ∧
    [target937.elements.count 0, target937.elements.count 1,
      target937.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain937
def tree938 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 2))
def target938 : Target Nat := ⟨.seq, [0, 2]⟩
theorem chain938 : accepts tree938 target938 = true ∧
    sourceLeaves tree938 = [0, 2] ∧
    target938.elements.length = 2 ∧
    [target938.elements.count 0, target938.elements.count 1,
      target938.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain938
def tree939 : SourceTree Nat .join := (.app .join (.leaf 1) (.leaf 0))
def target939 : Target Nat := ⟨.seq, [1, 0]⟩
theorem chain939 : accepts tree939 target939 = true ∧
    sourceLeaves tree939 = [1, 0] ∧
    target939.elements.length = 2 ∧
    [target939.elements.count 0, target939.elements.count 1,
      target939.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain939
def tree940 : SourceTree Nat .join := (.app .join (.leaf 1) (.leaf 1))
def target940 : Target Nat := ⟨.seq, [1, 1]⟩
theorem chain940 : accepts tree940 target940 = true ∧
    sourceLeaves tree940 = [1, 1] ∧
    target940.elements.length = 2 ∧
    [target940.elements.count 0, target940.elements.count 1,
      target940.elements.count 2] = [0, 2, 0] := by decide
#print axioms chain940
def tree941 : SourceTree Nat .join := (.app .join (.leaf 1) (.leaf 2))
def target941 : Target Nat := ⟨.seq, [1, 2]⟩
theorem chain941 : accepts tree941 target941 = true ∧
    sourceLeaves tree941 = [1, 2] ∧
    target941.elements.length = 2 ∧
    [target941.elements.count 0, target941.elements.count 1,
      target941.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain941
def tree942 : SourceTree Nat .join := (.app .join (.leaf 2) (.leaf 0))
def target942 : Target Nat := ⟨.seq, [2, 0]⟩
theorem chain942 : accepts tree942 target942 = true ∧
    sourceLeaves tree942 = [2, 0] ∧
    target942.elements.length = 2 ∧
    [target942.elements.count 0, target942.elements.count 1,
      target942.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain942
def tree943 : SourceTree Nat .join := (.app .join (.leaf 2) (.leaf 1))
def target943 : Target Nat := ⟨.seq, [2, 1]⟩
theorem chain943 : accepts tree943 target943 = true ∧
    sourceLeaves tree943 = [2, 1] ∧
    target943.elements.length = 2 ∧
    [target943.elements.count 0, target943.elements.count 1,
      target943.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain943
def tree944 : SourceTree Nat .join := (.app .join (.leaf 2) (.leaf 2))
def target944 : Target Nat := ⟨.seq, [2, 2]⟩
theorem chain944 : accepts tree944 target944 = true ∧
    sourceLeaves tree944 = [2, 2] ∧
    target944.elements.length = 2 ∧
    [target944.elements.count 0, target944.elements.count 1,
      target944.elements.count 2] = [0, 0, 2] := by decide
#print axioms chain944
def tree945 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0)))
def target945 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain945 : accepts tree945 target945 = true ∧
    sourceLeaves tree945 = [0, 0, 0] ∧
    target945.elements.length = 3 ∧
    [target945.elements.count 0, target945.elements.count 1,
      target945.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain945
def tree946 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0))
def target946 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain946 : accepts tree946 target946 = true ∧
    sourceLeaves tree946 = [0, 0, 0] ∧
    target946.elements.length = 3 ∧
    [target946.elements.count 0, target946.elements.count 1,
      target946.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain946
def tree947 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1)))
def target947 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain947 : accepts tree947 target947 = true ∧
    sourceLeaves tree947 = [0, 0, 1] ∧
    target947.elements.length = 3 ∧
    [target947.elements.count 0, target947.elements.count 1,
      target947.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain947
def tree948 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1))
def target948 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain948 : accepts tree948 target948 = true ∧
    sourceLeaves tree948 = [0, 0, 1] ∧
    target948.elements.length = 3 ∧
    [target948.elements.count 0, target948.elements.count 1,
      target948.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain948
def tree949 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2)))
def target949 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain949 : accepts tree949 target949 = true ∧
    sourceLeaves tree949 = [0, 0, 2] ∧
    target949.elements.length = 3 ∧
    [target949.elements.count 0, target949.elements.count 1,
      target949.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain949
def tree950 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2))
def target950 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain950 : accepts tree950 target950 = true ∧
    sourceLeaves tree950 = [0, 0, 2] ∧
    target950.elements.length = 3 ∧
    [target950.elements.count 0, target950.elements.count 1,
      target950.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain950
def tree951 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0)))
def target951 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain951 : accepts tree951 target951 = true ∧
    sourceLeaves tree951 = [0, 1, 0] ∧
    target951.elements.length = 3 ∧
    [target951.elements.count 0, target951.elements.count 1,
      target951.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain951
def tree952 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0))
def target952 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain952 : accepts tree952 target952 = true ∧
    sourceLeaves tree952 = [0, 1, 0] ∧
    target952.elements.length = 3 ∧
    [target952.elements.count 0, target952.elements.count 1,
      target952.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain952
def tree953 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1)))
def target953 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain953 : accepts tree953 target953 = true ∧
    sourceLeaves tree953 = [0, 1, 1] ∧
    target953.elements.length = 3 ∧
    [target953.elements.count 0, target953.elements.count 1,
      target953.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain953
def tree954 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1))
def target954 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain954 : accepts tree954 target954 = true ∧
    sourceLeaves tree954 = [0, 1, 1] ∧
    target954.elements.length = 3 ∧
    [target954.elements.count 0, target954.elements.count 1,
      target954.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain954
def tree955 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2)))
def target955 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain955 : accepts tree955 target955 = true ∧
    sourceLeaves tree955 = [0, 1, 2] ∧
    target955.elements.length = 3 ∧
    [target955.elements.count 0, target955.elements.count 1,
      target955.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain955
def tree956 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2))
def target956 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain956 : accepts tree956 target956 = true ∧
    sourceLeaves tree956 = [0, 1, 2] ∧
    target956.elements.length = 3 ∧
    [target956.elements.count 0, target956.elements.count 1,
      target956.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain956
def tree957 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0)))
def target957 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain957 : accepts tree957 target957 = true ∧
    sourceLeaves tree957 = [0, 2, 0] ∧
    target957.elements.length = 3 ∧
    [target957.elements.count 0, target957.elements.count 1,
      target957.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain957
def tree958 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0))
def target958 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain958 : accepts tree958 target958 = true ∧
    sourceLeaves tree958 = [0, 2, 0] ∧
    target958.elements.length = 3 ∧
    [target958.elements.count 0, target958.elements.count 1,
      target958.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain958
def tree959 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1)))
def target959 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain959 : accepts tree959 target959 = true ∧
    sourceLeaves tree959 = [0, 2, 1] ∧
    target959.elements.length = 3 ∧
    [target959.elements.count 0, target959.elements.count 1,
      target959.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain959
def tree960 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1))
def target960 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain960 : accepts tree960 target960 = true ∧
    sourceLeaves tree960 = [0, 2, 1] ∧
    target960.elements.length = 3 ∧
    [target960.elements.count 0, target960.elements.count 1,
      target960.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain960
def tree961 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2)))
def target961 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain961 : accepts tree961 target961 = true ∧
    sourceLeaves tree961 = [0, 2, 2] ∧
    target961.elements.length = 3 ∧
    [target961.elements.count 0, target961.elements.count 1,
      target961.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain961
def tree962 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2))
def target962 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain962 : accepts tree962 target962 = true ∧
    sourceLeaves tree962 = [0, 2, 2] ∧
    target962.elements.length = 3 ∧
    [target962.elements.count 0, target962.elements.count 1,
      target962.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain962
def tree963 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0)))
def target963 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain963 : accepts tree963 target963 = true ∧
    sourceLeaves tree963 = [1, 0, 0] ∧
    target963.elements.length = 3 ∧
    [target963.elements.count 0, target963.elements.count 1,
      target963.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain963
def tree964 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0))
def target964 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain964 : accepts tree964 target964 = true ∧
    sourceLeaves tree964 = [1, 0, 0] ∧
    target964.elements.length = 3 ∧
    [target964.elements.count 0, target964.elements.count 1,
      target964.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain964
def tree965 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1)))
def target965 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain965 : accepts tree965 target965 = true ∧
    sourceLeaves tree965 = [1, 0, 1] ∧
    target965.elements.length = 3 ∧
    [target965.elements.count 0, target965.elements.count 1,
      target965.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain965
def tree966 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1))
def target966 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain966 : accepts tree966 target966 = true ∧
    sourceLeaves tree966 = [1, 0, 1] ∧
    target966.elements.length = 3 ∧
    [target966.elements.count 0, target966.elements.count 1,
      target966.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain966
def tree967 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2)))
def target967 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain967 : accepts tree967 target967 = true ∧
    sourceLeaves tree967 = [1, 0, 2] ∧
    target967.elements.length = 3 ∧
    [target967.elements.count 0, target967.elements.count 1,
      target967.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain967
def tree968 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2))
def target968 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain968 : accepts tree968 target968 = true ∧
    sourceLeaves tree968 = [1, 0, 2] ∧
    target968.elements.length = 3 ∧
    [target968.elements.count 0, target968.elements.count 1,
      target968.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain968
def tree969 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0)))
def target969 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain969 : accepts tree969 target969 = true ∧
    sourceLeaves tree969 = [1, 1, 0] ∧
    target969.elements.length = 3 ∧
    [target969.elements.count 0, target969.elements.count 1,
      target969.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain969
def tree970 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0))
def target970 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain970 : accepts tree970 target970 = true ∧
    sourceLeaves tree970 = [1, 1, 0] ∧
    target970.elements.length = 3 ∧
    [target970.elements.count 0, target970.elements.count 1,
      target970.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain970
def tree971 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1)))
def target971 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain971 : accepts tree971 target971 = true ∧
    sourceLeaves tree971 = [1, 1, 1] ∧
    target971.elements.length = 3 ∧
    [target971.elements.count 0, target971.elements.count 1,
      target971.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain971
def tree972 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1))
def target972 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain972 : accepts tree972 target972 = true ∧
    sourceLeaves tree972 = [1, 1, 1] ∧
    target972.elements.length = 3 ∧
    [target972.elements.count 0, target972.elements.count 1,
      target972.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain972
def tree973 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2)))
def target973 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain973 : accepts tree973 target973 = true ∧
    sourceLeaves tree973 = [1, 1, 2] ∧
    target973.elements.length = 3 ∧
    [target973.elements.count 0, target973.elements.count 1,
      target973.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain973
def tree974 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2))
def target974 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain974 : accepts tree974 target974 = true ∧
    sourceLeaves tree974 = [1, 1, 2] ∧
    target974.elements.length = 3 ∧
    [target974.elements.count 0, target974.elements.count 1,
      target974.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain974
def tree975 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0)))
def target975 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain975 : accepts tree975 target975 = true ∧
    sourceLeaves tree975 = [1, 2, 0] ∧
    target975.elements.length = 3 ∧
    [target975.elements.count 0, target975.elements.count 1,
      target975.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain975
def tree976 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0))
def target976 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain976 : accepts tree976 target976 = true ∧
    sourceLeaves tree976 = [1, 2, 0] ∧
    target976.elements.length = 3 ∧
    [target976.elements.count 0, target976.elements.count 1,
      target976.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain976
def tree977 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1)))
def target977 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain977 : accepts tree977 target977 = true ∧
    sourceLeaves tree977 = [1, 2, 1] ∧
    target977.elements.length = 3 ∧
    [target977.elements.count 0, target977.elements.count 1,
      target977.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain977
def tree978 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1))
def target978 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain978 : accepts tree978 target978 = true ∧
    sourceLeaves tree978 = [1, 2, 1] ∧
    target978.elements.length = 3 ∧
    [target978.elements.count 0, target978.elements.count 1,
      target978.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain978
def tree979 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2)))
def target979 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain979 : accepts tree979 target979 = true ∧
    sourceLeaves tree979 = [1, 2, 2] ∧
    target979.elements.length = 3 ∧
    [target979.elements.count 0, target979.elements.count 1,
      target979.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain979
def tree980 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2))
def target980 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain980 : accepts tree980 target980 = true ∧
    sourceLeaves tree980 = [1, 2, 2] ∧
    target980.elements.length = 3 ∧
    [target980.elements.count 0, target980.elements.count 1,
      target980.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain980
def tree981 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0)))
def target981 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain981 : accepts tree981 target981 = true ∧
    sourceLeaves tree981 = [2, 0, 0] ∧
    target981.elements.length = 3 ∧
    [target981.elements.count 0, target981.elements.count 1,
      target981.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain981
def tree982 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0))
def target982 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain982 : accepts tree982 target982 = true ∧
    sourceLeaves tree982 = [2, 0, 0] ∧
    target982.elements.length = 3 ∧
    [target982.elements.count 0, target982.elements.count 1,
      target982.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain982
def tree983 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1)))
def target983 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain983 : accepts tree983 target983 = true ∧
    sourceLeaves tree983 = [2, 0, 1] ∧
    target983.elements.length = 3 ∧
    [target983.elements.count 0, target983.elements.count 1,
      target983.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain983
def tree984 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1))
def target984 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain984 : accepts tree984 target984 = true ∧
    sourceLeaves tree984 = [2, 0, 1] ∧
    target984.elements.length = 3 ∧
    [target984.elements.count 0, target984.elements.count 1,
      target984.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain984
def tree985 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2)))
def target985 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain985 : accepts tree985 target985 = true ∧
    sourceLeaves tree985 = [2, 0, 2] ∧
    target985.elements.length = 3 ∧
    [target985.elements.count 0, target985.elements.count 1,
      target985.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain985
def tree986 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2))
def target986 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain986 : accepts tree986 target986 = true ∧
    sourceLeaves tree986 = [2, 0, 2] ∧
    target986.elements.length = 3 ∧
    [target986.elements.count 0, target986.elements.count 1,
      target986.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain986
def tree987 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0)))
def target987 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain987 : accepts tree987 target987 = true ∧
    sourceLeaves tree987 = [2, 1, 0] ∧
    target987.elements.length = 3 ∧
    [target987.elements.count 0, target987.elements.count 1,
      target987.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain987
def tree988 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0))
def target988 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain988 : accepts tree988 target988 = true ∧
    sourceLeaves tree988 = [2, 1, 0] ∧
    target988.elements.length = 3 ∧
    [target988.elements.count 0, target988.elements.count 1,
      target988.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain988
def tree989 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1)))
def target989 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain989 : accepts tree989 target989 = true ∧
    sourceLeaves tree989 = [2, 1, 1] ∧
    target989.elements.length = 3 ∧
    [target989.elements.count 0, target989.elements.count 1,
      target989.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain989
def tree990 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1))
def target990 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain990 : accepts tree990 target990 = true ∧
    sourceLeaves tree990 = [2, 1, 1] ∧
    target990.elements.length = 3 ∧
    [target990.elements.count 0, target990.elements.count 1,
      target990.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain990
def tree991 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2)))
def target991 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain991 : accepts tree991 target991 = true ∧
    sourceLeaves tree991 = [2, 1, 2] ∧
    target991.elements.length = 3 ∧
    [target991.elements.count 0, target991.elements.count 1,
      target991.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain991
def tree992 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2))
def target992 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain992 : accepts tree992 target992 = true ∧
    sourceLeaves tree992 = [2, 1, 2] ∧
    target992.elements.length = 3 ∧
    [target992.elements.count 0, target992.elements.count 1,
      target992.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain992
def tree993 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0)))
def target993 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain993 : accepts tree993 target993 = true ∧
    sourceLeaves tree993 = [2, 2, 0] ∧
    target993.elements.length = 3 ∧
    [target993.elements.count 0, target993.elements.count 1,
      target993.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain993
def tree994 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0))
def target994 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain994 : accepts tree994 target994 = true ∧
    sourceLeaves tree994 = [2, 2, 0] ∧
    target994.elements.length = 3 ∧
    [target994.elements.count 0, target994.elements.count 1,
      target994.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain994
def tree995 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1)))
def target995 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain995 : accepts tree995 target995 = true ∧
    sourceLeaves tree995 = [2, 2, 1] ∧
    target995.elements.length = 3 ∧
    [target995.elements.count 0, target995.elements.count 1,
      target995.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain995
def tree996 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1))
def target996 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain996 : accepts tree996 target996 = true ∧
    sourceLeaves tree996 = [2, 2, 1] ∧
    target996.elements.length = 3 ∧
    [target996.elements.count 0, target996.elements.count 1,
      target996.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain996
def tree997 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2)))
def target997 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain997 : accepts tree997 target997 = true ∧
    sourceLeaves tree997 = [2, 2, 2] ∧
    target997.elements.length = 3 ∧
    [target997.elements.count 0, target997.elements.count 1,
      target997.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain997
def tree998 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2))
def target998 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain998 : accepts tree998 target998 = true ∧
    sourceLeaves tree998 = [2, 2, 2] ∧
    target998.elements.length = 3 ∧
    [target998.elements.count 0, target998.elements.count 1,
      target998.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain998
def tree999 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))))
def target999 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain999 : accepts tree999 target999 = true ∧
    sourceLeaves tree999 = [0, 0, 0, 0] ∧
    target999.elements.length = 4 ∧
    [target999.elements.count 0, target999.elements.count 1,
      target999.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain999
def tree1000 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)))
def target1000 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1000 : accepts tree1000 target1000 = true ∧
    sourceLeaves tree1000 = [0, 0, 0, 0] ∧
    target1000.elements.length = 4 ∧
    [target1000.elements.count 0, target1000.elements.count 1,
      target1000.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1000
def tree1001 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 0) (.leaf 0)))
def target1001 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1001 : accepts tree1001 target1001 = true ∧
    sourceLeaves tree1001 = [0, 0, 0, 0] ∧
    target1001.elements.length = 4 ∧
    [target1001.elements.count 0, target1001.elements.count 1,
      target1001.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1001
def tree1002 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))) (.leaf 0))
def target1002 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1002 : accepts tree1002 target1002 = true ∧
    sourceLeaves tree1002 = [0, 0, 0, 0] ∧
    target1002.elements.length = 4 ∧
    [target1002.elements.count 0, target1002.elements.count 1,
      target1002.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1002
def tree1003 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target1003 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1003 : accepts tree1003 target1003 = true ∧
    sourceLeaves tree1003 = [0, 0, 0, 0] ∧
    target1003.elements.length = 4 ∧
    [target1003.elements.count 0, target1003.elements.count 1,
      target1003.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1003
def tree1004 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))))
def target1004 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1004 : accepts tree1004 target1004 = true ∧
    sourceLeaves tree1004 = [0, 0, 0, 1] ∧
    target1004.elements.length = 4 ∧
    [target1004.elements.count 0, target1004.elements.count 1,
      target1004.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1004
def tree1005 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)))
def target1005 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1005 : accepts tree1005 target1005 = true ∧
    sourceLeaves tree1005 = [0, 0, 0, 1] ∧
    target1005.elements.length = 4 ∧
    [target1005.elements.count 0, target1005.elements.count 1,
      target1005.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1005
def tree1006 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 0) (.leaf 1)))
def target1006 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1006 : accepts tree1006 target1006 = true ∧
    sourceLeaves tree1006 = [0, 0, 0, 1] ∧
    target1006.elements.length = 4 ∧
    [target1006.elements.count 0, target1006.elements.count 1,
      target1006.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1006
def tree1007 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))) (.leaf 1))
def target1007 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1007 : accepts tree1007 target1007 = true ∧
    sourceLeaves tree1007 = [0, 0, 0, 1] ∧
    target1007.elements.length = 4 ∧
    [target1007.elements.count 0, target1007.elements.count 1,
      target1007.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1007
def tree1008 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target1008 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1008 : accepts tree1008 target1008 = true ∧
    sourceLeaves tree1008 = [0, 0, 0, 1] ∧
    target1008.elements.length = 4 ∧
    [target1008.elements.count 0, target1008.elements.count 1,
      target1008.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1008
def tree1009 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))))
def target1009 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1009 : accepts tree1009 target1009 = true ∧
    sourceLeaves tree1009 = [0, 0, 0, 2] ∧
    target1009.elements.length = 4 ∧
    [target1009.elements.count 0, target1009.elements.count 1,
      target1009.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1009
def tree1010 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)))
def target1010 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1010 : accepts tree1010 target1010 = true ∧
    sourceLeaves tree1010 = [0, 0, 0, 2] ∧
    target1010.elements.length = 4 ∧
    [target1010.elements.count 0, target1010.elements.count 1,
      target1010.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1010
def tree1011 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 0) (.leaf 2)))
def target1011 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1011 : accepts tree1011 target1011 = true ∧
    sourceLeaves tree1011 = [0, 0, 0, 2] ∧
    target1011.elements.length = 4 ∧
    [target1011.elements.count 0, target1011.elements.count 1,
      target1011.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1011
def tree1012 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))) (.leaf 2))
def target1012 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1012 : accepts tree1012 target1012 = true ∧
    sourceLeaves tree1012 = [0, 0, 0, 2] ∧
    target1012.elements.length = 4 ∧
    [target1012.elements.count 0, target1012.elements.count 1,
      target1012.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1012
def tree1013 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target1013 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1013 : accepts tree1013 target1013 = true ∧
    sourceLeaves tree1013 = [0, 0, 0, 2] ∧
    target1013.elements.length = 4 ∧
    [target1013.elements.count 0, target1013.elements.count 1,
      target1013.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1013
def tree1014 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))))
def target1014 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1014 : accepts tree1014 target1014 = true ∧
    sourceLeaves tree1014 = [0, 0, 1, 0] ∧
    target1014.elements.length = 4 ∧
    [target1014.elements.count 0, target1014.elements.count 1,
      target1014.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1014
def tree1015 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)))
def target1015 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1015 : accepts tree1015 target1015 = true ∧
    sourceLeaves tree1015 = [0, 0, 1, 0] ∧
    target1015.elements.length = 4 ∧
    [target1015.elements.count 0, target1015.elements.count 1,
      target1015.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1015
def tree1016 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 1) (.leaf 0)))
def target1016 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1016 : accepts tree1016 target1016 = true ∧
    sourceLeaves tree1016 = [0, 0, 1, 0] ∧
    target1016.elements.length = 4 ∧
    [target1016.elements.count 0, target1016.elements.count 1,
      target1016.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1016
def tree1017 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))) (.leaf 0))
def target1017 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1017 : accepts tree1017 target1017 = true ∧
    sourceLeaves tree1017 = [0, 0, 1, 0] ∧
    target1017.elements.length = 4 ∧
    [target1017.elements.count 0, target1017.elements.count 1,
      target1017.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1017
def tree1018 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target1018 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1018 : accepts tree1018 target1018 = true ∧
    sourceLeaves tree1018 = [0, 0, 1, 0] ∧
    target1018.elements.length = 4 ∧
    [target1018.elements.count 0, target1018.elements.count 1,
      target1018.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1018
def tree1019 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))))
def target1019 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1019 : accepts tree1019 target1019 = true ∧
    sourceLeaves tree1019 = [0, 0, 1, 1] ∧
    target1019.elements.length = 4 ∧
    [target1019.elements.count 0, target1019.elements.count 1,
      target1019.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1019
def tree1020 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)))
def target1020 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1020 : accepts tree1020 target1020 = true ∧
    sourceLeaves tree1020 = [0, 0, 1, 1] ∧
    target1020.elements.length = 4 ∧
    [target1020.elements.count 0, target1020.elements.count 1,
      target1020.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1020
def tree1021 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 1) (.leaf 1)))
def target1021 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1021 : accepts tree1021 target1021 = true ∧
    sourceLeaves tree1021 = [0, 0, 1, 1] ∧
    target1021.elements.length = 4 ∧
    [target1021.elements.count 0, target1021.elements.count 1,
      target1021.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1021
def tree1022 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))) (.leaf 1))
def target1022 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1022 : accepts tree1022 target1022 = true ∧
    sourceLeaves tree1022 = [0, 0, 1, 1] ∧
    target1022.elements.length = 4 ∧
    [target1022.elements.count 0, target1022.elements.count 1,
      target1022.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1022
def tree1023 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target1023 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1023 : accepts tree1023 target1023 = true ∧
    sourceLeaves tree1023 = [0, 0, 1, 1] ∧
    target1023.elements.length = 4 ∧
    [target1023.elements.count 0, target1023.elements.count 1,
      target1023.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1023
def tree1024 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))))
def target1024 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1024 : accepts tree1024 target1024 = true ∧
    sourceLeaves tree1024 = [0, 0, 1, 2] ∧
    target1024.elements.length = 4 ∧
    [target1024.elements.count 0, target1024.elements.count 1,
      target1024.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1024
def tree1025 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)))
def target1025 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1025 : accepts tree1025 target1025 = true ∧
    sourceLeaves tree1025 = [0, 0, 1, 2] ∧
    target1025.elements.length = 4 ∧
    [target1025.elements.count 0, target1025.elements.count 1,
      target1025.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1025
def tree1026 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 1) (.leaf 2)))
def target1026 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1026 : accepts tree1026 target1026 = true ∧
    sourceLeaves tree1026 = [0, 0, 1, 2] ∧
    target1026.elements.length = 4 ∧
    [target1026.elements.count 0, target1026.elements.count 1,
      target1026.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1026
def tree1027 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))) (.leaf 2))
def target1027 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1027 : accepts tree1027 target1027 = true ∧
    sourceLeaves tree1027 = [0, 0, 1, 2] ∧
    target1027.elements.length = 4 ∧
    [target1027.elements.count 0, target1027.elements.count 1,
      target1027.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1027
def tree1028 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target1028 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1028 : accepts tree1028 target1028 = true ∧
    sourceLeaves tree1028 = [0, 0, 1, 2] ∧
    target1028.elements.length = 4 ∧
    [target1028.elements.count 0, target1028.elements.count 1,
      target1028.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1028
def tree1029 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))))
def target1029 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1029 : accepts tree1029 target1029 = true ∧
    sourceLeaves tree1029 = [0, 0, 2, 0] ∧
    target1029.elements.length = 4 ∧
    [target1029.elements.count 0, target1029.elements.count 1,
      target1029.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1029
def tree1030 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)))
def target1030 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1030 : accepts tree1030 target1030 = true ∧
    sourceLeaves tree1030 = [0, 0, 2, 0] ∧
    target1030.elements.length = 4 ∧
    [target1030.elements.count 0, target1030.elements.count 1,
      target1030.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1030
def tree1031 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 2) (.leaf 0)))
def target1031 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1031 : accepts tree1031 target1031 = true ∧
    sourceLeaves tree1031 = [0, 0, 2, 0] ∧
    target1031.elements.length = 4 ∧
    [target1031.elements.count 0, target1031.elements.count 1,
      target1031.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1031
def tree1032 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))) (.leaf 0))
def target1032 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1032 : accepts tree1032 target1032 = true ∧
    sourceLeaves tree1032 = [0, 0, 2, 0] ∧
    target1032.elements.length = 4 ∧
    [target1032.elements.count 0, target1032.elements.count 1,
      target1032.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1032
def tree1033 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target1033 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1033 : accepts tree1033 target1033 = true ∧
    sourceLeaves tree1033 = [0, 0, 2, 0] ∧
    target1033.elements.length = 4 ∧
    [target1033.elements.count 0, target1033.elements.count 1,
      target1033.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1033
def tree1034 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))))
def target1034 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1034 : accepts tree1034 target1034 = true ∧
    sourceLeaves tree1034 = [0, 0, 2, 1] ∧
    target1034.elements.length = 4 ∧
    [target1034.elements.count 0, target1034.elements.count 1,
      target1034.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1034
def tree1035 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)))
def target1035 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1035 : accepts tree1035 target1035 = true ∧
    sourceLeaves tree1035 = [0, 0, 2, 1] ∧
    target1035.elements.length = 4 ∧
    [target1035.elements.count 0, target1035.elements.count 1,
      target1035.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1035
def tree1036 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 2) (.leaf 1)))
def target1036 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1036 : accepts tree1036 target1036 = true ∧
    sourceLeaves tree1036 = [0, 0, 2, 1] ∧
    target1036.elements.length = 4 ∧
    [target1036.elements.count 0, target1036.elements.count 1,
      target1036.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1036
def tree1037 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))) (.leaf 1))
def target1037 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1037 : accepts tree1037 target1037 = true ∧
    sourceLeaves tree1037 = [0, 0, 2, 1] ∧
    target1037.elements.length = 4 ∧
    [target1037.elements.count 0, target1037.elements.count 1,
      target1037.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1037
def tree1038 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target1038 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1038 : accepts tree1038 target1038 = true ∧
    sourceLeaves tree1038 = [0, 0, 2, 1] ∧
    target1038.elements.length = 4 ∧
    [target1038.elements.count 0, target1038.elements.count 1,
      target1038.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1038
def tree1039 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))))
def target1039 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1039 : accepts tree1039 target1039 = true ∧
    sourceLeaves tree1039 = [0, 0, 2, 2] ∧
    target1039.elements.length = 4 ∧
    [target1039.elements.count 0, target1039.elements.count 1,
      target1039.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1039
def tree1040 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)))
def target1040 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1040 : accepts tree1040 target1040 = true ∧
    sourceLeaves tree1040 = [0, 0, 2, 2] ∧
    target1040.elements.length = 4 ∧
    [target1040.elements.count 0, target1040.elements.count 1,
      target1040.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1040
def tree1041 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 0)) (.app .join (.leaf 2) (.leaf 2)))
def target1041 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1041 : accepts tree1041 target1041 = true ∧
    sourceLeaves tree1041 = [0, 0, 2, 2] ∧
    target1041.elements.length = 4 ∧
    [target1041.elements.count 0, target1041.elements.count 1,
      target1041.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1041
def tree1042 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))) (.leaf 2))
def target1042 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1042 : accepts tree1042 target1042 = true ∧
    sourceLeaves tree1042 = [0, 0, 2, 2] ∧
    target1042.elements.length = 4 ∧
    [target1042.elements.count 0, target1042.elements.count 1,
      target1042.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1042
def tree1043 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target1043 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1043 : accepts tree1043 target1043 = true ∧
    sourceLeaves tree1043 = [0, 0, 2, 2] ∧
    target1043.elements.length = 4 ∧
    [target1043.elements.count 0, target1043.elements.count 1,
      target1043.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1043
def tree1044 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))))
def target1044 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1044 : accepts tree1044 target1044 = true ∧
    sourceLeaves tree1044 = [0, 1, 0, 0] ∧
    target1044.elements.length = 4 ∧
    [target1044.elements.count 0, target1044.elements.count 1,
      target1044.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1044
def tree1045 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)))
def target1045 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1045 : accepts tree1045 target1045 = true ∧
    sourceLeaves tree1045 = [0, 1, 0, 0] ∧
    target1045.elements.length = 4 ∧
    [target1045.elements.count 0, target1045.elements.count 1,
      target1045.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1045
def tree1046 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 0) (.leaf 0)))
def target1046 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1046 : accepts tree1046 target1046 = true ∧
    sourceLeaves tree1046 = [0, 1, 0, 0] ∧
    target1046.elements.length = 4 ∧
    [target1046.elements.count 0, target1046.elements.count 1,
      target1046.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1046
def tree1047 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))) (.leaf 0))
def target1047 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1047 : accepts tree1047 target1047 = true ∧
    sourceLeaves tree1047 = [0, 1, 0, 0] ∧
    target1047.elements.length = 4 ∧
    [target1047.elements.count 0, target1047.elements.count 1,
      target1047.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1047
def tree1048 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target1048 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1048 : accepts tree1048 target1048 = true ∧
    sourceLeaves tree1048 = [0, 1, 0, 0] ∧
    target1048.elements.length = 4 ∧
    [target1048.elements.count 0, target1048.elements.count 1,
      target1048.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1048
def tree1049 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))))
def target1049 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1049 : accepts tree1049 target1049 = true ∧
    sourceLeaves tree1049 = [0, 1, 0, 1] ∧
    target1049.elements.length = 4 ∧
    [target1049.elements.count 0, target1049.elements.count 1,
      target1049.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1049
def tree1050 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)))
def target1050 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1050 : accepts tree1050 target1050 = true ∧
    sourceLeaves tree1050 = [0, 1, 0, 1] ∧
    target1050.elements.length = 4 ∧
    [target1050.elements.count 0, target1050.elements.count 1,
      target1050.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1050
def tree1051 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 0) (.leaf 1)))
def target1051 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1051 : accepts tree1051 target1051 = true ∧
    sourceLeaves tree1051 = [0, 1, 0, 1] ∧
    target1051.elements.length = 4 ∧
    [target1051.elements.count 0, target1051.elements.count 1,
      target1051.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1051
def tree1052 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))) (.leaf 1))
def target1052 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1052 : accepts tree1052 target1052 = true ∧
    sourceLeaves tree1052 = [0, 1, 0, 1] ∧
    target1052.elements.length = 4 ∧
    [target1052.elements.count 0, target1052.elements.count 1,
      target1052.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1052
def tree1053 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target1053 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1053 : accepts tree1053 target1053 = true ∧
    sourceLeaves tree1053 = [0, 1, 0, 1] ∧
    target1053.elements.length = 4 ∧
    [target1053.elements.count 0, target1053.elements.count 1,
      target1053.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1053
def tree1054 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))))
def target1054 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1054 : accepts tree1054 target1054 = true ∧
    sourceLeaves tree1054 = [0, 1, 0, 2] ∧
    target1054.elements.length = 4 ∧
    [target1054.elements.count 0, target1054.elements.count 1,
      target1054.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1054
def tree1055 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)))
def target1055 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1055 : accepts tree1055 target1055 = true ∧
    sourceLeaves tree1055 = [0, 1, 0, 2] ∧
    target1055.elements.length = 4 ∧
    [target1055.elements.count 0, target1055.elements.count 1,
      target1055.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1055
def tree1056 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 0) (.leaf 2)))
def target1056 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1056 : accepts tree1056 target1056 = true ∧
    sourceLeaves tree1056 = [0, 1, 0, 2] ∧
    target1056.elements.length = 4 ∧
    [target1056.elements.count 0, target1056.elements.count 1,
      target1056.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1056
def tree1057 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))) (.leaf 2))
def target1057 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1057 : accepts tree1057 target1057 = true ∧
    sourceLeaves tree1057 = [0, 1, 0, 2] ∧
    target1057.elements.length = 4 ∧
    [target1057.elements.count 0, target1057.elements.count 1,
      target1057.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1057
def tree1058 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target1058 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1058 : accepts tree1058 target1058 = true ∧
    sourceLeaves tree1058 = [0, 1, 0, 2] ∧
    target1058.elements.length = 4 ∧
    [target1058.elements.count 0, target1058.elements.count 1,
      target1058.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1058
def tree1059 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))))
def target1059 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1059 : accepts tree1059 target1059 = true ∧
    sourceLeaves tree1059 = [0, 1, 1, 0] ∧
    target1059.elements.length = 4 ∧
    [target1059.elements.count 0, target1059.elements.count 1,
      target1059.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1059
def tree1060 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)))
def target1060 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1060 : accepts tree1060 target1060 = true ∧
    sourceLeaves tree1060 = [0, 1, 1, 0] ∧
    target1060.elements.length = 4 ∧
    [target1060.elements.count 0, target1060.elements.count 1,
      target1060.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1060
def tree1061 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 1) (.leaf 0)))
def target1061 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1061 : accepts tree1061 target1061 = true ∧
    sourceLeaves tree1061 = [0, 1, 1, 0] ∧
    target1061.elements.length = 4 ∧
    [target1061.elements.count 0, target1061.elements.count 1,
      target1061.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1061
def tree1062 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))) (.leaf 0))
def target1062 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1062 : accepts tree1062 target1062 = true ∧
    sourceLeaves tree1062 = [0, 1, 1, 0] ∧
    target1062.elements.length = 4 ∧
    [target1062.elements.count 0, target1062.elements.count 1,
      target1062.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1062
def tree1063 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target1063 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1063 : accepts tree1063 target1063 = true ∧
    sourceLeaves tree1063 = [0, 1, 1, 0] ∧
    target1063.elements.length = 4 ∧
    [target1063.elements.count 0, target1063.elements.count 1,
      target1063.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1063
def tree1064 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))))
def target1064 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1064 : accepts tree1064 target1064 = true ∧
    sourceLeaves tree1064 = [0, 1, 1, 1] ∧
    target1064.elements.length = 4 ∧
    [target1064.elements.count 0, target1064.elements.count 1,
      target1064.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1064
def tree1065 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)))
def target1065 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1065 : accepts tree1065 target1065 = true ∧
    sourceLeaves tree1065 = [0, 1, 1, 1] ∧
    target1065.elements.length = 4 ∧
    [target1065.elements.count 0, target1065.elements.count 1,
      target1065.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1065
def tree1066 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 1) (.leaf 1)))
def target1066 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1066 : accepts tree1066 target1066 = true ∧
    sourceLeaves tree1066 = [0, 1, 1, 1] ∧
    target1066.elements.length = 4 ∧
    [target1066.elements.count 0, target1066.elements.count 1,
      target1066.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1066
def tree1067 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))) (.leaf 1))
def target1067 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1067 : accepts tree1067 target1067 = true ∧
    sourceLeaves tree1067 = [0, 1, 1, 1] ∧
    target1067.elements.length = 4 ∧
    [target1067.elements.count 0, target1067.elements.count 1,
      target1067.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1067
def tree1068 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target1068 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1068 : accepts tree1068 target1068 = true ∧
    sourceLeaves tree1068 = [0, 1, 1, 1] ∧
    target1068.elements.length = 4 ∧
    [target1068.elements.count 0, target1068.elements.count 1,
      target1068.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1068
def tree1069 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))))
def target1069 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1069 : accepts tree1069 target1069 = true ∧
    sourceLeaves tree1069 = [0, 1, 1, 2] ∧
    target1069.elements.length = 4 ∧
    [target1069.elements.count 0, target1069.elements.count 1,
      target1069.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1069
def tree1070 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)))
def target1070 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1070 : accepts tree1070 target1070 = true ∧
    sourceLeaves tree1070 = [0, 1, 1, 2] ∧
    target1070.elements.length = 4 ∧
    [target1070.elements.count 0, target1070.elements.count 1,
      target1070.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1070
def tree1071 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 1) (.leaf 2)))
def target1071 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1071 : accepts tree1071 target1071 = true ∧
    sourceLeaves tree1071 = [0, 1, 1, 2] ∧
    target1071.elements.length = 4 ∧
    [target1071.elements.count 0, target1071.elements.count 1,
      target1071.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1071
def tree1072 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))) (.leaf 2))
def target1072 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1072 : accepts tree1072 target1072 = true ∧
    sourceLeaves tree1072 = [0, 1, 1, 2] ∧
    target1072.elements.length = 4 ∧
    [target1072.elements.count 0, target1072.elements.count 1,
      target1072.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1072
def tree1073 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target1073 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1073 : accepts tree1073 target1073 = true ∧
    sourceLeaves tree1073 = [0, 1, 1, 2] ∧
    target1073.elements.length = 4 ∧
    [target1073.elements.count 0, target1073.elements.count 1,
      target1073.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1073
def tree1074 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))))
def target1074 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1074 : accepts tree1074 target1074 = true ∧
    sourceLeaves tree1074 = [0, 1, 2, 0] ∧
    target1074.elements.length = 4 ∧
    [target1074.elements.count 0, target1074.elements.count 1,
      target1074.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1074
def tree1075 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)))
def target1075 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1075 : accepts tree1075 target1075 = true ∧
    sourceLeaves tree1075 = [0, 1, 2, 0] ∧
    target1075.elements.length = 4 ∧
    [target1075.elements.count 0, target1075.elements.count 1,
      target1075.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1075
def tree1076 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 0)))
def target1076 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1076 : accepts tree1076 target1076 = true ∧
    sourceLeaves tree1076 = [0, 1, 2, 0] ∧
    target1076.elements.length = 4 ∧
    [target1076.elements.count 0, target1076.elements.count 1,
      target1076.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1076
def tree1077 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 0))
def target1077 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1077 : accepts tree1077 target1077 = true ∧
    sourceLeaves tree1077 = [0, 1, 2, 0] ∧
    target1077.elements.length = 4 ∧
    [target1077.elements.count 0, target1077.elements.count 1,
      target1077.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1077
def tree1078 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target1078 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1078 : accepts tree1078 target1078 = true ∧
    sourceLeaves tree1078 = [0, 1, 2, 0] ∧
    target1078.elements.length = 4 ∧
    [target1078.elements.count 0, target1078.elements.count 1,
      target1078.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1078
def tree1079 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))))
def target1079 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1079 : accepts tree1079 target1079 = true ∧
    sourceLeaves tree1079 = [0, 1, 2, 1] ∧
    target1079.elements.length = 4 ∧
    [target1079.elements.count 0, target1079.elements.count 1,
      target1079.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1079
def tree1080 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)))
def target1080 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1080 : accepts tree1080 target1080 = true ∧
    sourceLeaves tree1080 = [0, 1, 2, 1] ∧
    target1080.elements.length = 4 ∧
    [target1080.elements.count 0, target1080.elements.count 1,
      target1080.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1080
def tree1081 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 1)))
def target1081 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1081 : accepts tree1081 target1081 = true ∧
    sourceLeaves tree1081 = [0, 1, 2, 1] ∧
    target1081.elements.length = 4 ∧
    [target1081.elements.count 0, target1081.elements.count 1,
      target1081.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1081
def tree1082 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 1))
def target1082 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1082 : accepts tree1082 target1082 = true ∧
    sourceLeaves tree1082 = [0, 1, 2, 1] ∧
    target1082.elements.length = 4 ∧
    [target1082.elements.count 0, target1082.elements.count 1,
      target1082.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1082
def tree1083 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target1083 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1083 : accepts tree1083 target1083 = true ∧
    sourceLeaves tree1083 = [0, 1, 2, 1] ∧
    target1083.elements.length = 4 ∧
    [target1083.elements.count 0, target1083.elements.count 1,
      target1083.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1083
def tree1084 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))))
def target1084 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1084 : accepts tree1084 target1084 = true ∧
    sourceLeaves tree1084 = [0, 1, 2, 2] ∧
    target1084.elements.length = 4 ∧
    [target1084.elements.count 0, target1084.elements.count 1,
      target1084.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1084
def tree1085 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)))
def target1085 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1085 : accepts tree1085 target1085 = true ∧
    sourceLeaves tree1085 = [0, 1, 2, 2] ∧
    target1085.elements.length = 4 ∧
    [target1085.elements.count 0, target1085.elements.count 1,
      target1085.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1085
def tree1086 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.app .join (.leaf 2) (.leaf 2)))
def target1086 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1086 : accepts tree1086 target1086 = true ∧
    sourceLeaves tree1086 = [0, 1, 2, 2] ∧
    target1086.elements.length = 4 ∧
    [target1086.elements.count 0, target1086.elements.count 1,
      target1086.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1086
def tree1087 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))) (.leaf 2))
def target1087 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1087 : accepts tree1087 target1087 = true ∧
    sourceLeaves tree1087 = [0, 1, 2, 2] ∧
    target1087.elements.length = 4 ∧
    [target1087.elements.count 0, target1087.elements.count 1,
      target1087.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1087
def tree1088 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target1088 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1088 : accepts tree1088 target1088 = true ∧
    sourceLeaves tree1088 = [0, 1, 2, 2] ∧
    target1088.elements.length = 4 ∧
    [target1088.elements.count 0, target1088.elements.count 1,
      target1088.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1088
def tree1089 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))))
def target1089 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1089 : accepts tree1089 target1089 = true ∧
    sourceLeaves tree1089 = [0, 2, 0, 0] ∧
    target1089.elements.length = 4 ∧
    [target1089.elements.count 0, target1089.elements.count 1,
      target1089.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1089
def tree1090 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)))
def target1090 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1090 : accepts tree1090 target1090 = true ∧
    sourceLeaves tree1090 = [0, 2, 0, 0] ∧
    target1090.elements.length = 4 ∧
    [target1090.elements.count 0, target1090.elements.count 1,
      target1090.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1090
def tree1091 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 0) (.leaf 0)))
def target1091 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1091 : accepts tree1091 target1091 = true ∧
    sourceLeaves tree1091 = [0, 2, 0, 0] ∧
    target1091.elements.length = 4 ∧
    [target1091.elements.count 0, target1091.elements.count 1,
      target1091.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1091
def tree1092 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))) (.leaf 0))
def target1092 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1092 : accepts tree1092 target1092 = true ∧
    sourceLeaves tree1092 = [0, 2, 0, 0] ∧
    target1092.elements.length = 4 ∧
    [target1092.elements.count 0, target1092.elements.count 1,
      target1092.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1092
def tree1093 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target1093 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1093 : accepts tree1093 target1093 = true ∧
    sourceLeaves tree1093 = [0, 2, 0, 0] ∧
    target1093.elements.length = 4 ∧
    [target1093.elements.count 0, target1093.elements.count 1,
      target1093.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1093
def tree1094 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))))
def target1094 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1094 : accepts tree1094 target1094 = true ∧
    sourceLeaves tree1094 = [0, 2, 0, 1] ∧
    target1094.elements.length = 4 ∧
    [target1094.elements.count 0, target1094.elements.count 1,
      target1094.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1094
def tree1095 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)))
def target1095 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1095 : accepts tree1095 target1095 = true ∧
    sourceLeaves tree1095 = [0, 2, 0, 1] ∧
    target1095.elements.length = 4 ∧
    [target1095.elements.count 0, target1095.elements.count 1,
      target1095.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1095
def tree1096 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 0) (.leaf 1)))
def target1096 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1096 : accepts tree1096 target1096 = true ∧
    sourceLeaves tree1096 = [0, 2, 0, 1] ∧
    target1096.elements.length = 4 ∧
    [target1096.elements.count 0, target1096.elements.count 1,
      target1096.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1096
def tree1097 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))) (.leaf 1))
def target1097 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1097 : accepts tree1097 target1097 = true ∧
    sourceLeaves tree1097 = [0, 2, 0, 1] ∧
    target1097.elements.length = 4 ∧
    [target1097.elements.count 0, target1097.elements.count 1,
      target1097.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1097
def tree1098 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target1098 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1098 : accepts tree1098 target1098 = true ∧
    sourceLeaves tree1098 = [0, 2, 0, 1] ∧
    target1098.elements.length = 4 ∧
    [target1098.elements.count 0, target1098.elements.count 1,
      target1098.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1098
def tree1099 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))))
def target1099 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1099 : accepts tree1099 target1099 = true ∧
    sourceLeaves tree1099 = [0, 2, 0, 2] ∧
    target1099.elements.length = 4 ∧
    [target1099.elements.count 0, target1099.elements.count 1,
      target1099.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1099
def tree1100 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)))
def target1100 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1100 : accepts tree1100 target1100 = true ∧
    sourceLeaves tree1100 = [0, 2, 0, 2] ∧
    target1100.elements.length = 4 ∧
    [target1100.elements.count 0, target1100.elements.count 1,
      target1100.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1100
def tree1101 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 0) (.leaf 2)))
def target1101 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1101 : accepts tree1101 target1101 = true ∧
    sourceLeaves tree1101 = [0, 2, 0, 2] ∧
    target1101.elements.length = 4 ∧
    [target1101.elements.count 0, target1101.elements.count 1,
      target1101.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1101
def tree1102 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))) (.leaf 2))
def target1102 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1102 : accepts tree1102 target1102 = true ∧
    sourceLeaves tree1102 = [0, 2, 0, 2] ∧
    target1102.elements.length = 4 ∧
    [target1102.elements.count 0, target1102.elements.count 1,
      target1102.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1102
def tree1103 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target1103 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1103 : accepts tree1103 target1103 = true ∧
    sourceLeaves tree1103 = [0, 2, 0, 2] ∧
    target1103.elements.length = 4 ∧
    [target1103.elements.count 0, target1103.elements.count 1,
      target1103.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1103
def tree1104 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))))
def target1104 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1104 : accepts tree1104 target1104 = true ∧
    sourceLeaves tree1104 = [0, 2, 1, 0] ∧
    target1104.elements.length = 4 ∧
    [target1104.elements.count 0, target1104.elements.count 1,
      target1104.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1104
def tree1105 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)))
def target1105 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1105 : accepts tree1105 target1105 = true ∧
    sourceLeaves tree1105 = [0, 2, 1, 0] ∧
    target1105.elements.length = 4 ∧
    [target1105.elements.count 0, target1105.elements.count 1,
      target1105.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1105
def tree1106 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 1) (.leaf 0)))
def target1106 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1106 : accepts tree1106 target1106 = true ∧
    sourceLeaves tree1106 = [0, 2, 1, 0] ∧
    target1106.elements.length = 4 ∧
    [target1106.elements.count 0, target1106.elements.count 1,
      target1106.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1106
def tree1107 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))) (.leaf 0))
def target1107 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1107 : accepts tree1107 target1107 = true ∧
    sourceLeaves tree1107 = [0, 2, 1, 0] ∧
    target1107.elements.length = 4 ∧
    [target1107.elements.count 0, target1107.elements.count 1,
      target1107.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1107
def tree1108 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target1108 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1108 : accepts tree1108 target1108 = true ∧
    sourceLeaves tree1108 = [0, 2, 1, 0] ∧
    target1108.elements.length = 4 ∧
    [target1108.elements.count 0, target1108.elements.count 1,
      target1108.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1108
def tree1109 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))))
def target1109 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1109 : accepts tree1109 target1109 = true ∧
    sourceLeaves tree1109 = [0, 2, 1, 1] ∧
    target1109.elements.length = 4 ∧
    [target1109.elements.count 0, target1109.elements.count 1,
      target1109.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1109
def tree1110 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)))
def target1110 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1110 : accepts tree1110 target1110 = true ∧
    sourceLeaves tree1110 = [0, 2, 1, 1] ∧
    target1110.elements.length = 4 ∧
    [target1110.elements.count 0, target1110.elements.count 1,
      target1110.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1110
def tree1111 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 1) (.leaf 1)))
def target1111 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1111 : accepts tree1111 target1111 = true ∧
    sourceLeaves tree1111 = [0, 2, 1, 1] ∧
    target1111.elements.length = 4 ∧
    [target1111.elements.count 0, target1111.elements.count 1,
      target1111.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1111
def tree1112 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))) (.leaf 1))
def target1112 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1112 : accepts tree1112 target1112 = true ∧
    sourceLeaves tree1112 = [0, 2, 1, 1] ∧
    target1112.elements.length = 4 ∧
    [target1112.elements.count 0, target1112.elements.count 1,
      target1112.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1112
def tree1113 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target1113 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1113 : accepts tree1113 target1113 = true ∧
    sourceLeaves tree1113 = [0, 2, 1, 1] ∧
    target1113.elements.length = 4 ∧
    [target1113.elements.count 0, target1113.elements.count 1,
      target1113.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1113
def tree1114 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))))
def target1114 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1114 : accepts tree1114 target1114 = true ∧
    sourceLeaves tree1114 = [0, 2, 1, 2] ∧
    target1114.elements.length = 4 ∧
    [target1114.elements.count 0, target1114.elements.count 1,
      target1114.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1114
def tree1115 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)))
def target1115 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1115 : accepts tree1115 target1115 = true ∧
    sourceLeaves tree1115 = [0, 2, 1, 2] ∧
    target1115.elements.length = 4 ∧
    [target1115.elements.count 0, target1115.elements.count 1,
      target1115.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1115
def tree1116 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 1) (.leaf 2)))
def target1116 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1116 : accepts tree1116 target1116 = true ∧
    sourceLeaves tree1116 = [0, 2, 1, 2] ∧
    target1116.elements.length = 4 ∧
    [target1116.elements.count 0, target1116.elements.count 1,
      target1116.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1116
def tree1117 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))) (.leaf 2))
def target1117 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1117 : accepts tree1117 target1117 = true ∧
    sourceLeaves tree1117 = [0, 2, 1, 2] ∧
    target1117.elements.length = 4 ∧
    [target1117.elements.count 0, target1117.elements.count 1,
      target1117.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1117
def tree1118 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target1118 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1118 : accepts tree1118 target1118 = true ∧
    sourceLeaves tree1118 = [0, 2, 1, 2] ∧
    target1118.elements.length = 4 ∧
    [target1118.elements.count 0, target1118.elements.count 1,
      target1118.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1118
def tree1119 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))))
def target1119 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1119 : accepts tree1119 target1119 = true ∧
    sourceLeaves tree1119 = [0, 2, 2, 0] ∧
    target1119.elements.length = 4 ∧
    [target1119.elements.count 0, target1119.elements.count 1,
      target1119.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1119
def tree1120 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)))
def target1120 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1120 : accepts tree1120 target1120 = true ∧
    sourceLeaves tree1120 = [0, 2, 2, 0] ∧
    target1120.elements.length = 4 ∧
    [target1120.elements.count 0, target1120.elements.count 1,
      target1120.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1120
def tree1121 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 2) (.leaf 0)))
def target1121 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1121 : accepts tree1121 target1121 = true ∧
    sourceLeaves tree1121 = [0, 2, 2, 0] ∧
    target1121.elements.length = 4 ∧
    [target1121.elements.count 0, target1121.elements.count 1,
      target1121.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1121
def tree1122 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))) (.leaf 0))
def target1122 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1122 : accepts tree1122 target1122 = true ∧
    sourceLeaves tree1122 = [0, 2, 2, 0] ∧
    target1122.elements.length = 4 ∧
    [target1122.elements.count 0, target1122.elements.count 1,
      target1122.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1122
def tree1123 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target1123 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1123 : accepts tree1123 target1123 = true ∧
    sourceLeaves tree1123 = [0, 2, 2, 0] ∧
    target1123.elements.length = 4 ∧
    [target1123.elements.count 0, target1123.elements.count 1,
      target1123.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1123
def tree1124 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))))
def target1124 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1124 : accepts tree1124 target1124 = true ∧
    sourceLeaves tree1124 = [0, 2, 2, 1] ∧
    target1124.elements.length = 4 ∧
    [target1124.elements.count 0, target1124.elements.count 1,
      target1124.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1124
def tree1125 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)))
def target1125 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1125 : accepts tree1125 target1125 = true ∧
    sourceLeaves tree1125 = [0, 2, 2, 1] ∧
    target1125.elements.length = 4 ∧
    [target1125.elements.count 0, target1125.elements.count 1,
      target1125.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1125
def tree1126 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 2) (.leaf 1)))
def target1126 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1126 : accepts tree1126 target1126 = true ∧
    sourceLeaves tree1126 = [0, 2, 2, 1] ∧
    target1126.elements.length = 4 ∧
    [target1126.elements.count 0, target1126.elements.count 1,
      target1126.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1126
def tree1127 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))) (.leaf 1))
def target1127 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1127 : accepts tree1127 target1127 = true ∧
    sourceLeaves tree1127 = [0, 2, 2, 1] ∧
    target1127.elements.length = 4 ∧
    [target1127.elements.count 0, target1127.elements.count 1,
      target1127.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1127
def tree1128 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target1128 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1128 : accepts tree1128 target1128 = true ∧
    sourceLeaves tree1128 = [0, 2, 2, 1] ∧
    target1128.elements.length = 4 ∧
    [target1128.elements.count 0, target1128.elements.count 1,
      target1128.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1128
def tree1129 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))))
def target1129 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1129 : accepts tree1129 target1129 = true ∧
    sourceLeaves tree1129 = [0, 2, 2, 2] ∧
    target1129.elements.length = 4 ∧
    [target1129.elements.count 0, target1129.elements.count 1,
      target1129.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1129
def tree1130 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)))
def target1130 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1130 : accepts tree1130 target1130 = true ∧
    sourceLeaves tree1130 = [0, 2, 2, 2] ∧
    target1130.elements.length = 4 ∧
    [target1130.elements.count 0, target1130.elements.count 1,
      target1130.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1130
def tree1131 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 2)) (.app .join (.leaf 2) (.leaf 2)))
def target1131 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1131 : accepts tree1131 target1131 = true ∧
    sourceLeaves tree1131 = [0, 2, 2, 2] ∧
    target1131.elements.length = 4 ∧
    [target1131.elements.count 0, target1131.elements.count 1,
      target1131.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1131
def tree1132 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))) (.leaf 2))
def target1132 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1132 : accepts tree1132 target1132 = true ∧
    sourceLeaves tree1132 = [0, 2, 2, 2] ∧
    target1132.elements.length = 4 ∧
    [target1132.elements.count 0, target1132.elements.count 1,
      target1132.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1132
def tree1133 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target1133 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1133 : accepts tree1133 target1133 = true ∧
    sourceLeaves tree1133 = [0, 2, 2, 2] ∧
    target1133.elements.length = 4 ∧
    [target1133.elements.count 0, target1133.elements.count 1,
      target1133.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1133
def tree1134 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))))
def target1134 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1134 : accepts tree1134 target1134 = true ∧
    sourceLeaves tree1134 = [1, 0, 0, 0] ∧
    target1134.elements.length = 4 ∧
    [target1134.elements.count 0, target1134.elements.count 1,
      target1134.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1134
def tree1135 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)))
def target1135 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1135 : accepts tree1135 target1135 = true ∧
    sourceLeaves tree1135 = [1, 0, 0, 0] ∧
    target1135.elements.length = 4 ∧
    [target1135.elements.count 0, target1135.elements.count 1,
      target1135.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1135
def tree1136 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 0) (.leaf 0)))
def target1136 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1136 : accepts tree1136 target1136 = true ∧
    sourceLeaves tree1136 = [1, 0, 0, 0] ∧
    target1136.elements.length = 4 ∧
    [target1136.elements.count 0, target1136.elements.count 1,
      target1136.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1136
def tree1137 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))) (.leaf 0))
def target1137 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1137 : accepts tree1137 target1137 = true ∧
    sourceLeaves tree1137 = [1, 0, 0, 0] ∧
    target1137.elements.length = 4 ∧
    [target1137.elements.count 0, target1137.elements.count 1,
      target1137.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1137
def tree1138 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target1138 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1138 : accepts tree1138 target1138 = true ∧
    sourceLeaves tree1138 = [1, 0, 0, 0] ∧
    target1138.elements.length = 4 ∧
    [target1138.elements.count 0, target1138.elements.count 1,
      target1138.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1138
def tree1139 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))))
def target1139 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1139 : accepts tree1139 target1139 = true ∧
    sourceLeaves tree1139 = [1, 0, 0, 1] ∧
    target1139.elements.length = 4 ∧
    [target1139.elements.count 0, target1139.elements.count 1,
      target1139.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1139
def tree1140 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)))
def target1140 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1140 : accepts tree1140 target1140 = true ∧
    sourceLeaves tree1140 = [1, 0, 0, 1] ∧
    target1140.elements.length = 4 ∧
    [target1140.elements.count 0, target1140.elements.count 1,
      target1140.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1140
def tree1141 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 0) (.leaf 1)))
def target1141 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1141 : accepts tree1141 target1141 = true ∧
    sourceLeaves tree1141 = [1, 0, 0, 1] ∧
    target1141.elements.length = 4 ∧
    [target1141.elements.count 0, target1141.elements.count 1,
      target1141.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1141
def tree1142 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))) (.leaf 1))
def target1142 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1142 : accepts tree1142 target1142 = true ∧
    sourceLeaves tree1142 = [1, 0, 0, 1] ∧
    target1142.elements.length = 4 ∧
    [target1142.elements.count 0, target1142.elements.count 1,
      target1142.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1142
def tree1143 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target1143 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1143 : accepts tree1143 target1143 = true ∧
    sourceLeaves tree1143 = [1, 0, 0, 1] ∧
    target1143.elements.length = 4 ∧
    [target1143.elements.count 0, target1143.elements.count 1,
      target1143.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1143
def tree1144 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))))
def target1144 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1144 : accepts tree1144 target1144 = true ∧
    sourceLeaves tree1144 = [1, 0, 0, 2] ∧
    target1144.elements.length = 4 ∧
    [target1144.elements.count 0, target1144.elements.count 1,
      target1144.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1144
def tree1145 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)))
def target1145 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1145 : accepts tree1145 target1145 = true ∧
    sourceLeaves tree1145 = [1, 0, 0, 2] ∧
    target1145.elements.length = 4 ∧
    [target1145.elements.count 0, target1145.elements.count 1,
      target1145.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1145
def tree1146 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 0) (.leaf 2)))
def target1146 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1146 : accepts tree1146 target1146 = true ∧
    sourceLeaves tree1146 = [1, 0, 0, 2] ∧
    target1146.elements.length = 4 ∧
    [target1146.elements.count 0, target1146.elements.count 1,
      target1146.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1146
def tree1147 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))) (.leaf 2))
def target1147 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1147 : accepts tree1147 target1147 = true ∧
    sourceLeaves tree1147 = [1, 0, 0, 2] ∧
    target1147.elements.length = 4 ∧
    [target1147.elements.count 0, target1147.elements.count 1,
      target1147.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1147
def tree1148 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target1148 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1148 : accepts tree1148 target1148 = true ∧
    sourceLeaves tree1148 = [1, 0, 0, 2] ∧
    target1148.elements.length = 4 ∧
    [target1148.elements.count 0, target1148.elements.count 1,
      target1148.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1148
def tree1149 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))))
def target1149 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1149 : accepts tree1149 target1149 = true ∧
    sourceLeaves tree1149 = [1, 0, 1, 0] ∧
    target1149.elements.length = 4 ∧
    [target1149.elements.count 0, target1149.elements.count 1,
      target1149.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1149
def tree1150 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)))
def target1150 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1150 : accepts tree1150 target1150 = true ∧
    sourceLeaves tree1150 = [1, 0, 1, 0] ∧
    target1150.elements.length = 4 ∧
    [target1150.elements.count 0, target1150.elements.count 1,
      target1150.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1150
def tree1151 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 1) (.leaf 0)))
def target1151 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1151 : accepts tree1151 target1151 = true ∧
    sourceLeaves tree1151 = [1, 0, 1, 0] ∧
    target1151.elements.length = 4 ∧
    [target1151.elements.count 0, target1151.elements.count 1,
      target1151.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1151
def tree1152 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))) (.leaf 0))
def target1152 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1152 : accepts tree1152 target1152 = true ∧
    sourceLeaves tree1152 = [1, 0, 1, 0] ∧
    target1152.elements.length = 4 ∧
    [target1152.elements.count 0, target1152.elements.count 1,
      target1152.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1152
def tree1153 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target1153 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1153 : accepts tree1153 target1153 = true ∧
    sourceLeaves tree1153 = [1, 0, 1, 0] ∧
    target1153.elements.length = 4 ∧
    [target1153.elements.count 0, target1153.elements.count 1,
      target1153.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1153
def tree1154 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))))
def target1154 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1154 : accepts tree1154 target1154 = true ∧
    sourceLeaves tree1154 = [1, 0, 1, 1] ∧
    target1154.elements.length = 4 ∧
    [target1154.elements.count 0, target1154.elements.count 1,
      target1154.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1154
def tree1155 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)))
def target1155 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1155 : accepts tree1155 target1155 = true ∧
    sourceLeaves tree1155 = [1, 0, 1, 1] ∧
    target1155.elements.length = 4 ∧
    [target1155.elements.count 0, target1155.elements.count 1,
      target1155.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1155
def tree1156 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 1) (.leaf 1)))
def target1156 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1156 : accepts tree1156 target1156 = true ∧
    sourceLeaves tree1156 = [1, 0, 1, 1] ∧
    target1156.elements.length = 4 ∧
    [target1156.elements.count 0, target1156.elements.count 1,
      target1156.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1156
def tree1157 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))) (.leaf 1))
def target1157 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1157 : accepts tree1157 target1157 = true ∧
    sourceLeaves tree1157 = [1, 0, 1, 1] ∧
    target1157.elements.length = 4 ∧
    [target1157.elements.count 0, target1157.elements.count 1,
      target1157.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1157
def tree1158 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target1158 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1158 : accepts tree1158 target1158 = true ∧
    sourceLeaves tree1158 = [1, 0, 1, 1] ∧
    target1158.elements.length = 4 ∧
    [target1158.elements.count 0, target1158.elements.count 1,
      target1158.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1158
def tree1159 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))))
def target1159 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1159 : accepts tree1159 target1159 = true ∧
    sourceLeaves tree1159 = [1, 0, 1, 2] ∧
    target1159.elements.length = 4 ∧
    [target1159.elements.count 0, target1159.elements.count 1,
      target1159.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1159
def tree1160 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)))
def target1160 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1160 : accepts tree1160 target1160 = true ∧
    sourceLeaves tree1160 = [1, 0, 1, 2] ∧
    target1160.elements.length = 4 ∧
    [target1160.elements.count 0, target1160.elements.count 1,
      target1160.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1160
def tree1161 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 1) (.leaf 2)))
def target1161 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1161 : accepts tree1161 target1161 = true ∧
    sourceLeaves tree1161 = [1, 0, 1, 2] ∧
    target1161.elements.length = 4 ∧
    [target1161.elements.count 0, target1161.elements.count 1,
      target1161.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1161
def tree1162 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))) (.leaf 2))
def target1162 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1162 : accepts tree1162 target1162 = true ∧
    sourceLeaves tree1162 = [1, 0, 1, 2] ∧
    target1162.elements.length = 4 ∧
    [target1162.elements.count 0, target1162.elements.count 1,
      target1162.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1162
def tree1163 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target1163 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1163 : accepts tree1163 target1163 = true ∧
    sourceLeaves tree1163 = [1, 0, 1, 2] ∧
    target1163.elements.length = 4 ∧
    [target1163.elements.count 0, target1163.elements.count 1,
      target1163.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1163
def tree1164 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))))
def target1164 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1164 : accepts tree1164 target1164 = true ∧
    sourceLeaves tree1164 = [1, 0, 2, 0] ∧
    target1164.elements.length = 4 ∧
    [target1164.elements.count 0, target1164.elements.count 1,
      target1164.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1164
def tree1165 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)))
def target1165 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1165 : accepts tree1165 target1165 = true ∧
    sourceLeaves tree1165 = [1, 0, 2, 0] ∧
    target1165.elements.length = 4 ∧
    [target1165.elements.count 0, target1165.elements.count 1,
      target1165.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1165
def tree1166 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 2) (.leaf 0)))
def target1166 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1166 : accepts tree1166 target1166 = true ∧
    sourceLeaves tree1166 = [1, 0, 2, 0] ∧
    target1166.elements.length = 4 ∧
    [target1166.elements.count 0, target1166.elements.count 1,
      target1166.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1166
def tree1167 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))) (.leaf 0))
def target1167 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1167 : accepts tree1167 target1167 = true ∧
    sourceLeaves tree1167 = [1, 0, 2, 0] ∧
    target1167.elements.length = 4 ∧
    [target1167.elements.count 0, target1167.elements.count 1,
      target1167.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1167
def tree1168 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target1168 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1168 : accepts tree1168 target1168 = true ∧
    sourceLeaves tree1168 = [1, 0, 2, 0] ∧
    target1168.elements.length = 4 ∧
    [target1168.elements.count 0, target1168.elements.count 1,
      target1168.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1168
def tree1169 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))))
def target1169 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1169 : accepts tree1169 target1169 = true ∧
    sourceLeaves tree1169 = [1, 0, 2, 1] ∧
    target1169.elements.length = 4 ∧
    [target1169.elements.count 0, target1169.elements.count 1,
      target1169.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1169
def tree1170 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)))
def target1170 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1170 : accepts tree1170 target1170 = true ∧
    sourceLeaves tree1170 = [1, 0, 2, 1] ∧
    target1170.elements.length = 4 ∧
    [target1170.elements.count 0, target1170.elements.count 1,
      target1170.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1170
def tree1171 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 2) (.leaf 1)))
def target1171 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1171 : accepts tree1171 target1171 = true ∧
    sourceLeaves tree1171 = [1, 0, 2, 1] ∧
    target1171.elements.length = 4 ∧
    [target1171.elements.count 0, target1171.elements.count 1,
      target1171.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1171
def tree1172 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))) (.leaf 1))
def target1172 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1172 : accepts tree1172 target1172 = true ∧
    sourceLeaves tree1172 = [1, 0, 2, 1] ∧
    target1172.elements.length = 4 ∧
    [target1172.elements.count 0, target1172.elements.count 1,
      target1172.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1172
def tree1173 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target1173 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1173 : accepts tree1173 target1173 = true ∧
    sourceLeaves tree1173 = [1, 0, 2, 1] ∧
    target1173.elements.length = 4 ∧
    [target1173.elements.count 0, target1173.elements.count 1,
      target1173.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1173
def tree1174 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))))
def target1174 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1174 : accepts tree1174 target1174 = true ∧
    sourceLeaves tree1174 = [1, 0, 2, 2] ∧
    target1174.elements.length = 4 ∧
    [target1174.elements.count 0, target1174.elements.count 1,
      target1174.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1174
def tree1175 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)))
def target1175 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1175 : accepts tree1175 target1175 = true ∧
    sourceLeaves tree1175 = [1, 0, 2, 2] ∧
    target1175.elements.length = 4 ∧
    [target1175.elements.count 0, target1175.elements.count 1,
      target1175.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1175
def tree1176 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.app .join (.leaf 2) (.leaf 2)))
def target1176 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1176 : accepts tree1176 target1176 = true ∧
    sourceLeaves tree1176 = [1, 0, 2, 2] ∧
    target1176.elements.length = 4 ∧
    [target1176.elements.count 0, target1176.elements.count 1,
      target1176.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1176
def tree1177 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))) (.leaf 2))
def target1177 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1177 : accepts tree1177 target1177 = true ∧
    sourceLeaves tree1177 = [1, 0, 2, 2] ∧
    target1177.elements.length = 4 ∧
    [target1177.elements.count 0, target1177.elements.count 1,
      target1177.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1177
def tree1178 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target1178 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1178 : accepts tree1178 target1178 = true ∧
    sourceLeaves tree1178 = [1, 0, 2, 2] ∧
    target1178.elements.length = 4 ∧
    [target1178.elements.count 0, target1178.elements.count 1,
      target1178.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1178
def tree1179 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))))
def target1179 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1179 : accepts tree1179 target1179 = true ∧
    sourceLeaves tree1179 = [1, 1, 0, 0] ∧
    target1179.elements.length = 4 ∧
    [target1179.elements.count 0, target1179.elements.count 1,
      target1179.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1179
def tree1180 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)))
def target1180 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1180 : accepts tree1180 target1180 = true ∧
    sourceLeaves tree1180 = [1, 1, 0, 0] ∧
    target1180.elements.length = 4 ∧
    [target1180.elements.count 0, target1180.elements.count 1,
      target1180.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1180
def tree1181 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 0) (.leaf 0)))
def target1181 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1181 : accepts tree1181 target1181 = true ∧
    sourceLeaves tree1181 = [1, 1, 0, 0] ∧
    target1181.elements.length = 4 ∧
    [target1181.elements.count 0, target1181.elements.count 1,
      target1181.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1181
def tree1182 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))) (.leaf 0))
def target1182 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1182 : accepts tree1182 target1182 = true ∧
    sourceLeaves tree1182 = [1, 1, 0, 0] ∧
    target1182.elements.length = 4 ∧
    [target1182.elements.count 0, target1182.elements.count 1,
      target1182.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1182
def tree1183 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target1183 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1183 : accepts tree1183 target1183 = true ∧
    sourceLeaves tree1183 = [1, 1, 0, 0] ∧
    target1183.elements.length = 4 ∧
    [target1183.elements.count 0, target1183.elements.count 1,
      target1183.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1183
def tree1184 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))))
def target1184 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1184 : accepts tree1184 target1184 = true ∧
    sourceLeaves tree1184 = [1, 1, 0, 1] ∧
    target1184.elements.length = 4 ∧
    [target1184.elements.count 0, target1184.elements.count 1,
      target1184.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1184
def tree1185 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)))
def target1185 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1185 : accepts tree1185 target1185 = true ∧
    sourceLeaves tree1185 = [1, 1, 0, 1] ∧
    target1185.elements.length = 4 ∧
    [target1185.elements.count 0, target1185.elements.count 1,
      target1185.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1185
def tree1186 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 0) (.leaf 1)))
def target1186 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1186 : accepts tree1186 target1186 = true ∧
    sourceLeaves tree1186 = [1, 1, 0, 1] ∧
    target1186.elements.length = 4 ∧
    [target1186.elements.count 0, target1186.elements.count 1,
      target1186.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1186
def tree1187 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))) (.leaf 1))
def target1187 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1187 : accepts tree1187 target1187 = true ∧
    sourceLeaves tree1187 = [1, 1, 0, 1] ∧
    target1187.elements.length = 4 ∧
    [target1187.elements.count 0, target1187.elements.count 1,
      target1187.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1187
def tree1188 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target1188 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1188 : accepts tree1188 target1188 = true ∧
    sourceLeaves tree1188 = [1, 1, 0, 1] ∧
    target1188.elements.length = 4 ∧
    [target1188.elements.count 0, target1188.elements.count 1,
      target1188.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1188
def tree1189 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))))
def target1189 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1189 : accepts tree1189 target1189 = true ∧
    sourceLeaves tree1189 = [1, 1, 0, 2] ∧
    target1189.elements.length = 4 ∧
    [target1189.elements.count 0, target1189.elements.count 1,
      target1189.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1189
def tree1190 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)))
def target1190 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1190 : accepts tree1190 target1190 = true ∧
    sourceLeaves tree1190 = [1, 1, 0, 2] ∧
    target1190.elements.length = 4 ∧
    [target1190.elements.count 0, target1190.elements.count 1,
      target1190.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1190
def tree1191 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 0) (.leaf 2)))
def target1191 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1191 : accepts tree1191 target1191 = true ∧
    sourceLeaves tree1191 = [1, 1, 0, 2] ∧
    target1191.elements.length = 4 ∧
    [target1191.elements.count 0, target1191.elements.count 1,
      target1191.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1191
def tree1192 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))) (.leaf 2))
def target1192 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1192 : accepts tree1192 target1192 = true ∧
    sourceLeaves tree1192 = [1, 1, 0, 2] ∧
    target1192.elements.length = 4 ∧
    [target1192.elements.count 0, target1192.elements.count 1,
      target1192.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1192
def tree1193 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target1193 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1193 : accepts tree1193 target1193 = true ∧
    sourceLeaves tree1193 = [1, 1, 0, 2] ∧
    target1193.elements.length = 4 ∧
    [target1193.elements.count 0, target1193.elements.count 1,
      target1193.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1193
def tree1194 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))))
def target1194 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1194 : accepts tree1194 target1194 = true ∧
    sourceLeaves tree1194 = [1, 1, 1, 0] ∧
    target1194.elements.length = 4 ∧
    [target1194.elements.count 0, target1194.elements.count 1,
      target1194.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1194
def tree1195 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)))
def target1195 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1195 : accepts tree1195 target1195 = true ∧
    sourceLeaves tree1195 = [1, 1, 1, 0] ∧
    target1195.elements.length = 4 ∧
    [target1195.elements.count 0, target1195.elements.count 1,
      target1195.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1195
def tree1196 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 1) (.leaf 0)))
def target1196 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1196 : accepts tree1196 target1196 = true ∧
    sourceLeaves tree1196 = [1, 1, 1, 0] ∧
    target1196.elements.length = 4 ∧
    [target1196.elements.count 0, target1196.elements.count 1,
      target1196.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1196
def tree1197 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))) (.leaf 0))
def target1197 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1197 : accepts tree1197 target1197 = true ∧
    sourceLeaves tree1197 = [1, 1, 1, 0] ∧
    target1197.elements.length = 4 ∧
    [target1197.elements.count 0, target1197.elements.count 1,
      target1197.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1197
def tree1198 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target1198 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1198 : accepts tree1198 target1198 = true ∧
    sourceLeaves tree1198 = [1, 1, 1, 0] ∧
    target1198.elements.length = 4 ∧
    [target1198.elements.count 0, target1198.elements.count 1,
      target1198.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1198
def tree1199 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))))
def target1199 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1199 : accepts tree1199 target1199 = true ∧
    sourceLeaves tree1199 = [1, 1, 1, 1] ∧
    target1199.elements.length = 4 ∧
    [target1199.elements.count 0, target1199.elements.count 1,
      target1199.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1199
def tree1200 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)))
def target1200 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1200 : accepts tree1200 target1200 = true ∧
    sourceLeaves tree1200 = [1, 1, 1, 1] ∧
    target1200.elements.length = 4 ∧
    [target1200.elements.count 0, target1200.elements.count 1,
      target1200.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1200
def tree1201 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 1) (.leaf 1)))
def target1201 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1201 : accepts tree1201 target1201 = true ∧
    sourceLeaves tree1201 = [1, 1, 1, 1] ∧
    target1201.elements.length = 4 ∧
    [target1201.elements.count 0, target1201.elements.count 1,
      target1201.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1201
def tree1202 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))) (.leaf 1))
def target1202 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1202 : accepts tree1202 target1202 = true ∧
    sourceLeaves tree1202 = [1, 1, 1, 1] ∧
    target1202.elements.length = 4 ∧
    [target1202.elements.count 0, target1202.elements.count 1,
      target1202.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1202
def tree1203 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target1203 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1203 : accepts tree1203 target1203 = true ∧
    sourceLeaves tree1203 = [1, 1, 1, 1] ∧
    target1203.elements.length = 4 ∧
    [target1203.elements.count 0, target1203.elements.count 1,
      target1203.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1203
def tree1204 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))))
def target1204 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1204 : accepts tree1204 target1204 = true ∧
    sourceLeaves tree1204 = [1, 1, 1, 2] ∧
    target1204.elements.length = 4 ∧
    [target1204.elements.count 0, target1204.elements.count 1,
      target1204.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1204
def tree1205 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)))
def target1205 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1205 : accepts tree1205 target1205 = true ∧
    sourceLeaves tree1205 = [1, 1, 1, 2] ∧
    target1205.elements.length = 4 ∧
    [target1205.elements.count 0, target1205.elements.count 1,
      target1205.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1205
def tree1206 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 1) (.leaf 2)))
def target1206 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1206 : accepts tree1206 target1206 = true ∧
    sourceLeaves tree1206 = [1, 1, 1, 2] ∧
    target1206.elements.length = 4 ∧
    [target1206.elements.count 0, target1206.elements.count 1,
      target1206.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1206
def tree1207 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))) (.leaf 2))
def target1207 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1207 : accepts tree1207 target1207 = true ∧
    sourceLeaves tree1207 = [1, 1, 1, 2] ∧
    target1207.elements.length = 4 ∧
    [target1207.elements.count 0, target1207.elements.count 1,
      target1207.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1207
def tree1208 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target1208 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1208 : accepts tree1208 target1208 = true ∧
    sourceLeaves tree1208 = [1, 1, 1, 2] ∧
    target1208.elements.length = 4 ∧
    [target1208.elements.count 0, target1208.elements.count 1,
      target1208.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1208
def tree1209 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))))
def target1209 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1209 : accepts tree1209 target1209 = true ∧
    sourceLeaves tree1209 = [1, 1, 2, 0] ∧
    target1209.elements.length = 4 ∧
    [target1209.elements.count 0, target1209.elements.count 1,
      target1209.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1209
def tree1210 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)))
def target1210 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1210 : accepts tree1210 target1210 = true ∧
    sourceLeaves tree1210 = [1, 1, 2, 0] ∧
    target1210.elements.length = 4 ∧
    [target1210.elements.count 0, target1210.elements.count 1,
      target1210.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1210
def tree1211 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 2) (.leaf 0)))
def target1211 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1211 : accepts tree1211 target1211 = true ∧
    sourceLeaves tree1211 = [1, 1, 2, 0] ∧
    target1211.elements.length = 4 ∧
    [target1211.elements.count 0, target1211.elements.count 1,
      target1211.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1211
def tree1212 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))) (.leaf 0))
def target1212 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1212 : accepts tree1212 target1212 = true ∧
    sourceLeaves tree1212 = [1, 1, 2, 0] ∧
    target1212.elements.length = 4 ∧
    [target1212.elements.count 0, target1212.elements.count 1,
      target1212.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1212
def tree1213 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target1213 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1213 : accepts tree1213 target1213 = true ∧
    sourceLeaves tree1213 = [1, 1, 2, 0] ∧
    target1213.elements.length = 4 ∧
    [target1213.elements.count 0, target1213.elements.count 1,
      target1213.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1213
def tree1214 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))))
def target1214 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1214 : accepts tree1214 target1214 = true ∧
    sourceLeaves tree1214 = [1, 1, 2, 1] ∧
    target1214.elements.length = 4 ∧
    [target1214.elements.count 0, target1214.elements.count 1,
      target1214.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1214
def tree1215 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)))
def target1215 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1215 : accepts tree1215 target1215 = true ∧
    sourceLeaves tree1215 = [1, 1, 2, 1] ∧
    target1215.elements.length = 4 ∧
    [target1215.elements.count 0, target1215.elements.count 1,
      target1215.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1215
def tree1216 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 2) (.leaf 1)))
def target1216 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1216 : accepts tree1216 target1216 = true ∧
    sourceLeaves tree1216 = [1, 1, 2, 1] ∧
    target1216.elements.length = 4 ∧
    [target1216.elements.count 0, target1216.elements.count 1,
      target1216.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1216
def tree1217 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))) (.leaf 1))
def target1217 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1217 : accepts tree1217 target1217 = true ∧
    sourceLeaves tree1217 = [1, 1, 2, 1] ∧
    target1217.elements.length = 4 ∧
    [target1217.elements.count 0, target1217.elements.count 1,
      target1217.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1217
def tree1218 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target1218 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1218 : accepts tree1218 target1218 = true ∧
    sourceLeaves tree1218 = [1, 1, 2, 1] ∧
    target1218.elements.length = 4 ∧
    [target1218.elements.count 0, target1218.elements.count 1,
      target1218.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1218
def tree1219 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))))
def target1219 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1219 : accepts tree1219 target1219 = true ∧
    sourceLeaves tree1219 = [1, 1, 2, 2] ∧
    target1219.elements.length = 4 ∧
    [target1219.elements.count 0, target1219.elements.count 1,
      target1219.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1219
def tree1220 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)))
def target1220 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1220 : accepts tree1220 target1220 = true ∧
    sourceLeaves tree1220 = [1, 1, 2, 2] ∧
    target1220.elements.length = 4 ∧
    [target1220.elements.count 0, target1220.elements.count 1,
      target1220.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1220
def tree1221 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 1)) (.app .join (.leaf 2) (.leaf 2)))
def target1221 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1221 : accepts tree1221 target1221 = true ∧
    sourceLeaves tree1221 = [1, 1, 2, 2] ∧
    target1221.elements.length = 4 ∧
    [target1221.elements.count 0, target1221.elements.count 1,
      target1221.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1221
def tree1222 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))) (.leaf 2))
def target1222 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1222 : accepts tree1222 target1222 = true ∧
    sourceLeaves tree1222 = [1, 1, 2, 2] ∧
    target1222.elements.length = 4 ∧
    [target1222.elements.count 0, target1222.elements.count 1,
      target1222.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1222
def tree1223 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target1223 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1223 : accepts tree1223 target1223 = true ∧
    sourceLeaves tree1223 = [1, 1, 2, 2] ∧
    target1223.elements.length = 4 ∧
    [target1223.elements.count 0, target1223.elements.count 1,
      target1223.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1223
def tree1224 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))))
def target1224 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1224 : accepts tree1224 target1224 = true ∧
    sourceLeaves tree1224 = [1, 2, 0, 0] ∧
    target1224.elements.length = 4 ∧
    [target1224.elements.count 0, target1224.elements.count 1,
      target1224.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1224
def tree1225 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)))
def target1225 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1225 : accepts tree1225 target1225 = true ∧
    sourceLeaves tree1225 = [1, 2, 0, 0] ∧
    target1225.elements.length = 4 ∧
    [target1225.elements.count 0, target1225.elements.count 1,
      target1225.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1225
def tree1226 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 0) (.leaf 0)))
def target1226 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1226 : accepts tree1226 target1226 = true ∧
    sourceLeaves tree1226 = [1, 2, 0, 0] ∧
    target1226.elements.length = 4 ∧
    [target1226.elements.count 0, target1226.elements.count 1,
      target1226.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1226
def tree1227 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))) (.leaf 0))
def target1227 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1227 : accepts tree1227 target1227 = true ∧
    sourceLeaves tree1227 = [1, 2, 0, 0] ∧
    target1227.elements.length = 4 ∧
    [target1227.elements.count 0, target1227.elements.count 1,
      target1227.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1227
def tree1228 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target1228 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1228 : accepts tree1228 target1228 = true ∧
    sourceLeaves tree1228 = [1, 2, 0, 0] ∧
    target1228.elements.length = 4 ∧
    [target1228.elements.count 0, target1228.elements.count 1,
      target1228.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1228
def tree1229 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))))
def target1229 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1229 : accepts tree1229 target1229 = true ∧
    sourceLeaves tree1229 = [1, 2, 0, 1] ∧
    target1229.elements.length = 4 ∧
    [target1229.elements.count 0, target1229.elements.count 1,
      target1229.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1229
def tree1230 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)))
def target1230 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1230 : accepts tree1230 target1230 = true ∧
    sourceLeaves tree1230 = [1, 2, 0, 1] ∧
    target1230.elements.length = 4 ∧
    [target1230.elements.count 0, target1230.elements.count 1,
      target1230.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1230
def tree1231 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 0) (.leaf 1)))
def target1231 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1231 : accepts tree1231 target1231 = true ∧
    sourceLeaves tree1231 = [1, 2, 0, 1] ∧
    target1231.elements.length = 4 ∧
    [target1231.elements.count 0, target1231.elements.count 1,
      target1231.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1231
def tree1232 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))) (.leaf 1))
def target1232 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1232 : accepts tree1232 target1232 = true ∧
    sourceLeaves tree1232 = [1, 2, 0, 1] ∧
    target1232.elements.length = 4 ∧
    [target1232.elements.count 0, target1232.elements.count 1,
      target1232.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1232
def tree1233 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target1233 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1233 : accepts tree1233 target1233 = true ∧
    sourceLeaves tree1233 = [1, 2, 0, 1] ∧
    target1233.elements.length = 4 ∧
    [target1233.elements.count 0, target1233.elements.count 1,
      target1233.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1233
def tree1234 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))))
def target1234 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1234 : accepts tree1234 target1234 = true ∧
    sourceLeaves tree1234 = [1, 2, 0, 2] ∧
    target1234.elements.length = 4 ∧
    [target1234.elements.count 0, target1234.elements.count 1,
      target1234.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1234
def tree1235 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)))
def target1235 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1235 : accepts tree1235 target1235 = true ∧
    sourceLeaves tree1235 = [1, 2, 0, 2] ∧
    target1235.elements.length = 4 ∧
    [target1235.elements.count 0, target1235.elements.count 1,
      target1235.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1235
def tree1236 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 0) (.leaf 2)))
def target1236 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1236 : accepts tree1236 target1236 = true ∧
    sourceLeaves tree1236 = [1, 2, 0, 2] ∧
    target1236.elements.length = 4 ∧
    [target1236.elements.count 0, target1236.elements.count 1,
      target1236.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1236
def tree1237 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))) (.leaf 2))
def target1237 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1237 : accepts tree1237 target1237 = true ∧
    sourceLeaves tree1237 = [1, 2, 0, 2] ∧
    target1237.elements.length = 4 ∧
    [target1237.elements.count 0, target1237.elements.count 1,
      target1237.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1237
def tree1238 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target1238 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1238 : accepts tree1238 target1238 = true ∧
    sourceLeaves tree1238 = [1, 2, 0, 2] ∧
    target1238.elements.length = 4 ∧
    [target1238.elements.count 0, target1238.elements.count 1,
      target1238.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1238
def tree1239 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))))
def target1239 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1239 : accepts tree1239 target1239 = true ∧
    sourceLeaves tree1239 = [1, 2, 1, 0] ∧
    target1239.elements.length = 4 ∧
    [target1239.elements.count 0, target1239.elements.count 1,
      target1239.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1239
def tree1240 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)))
def target1240 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1240 : accepts tree1240 target1240 = true ∧
    sourceLeaves tree1240 = [1, 2, 1, 0] ∧
    target1240.elements.length = 4 ∧
    [target1240.elements.count 0, target1240.elements.count 1,
      target1240.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1240
def tree1241 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 1) (.leaf 0)))
def target1241 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1241 : accepts tree1241 target1241 = true ∧
    sourceLeaves tree1241 = [1, 2, 1, 0] ∧
    target1241.elements.length = 4 ∧
    [target1241.elements.count 0, target1241.elements.count 1,
      target1241.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1241
def tree1242 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))) (.leaf 0))
def target1242 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1242 : accepts tree1242 target1242 = true ∧
    sourceLeaves tree1242 = [1, 2, 1, 0] ∧
    target1242.elements.length = 4 ∧
    [target1242.elements.count 0, target1242.elements.count 1,
      target1242.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1242
def tree1243 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target1243 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1243 : accepts tree1243 target1243 = true ∧
    sourceLeaves tree1243 = [1, 2, 1, 0] ∧
    target1243.elements.length = 4 ∧
    [target1243.elements.count 0, target1243.elements.count 1,
      target1243.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1243
def tree1244 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))))
def target1244 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1244 : accepts tree1244 target1244 = true ∧
    sourceLeaves tree1244 = [1, 2, 1, 1] ∧
    target1244.elements.length = 4 ∧
    [target1244.elements.count 0, target1244.elements.count 1,
      target1244.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1244
def tree1245 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)))
def target1245 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1245 : accepts tree1245 target1245 = true ∧
    sourceLeaves tree1245 = [1, 2, 1, 1] ∧
    target1245.elements.length = 4 ∧
    [target1245.elements.count 0, target1245.elements.count 1,
      target1245.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1245
def tree1246 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 1) (.leaf 1)))
def target1246 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1246 : accepts tree1246 target1246 = true ∧
    sourceLeaves tree1246 = [1, 2, 1, 1] ∧
    target1246.elements.length = 4 ∧
    [target1246.elements.count 0, target1246.elements.count 1,
      target1246.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1246
def tree1247 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))) (.leaf 1))
def target1247 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1247 : accepts tree1247 target1247 = true ∧
    sourceLeaves tree1247 = [1, 2, 1, 1] ∧
    target1247.elements.length = 4 ∧
    [target1247.elements.count 0, target1247.elements.count 1,
      target1247.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1247
def tree1248 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target1248 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1248 : accepts tree1248 target1248 = true ∧
    sourceLeaves tree1248 = [1, 2, 1, 1] ∧
    target1248.elements.length = 4 ∧
    [target1248.elements.count 0, target1248.elements.count 1,
      target1248.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1248
def tree1249 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))))
def target1249 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1249 : accepts tree1249 target1249 = true ∧
    sourceLeaves tree1249 = [1, 2, 1, 2] ∧
    target1249.elements.length = 4 ∧
    [target1249.elements.count 0, target1249.elements.count 1,
      target1249.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1249
def tree1250 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)))
def target1250 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1250 : accepts tree1250 target1250 = true ∧
    sourceLeaves tree1250 = [1, 2, 1, 2] ∧
    target1250.elements.length = 4 ∧
    [target1250.elements.count 0, target1250.elements.count 1,
      target1250.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1250
def tree1251 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 1) (.leaf 2)))
def target1251 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1251 : accepts tree1251 target1251 = true ∧
    sourceLeaves tree1251 = [1, 2, 1, 2] ∧
    target1251.elements.length = 4 ∧
    [target1251.elements.count 0, target1251.elements.count 1,
      target1251.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1251
def tree1252 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))) (.leaf 2))
def target1252 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1252 : accepts tree1252 target1252 = true ∧
    sourceLeaves tree1252 = [1, 2, 1, 2] ∧
    target1252.elements.length = 4 ∧
    [target1252.elements.count 0, target1252.elements.count 1,
      target1252.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1252
def tree1253 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target1253 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1253 : accepts tree1253 target1253 = true ∧
    sourceLeaves tree1253 = [1, 2, 1, 2] ∧
    target1253.elements.length = 4 ∧
    [target1253.elements.count 0, target1253.elements.count 1,
      target1253.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1253
def tree1254 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))))
def target1254 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1254 : accepts tree1254 target1254 = true ∧
    sourceLeaves tree1254 = [1, 2, 2, 0] ∧
    target1254.elements.length = 4 ∧
    [target1254.elements.count 0, target1254.elements.count 1,
      target1254.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1254
def tree1255 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)))
def target1255 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1255 : accepts tree1255 target1255 = true ∧
    sourceLeaves tree1255 = [1, 2, 2, 0] ∧
    target1255.elements.length = 4 ∧
    [target1255.elements.count 0, target1255.elements.count 1,
      target1255.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1255
def tree1256 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 2) (.leaf 0)))
def target1256 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1256 : accepts tree1256 target1256 = true ∧
    sourceLeaves tree1256 = [1, 2, 2, 0] ∧
    target1256.elements.length = 4 ∧
    [target1256.elements.count 0, target1256.elements.count 1,
      target1256.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1256
def tree1257 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))) (.leaf 0))
def target1257 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1257 : accepts tree1257 target1257 = true ∧
    sourceLeaves tree1257 = [1, 2, 2, 0] ∧
    target1257.elements.length = 4 ∧
    [target1257.elements.count 0, target1257.elements.count 1,
      target1257.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1257
def tree1258 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target1258 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1258 : accepts tree1258 target1258 = true ∧
    sourceLeaves tree1258 = [1, 2, 2, 0] ∧
    target1258.elements.length = 4 ∧
    [target1258.elements.count 0, target1258.elements.count 1,
      target1258.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1258
def tree1259 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))))
def target1259 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1259 : accepts tree1259 target1259 = true ∧
    sourceLeaves tree1259 = [1, 2, 2, 1] ∧
    target1259.elements.length = 4 ∧
    [target1259.elements.count 0, target1259.elements.count 1,
      target1259.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1259
def tree1260 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)))
def target1260 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1260 : accepts tree1260 target1260 = true ∧
    sourceLeaves tree1260 = [1, 2, 2, 1] ∧
    target1260.elements.length = 4 ∧
    [target1260.elements.count 0, target1260.elements.count 1,
      target1260.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1260
def tree1261 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 2) (.leaf 1)))
def target1261 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1261 : accepts tree1261 target1261 = true ∧
    sourceLeaves tree1261 = [1, 2, 2, 1] ∧
    target1261.elements.length = 4 ∧
    [target1261.elements.count 0, target1261.elements.count 1,
      target1261.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1261
def tree1262 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))) (.leaf 1))
def target1262 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1262 : accepts tree1262 target1262 = true ∧
    sourceLeaves tree1262 = [1, 2, 2, 1] ∧
    target1262.elements.length = 4 ∧
    [target1262.elements.count 0, target1262.elements.count 1,
      target1262.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1262
def tree1263 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target1263 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1263 : accepts tree1263 target1263 = true ∧
    sourceLeaves tree1263 = [1, 2, 2, 1] ∧
    target1263.elements.length = 4 ∧
    [target1263.elements.count 0, target1263.elements.count 1,
      target1263.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1263
def tree1264 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))))
def target1264 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1264 : accepts tree1264 target1264 = true ∧
    sourceLeaves tree1264 = [1, 2, 2, 2] ∧
    target1264.elements.length = 4 ∧
    [target1264.elements.count 0, target1264.elements.count 1,
      target1264.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1264
def tree1265 : SourceTree Nat .join := (.app .join (.leaf 1) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)))
def target1265 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1265 : accepts tree1265 target1265 = true ∧
    sourceLeaves tree1265 = [1, 2, 2, 2] ∧
    target1265.elements.length = 4 ∧
    [target1265.elements.count 0, target1265.elements.count 1,
      target1265.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1265
def tree1266 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 2)) (.app .join (.leaf 2) (.leaf 2)))
def target1266 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1266 : accepts tree1266 target1266 = true ∧
    sourceLeaves tree1266 = [1, 2, 2, 2] ∧
    target1266.elements.length = 4 ∧
    [target1266.elements.count 0, target1266.elements.count 1,
      target1266.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1266
def tree1267 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))) (.leaf 2))
def target1267 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1267 : accepts tree1267 target1267 = true ∧
    sourceLeaves tree1267 = [1, 2, 2, 2] ∧
    target1267.elements.length = 4 ∧
    [target1267.elements.count 0, target1267.elements.count 1,
      target1267.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1267
def tree1268 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target1268 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1268 : accepts tree1268 target1268 = true ∧
    sourceLeaves tree1268 = [1, 2, 2, 2] ∧
    target1268.elements.length = 4 ∧
    [target1268.elements.count 0, target1268.elements.count 1,
      target1268.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1268
def tree1269 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 0))))
def target1269 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1269 : accepts tree1269 target1269 = true ∧
    sourceLeaves tree1269 = [2, 0, 0, 0] ∧
    target1269.elements.length = 4 ∧
    [target1269.elements.count 0, target1269.elements.count 1,
      target1269.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1269
def tree1270 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 0)))
def target1270 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1270 : accepts tree1270 target1270 = true ∧
    sourceLeaves tree1270 = [2, 0, 0, 0] ∧
    target1270.elements.length = 4 ∧
    [target1270.elements.count 0, target1270.elements.count 1,
      target1270.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1270
def tree1271 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 0) (.leaf 0)))
def target1271 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1271 : accepts tree1271 target1271 = true ∧
    sourceLeaves tree1271 = [2, 0, 0, 0] ∧
    target1271.elements.length = 4 ∧
    [target1271.elements.count 0, target1271.elements.count 1,
      target1271.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1271
def tree1272 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))) (.leaf 0))
def target1272 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1272 : accepts tree1272 target1272 = true ∧
    sourceLeaves tree1272 = [2, 0, 0, 0] ∧
    target1272.elements.length = 4 ∧
    [target1272.elements.count 0, target1272.elements.count 1,
      target1272.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1272
def tree1273 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target1273 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1273 : accepts tree1273 target1273 = true ∧
    sourceLeaves tree1273 = [2, 0, 0, 0] ∧
    target1273.elements.length = 4 ∧
    [target1273.elements.count 0, target1273.elements.count 1,
      target1273.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1273
def tree1274 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 1))))
def target1274 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1274 : accepts tree1274 target1274 = true ∧
    sourceLeaves tree1274 = [2, 0, 0, 1] ∧
    target1274.elements.length = 4 ∧
    [target1274.elements.count 0, target1274.elements.count 1,
      target1274.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1274
def tree1275 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 1)))
def target1275 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1275 : accepts tree1275 target1275 = true ∧
    sourceLeaves tree1275 = [2, 0, 0, 1] ∧
    target1275.elements.length = 4 ∧
    [target1275.elements.count 0, target1275.elements.count 1,
      target1275.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1275
def tree1276 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 0) (.leaf 1)))
def target1276 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1276 : accepts tree1276 target1276 = true ∧
    sourceLeaves tree1276 = [2, 0, 0, 1] ∧
    target1276.elements.length = 4 ∧
    [target1276.elements.count 0, target1276.elements.count 1,
      target1276.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1276
def tree1277 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))) (.leaf 1))
def target1277 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1277 : accepts tree1277 target1277 = true ∧
    sourceLeaves tree1277 = [2, 0, 0, 1] ∧
    target1277.elements.length = 4 ∧
    [target1277.elements.count 0, target1277.elements.count 1,
      target1277.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1277
def tree1278 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target1278 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1278 : accepts tree1278 target1278 = true ∧
    sourceLeaves tree1278 = [2, 0, 0, 1] ∧
    target1278.elements.length = 4 ∧
    [target1278.elements.count 0, target1278.elements.count 1,
      target1278.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1278
def tree1279 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 0) (.leaf 2))))
def target1279 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1279 : accepts tree1279 target1279 = true ∧
    sourceLeaves tree1279 = [2, 0, 0, 2] ∧
    target1279.elements.length = 4 ∧
    [target1279.elements.count 0, target1279.elements.count 1,
      target1279.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1279
def tree1280 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 0)) (.leaf 2)))
def target1280 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1280 : accepts tree1280 target1280 = true ∧
    sourceLeaves tree1280 = [2, 0, 0, 2] ∧
    target1280.elements.length = 4 ∧
    [target1280.elements.count 0, target1280.elements.count 1,
      target1280.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1280
def tree1281 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 0) (.leaf 2)))
def target1281 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1281 : accepts tree1281 target1281 = true ∧
    sourceLeaves tree1281 = [2, 0, 0, 2] ∧
    target1281.elements.length = 4 ∧
    [target1281.elements.count 0, target1281.elements.count 1,
      target1281.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1281
def tree1282 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))) (.leaf 2))
def target1282 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1282 : accepts tree1282 target1282 = true ∧
    sourceLeaves tree1282 = [2, 0, 0, 2] ∧
    target1282.elements.length = 4 ∧
    [target1282.elements.count 0, target1282.elements.count 1,
      target1282.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1282
def tree1283 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target1283 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1283 : accepts tree1283 target1283 = true ∧
    sourceLeaves tree1283 = [2, 0, 0, 2] ∧
    target1283.elements.length = 4 ∧
    [target1283.elements.count 0, target1283.elements.count 1,
      target1283.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1283
def tree1284 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0))))
def target1284 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1284 : accepts tree1284 target1284 = true ∧
    sourceLeaves tree1284 = [2, 0, 1, 0] ∧
    target1284.elements.length = 4 ∧
    [target1284.elements.count 0, target1284.elements.count 1,
      target1284.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1284
def tree1285 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0)))
def target1285 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1285 : accepts tree1285 target1285 = true ∧
    sourceLeaves tree1285 = [2, 0, 1, 0] ∧
    target1285.elements.length = 4 ∧
    [target1285.elements.count 0, target1285.elements.count 1,
      target1285.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1285
def tree1286 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 1) (.leaf 0)))
def target1286 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1286 : accepts tree1286 target1286 = true ∧
    sourceLeaves tree1286 = [2, 0, 1, 0] ∧
    target1286.elements.length = 4 ∧
    [target1286.elements.count 0, target1286.elements.count 1,
      target1286.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1286
def tree1287 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))) (.leaf 0))
def target1287 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1287 : accepts tree1287 target1287 = true ∧
    sourceLeaves tree1287 = [2, 0, 1, 0] ∧
    target1287.elements.length = 4 ∧
    [target1287.elements.count 0, target1287.elements.count 1,
      target1287.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1287
def tree1288 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target1288 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1288 : accepts tree1288 target1288 = true ∧
    sourceLeaves tree1288 = [2, 0, 1, 0] ∧
    target1288.elements.length = 4 ∧
    [target1288.elements.count 0, target1288.elements.count 1,
      target1288.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1288
def tree1289 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 1))))
def target1289 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1289 : accepts tree1289 target1289 = true ∧
    sourceLeaves tree1289 = [2, 0, 1, 1] ∧
    target1289.elements.length = 4 ∧
    [target1289.elements.count 0, target1289.elements.count 1,
      target1289.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1289
def tree1290 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1)))
def target1290 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1290 : accepts tree1290 target1290 = true ∧
    sourceLeaves tree1290 = [2, 0, 1, 1] ∧
    target1290.elements.length = 4 ∧
    [target1290.elements.count 0, target1290.elements.count 1,
      target1290.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1290
def tree1291 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 1) (.leaf 1)))
def target1291 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1291 : accepts tree1291 target1291 = true ∧
    sourceLeaves tree1291 = [2, 0, 1, 1] ∧
    target1291.elements.length = 4 ∧
    [target1291.elements.count 0, target1291.elements.count 1,
      target1291.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1291
def tree1292 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))) (.leaf 1))
def target1292 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1292 : accepts tree1292 target1292 = true ∧
    sourceLeaves tree1292 = [2, 0, 1, 1] ∧
    target1292.elements.length = 4 ∧
    [target1292.elements.count 0, target1292.elements.count 1,
      target1292.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1292
def tree1293 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target1293 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1293 : accepts tree1293 target1293 = true ∧
    sourceLeaves tree1293 = [2, 0, 1, 1] ∧
    target1293.elements.length = 4 ∧
    [target1293.elements.count 0, target1293.elements.count 1,
      target1293.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1293
def tree1294 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 2))))
def target1294 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1294 : accepts tree1294 target1294 = true ∧
    sourceLeaves tree1294 = [2, 0, 1, 2] ∧
    target1294.elements.length = 4 ∧
    [target1294.elements.count 0, target1294.elements.count 1,
      target1294.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1294
def tree1295 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 2)))
def target1295 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1295 : accepts tree1295 target1295 = true ∧
    sourceLeaves tree1295 = [2, 0, 1, 2] ∧
    target1295.elements.length = 4 ∧
    [target1295.elements.count 0, target1295.elements.count 1,
      target1295.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1295
def tree1296 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 1) (.leaf 2)))
def target1296 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1296 : accepts tree1296 target1296 = true ∧
    sourceLeaves tree1296 = [2, 0, 1, 2] ∧
    target1296.elements.length = 4 ∧
    [target1296.elements.count 0, target1296.elements.count 1,
      target1296.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1296
def tree1297 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))) (.leaf 2))
def target1297 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1297 : accepts tree1297 target1297 = true ∧
    sourceLeaves tree1297 = [2, 0, 1, 2] ∧
    target1297.elements.length = 4 ∧
    [target1297.elements.count 0, target1297.elements.count 1,
      target1297.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1297
def tree1298 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target1298 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1298 : accepts tree1298 target1298 = true ∧
    sourceLeaves tree1298 = [2, 0, 1, 2] ∧
    target1298.elements.length = 4 ∧
    [target1298.elements.count 0, target1298.elements.count 1,
      target1298.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1298
def tree1299 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 0))))
def target1299 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1299 : accepts tree1299 target1299 = true ∧
    sourceLeaves tree1299 = [2, 0, 2, 0] ∧
    target1299.elements.length = 4 ∧
    [target1299.elements.count 0, target1299.elements.count 1,
      target1299.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1299
def tree1300 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 0)))
def target1300 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1300 : accepts tree1300 target1300 = true ∧
    sourceLeaves tree1300 = [2, 0, 2, 0] ∧
    target1300.elements.length = 4 ∧
    [target1300.elements.count 0, target1300.elements.count 1,
      target1300.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1300
def tree1301 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 2) (.leaf 0)))
def target1301 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1301 : accepts tree1301 target1301 = true ∧
    sourceLeaves tree1301 = [2, 0, 2, 0] ∧
    target1301.elements.length = 4 ∧
    [target1301.elements.count 0, target1301.elements.count 1,
      target1301.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1301
def tree1302 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))) (.leaf 0))
def target1302 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1302 : accepts tree1302 target1302 = true ∧
    sourceLeaves tree1302 = [2, 0, 2, 0] ∧
    target1302.elements.length = 4 ∧
    [target1302.elements.count 0, target1302.elements.count 1,
      target1302.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1302
def tree1303 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target1303 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1303 : accepts tree1303 target1303 = true ∧
    sourceLeaves tree1303 = [2, 0, 2, 0] ∧
    target1303.elements.length = 4 ∧
    [target1303.elements.count 0, target1303.elements.count 1,
      target1303.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1303
def tree1304 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 1))))
def target1304 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1304 : accepts tree1304 target1304 = true ∧
    sourceLeaves tree1304 = [2, 0, 2, 1] ∧
    target1304.elements.length = 4 ∧
    [target1304.elements.count 0, target1304.elements.count 1,
      target1304.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1304
def tree1305 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 1)))
def target1305 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1305 : accepts tree1305 target1305 = true ∧
    sourceLeaves tree1305 = [2, 0, 2, 1] ∧
    target1305.elements.length = 4 ∧
    [target1305.elements.count 0, target1305.elements.count 1,
      target1305.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1305
def tree1306 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 2) (.leaf 1)))
def target1306 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1306 : accepts tree1306 target1306 = true ∧
    sourceLeaves tree1306 = [2, 0, 2, 1] ∧
    target1306.elements.length = 4 ∧
    [target1306.elements.count 0, target1306.elements.count 1,
      target1306.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1306
def tree1307 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))) (.leaf 1))
def target1307 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1307 : accepts tree1307 target1307 = true ∧
    sourceLeaves tree1307 = [2, 0, 2, 1] ∧
    target1307.elements.length = 4 ∧
    [target1307.elements.count 0, target1307.elements.count 1,
      target1307.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1307
def tree1308 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target1308 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1308 : accepts tree1308 target1308 = true ∧
    sourceLeaves tree1308 = [2, 0, 2, 1] ∧
    target1308.elements.length = 4 ∧
    [target1308.elements.count 0, target1308.elements.count 1,
      target1308.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1308
def tree1309 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 0) (.app .join (.leaf 2) (.leaf 2))))
def target1309 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1309 : accepts tree1309 target1309 = true ∧
    sourceLeaves tree1309 = [2, 0, 2, 2] ∧
    target1309.elements.length = 4 ∧
    [target1309.elements.count 0, target1309.elements.count 1,
      target1309.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1309
def tree1310 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 0) (.leaf 2)) (.leaf 2)))
def target1310 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1310 : accepts tree1310 target1310 = true ∧
    sourceLeaves tree1310 = [2, 0, 2, 2] ∧
    target1310.elements.length = 4 ∧
    [target1310.elements.count 0, target1310.elements.count 1,
      target1310.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1310
def tree1311 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 0)) (.app .join (.leaf 2) (.leaf 2)))
def target1311 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1311 : accepts tree1311 target1311 = true ∧
    sourceLeaves tree1311 = [2, 0, 2, 2] ∧
    target1311.elements.length = 4 ∧
    [target1311.elements.count 0, target1311.elements.count 1,
      target1311.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1311
def tree1312 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))) (.leaf 2))
def target1312 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1312 : accepts tree1312 target1312 = true ∧
    sourceLeaves tree1312 = [2, 0, 2, 2] ∧
    target1312.elements.length = 4 ∧
    [target1312.elements.count 0, target1312.elements.count 1,
      target1312.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1312
def tree1313 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target1313 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1313 : accepts tree1313 target1313 = true ∧
    sourceLeaves tree1313 = [2, 0, 2, 2] ∧
    target1313.elements.length = 4 ∧
    [target1313.elements.count 0, target1313.elements.count 1,
      target1313.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1313
def tree1314 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 0))))
def target1314 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1314 : accepts tree1314 target1314 = true ∧
    sourceLeaves tree1314 = [2, 1, 0, 0] ∧
    target1314.elements.length = 4 ∧
    [target1314.elements.count 0, target1314.elements.count 1,
      target1314.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1314
def tree1315 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0)))
def target1315 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1315 : accepts tree1315 target1315 = true ∧
    sourceLeaves tree1315 = [2, 1, 0, 0] ∧
    target1315.elements.length = 4 ∧
    [target1315.elements.count 0, target1315.elements.count 1,
      target1315.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1315
def tree1316 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 0) (.leaf 0)))
def target1316 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1316 : accepts tree1316 target1316 = true ∧
    sourceLeaves tree1316 = [2, 1, 0, 0] ∧
    target1316.elements.length = 4 ∧
    [target1316.elements.count 0, target1316.elements.count 1,
      target1316.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1316
def tree1317 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))) (.leaf 0))
def target1317 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1317 : accepts tree1317 target1317 = true ∧
    sourceLeaves tree1317 = [2, 1, 0, 0] ∧
    target1317.elements.length = 4 ∧
    [target1317.elements.count 0, target1317.elements.count 1,
      target1317.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1317
def tree1318 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target1318 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1318 : accepts tree1318 target1318 = true ∧
    sourceLeaves tree1318 = [2, 1, 0, 0] ∧
    target1318.elements.length = 4 ∧
    [target1318.elements.count 0, target1318.elements.count 1,
      target1318.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1318
def tree1319 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 1))))
def target1319 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1319 : accepts tree1319 target1319 = true ∧
    sourceLeaves tree1319 = [2, 1, 0, 1] ∧
    target1319.elements.length = 4 ∧
    [target1319.elements.count 0, target1319.elements.count 1,
      target1319.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1319
def tree1320 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 1)))
def target1320 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1320 : accepts tree1320 target1320 = true ∧
    sourceLeaves tree1320 = [2, 1, 0, 1] ∧
    target1320.elements.length = 4 ∧
    [target1320.elements.count 0, target1320.elements.count 1,
      target1320.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1320
def tree1321 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 0) (.leaf 1)))
def target1321 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1321 : accepts tree1321 target1321 = true ∧
    sourceLeaves tree1321 = [2, 1, 0, 1] ∧
    target1321.elements.length = 4 ∧
    [target1321.elements.count 0, target1321.elements.count 1,
      target1321.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1321
def tree1322 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))) (.leaf 1))
def target1322 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1322 : accepts tree1322 target1322 = true ∧
    sourceLeaves tree1322 = [2, 1, 0, 1] ∧
    target1322.elements.length = 4 ∧
    [target1322.elements.count 0, target1322.elements.count 1,
      target1322.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1322
def tree1323 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target1323 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1323 : accepts tree1323 target1323 = true ∧
    sourceLeaves tree1323 = [2, 1, 0, 1] ∧
    target1323.elements.length = 4 ∧
    [target1323.elements.count 0, target1323.elements.count 1,
      target1323.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1323
def tree1324 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 0) (.leaf 2))))
def target1324 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1324 : accepts tree1324 target1324 = true ∧
    sourceLeaves tree1324 = [2, 1, 0, 2] ∧
    target1324.elements.length = 4 ∧
    [target1324.elements.count 0, target1324.elements.count 1,
      target1324.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1324
def tree1325 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 2)))
def target1325 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1325 : accepts tree1325 target1325 = true ∧
    sourceLeaves tree1325 = [2, 1, 0, 2] ∧
    target1325.elements.length = 4 ∧
    [target1325.elements.count 0, target1325.elements.count 1,
      target1325.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1325
def tree1326 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 0) (.leaf 2)))
def target1326 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1326 : accepts tree1326 target1326 = true ∧
    sourceLeaves tree1326 = [2, 1, 0, 2] ∧
    target1326.elements.length = 4 ∧
    [target1326.elements.count 0, target1326.elements.count 1,
      target1326.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1326
def tree1327 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))) (.leaf 2))
def target1327 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1327 : accepts tree1327 target1327 = true ∧
    sourceLeaves tree1327 = [2, 1, 0, 2] ∧
    target1327.elements.length = 4 ∧
    [target1327.elements.count 0, target1327.elements.count 1,
      target1327.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1327
def tree1328 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target1328 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1328 : accepts tree1328 target1328 = true ∧
    sourceLeaves tree1328 = [2, 1, 0, 2] ∧
    target1328.elements.length = 4 ∧
    [target1328.elements.count 0, target1328.elements.count 1,
      target1328.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1328
def tree1329 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 0))))
def target1329 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1329 : accepts tree1329 target1329 = true ∧
    sourceLeaves tree1329 = [2, 1, 1, 0] ∧
    target1329.elements.length = 4 ∧
    [target1329.elements.count 0, target1329.elements.count 1,
      target1329.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1329
def tree1330 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 0)))
def target1330 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1330 : accepts tree1330 target1330 = true ∧
    sourceLeaves tree1330 = [2, 1, 1, 0] ∧
    target1330.elements.length = 4 ∧
    [target1330.elements.count 0, target1330.elements.count 1,
      target1330.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1330
def tree1331 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 1) (.leaf 0)))
def target1331 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1331 : accepts tree1331 target1331 = true ∧
    sourceLeaves tree1331 = [2, 1, 1, 0] ∧
    target1331.elements.length = 4 ∧
    [target1331.elements.count 0, target1331.elements.count 1,
      target1331.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1331
def tree1332 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))) (.leaf 0))
def target1332 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1332 : accepts tree1332 target1332 = true ∧
    sourceLeaves tree1332 = [2, 1, 1, 0] ∧
    target1332.elements.length = 4 ∧
    [target1332.elements.count 0, target1332.elements.count 1,
      target1332.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1332
def tree1333 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target1333 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1333 : accepts tree1333 target1333 = true ∧
    sourceLeaves tree1333 = [2, 1, 1, 0] ∧
    target1333.elements.length = 4 ∧
    [target1333.elements.count 0, target1333.elements.count 1,
      target1333.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1333
def tree1334 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 1))))
def target1334 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1334 : accepts tree1334 target1334 = true ∧
    sourceLeaves tree1334 = [2, 1, 1, 1] ∧
    target1334.elements.length = 4 ∧
    [target1334.elements.count 0, target1334.elements.count 1,
      target1334.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1334
def tree1335 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 1)))
def target1335 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1335 : accepts tree1335 target1335 = true ∧
    sourceLeaves tree1335 = [2, 1, 1, 1] ∧
    target1335.elements.length = 4 ∧
    [target1335.elements.count 0, target1335.elements.count 1,
      target1335.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1335
def tree1336 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 1) (.leaf 1)))
def target1336 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1336 : accepts tree1336 target1336 = true ∧
    sourceLeaves tree1336 = [2, 1, 1, 1] ∧
    target1336.elements.length = 4 ∧
    [target1336.elements.count 0, target1336.elements.count 1,
      target1336.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1336
def tree1337 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))) (.leaf 1))
def target1337 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1337 : accepts tree1337 target1337 = true ∧
    sourceLeaves tree1337 = [2, 1, 1, 1] ∧
    target1337.elements.length = 4 ∧
    [target1337.elements.count 0, target1337.elements.count 1,
      target1337.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1337
def tree1338 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target1338 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1338 : accepts tree1338 target1338 = true ∧
    sourceLeaves tree1338 = [2, 1, 1, 1] ∧
    target1338.elements.length = 4 ∧
    [target1338.elements.count 0, target1338.elements.count 1,
      target1338.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1338
def tree1339 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 1) (.leaf 2))))
def target1339 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1339 : accepts tree1339 target1339 = true ∧
    sourceLeaves tree1339 = [2, 1, 1, 2] ∧
    target1339.elements.length = 4 ∧
    [target1339.elements.count 0, target1339.elements.count 1,
      target1339.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1339
def tree1340 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 1)) (.leaf 2)))
def target1340 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1340 : accepts tree1340 target1340 = true ∧
    sourceLeaves tree1340 = [2, 1, 1, 2] ∧
    target1340.elements.length = 4 ∧
    [target1340.elements.count 0, target1340.elements.count 1,
      target1340.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1340
def tree1341 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 1) (.leaf 2)))
def target1341 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1341 : accepts tree1341 target1341 = true ∧
    sourceLeaves tree1341 = [2, 1, 1, 2] ∧
    target1341.elements.length = 4 ∧
    [target1341.elements.count 0, target1341.elements.count 1,
      target1341.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1341
def tree1342 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))) (.leaf 2))
def target1342 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1342 : accepts tree1342 target1342 = true ∧
    sourceLeaves tree1342 = [2, 1, 1, 2] ∧
    target1342.elements.length = 4 ∧
    [target1342.elements.count 0, target1342.elements.count 1,
      target1342.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1342
def tree1343 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target1343 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1343 : accepts tree1343 target1343 = true ∧
    sourceLeaves tree1343 = [2, 1, 1, 2] ∧
    target1343.elements.length = 4 ∧
    [target1343.elements.count 0, target1343.elements.count 1,
      target1343.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1343
def tree1344 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 0))))
def target1344 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1344 : accepts tree1344 target1344 = true ∧
    sourceLeaves tree1344 = [2, 1, 2, 0] ∧
    target1344.elements.length = 4 ∧
    [target1344.elements.count 0, target1344.elements.count 1,
      target1344.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1344
def tree1345 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 0)))
def target1345 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1345 : accepts tree1345 target1345 = true ∧
    sourceLeaves tree1345 = [2, 1, 2, 0] ∧
    target1345.elements.length = 4 ∧
    [target1345.elements.count 0, target1345.elements.count 1,
      target1345.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1345
def tree1346 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 2) (.leaf 0)))
def target1346 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1346 : accepts tree1346 target1346 = true ∧
    sourceLeaves tree1346 = [2, 1, 2, 0] ∧
    target1346.elements.length = 4 ∧
    [target1346.elements.count 0, target1346.elements.count 1,
      target1346.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1346
def tree1347 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))) (.leaf 0))
def target1347 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1347 : accepts tree1347 target1347 = true ∧
    sourceLeaves tree1347 = [2, 1, 2, 0] ∧
    target1347.elements.length = 4 ∧
    [target1347.elements.count 0, target1347.elements.count 1,
      target1347.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1347
def tree1348 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target1348 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1348 : accepts tree1348 target1348 = true ∧
    sourceLeaves tree1348 = [2, 1, 2, 0] ∧
    target1348.elements.length = 4 ∧
    [target1348.elements.count 0, target1348.elements.count 1,
      target1348.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1348
def tree1349 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 1))))
def target1349 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1349 : accepts tree1349 target1349 = true ∧
    sourceLeaves tree1349 = [2, 1, 2, 1] ∧
    target1349.elements.length = 4 ∧
    [target1349.elements.count 0, target1349.elements.count 1,
      target1349.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1349
def tree1350 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 1)))
def target1350 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1350 : accepts tree1350 target1350 = true ∧
    sourceLeaves tree1350 = [2, 1, 2, 1] ∧
    target1350.elements.length = 4 ∧
    [target1350.elements.count 0, target1350.elements.count 1,
      target1350.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1350
def tree1351 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 2) (.leaf 1)))
def target1351 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1351 : accepts tree1351 target1351 = true ∧
    sourceLeaves tree1351 = [2, 1, 2, 1] ∧
    target1351.elements.length = 4 ∧
    [target1351.elements.count 0, target1351.elements.count 1,
      target1351.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1351
def tree1352 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))) (.leaf 1))
def target1352 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1352 : accepts tree1352 target1352 = true ∧
    sourceLeaves tree1352 = [2, 1, 2, 1] ∧
    target1352.elements.length = 4 ∧
    [target1352.elements.count 0, target1352.elements.count 1,
      target1352.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1352
def tree1353 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target1353 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1353 : accepts tree1353 target1353 = true ∧
    sourceLeaves tree1353 = [2, 1, 2, 1] ∧
    target1353.elements.length = 4 ∧
    [target1353.elements.count 0, target1353.elements.count 1,
      target1353.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1353
def tree1354 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 1) (.app .join (.leaf 2) (.leaf 2))))
def target1354 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1354 : accepts tree1354 target1354 = true ∧
    sourceLeaves tree1354 = [2, 1, 2, 2] ∧
    target1354.elements.length = 4 ∧
    [target1354.elements.count 0, target1354.elements.count 1,
      target1354.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1354
def tree1355 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 1) (.leaf 2)) (.leaf 2)))
def target1355 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1355 : accepts tree1355 target1355 = true ∧
    sourceLeaves tree1355 = [2, 1, 2, 2] ∧
    target1355.elements.length = 4 ∧
    [target1355.elements.count 0, target1355.elements.count 1,
      target1355.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1355
def tree1356 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 1)) (.app .join (.leaf 2) (.leaf 2)))
def target1356 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1356 : accepts tree1356 target1356 = true ∧
    sourceLeaves tree1356 = [2, 1, 2, 2] ∧
    target1356.elements.length = 4 ∧
    [target1356.elements.count 0, target1356.elements.count 1,
      target1356.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1356
def tree1357 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))) (.leaf 2))
def target1357 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1357 : accepts tree1357 target1357 = true ∧
    sourceLeaves tree1357 = [2, 1, 2, 2] ∧
    target1357.elements.length = 4 ∧
    [target1357.elements.count 0, target1357.elements.count 1,
      target1357.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1357
def tree1358 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target1358 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1358 : accepts tree1358 target1358 = true ∧
    sourceLeaves tree1358 = [2, 1, 2, 2] ∧
    target1358.elements.length = 4 ∧
    [target1358.elements.count 0, target1358.elements.count 1,
      target1358.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1358
def tree1359 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 0))))
def target1359 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1359 : accepts tree1359 target1359 = true ∧
    sourceLeaves tree1359 = [2, 2, 0, 0] ∧
    target1359.elements.length = 4 ∧
    [target1359.elements.count 0, target1359.elements.count 1,
      target1359.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1359
def tree1360 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 0)))
def target1360 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1360 : accepts tree1360 target1360 = true ∧
    sourceLeaves tree1360 = [2, 2, 0, 0] ∧
    target1360.elements.length = 4 ∧
    [target1360.elements.count 0, target1360.elements.count 1,
      target1360.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1360
def tree1361 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 0) (.leaf 0)))
def target1361 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1361 : accepts tree1361 target1361 = true ∧
    sourceLeaves tree1361 = [2, 2, 0, 0] ∧
    target1361.elements.length = 4 ∧
    [target1361.elements.count 0, target1361.elements.count 1,
      target1361.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1361
def tree1362 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))) (.leaf 0))
def target1362 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1362 : accepts tree1362 target1362 = true ∧
    sourceLeaves tree1362 = [2, 2, 0, 0] ∧
    target1362.elements.length = 4 ∧
    [target1362.elements.count 0, target1362.elements.count 1,
      target1362.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1362
def tree1363 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target1363 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1363 : accepts tree1363 target1363 = true ∧
    sourceLeaves tree1363 = [2, 2, 0, 0] ∧
    target1363.elements.length = 4 ∧
    [target1363.elements.count 0, target1363.elements.count 1,
      target1363.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1363
def tree1364 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 1))))
def target1364 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1364 : accepts tree1364 target1364 = true ∧
    sourceLeaves tree1364 = [2, 2, 0, 1] ∧
    target1364.elements.length = 4 ∧
    [target1364.elements.count 0, target1364.elements.count 1,
      target1364.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1364
def tree1365 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 1)))
def target1365 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1365 : accepts tree1365 target1365 = true ∧
    sourceLeaves tree1365 = [2, 2, 0, 1] ∧
    target1365.elements.length = 4 ∧
    [target1365.elements.count 0, target1365.elements.count 1,
      target1365.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1365
def tree1366 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 0) (.leaf 1)))
def target1366 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1366 : accepts tree1366 target1366 = true ∧
    sourceLeaves tree1366 = [2, 2, 0, 1] ∧
    target1366.elements.length = 4 ∧
    [target1366.elements.count 0, target1366.elements.count 1,
      target1366.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1366
def tree1367 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))) (.leaf 1))
def target1367 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1367 : accepts tree1367 target1367 = true ∧
    sourceLeaves tree1367 = [2, 2, 0, 1] ∧
    target1367.elements.length = 4 ∧
    [target1367.elements.count 0, target1367.elements.count 1,
      target1367.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1367
def tree1368 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target1368 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1368 : accepts tree1368 target1368 = true ∧
    sourceLeaves tree1368 = [2, 2, 0, 1] ∧
    target1368.elements.length = 4 ∧
    [target1368.elements.count 0, target1368.elements.count 1,
      target1368.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1368
def tree1369 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 0) (.leaf 2))))
def target1369 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1369 : accepts tree1369 target1369 = true ∧
    sourceLeaves tree1369 = [2, 2, 0, 2] ∧
    target1369.elements.length = 4 ∧
    [target1369.elements.count 0, target1369.elements.count 1,
      target1369.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1369
def tree1370 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 0)) (.leaf 2)))
def target1370 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1370 : accepts tree1370 target1370 = true ∧
    sourceLeaves tree1370 = [2, 2, 0, 2] ∧
    target1370.elements.length = 4 ∧
    [target1370.elements.count 0, target1370.elements.count 1,
      target1370.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1370
def tree1371 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 0) (.leaf 2)))
def target1371 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1371 : accepts tree1371 target1371 = true ∧
    sourceLeaves tree1371 = [2, 2, 0, 2] ∧
    target1371.elements.length = 4 ∧
    [target1371.elements.count 0, target1371.elements.count 1,
      target1371.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1371
def tree1372 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))) (.leaf 2))
def target1372 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1372 : accepts tree1372 target1372 = true ∧
    sourceLeaves tree1372 = [2, 2, 0, 2] ∧
    target1372.elements.length = 4 ∧
    [target1372.elements.count 0, target1372.elements.count 1,
      target1372.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1372
def tree1373 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target1373 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1373 : accepts tree1373 target1373 = true ∧
    sourceLeaves tree1373 = [2, 2, 0, 2] ∧
    target1373.elements.length = 4 ∧
    [target1373.elements.count 0, target1373.elements.count 1,
      target1373.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1373
def tree1374 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 0))))
def target1374 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1374 : accepts tree1374 target1374 = true ∧
    sourceLeaves tree1374 = [2, 2, 1, 0] ∧
    target1374.elements.length = 4 ∧
    [target1374.elements.count 0, target1374.elements.count 1,
      target1374.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1374
def tree1375 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 0)))
def target1375 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1375 : accepts tree1375 target1375 = true ∧
    sourceLeaves tree1375 = [2, 2, 1, 0] ∧
    target1375.elements.length = 4 ∧
    [target1375.elements.count 0, target1375.elements.count 1,
      target1375.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1375
def tree1376 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 1) (.leaf 0)))
def target1376 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1376 : accepts tree1376 target1376 = true ∧
    sourceLeaves tree1376 = [2, 2, 1, 0] ∧
    target1376.elements.length = 4 ∧
    [target1376.elements.count 0, target1376.elements.count 1,
      target1376.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1376
def tree1377 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))) (.leaf 0))
def target1377 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1377 : accepts tree1377 target1377 = true ∧
    sourceLeaves tree1377 = [2, 2, 1, 0] ∧
    target1377.elements.length = 4 ∧
    [target1377.elements.count 0, target1377.elements.count 1,
      target1377.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1377
def tree1378 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target1378 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1378 : accepts tree1378 target1378 = true ∧
    sourceLeaves tree1378 = [2, 2, 1, 0] ∧
    target1378.elements.length = 4 ∧
    [target1378.elements.count 0, target1378.elements.count 1,
      target1378.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1378
def tree1379 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 1))))
def target1379 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1379 : accepts tree1379 target1379 = true ∧
    sourceLeaves tree1379 = [2, 2, 1, 1] ∧
    target1379.elements.length = 4 ∧
    [target1379.elements.count 0, target1379.elements.count 1,
      target1379.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1379
def tree1380 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 1)))
def target1380 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1380 : accepts tree1380 target1380 = true ∧
    sourceLeaves tree1380 = [2, 2, 1, 1] ∧
    target1380.elements.length = 4 ∧
    [target1380.elements.count 0, target1380.elements.count 1,
      target1380.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1380
def tree1381 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 1) (.leaf 1)))
def target1381 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1381 : accepts tree1381 target1381 = true ∧
    sourceLeaves tree1381 = [2, 2, 1, 1] ∧
    target1381.elements.length = 4 ∧
    [target1381.elements.count 0, target1381.elements.count 1,
      target1381.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1381
def tree1382 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))) (.leaf 1))
def target1382 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1382 : accepts tree1382 target1382 = true ∧
    sourceLeaves tree1382 = [2, 2, 1, 1] ∧
    target1382.elements.length = 4 ∧
    [target1382.elements.count 0, target1382.elements.count 1,
      target1382.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1382
def tree1383 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target1383 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1383 : accepts tree1383 target1383 = true ∧
    sourceLeaves tree1383 = [2, 2, 1, 1] ∧
    target1383.elements.length = 4 ∧
    [target1383.elements.count 0, target1383.elements.count 1,
      target1383.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1383
def tree1384 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 1) (.leaf 2))))
def target1384 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1384 : accepts tree1384 target1384 = true ∧
    sourceLeaves tree1384 = [2, 2, 1, 2] ∧
    target1384.elements.length = 4 ∧
    [target1384.elements.count 0, target1384.elements.count 1,
      target1384.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1384
def tree1385 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 1)) (.leaf 2)))
def target1385 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1385 : accepts tree1385 target1385 = true ∧
    sourceLeaves tree1385 = [2, 2, 1, 2] ∧
    target1385.elements.length = 4 ∧
    [target1385.elements.count 0, target1385.elements.count 1,
      target1385.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1385
def tree1386 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 1) (.leaf 2)))
def target1386 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1386 : accepts tree1386 target1386 = true ∧
    sourceLeaves tree1386 = [2, 2, 1, 2] ∧
    target1386.elements.length = 4 ∧
    [target1386.elements.count 0, target1386.elements.count 1,
      target1386.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1386
def tree1387 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))) (.leaf 2))
def target1387 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1387 : accepts tree1387 target1387 = true ∧
    sourceLeaves tree1387 = [2, 2, 1, 2] ∧
    target1387.elements.length = 4 ∧
    [target1387.elements.count 0, target1387.elements.count 1,
      target1387.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1387
def tree1388 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target1388 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1388 : accepts tree1388 target1388 = true ∧
    sourceLeaves tree1388 = [2, 2, 1, 2] ∧
    target1388.elements.length = 4 ∧
    [target1388.elements.count 0, target1388.elements.count 1,
      target1388.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1388
def tree1389 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 0))))
def target1389 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1389 : accepts tree1389 target1389 = true ∧
    sourceLeaves tree1389 = [2, 2, 2, 0] ∧
    target1389.elements.length = 4 ∧
    [target1389.elements.count 0, target1389.elements.count 1,
      target1389.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1389
def tree1390 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 0)))
def target1390 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1390 : accepts tree1390 target1390 = true ∧
    sourceLeaves tree1390 = [2, 2, 2, 0] ∧
    target1390.elements.length = 4 ∧
    [target1390.elements.count 0, target1390.elements.count 1,
      target1390.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1390
def tree1391 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 2) (.leaf 0)))
def target1391 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1391 : accepts tree1391 target1391 = true ∧
    sourceLeaves tree1391 = [2, 2, 2, 0] ∧
    target1391.elements.length = 4 ∧
    [target1391.elements.count 0, target1391.elements.count 1,
      target1391.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1391
def tree1392 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))) (.leaf 0))
def target1392 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1392 : accepts tree1392 target1392 = true ∧
    sourceLeaves tree1392 = [2, 2, 2, 0] ∧
    target1392.elements.length = 4 ∧
    [target1392.elements.count 0, target1392.elements.count 1,
      target1392.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1392
def tree1393 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target1393 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1393 : accepts tree1393 target1393 = true ∧
    sourceLeaves tree1393 = [2, 2, 2, 0] ∧
    target1393.elements.length = 4 ∧
    [target1393.elements.count 0, target1393.elements.count 1,
      target1393.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1393
def tree1394 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 1))))
def target1394 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1394 : accepts tree1394 target1394 = true ∧
    sourceLeaves tree1394 = [2, 2, 2, 1] ∧
    target1394.elements.length = 4 ∧
    [target1394.elements.count 0, target1394.elements.count 1,
      target1394.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1394
def tree1395 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 1)))
def target1395 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1395 : accepts tree1395 target1395 = true ∧
    sourceLeaves tree1395 = [2, 2, 2, 1] ∧
    target1395.elements.length = 4 ∧
    [target1395.elements.count 0, target1395.elements.count 1,
      target1395.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1395
def tree1396 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 2) (.leaf 1)))
def target1396 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1396 : accepts tree1396 target1396 = true ∧
    sourceLeaves tree1396 = [2, 2, 2, 1] ∧
    target1396.elements.length = 4 ∧
    [target1396.elements.count 0, target1396.elements.count 1,
      target1396.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1396
def tree1397 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))) (.leaf 1))
def target1397 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1397 : accepts tree1397 target1397 = true ∧
    sourceLeaves tree1397 = [2, 2, 2, 1] ∧
    target1397.elements.length = 4 ∧
    [target1397.elements.count 0, target1397.elements.count 1,
      target1397.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1397
def tree1398 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target1398 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1398 : accepts tree1398 target1398 = true ∧
    sourceLeaves tree1398 = [2, 2, 2, 1] ∧
    target1398.elements.length = 4 ∧
    [target1398.elements.count 0, target1398.elements.count 1,
      target1398.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1398
def tree1399 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))))
def target1399 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1399 : accepts tree1399 target1399 = true ∧
    sourceLeaves tree1399 = [2, 2, 2, 2] ∧
    target1399.elements.length = 4 ∧
    [target1399.elements.count 0, target1399.elements.count 1,
      target1399.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1399
def tree1400 : SourceTree Nat .join := (.app .join (.leaf 2) (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)))
def target1400 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1400 : accepts tree1400 target1400 = true ∧
    sourceLeaves tree1400 = [2, 2, 2, 2] ∧
    target1400.elements.length = 4 ∧
    [target1400.elements.count 0, target1400.elements.count 1,
      target1400.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1400
def tree1401 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.leaf 2)) (.app .join (.leaf 2) (.leaf 2)))
def target1401 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1401 : accepts tree1401 target1401 = true ∧
    sourceLeaves tree1401 = [2, 2, 2, 2] ∧
    target1401.elements.length = 4 ∧
    [target1401.elements.count 0, target1401.elements.count 1,
      target1401.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1401
def tree1402 : SourceTree Nat .join := (.app .join (.app .join (.leaf 2) (.app .join (.leaf 2) (.leaf 2))) (.leaf 2))
def target1402 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1402 : accepts tree1402 target1402 = true ∧
    sourceLeaves tree1402 = [2, 2, 2, 2] ∧
    target1402.elements.length = 4 ∧
    [target1402.elements.count 0, target1402.elements.count 1,
      target1402.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1402
def tree1403 : SourceTree Nat .join := (.app .join (.app .join (.app .join (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target1403 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1403 : accepts tree1403 target1403 = true ∧
    sourceLeaves tree1403 = [2, 2, 2, 2] ∧
    target1403.elements.length = 4 ∧
    [target1403.elements.count 0, target1403.elements.count 1,
      target1403.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1403
def tree1404 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 0))
def target1404 : Target Nat := ⟨.seq, [0, 0]⟩
theorem chain1404 : accepts tree1404 target1404 = true ∧
    sourceLeaves tree1404 = [0, 0] ∧
    target1404.elements.length = 2 ∧
    [target1404.elements.count 0, target1404.elements.count 1,
      target1404.elements.count 2] = [2, 0, 0] := by decide
#print axioms chain1404
def tree1405 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 1))
def target1405 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain1405 : accepts tree1405 target1405 = true ∧
    sourceLeaves tree1405 = [0, 1] ∧
    target1405.elements.length = 2 ∧
    [target1405.elements.count 0, target1405.elements.count 1,
      target1405.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1405
def tree1406 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 2))
def target1406 : Target Nat := ⟨.seq, [0, 2]⟩
theorem chain1406 : accepts tree1406 target1406 = true ∧
    sourceLeaves tree1406 = [0, 2] ∧
    target1406.elements.length = 2 ∧
    [target1406.elements.count 0, target1406.elements.count 1,
      target1406.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain1406
def tree1407 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.leaf 0))
def target1407 : Target Nat := ⟨.seq, [1, 0]⟩
theorem chain1407 : accepts tree1407 target1407 = true ∧
    sourceLeaves tree1407 = [1, 0] ∧
    target1407.elements.length = 2 ∧
    [target1407.elements.count 0, target1407.elements.count 1,
      target1407.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1407
def tree1408 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.leaf 1))
def target1408 : Target Nat := ⟨.seq, [1, 1]⟩
theorem chain1408 : accepts tree1408 target1408 = true ∧
    sourceLeaves tree1408 = [1, 1] ∧
    target1408.elements.length = 2 ∧
    [target1408.elements.count 0, target1408.elements.count 1,
      target1408.elements.count 2] = [0, 2, 0] := by decide
#print axioms chain1408
def tree1409 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.leaf 2))
def target1409 : Target Nat := ⟨.seq, [1, 2]⟩
theorem chain1409 : accepts tree1409 target1409 = true ∧
    sourceLeaves tree1409 = [1, 2] ∧
    target1409.elements.length = 2 ∧
    [target1409.elements.count 0, target1409.elements.count 1,
      target1409.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain1409
def tree1410 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.leaf 0))
def target1410 : Target Nat := ⟨.seq, [2, 0]⟩
theorem chain1410 : accepts tree1410 target1410 = true ∧
    sourceLeaves tree1410 = [2, 0] ∧
    target1410.elements.length = 2 ∧
    [target1410.elements.count 0, target1410.elements.count 1,
      target1410.elements.count 2] = [1, 0, 1] := by decide
#print axioms chain1410
def tree1411 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.leaf 1))
def target1411 : Target Nat := ⟨.seq, [2, 1]⟩
theorem chain1411 : accepts tree1411 target1411 = true ∧
    sourceLeaves tree1411 = [2, 1] ∧
    target1411.elements.length = 2 ∧
    [target1411.elements.count 0, target1411.elements.count 1,
      target1411.elements.count 2] = [0, 1, 1] := by decide
#print axioms chain1411
def tree1412 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.leaf 2))
def target1412 : Target Nat := ⟨.seq, [2, 2]⟩
theorem chain1412 : accepts tree1412 target1412 = true ∧
    sourceLeaves tree1412 = [2, 2] ∧
    target1412.elements.length = 2 ∧
    [target1412.elements.count 0, target1412.elements.count 1,
      target1412.elements.count 2] = [0, 0, 2] := by decide
#print axioms chain1412
def tree1413 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0)))
def target1413 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain1413 : accepts tree1413 target1413 = true ∧
    sourceLeaves tree1413 = [0, 0, 0] ∧
    target1413.elements.length = 3 ∧
    [target1413.elements.count 0, target1413.elements.count 1,
      target1413.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain1413
def tree1414 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0))
def target1414 : Target Nat := ⟨.seq, [0, 0, 0]⟩
theorem chain1414 : accepts tree1414 target1414 = true ∧
    sourceLeaves tree1414 = [0, 0, 0] ∧
    target1414.elements.length = 3 ∧
    [target1414.elements.count 0, target1414.elements.count 1,
      target1414.elements.count 2] = [3, 0, 0] := by decide
#print axioms chain1414
def tree1415 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1)))
def target1415 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain1415 : accepts tree1415 target1415 = true ∧
    sourceLeaves tree1415 = [0, 0, 1] ∧
    target1415.elements.length = 3 ∧
    [target1415.elements.count 0, target1415.elements.count 1,
      target1415.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1415
def tree1416 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1))
def target1416 : Target Nat := ⟨.seq, [0, 0, 1]⟩
theorem chain1416 : accepts tree1416 target1416 = true ∧
    sourceLeaves tree1416 = [0, 0, 1] ∧
    target1416.elements.length = 3 ∧
    [target1416.elements.count 0, target1416.elements.count 1,
      target1416.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1416
def tree1417 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2)))
def target1417 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain1417 : accepts tree1417 target1417 = true ∧
    sourceLeaves tree1417 = [0, 0, 2] ∧
    target1417.elements.length = 3 ∧
    [target1417.elements.count 0, target1417.elements.count 1,
      target1417.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain1417
def tree1418 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2))
def target1418 : Target Nat := ⟨.seq, [0, 0, 2]⟩
theorem chain1418 : accepts tree1418 target1418 = true ∧
    sourceLeaves tree1418 = [0, 0, 2] ∧
    target1418.elements.length = 3 ∧
    [target1418.elements.count 0, target1418.elements.count 1,
      target1418.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain1418
def tree1419 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0)))
def target1419 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1419 : accepts tree1419 target1419 = true ∧
    sourceLeaves tree1419 = [0, 1, 0] ∧
    target1419.elements.length = 3 ∧
    [target1419.elements.count 0, target1419.elements.count 1,
      target1419.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1419
def tree1420 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0))
def target1420 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1420 : accepts tree1420 target1420 = true ∧
    sourceLeaves tree1420 = [0, 1, 0] ∧
    target1420.elements.length = 3 ∧
    [target1420.elements.count 0, target1420.elements.count 1,
      target1420.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1420
def tree1421 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1)))
def target1421 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain1421 : accepts tree1421 target1421 = true ∧
    sourceLeaves tree1421 = [0, 1, 1] ∧
    target1421.elements.length = 3 ∧
    [target1421.elements.count 0, target1421.elements.count 1,
      target1421.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1421
def tree1422 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1))
def target1422 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain1422 : accepts tree1422 target1422 = true ∧
    sourceLeaves tree1422 = [0, 1, 1] ∧
    target1422.elements.length = 3 ∧
    [target1422.elements.count 0, target1422.elements.count 1,
      target1422.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1422
def tree1423 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2)))
def target1423 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain1423 : accepts tree1423 target1423 = true ∧
    sourceLeaves tree1423 = [0, 1, 2] ∧
    target1423.elements.length = 3 ∧
    [target1423.elements.count 0, target1423.elements.count 1,
      target1423.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1423
def tree1424 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2))
def target1424 : Target Nat := ⟨.seq, [0, 1, 2]⟩
theorem chain1424 : accepts tree1424 target1424 = true ∧
    sourceLeaves tree1424 = [0, 1, 2] ∧
    target1424.elements.length = 3 ∧
    [target1424.elements.count 0, target1424.elements.count 1,
      target1424.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1424
def tree1425 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0)))
def target1425 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain1425 : accepts tree1425 target1425 = true ∧
    sourceLeaves tree1425 = [0, 2, 0] ∧
    target1425.elements.length = 3 ∧
    [target1425.elements.count 0, target1425.elements.count 1,
      target1425.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain1425
def tree1426 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0))
def target1426 : Target Nat := ⟨.seq, [0, 2, 0]⟩
theorem chain1426 : accepts tree1426 target1426 = true ∧
    sourceLeaves tree1426 = [0, 2, 0] ∧
    target1426.elements.length = 3 ∧
    [target1426.elements.count 0, target1426.elements.count 1,
      target1426.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain1426
def tree1427 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1)))
def target1427 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain1427 : accepts tree1427 target1427 = true ∧
    sourceLeaves tree1427 = [0, 2, 1] ∧
    target1427.elements.length = 3 ∧
    [target1427.elements.count 0, target1427.elements.count 1,
      target1427.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1427
def tree1428 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1))
def target1428 : Target Nat := ⟨.seq, [0, 2, 1]⟩
theorem chain1428 : accepts tree1428 target1428 = true ∧
    sourceLeaves tree1428 = [0, 2, 1] ∧
    target1428.elements.length = 3 ∧
    [target1428.elements.count 0, target1428.elements.count 1,
      target1428.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1428
def tree1429 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2)))
def target1429 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain1429 : accepts tree1429 target1429 = true ∧
    sourceLeaves tree1429 = [0, 2, 2] ∧
    target1429.elements.length = 3 ∧
    [target1429.elements.count 0, target1429.elements.count 1,
      target1429.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain1429
def tree1430 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2))
def target1430 : Target Nat := ⟨.seq, [0, 2, 2]⟩
theorem chain1430 : accepts tree1430 target1430 = true ∧
    sourceLeaves tree1430 = [0, 2, 2] ∧
    target1430.elements.length = 3 ∧
    [target1430.elements.count 0, target1430.elements.count 1,
      target1430.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain1430
def tree1431 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0)))
def target1431 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain1431 : accepts tree1431 target1431 = true ∧
    sourceLeaves tree1431 = [1, 0, 0] ∧
    target1431.elements.length = 3 ∧
    [target1431.elements.count 0, target1431.elements.count 1,
      target1431.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1431
def tree1432 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0))
def target1432 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain1432 : accepts tree1432 target1432 = true ∧
    sourceLeaves tree1432 = [1, 0, 0] ∧
    target1432.elements.length = 3 ∧
    [target1432.elements.count 0, target1432.elements.count 1,
      target1432.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1432
def tree1433 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1)))
def target1433 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain1433 : accepts tree1433 target1433 = true ∧
    sourceLeaves tree1433 = [1, 0, 1] ∧
    target1433.elements.length = 3 ∧
    [target1433.elements.count 0, target1433.elements.count 1,
      target1433.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1433
def tree1434 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1))
def target1434 : Target Nat := ⟨.seq, [1, 0, 1]⟩
theorem chain1434 : accepts tree1434 target1434 = true ∧
    sourceLeaves tree1434 = [1, 0, 1] ∧
    target1434.elements.length = 3 ∧
    [target1434.elements.count 0, target1434.elements.count 1,
      target1434.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1434
def tree1435 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2)))
def target1435 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain1435 : accepts tree1435 target1435 = true ∧
    sourceLeaves tree1435 = [1, 0, 2] ∧
    target1435.elements.length = 3 ∧
    [target1435.elements.count 0, target1435.elements.count 1,
      target1435.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1435
def tree1436 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2))
def target1436 : Target Nat := ⟨.seq, [1, 0, 2]⟩
theorem chain1436 : accepts tree1436 target1436 = true ∧
    sourceLeaves tree1436 = [1, 0, 2] ∧
    target1436.elements.length = 3 ∧
    [target1436.elements.count 0, target1436.elements.count 1,
      target1436.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1436
def tree1437 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0)))
def target1437 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain1437 : accepts tree1437 target1437 = true ∧
    sourceLeaves tree1437 = [1, 1, 0] ∧
    target1437.elements.length = 3 ∧
    [target1437.elements.count 0, target1437.elements.count 1,
      target1437.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1437
def tree1438 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0))
def target1438 : Target Nat := ⟨.seq, [1, 1, 0]⟩
theorem chain1438 : accepts tree1438 target1438 = true ∧
    sourceLeaves tree1438 = [1, 1, 0] ∧
    target1438.elements.length = 3 ∧
    [target1438.elements.count 0, target1438.elements.count 1,
      target1438.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1438
def tree1439 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1)))
def target1439 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain1439 : accepts tree1439 target1439 = true ∧
    sourceLeaves tree1439 = [1, 1, 1] ∧
    target1439.elements.length = 3 ∧
    [target1439.elements.count 0, target1439.elements.count 1,
      target1439.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain1439
def tree1440 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1))
def target1440 : Target Nat := ⟨.seq, [1, 1, 1]⟩
theorem chain1440 : accepts tree1440 target1440 = true ∧
    sourceLeaves tree1440 = [1, 1, 1] ∧
    target1440.elements.length = 3 ∧
    [target1440.elements.count 0, target1440.elements.count 1,
      target1440.elements.count 2] = [0, 3, 0] := by decide
#print axioms chain1440
def tree1441 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2)))
def target1441 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain1441 : accepts tree1441 target1441 = true ∧
    sourceLeaves tree1441 = [1, 1, 2] ∧
    target1441.elements.length = 3 ∧
    [target1441.elements.count 0, target1441.elements.count 1,
      target1441.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain1441
def tree1442 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2))
def target1442 : Target Nat := ⟨.seq, [1, 1, 2]⟩
theorem chain1442 : accepts tree1442 target1442 = true ∧
    sourceLeaves tree1442 = [1, 1, 2] ∧
    target1442.elements.length = 3 ∧
    [target1442.elements.count 0, target1442.elements.count 1,
      target1442.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain1442
def tree1443 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0)))
def target1443 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain1443 : accepts tree1443 target1443 = true ∧
    sourceLeaves tree1443 = [1, 2, 0] ∧
    target1443.elements.length = 3 ∧
    [target1443.elements.count 0, target1443.elements.count 1,
      target1443.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1443
def tree1444 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0))
def target1444 : Target Nat := ⟨.seq, [1, 2, 0]⟩
theorem chain1444 : accepts tree1444 target1444 = true ∧
    sourceLeaves tree1444 = [1, 2, 0] ∧
    target1444.elements.length = 3 ∧
    [target1444.elements.count 0, target1444.elements.count 1,
      target1444.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1444
def tree1445 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1)))
def target1445 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain1445 : accepts tree1445 target1445 = true ∧
    sourceLeaves tree1445 = [1, 2, 1] ∧
    target1445.elements.length = 3 ∧
    [target1445.elements.count 0, target1445.elements.count 1,
      target1445.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain1445
def tree1446 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1))
def target1446 : Target Nat := ⟨.seq, [1, 2, 1]⟩
theorem chain1446 : accepts tree1446 target1446 = true ∧
    sourceLeaves tree1446 = [1, 2, 1] ∧
    target1446.elements.length = 3 ∧
    [target1446.elements.count 0, target1446.elements.count 1,
      target1446.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain1446
def tree1447 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2)))
def target1447 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain1447 : accepts tree1447 target1447 = true ∧
    sourceLeaves tree1447 = [1, 2, 2] ∧
    target1447.elements.length = 3 ∧
    [target1447.elements.count 0, target1447.elements.count 1,
      target1447.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain1447
def tree1448 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2))
def target1448 : Target Nat := ⟨.seq, [1, 2, 2]⟩
theorem chain1448 : accepts tree1448 target1448 = true ∧
    sourceLeaves tree1448 = [1, 2, 2] ∧
    target1448.elements.length = 3 ∧
    [target1448.elements.count 0, target1448.elements.count 1,
      target1448.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain1448
def tree1449 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0)))
def target1449 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain1449 : accepts tree1449 target1449 = true ∧
    sourceLeaves tree1449 = [2, 0, 0] ∧
    target1449.elements.length = 3 ∧
    [target1449.elements.count 0, target1449.elements.count 1,
      target1449.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain1449
def tree1450 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0))
def target1450 : Target Nat := ⟨.seq, [2, 0, 0]⟩
theorem chain1450 : accepts tree1450 target1450 = true ∧
    sourceLeaves tree1450 = [2, 0, 0] ∧
    target1450.elements.length = 3 ∧
    [target1450.elements.count 0, target1450.elements.count 1,
      target1450.elements.count 2] = [2, 0, 1] := by decide
#print axioms chain1450
def tree1451 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1)))
def target1451 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain1451 : accepts tree1451 target1451 = true ∧
    sourceLeaves tree1451 = [2, 0, 1] ∧
    target1451.elements.length = 3 ∧
    [target1451.elements.count 0, target1451.elements.count 1,
      target1451.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1451
def tree1452 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1))
def target1452 : Target Nat := ⟨.seq, [2, 0, 1]⟩
theorem chain1452 : accepts tree1452 target1452 = true ∧
    sourceLeaves tree1452 = [2, 0, 1] ∧
    target1452.elements.length = 3 ∧
    [target1452.elements.count 0, target1452.elements.count 1,
      target1452.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1452
def tree1453 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2)))
def target1453 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain1453 : accepts tree1453 target1453 = true ∧
    sourceLeaves tree1453 = [2, 0, 2] ∧
    target1453.elements.length = 3 ∧
    [target1453.elements.count 0, target1453.elements.count 1,
      target1453.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain1453
def tree1454 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2))
def target1454 : Target Nat := ⟨.seq, [2, 0, 2]⟩
theorem chain1454 : accepts tree1454 target1454 = true ∧
    sourceLeaves tree1454 = [2, 0, 2] ∧
    target1454.elements.length = 3 ∧
    [target1454.elements.count 0, target1454.elements.count 1,
      target1454.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain1454
def tree1455 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0)))
def target1455 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain1455 : accepts tree1455 target1455 = true ∧
    sourceLeaves tree1455 = [2, 1, 0] ∧
    target1455.elements.length = 3 ∧
    [target1455.elements.count 0, target1455.elements.count 1,
      target1455.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1455
def tree1456 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0))
def target1456 : Target Nat := ⟨.seq, [2, 1, 0]⟩
theorem chain1456 : accepts tree1456 target1456 = true ∧
    sourceLeaves tree1456 = [2, 1, 0] ∧
    target1456.elements.length = 3 ∧
    [target1456.elements.count 0, target1456.elements.count 1,
      target1456.elements.count 2] = [1, 1, 1] := by decide
#print axioms chain1456
def tree1457 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1)))
def target1457 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain1457 : accepts tree1457 target1457 = true ∧
    sourceLeaves tree1457 = [2, 1, 1] ∧
    target1457.elements.length = 3 ∧
    [target1457.elements.count 0, target1457.elements.count 1,
      target1457.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain1457
def tree1458 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1))
def target1458 : Target Nat := ⟨.seq, [2, 1, 1]⟩
theorem chain1458 : accepts tree1458 target1458 = true ∧
    sourceLeaves tree1458 = [2, 1, 1] ∧
    target1458.elements.length = 3 ∧
    [target1458.elements.count 0, target1458.elements.count 1,
      target1458.elements.count 2] = [0, 2, 1] := by decide
#print axioms chain1458
def tree1459 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2)))
def target1459 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain1459 : accepts tree1459 target1459 = true ∧
    sourceLeaves tree1459 = [2, 1, 2] ∧
    target1459.elements.length = 3 ∧
    [target1459.elements.count 0, target1459.elements.count 1,
      target1459.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain1459
def tree1460 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2))
def target1460 : Target Nat := ⟨.seq, [2, 1, 2]⟩
theorem chain1460 : accepts tree1460 target1460 = true ∧
    sourceLeaves tree1460 = [2, 1, 2] ∧
    target1460.elements.length = 3 ∧
    [target1460.elements.count 0, target1460.elements.count 1,
      target1460.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain1460
def tree1461 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0)))
def target1461 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain1461 : accepts tree1461 target1461 = true ∧
    sourceLeaves tree1461 = [2, 2, 0] ∧
    target1461.elements.length = 3 ∧
    [target1461.elements.count 0, target1461.elements.count 1,
      target1461.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain1461
def tree1462 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0))
def target1462 : Target Nat := ⟨.seq, [2, 2, 0]⟩
theorem chain1462 : accepts tree1462 target1462 = true ∧
    sourceLeaves tree1462 = [2, 2, 0] ∧
    target1462.elements.length = 3 ∧
    [target1462.elements.count 0, target1462.elements.count 1,
      target1462.elements.count 2] = [1, 0, 2] := by decide
#print axioms chain1462
def tree1463 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1)))
def target1463 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain1463 : accepts tree1463 target1463 = true ∧
    sourceLeaves tree1463 = [2, 2, 1] ∧
    target1463.elements.length = 3 ∧
    [target1463.elements.count 0, target1463.elements.count 1,
      target1463.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain1463
def tree1464 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1))
def target1464 : Target Nat := ⟨.seq, [2, 2, 1]⟩
theorem chain1464 : accepts tree1464 target1464 = true ∧
    sourceLeaves tree1464 = [2, 2, 1] ∧
    target1464.elements.length = 3 ∧
    [target1464.elements.count 0, target1464.elements.count 1,
      target1464.elements.count 2] = [0, 1, 2] := by decide
#print axioms chain1464
def tree1465 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2)))
def target1465 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain1465 : accepts tree1465 target1465 = true ∧
    sourceLeaves tree1465 = [2, 2, 2] ∧
    target1465.elements.length = 3 ∧
    [target1465.elements.count 0, target1465.elements.count 1,
      target1465.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain1465
def tree1466 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2))
def target1466 : Target Nat := ⟨.seq, [2, 2, 2]⟩
theorem chain1466 : accepts tree1466 target1466 = true ∧
    sourceLeaves tree1466 = [2, 2, 2] ∧
    target1466.elements.length = 3 ∧
    [target1466.elements.count 0, target1466.elements.count 1,
      target1466.elements.count 2] = [0, 0, 3] := by decide
#print axioms chain1466
def tree1467 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))))
def target1467 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1467 : accepts tree1467 target1467 = true ∧
    sourceLeaves tree1467 = [0, 0, 0, 0] ∧
    target1467.elements.length = 4 ∧
    [target1467.elements.count 0, target1467.elements.count 1,
      target1467.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1467
def tree1468 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)))
def target1468 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1468 : accepts tree1468 target1468 = true ∧
    sourceLeaves tree1468 = [0, 0, 0, 0] ∧
    target1468.elements.length = 4 ∧
    [target1468.elements.count 0, target1468.elements.count 1,
      target1468.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1468
def tree1469 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1469 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1469 : accepts tree1469 target1469 = true ∧
    sourceLeaves tree1469 = [0, 0, 0, 0] ∧
    target1469.elements.length = 4 ∧
    [target1469.elements.count 0, target1469.elements.count 1,
      target1469.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1469
def tree1470 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 0))
def target1470 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1470 : accepts tree1470 target1470 = true ∧
    sourceLeaves tree1470 = [0, 0, 0, 0] ∧
    target1470.elements.length = 4 ∧
    [target1470.elements.count 0, target1470.elements.count 1,
      target1470.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1470
def tree1471 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target1471 : Target Nat := ⟨.seq, [0, 0, 0, 0]⟩
theorem chain1471 : accepts tree1471 target1471 = true ∧
    sourceLeaves tree1471 = [0, 0, 0, 0] ∧
    target1471.elements.length = 4 ∧
    [target1471.elements.count 0, target1471.elements.count 1,
      target1471.elements.count 2] = [4, 0, 0] := by decide
#print axioms chain1471
def tree1472 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))))
def target1472 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1472 : accepts tree1472 target1472 = true ∧
    sourceLeaves tree1472 = [0, 0, 0, 1] ∧
    target1472.elements.length = 4 ∧
    [target1472.elements.count 0, target1472.elements.count 1,
      target1472.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1472
def tree1473 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)))
def target1473 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1473 : accepts tree1473 target1473 = true ∧
    sourceLeaves tree1473 = [0, 0, 0, 1] ∧
    target1473.elements.length = 4 ∧
    [target1473.elements.count 0, target1473.elements.count 1,
      target1473.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1473
def tree1474 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1474 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1474 : accepts tree1474 target1474 = true ∧
    sourceLeaves tree1474 = [0, 0, 0, 1] ∧
    target1474.elements.length = 4 ∧
    [target1474.elements.count 0, target1474.elements.count 1,
      target1474.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1474
def tree1475 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 1))
def target1475 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1475 : accepts tree1475 target1475 = true ∧
    sourceLeaves tree1475 = [0, 0, 0, 1] ∧
    target1475.elements.length = 4 ∧
    [target1475.elements.count 0, target1475.elements.count 1,
      target1475.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1475
def tree1476 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target1476 : Target Nat := ⟨.seq, [0, 0, 0, 1]⟩
theorem chain1476 : accepts tree1476 target1476 = true ∧
    sourceLeaves tree1476 = [0, 0, 0, 1] ∧
    target1476.elements.length = 4 ∧
    [target1476.elements.count 0, target1476.elements.count 1,
      target1476.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1476
def tree1477 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))))
def target1477 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1477 : accepts tree1477 target1477 = true ∧
    sourceLeaves tree1477 = [0, 0, 0, 2] ∧
    target1477.elements.length = 4 ∧
    [target1477.elements.count 0, target1477.elements.count 1,
      target1477.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1477
def tree1478 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)))
def target1478 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1478 : accepts tree1478 target1478 = true ∧
    sourceLeaves tree1478 = [0, 0, 0, 2] ∧
    target1478.elements.length = 4 ∧
    [target1478.elements.count 0, target1478.elements.count 1,
      target1478.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1478
def tree1479 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1479 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1479 : accepts tree1479 target1479 = true ∧
    sourceLeaves tree1479 = [0, 0, 0, 2] ∧
    target1479.elements.length = 4 ∧
    [target1479.elements.count 0, target1479.elements.count 1,
      target1479.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1479
def tree1480 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 2))
def target1480 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1480 : accepts tree1480 target1480 = true ∧
    sourceLeaves tree1480 = [0, 0, 0, 2] ∧
    target1480.elements.length = 4 ∧
    [target1480.elements.count 0, target1480.elements.count 1,
      target1480.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1480
def tree1481 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target1481 : Target Nat := ⟨.seq, [0, 0, 0, 2]⟩
theorem chain1481 : accepts tree1481 target1481 = true ∧
    sourceLeaves tree1481 = [0, 0, 0, 2] ∧
    target1481.elements.length = 4 ∧
    [target1481.elements.count 0, target1481.elements.count 1,
      target1481.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1481
def tree1482 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))))
def target1482 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1482 : accepts tree1482 target1482 = true ∧
    sourceLeaves tree1482 = [0, 0, 1, 0] ∧
    target1482.elements.length = 4 ∧
    [target1482.elements.count 0, target1482.elements.count 1,
      target1482.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1482
def tree1483 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)))
def target1483 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1483 : accepts tree1483 target1483 = true ∧
    sourceLeaves tree1483 = [0, 0, 1, 0] ∧
    target1483.elements.length = 4 ∧
    [target1483.elements.count 0, target1483.elements.count 1,
      target1483.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1483
def tree1484 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1484 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1484 : accepts tree1484 target1484 = true ∧
    sourceLeaves tree1484 = [0, 0, 1, 0] ∧
    target1484.elements.length = 4 ∧
    [target1484.elements.count 0, target1484.elements.count 1,
      target1484.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1484
def tree1485 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 0))
def target1485 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1485 : accepts tree1485 target1485 = true ∧
    sourceLeaves tree1485 = [0, 0, 1, 0] ∧
    target1485.elements.length = 4 ∧
    [target1485.elements.count 0, target1485.elements.count 1,
      target1485.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1485
def tree1486 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target1486 : Target Nat := ⟨.seq, [0, 0, 1, 0]⟩
theorem chain1486 : accepts tree1486 target1486 = true ∧
    sourceLeaves tree1486 = [0, 0, 1, 0] ∧
    target1486.elements.length = 4 ∧
    [target1486.elements.count 0, target1486.elements.count 1,
      target1486.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1486
def tree1487 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))))
def target1487 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1487 : accepts tree1487 target1487 = true ∧
    sourceLeaves tree1487 = [0, 0, 1, 1] ∧
    target1487.elements.length = 4 ∧
    [target1487.elements.count 0, target1487.elements.count 1,
      target1487.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1487
def tree1488 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)))
def target1488 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1488 : accepts tree1488 target1488 = true ∧
    sourceLeaves tree1488 = [0, 0, 1, 1] ∧
    target1488.elements.length = 4 ∧
    [target1488.elements.count 0, target1488.elements.count 1,
      target1488.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1488
def tree1489 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1489 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1489 : accepts tree1489 target1489 = true ∧
    sourceLeaves tree1489 = [0, 0, 1, 1] ∧
    target1489.elements.length = 4 ∧
    [target1489.elements.count 0, target1489.elements.count 1,
      target1489.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1489
def tree1490 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 1))
def target1490 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1490 : accepts tree1490 target1490 = true ∧
    sourceLeaves tree1490 = [0, 0, 1, 1] ∧
    target1490.elements.length = 4 ∧
    [target1490.elements.count 0, target1490.elements.count 1,
      target1490.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1490
def tree1491 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target1491 : Target Nat := ⟨.seq, [0, 0, 1, 1]⟩
theorem chain1491 : accepts tree1491 target1491 = true ∧
    sourceLeaves tree1491 = [0, 0, 1, 1] ∧
    target1491.elements.length = 4 ∧
    [target1491.elements.count 0, target1491.elements.count 1,
      target1491.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1491
def tree1492 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))))
def target1492 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1492 : accepts tree1492 target1492 = true ∧
    sourceLeaves tree1492 = [0, 0, 1, 2] ∧
    target1492.elements.length = 4 ∧
    [target1492.elements.count 0, target1492.elements.count 1,
      target1492.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1492
def tree1493 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)))
def target1493 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1493 : accepts tree1493 target1493 = true ∧
    sourceLeaves tree1493 = [0, 0, 1, 2] ∧
    target1493.elements.length = 4 ∧
    [target1493.elements.count 0, target1493.elements.count 1,
      target1493.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1493
def tree1494 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1494 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1494 : accepts tree1494 target1494 = true ∧
    sourceLeaves tree1494 = [0, 0, 1, 2] ∧
    target1494.elements.length = 4 ∧
    [target1494.elements.count 0, target1494.elements.count 1,
      target1494.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1494
def tree1495 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 2))
def target1495 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1495 : accepts tree1495 target1495 = true ∧
    sourceLeaves tree1495 = [0, 0, 1, 2] ∧
    target1495.elements.length = 4 ∧
    [target1495.elements.count 0, target1495.elements.count 1,
      target1495.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1495
def tree1496 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target1496 : Target Nat := ⟨.seq, [0, 0, 1, 2]⟩
theorem chain1496 : accepts tree1496 target1496 = true ∧
    sourceLeaves tree1496 = [0, 0, 1, 2] ∧
    target1496.elements.length = 4 ∧
    [target1496.elements.count 0, target1496.elements.count 1,
      target1496.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1496
def tree1497 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))))
def target1497 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1497 : accepts tree1497 target1497 = true ∧
    sourceLeaves tree1497 = [0, 0, 2, 0] ∧
    target1497.elements.length = 4 ∧
    [target1497.elements.count 0, target1497.elements.count 1,
      target1497.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1497
def tree1498 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)))
def target1498 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1498 : accepts tree1498 target1498 = true ∧
    sourceLeaves tree1498 = [0, 0, 2, 0] ∧
    target1498.elements.length = 4 ∧
    [target1498.elements.count 0, target1498.elements.count 1,
      target1498.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1498
def tree1499 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1499 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1499 : accepts tree1499 target1499 = true ∧
    sourceLeaves tree1499 = [0, 0, 2, 0] ∧
    target1499.elements.length = 4 ∧
    [target1499.elements.count 0, target1499.elements.count 1,
      target1499.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1499
def tree1500 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 0))
def target1500 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1500 : accepts tree1500 target1500 = true ∧
    sourceLeaves tree1500 = [0, 0, 2, 0] ∧
    target1500.elements.length = 4 ∧
    [target1500.elements.count 0, target1500.elements.count 1,
      target1500.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1500
def tree1501 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target1501 : Target Nat := ⟨.seq, [0, 0, 2, 0]⟩
theorem chain1501 : accepts tree1501 target1501 = true ∧
    sourceLeaves tree1501 = [0, 0, 2, 0] ∧
    target1501.elements.length = 4 ∧
    [target1501.elements.count 0, target1501.elements.count 1,
      target1501.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1501
def tree1502 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))))
def target1502 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1502 : accepts tree1502 target1502 = true ∧
    sourceLeaves tree1502 = [0, 0, 2, 1] ∧
    target1502.elements.length = 4 ∧
    [target1502.elements.count 0, target1502.elements.count 1,
      target1502.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1502
def tree1503 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)))
def target1503 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1503 : accepts tree1503 target1503 = true ∧
    sourceLeaves tree1503 = [0, 0, 2, 1] ∧
    target1503.elements.length = 4 ∧
    [target1503.elements.count 0, target1503.elements.count 1,
      target1503.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1503
def tree1504 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1504 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1504 : accepts tree1504 target1504 = true ∧
    sourceLeaves tree1504 = [0, 0, 2, 1] ∧
    target1504.elements.length = 4 ∧
    [target1504.elements.count 0, target1504.elements.count 1,
      target1504.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1504
def tree1505 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 1))
def target1505 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1505 : accepts tree1505 target1505 = true ∧
    sourceLeaves tree1505 = [0, 0, 2, 1] ∧
    target1505.elements.length = 4 ∧
    [target1505.elements.count 0, target1505.elements.count 1,
      target1505.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1505
def tree1506 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target1506 : Target Nat := ⟨.seq, [0, 0, 2, 1]⟩
theorem chain1506 : accepts tree1506 target1506 = true ∧
    sourceLeaves tree1506 = [0, 0, 2, 1] ∧
    target1506.elements.length = 4 ∧
    [target1506.elements.count 0, target1506.elements.count 1,
      target1506.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1506
def tree1507 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))))
def target1507 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1507 : accepts tree1507 target1507 = true ∧
    sourceLeaves tree1507 = [0, 0, 2, 2] ∧
    target1507.elements.length = 4 ∧
    [target1507.elements.count 0, target1507.elements.count 1,
      target1507.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1507
def tree1508 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)))
def target1508 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1508 : accepts tree1508 target1508 = true ∧
    sourceLeaves tree1508 = [0, 0, 2, 2] ∧
    target1508.elements.length = 4 ∧
    [target1508.elements.count 0, target1508.elements.count 1,
      target1508.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1508
def tree1509 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1509 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1509 : accepts tree1509 target1509 = true ∧
    sourceLeaves tree1509 = [0, 0, 2, 2] ∧
    target1509.elements.length = 4 ∧
    [target1509.elements.count 0, target1509.elements.count 1,
      target1509.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1509
def tree1510 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 2))
def target1510 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1510 : accepts tree1510 target1510 = true ∧
    sourceLeaves tree1510 = [0, 0, 2, 2] ∧
    target1510.elements.length = 4 ∧
    [target1510.elements.count 0, target1510.elements.count 1,
      target1510.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1510
def tree1511 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target1511 : Target Nat := ⟨.seq, [0, 0, 2, 2]⟩
theorem chain1511 : accepts tree1511 target1511 = true ∧
    sourceLeaves tree1511 = [0, 0, 2, 2] ∧
    target1511.elements.length = 4 ∧
    [target1511.elements.count 0, target1511.elements.count 1,
      target1511.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1511
def tree1512 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))))
def target1512 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1512 : accepts tree1512 target1512 = true ∧
    sourceLeaves tree1512 = [0, 1, 0, 0] ∧
    target1512.elements.length = 4 ∧
    [target1512.elements.count 0, target1512.elements.count 1,
      target1512.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1512
def tree1513 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)))
def target1513 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1513 : accepts tree1513 target1513 = true ∧
    sourceLeaves tree1513 = [0, 1, 0, 0] ∧
    target1513.elements.length = 4 ∧
    [target1513.elements.count 0, target1513.elements.count 1,
      target1513.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1513
def tree1514 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1514 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1514 : accepts tree1514 target1514 = true ∧
    sourceLeaves tree1514 = [0, 1, 0, 0] ∧
    target1514.elements.length = 4 ∧
    [target1514.elements.count 0, target1514.elements.count 1,
      target1514.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1514
def tree1515 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 0))
def target1515 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1515 : accepts tree1515 target1515 = true ∧
    sourceLeaves tree1515 = [0, 1, 0, 0] ∧
    target1515.elements.length = 4 ∧
    [target1515.elements.count 0, target1515.elements.count 1,
      target1515.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1515
def tree1516 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target1516 : Target Nat := ⟨.seq, [0, 1, 0, 0]⟩
theorem chain1516 : accepts tree1516 target1516 = true ∧
    sourceLeaves tree1516 = [0, 1, 0, 0] ∧
    target1516.elements.length = 4 ∧
    [target1516.elements.count 0, target1516.elements.count 1,
      target1516.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1516
def tree1517 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))))
def target1517 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1517 : accepts tree1517 target1517 = true ∧
    sourceLeaves tree1517 = [0, 1, 0, 1] ∧
    target1517.elements.length = 4 ∧
    [target1517.elements.count 0, target1517.elements.count 1,
      target1517.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1517
def tree1518 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)))
def target1518 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1518 : accepts tree1518 target1518 = true ∧
    sourceLeaves tree1518 = [0, 1, 0, 1] ∧
    target1518.elements.length = 4 ∧
    [target1518.elements.count 0, target1518.elements.count 1,
      target1518.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1518
def tree1519 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1519 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1519 : accepts tree1519 target1519 = true ∧
    sourceLeaves tree1519 = [0, 1, 0, 1] ∧
    target1519.elements.length = 4 ∧
    [target1519.elements.count 0, target1519.elements.count 1,
      target1519.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1519
def tree1520 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 1))
def target1520 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1520 : accepts tree1520 target1520 = true ∧
    sourceLeaves tree1520 = [0, 1, 0, 1] ∧
    target1520.elements.length = 4 ∧
    [target1520.elements.count 0, target1520.elements.count 1,
      target1520.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1520
def tree1521 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target1521 : Target Nat := ⟨.seq, [0, 1, 0, 1]⟩
theorem chain1521 : accepts tree1521 target1521 = true ∧
    sourceLeaves tree1521 = [0, 1, 0, 1] ∧
    target1521.elements.length = 4 ∧
    [target1521.elements.count 0, target1521.elements.count 1,
      target1521.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1521
def tree1522 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))))
def target1522 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1522 : accepts tree1522 target1522 = true ∧
    sourceLeaves tree1522 = [0, 1, 0, 2] ∧
    target1522.elements.length = 4 ∧
    [target1522.elements.count 0, target1522.elements.count 1,
      target1522.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1522
def tree1523 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)))
def target1523 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1523 : accepts tree1523 target1523 = true ∧
    sourceLeaves tree1523 = [0, 1, 0, 2] ∧
    target1523.elements.length = 4 ∧
    [target1523.elements.count 0, target1523.elements.count 1,
      target1523.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1523
def tree1524 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1524 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1524 : accepts tree1524 target1524 = true ∧
    sourceLeaves tree1524 = [0, 1, 0, 2] ∧
    target1524.elements.length = 4 ∧
    [target1524.elements.count 0, target1524.elements.count 1,
      target1524.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1524
def tree1525 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 2))
def target1525 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1525 : accepts tree1525 target1525 = true ∧
    sourceLeaves tree1525 = [0, 1, 0, 2] ∧
    target1525.elements.length = 4 ∧
    [target1525.elements.count 0, target1525.elements.count 1,
      target1525.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1525
def tree1526 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target1526 : Target Nat := ⟨.seq, [0, 1, 0, 2]⟩
theorem chain1526 : accepts tree1526 target1526 = true ∧
    sourceLeaves tree1526 = [0, 1, 0, 2] ∧
    target1526.elements.length = 4 ∧
    [target1526.elements.count 0, target1526.elements.count 1,
      target1526.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1526
def tree1527 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))))
def target1527 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1527 : accepts tree1527 target1527 = true ∧
    sourceLeaves tree1527 = [0, 1, 1, 0] ∧
    target1527.elements.length = 4 ∧
    [target1527.elements.count 0, target1527.elements.count 1,
      target1527.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1527
def tree1528 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)))
def target1528 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1528 : accepts tree1528 target1528 = true ∧
    sourceLeaves tree1528 = [0, 1, 1, 0] ∧
    target1528.elements.length = 4 ∧
    [target1528.elements.count 0, target1528.elements.count 1,
      target1528.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1528
def tree1529 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1529 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1529 : accepts tree1529 target1529 = true ∧
    sourceLeaves tree1529 = [0, 1, 1, 0] ∧
    target1529.elements.length = 4 ∧
    [target1529.elements.count 0, target1529.elements.count 1,
      target1529.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1529
def tree1530 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 0))
def target1530 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1530 : accepts tree1530 target1530 = true ∧
    sourceLeaves tree1530 = [0, 1, 1, 0] ∧
    target1530.elements.length = 4 ∧
    [target1530.elements.count 0, target1530.elements.count 1,
      target1530.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1530
def tree1531 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target1531 : Target Nat := ⟨.seq, [0, 1, 1, 0]⟩
theorem chain1531 : accepts tree1531 target1531 = true ∧
    sourceLeaves tree1531 = [0, 1, 1, 0] ∧
    target1531.elements.length = 4 ∧
    [target1531.elements.count 0, target1531.elements.count 1,
      target1531.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1531
def tree1532 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))))
def target1532 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1532 : accepts tree1532 target1532 = true ∧
    sourceLeaves tree1532 = [0, 1, 1, 1] ∧
    target1532.elements.length = 4 ∧
    [target1532.elements.count 0, target1532.elements.count 1,
      target1532.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1532
def tree1533 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)))
def target1533 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1533 : accepts tree1533 target1533 = true ∧
    sourceLeaves tree1533 = [0, 1, 1, 1] ∧
    target1533.elements.length = 4 ∧
    [target1533.elements.count 0, target1533.elements.count 1,
      target1533.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1533
def tree1534 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1534 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1534 : accepts tree1534 target1534 = true ∧
    sourceLeaves tree1534 = [0, 1, 1, 1] ∧
    target1534.elements.length = 4 ∧
    [target1534.elements.count 0, target1534.elements.count 1,
      target1534.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1534
def tree1535 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 1))
def target1535 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1535 : accepts tree1535 target1535 = true ∧
    sourceLeaves tree1535 = [0, 1, 1, 1] ∧
    target1535.elements.length = 4 ∧
    [target1535.elements.count 0, target1535.elements.count 1,
      target1535.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1535
def tree1536 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target1536 : Target Nat := ⟨.seq, [0, 1, 1, 1]⟩
theorem chain1536 : accepts tree1536 target1536 = true ∧
    sourceLeaves tree1536 = [0, 1, 1, 1] ∧
    target1536.elements.length = 4 ∧
    [target1536.elements.count 0, target1536.elements.count 1,
      target1536.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1536
def tree1537 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))))
def target1537 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1537 : accepts tree1537 target1537 = true ∧
    sourceLeaves tree1537 = [0, 1, 1, 2] ∧
    target1537.elements.length = 4 ∧
    [target1537.elements.count 0, target1537.elements.count 1,
      target1537.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1537
def tree1538 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)))
def target1538 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1538 : accepts tree1538 target1538 = true ∧
    sourceLeaves tree1538 = [0, 1, 1, 2] ∧
    target1538.elements.length = 4 ∧
    [target1538.elements.count 0, target1538.elements.count 1,
      target1538.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1538
def tree1539 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1539 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1539 : accepts tree1539 target1539 = true ∧
    sourceLeaves tree1539 = [0, 1, 1, 2] ∧
    target1539.elements.length = 4 ∧
    [target1539.elements.count 0, target1539.elements.count 1,
      target1539.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1539
def tree1540 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 2))
def target1540 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1540 : accepts tree1540 target1540 = true ∧
    sourceLeaves tree1540 = [0, 1, 1, 2] ∧
    target1540.elements.length = 4 ∧
    [target1540.elements.count 0, target1540.elements.count 1,
      target1540.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1540
def tree1541 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target1541 : Target Nat := ⟨.seq, [0, 1, 1, 2]⟩
theorem chain1541 : accepts tree1541 target1541 = true ∧
    sourceLeaves tree1541 = [0, 1, 1, 2] ∧
    target1541.elements.length = 4 ∧
    [target1541.elements.count 0, target1541.elements.count 1,
      target1541.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1541
def tree1542 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))))
def target1542 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1542 : accepts tree1542 target1542 = true ∧
    sourceLeaves tree1542 = [0, 1, 2, 0] ∧
    target1542.elements.length = 4 ∧
    [target1542.elements.count 0, target1542.elements.count 1,
      target1542.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1542
def tree1543 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)))
def target1543 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1543 : accepts tree1543 target1543 = true ∧
    sourceLeaves tree1543 = [0, 1, 2, 0] ∧
    target1543.elements.length = 4 ∧
    [target1543.elements.count 0, target1543.elements.count 1,
      target1543.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1543
def tree1544 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1544 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1544 : accepts tree1544 target1544 = true ∧
    sourceLeaves tree1544 = [0, 1, 2, 0] ∧
    target1544.elements.length = 4 ∧
    [target1544.elements.count 0, target1544.elements.count 1,
      target1544.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1544
def tree1545 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 0))
def target1545 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1545 : accepts tree1545 target1545 = true ∧
    sourceLeaves tree1545 = [0, 1, 2, 0] ∧
    target1545.elements.length = 4 ∧
    [target1545.elements.count 0, target1545.elements.count 1,
      target1545.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1545
def tree1546 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target1546 : Target Nat := ⟨.seq, [0, 1, 2, 0]⟩
theorem chain1546 : accepts tree1546 target1546 = true ∧
    sourceLeaves tree1546 = [0, 1, 2, 0] ∧
    target1546.elements.length = 4 ∧
    [target1546.elements.count 0, target1546.elements.count 1,
      target1546.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1546
def tree1547 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))))
def target1547 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1547 : accepts tree1547 target1547 = true ∧
    sourceLeaves tree1547 = [0, 1, 2, 1] ∧
    target1547.elements.length = 4 ∧
    [target1547.elements.count 0, target1547.elements.count 1,
      target1547.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1547
def tree1548 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)))
def target1548 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1548 : accepts tree1548 target1548 = true ∧
    sourceLeaves tree1548 = [0, 1, 2, 1] ∧
    target1548.elements.length = 4 ∧
    [target1548.elements.count 0, target1548.elements.count 1,
      target1548.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1548
def tree1549 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1549 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1549 : accepts tree1549 target1549 = true ∧
    sourceLeaves tree1549 = [0, 1, 2, 1] ∧
    target1549.elements.length = 4 ∧
    [target1549.elements.count 0, target1549.elements.count 1,
      target1549.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1549
def tree1550 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 1))
def target1550 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1550 : accepts tree1550 target1550 = true ∧
    sourceLeaves tree1550 = [0, 1, 2, 1] ∧
    target1550.elements.length = 4 ∧
    [target1550.elements.count 0, target1550.elements.count 1,
      target1550.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1550
def tree1551 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target1551 : Target Nat := ⟨.seq, [0, 1, 2, 1]⟩
theorem chain1551 : accepts tree1551 target1551 = true ∧
    sourceLeaves tree1551 = [0, 1, 2, 1] ∧
    target1551.elements.length = 4 ∧
    [target1551.elements.count 0, target1551.elements.count 1,
      target1551.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1551
def tree1552 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))))
def target1552 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1552 : accepts tree1552 target1552 = true ∧
    sourceLeaves tree1552 = [0, 1, 2, 2] ∧
    target1552.elements.length = 4 ∧
    [target1552.elements.count 0, target1552.elements.count 1,
      target1552.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1552
def tree1553 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)))
def target1553 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1553 : accepts tree1553 target1553 = true ∧
    sourceLeaves tree1553 = [0, 1, 2, 2] ∧
    target1553.elements.length = 4 ∧
    [target1553.elements.count 0, target1553.elements.count 1,
      target1553.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1553
def tree1554 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1554 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1554 : accepts tree1554 target1554 = true ∧
    sourceLeaves tree1554 = [0, 1, 2, 2] ∧
    target1554.elements.length = 4 ∧
    [target1554.elements.count 0, target1554.elements.count 1,
      target1554.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1554
def tree1555 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 2))
def target1555 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1555 : accepts tree1555 target1555 = true ∧
    sourceLeaves tree1555 = [0, 1, 2, 2] ∧
    target1555.elements.length = 4 ∧
    [target1555.elements.count 0, target1555.elements.count 1,
      target1555.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1555
def tree1556 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target1556 : Target Nat := ⟨.seq, [0, 1, 2, 2]⟩
theorem chain1556 : accepts tree1556 target1556 = true ∧
    sourceLeaves tree1556 = [0, 1, 2, 2] ∧
    target1556.elements.length = 4 ∧
    [target1556.elements.count 0, target1556.elements.count 1,
      target1556.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1556
def tree1557 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))))
def target1557 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1557 : accepts tree1557 target1557 = true ∧
    sourceLeaves tree1557 = [0, 2, 0, 0] ∧
    target1557.elements.length = 4 ∧
    [target1557.elements.count 0, target1557.elements.count 1,
      target1557.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1557
def tree1558 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)))
def target1558 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1558 : accepts tree1558 target1558 = true ∧
    sourceLeaves tree1558 = [0, 2, 0, 0] ∧
    target1558.elements.length = 4 ∧
    [target1558.elements.count 0, target1558.elements.count 1,
      target1558.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1558
def tree1559 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1559 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1559 : accepts tree1559 target1559 = true ∧
    sourceLeaves tree1559 = [0, 2, 0, 0] ∧
    target1559.elements.length = 4 ∧
    [target1559.elements.count 0, target1559.elements.count 1,
      target1559.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1559
def tree1560 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 0))
def target1560 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1560 : accepts tree1560 target1560 = true ∧
    sourceLeaves tree1560 = [0, 2, 0, 0] ∧
    target1560.elements.length = 4 ∧
    [target1560.elements.count 0, target1560.elements.count 1,
      target1560.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1560
def tree1561 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target1561 : Target Nat := ⟨.seq, [0, 2, 0, 0]⟩
theorem chain1561 : accepts tree1561 target1561 = true ∧
    sourceLeaves tree1561 = [0, 2, 0, 0] ∧
    target1561.elements.length = 4 ∧
    [target1561.elements.count 0, target1561.elements.count 1,
      target1561.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1561
def tree1562 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))))
def target1562 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1562 : accepts tree1562 target1562 = true ∧
    sourceLeaves tree1562 = [0, 2, 0, 1] ∧
    target1562.elements.length = 4 ∧
    [target1562.elements.count 0, target1562.elements.count 1,
      target1562.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1562
def tree1563 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)))
def target1563 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1563 : accepts tree1563 target1563 = true ∧
    sourceLeaves tree1563 = [0, 2, 0, 1] ∧
    target1563.elements.length = 4 ∧
    [target1563.elements.count 0, target1563.elements.count 1,
      target1563.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1563
def tree1564 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1564 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1564 : accepts tree1564 target1564 = true ∧
    sourceLeaves tree1564 = [0, 2, 0, 1] ∧
    target1564.elements.length = 4 ∧
    [target1564.elements.count 0, target1564.elements.count 1,
      target1564.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1564
def tree1565 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 1))
def target1565 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1565 : accepts tree1565 target1565 = true ∧
    sourceLeaves tree1565 = [0, 2, 0, 1] ∧
    target1565.elements.length = 4 ∧
    [target1565.elements.count 0, target1565.elements.count 1,
      target1565.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1565
def tree1566 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target1566 : Target Nat := ⟨.seq, [0, 2, 0, 1]⟩
theorem chain1566 : accepts tree1566 target1566 = true ∧
    sourceLeaves tree1566 = [0, 2, 0, 1] ∧
    target1566.elements.length = 4 ∧
    [target1566.elements.count 0, target1566.elements.count 1,
      target1566.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1566
def tree1567 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))))
def target1567 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1567 : accepts tree1567 target1567 = true ∧
    sourceLeaves tree1567 = [0, 2, 0, 2] ∧
    target1567.elements.length = 4 ∧
    [target1567.elements.count 0, target1567.elements.count 1,
      target1567.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1567
def tree1568 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)))
def target1568 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1568 : accepts tree1568 target1568 = true ∧
    sourceLeaves tree1568 = [0, 2, 0, 2] ∧
    target1568.elements.length = 4 ∧
    [target1568.elements.count 0, target1568.elements.count 1,
      target1568.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1568
def tree1569 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1569 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1569 : accepts tree1569 target1569 = true ∧
    sourceLeaves tree1569 = [0, 2, 0, 2] ∧
    target1569.elements.length = 4 ∧
    [target1569.elements.count 0, target1569.elements.count 1,
      target1569.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1569
def tree1570 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 2))
def target1570 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1570 : accepts tree1570 target1570 = true ∧
    sourceLeaves tree1570 = [0, 2, 0, 2] ∧
    target1570.elements.length = 4 ∧
    [target1570.elements.count 0, target1570.elements.count 1,
      target1570.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1570
def tree1571 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target1571 : Target Nat := ⟨.seq, [0, 2, 0, 2]⟩
theorem chain1571 : accepts tree1571 target1571 = true ∧
    sourceLeaves tree1571 = [0, 2, 0, 2] ∧
    target1571.elements.length = 4 ∧
    [target1571.elements.count 0, target1571.elements.count 1,
      target1571.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1571
def tree1572 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))))
def target1572 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1572 : accepts tree1572 target1572 = true ∧
    sourceLeaves tree1572 = [0, 2, 1, 0] ∧
    target1572.elements.length = 4 ∧
    [target1572.elements.count 0, target1572.elements.count 1,
      target1572.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1572
def tree1573 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)))
def target1573 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1573 : accepts tree1573 target1573 = true ∧
    sourceLeaves tree1573 = [0, 2, 1, 0] ∧
    target1573.elements.length = 4 ∧
    [target1573.elements.count 0, target1573.elements.count 1,
      target1573.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1573
def tree1574 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1574 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1574 : accepts tree1574 target1574 = true ∧
    sourceLeaves tree1574 = [0, 2, 1, 0] ∧
    target1574.elements.length = 4 ∧
    [target1574.elements.count 0, target1574.elements.count 1,
      target1574.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1574
def tree1575 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 0))
def target1575 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1575 : accepts tree1575 target1575 = true ∧
    sourceLeaves tree1575 = [0, 2, 1, 0] ∧
    target1575.elements.length = 4 ∧
    [target1575.elements.count 0, target1575.elements.count 1,
      target1575.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1575
def tree1576 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target1576 : Target Nat := ⟨.seq, [0, 2, 1, 0]⟩
theorem chain1576 : accepts tree1576 target1576 = true ∧
    sourceLeaves tree1576 = [0, 2, 1, 0] ∧
    target1576.elements.length = 4 ∧
    [target1576.elements.count 0, target1576.elements.count 1,
      target1576.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1576
def tree1577 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))))
def target1577 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1577 : accepts tree1577 target1577 = true ∧
    sourceLeaves tree1577 = [0, 2, 1, 1] ∧
    target1577.elements.length = 4 ∧
    [target1577.elements.count 0, target1577.elements.count 1,
      target1577.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1577
def tree1578 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)))
def target1578 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1578 : accepts tree1578 target1578 = true ∧
    sourceLeaves tree1578 = [0, 2, 1, 1] ∧
    target1578.elements.length = 4 ∧
    [target1578.elements.count 0, target1578.elements.count 1,
      target1578.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1578
def tree1579 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1579 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1579 : accepts tree1579 target1579 = true ∧
    sourceLeaves tree1579 = [0, 2, 1, 1] ∧
    target1579.elements.length = 4 ∧
    [target1579.elements.count 0, target1579.elements.count 1,
      target1579.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1579
def tree1580 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 1))
def target1580 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1580 : accepts tree1580 target1580 = true ∧
    sourceLeaves tree1580 = [0, 2, 1, 1] ∧
    target1580.elements.length = 4 ∧
    [target1580.elements.count 0, target1580.elements.count 1,
      target1580.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1580
def tree1581 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target1581 : Target Nat := ⟨.seq, [0, 2, 1, 1]⟩
theorem chain1581 : accepts tree1581 target1581 = true ∧
    sourceLeaves tree1581 = [0, 2, 1, 1] ∧
    target1581.elements.length = 4 ∧
    [target1581.elements.count 0, target1581.elements.count 1,
      target1581.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1581
def tree1582 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))))
def target1582 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1582 : accepts tree1582 target1582 = true ∧
    sourceLeaves tree1582 = [0, 2, 1, 2] ∧
    target1582.elements.length = 4 ∧
    [target1582.elements.count 0, target1582.elements.count 1,
      target1582.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1582
def tree1583 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)))
def target1583 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1583 : accepts tree1583 target1583 = true ∧
    sourceLeaves tree1583 = [0, 2, 1, 2] ∧
    target1583.elements.length = 4 ∧
    [target1583.elements.count 0, target1583.elements.count 1,
      target1583.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1583
def tree1584 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1584 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1584 : accepts tree1584 target1584 = true ∧
    sourceLeaves tree1584 = [0, 2, 1, 2] ∧
    target1584.elements.length = 4 ∧
    [target1584.elements.count 0, target1584.elements.count 1,
      target1584.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1584
def tree1585 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 2))
def target1585 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1585 : accepts tree1585 target1585 = true ∧
    sourceLeaves tree1585 = [0, 2, 1, 2] ∧
    target1585.elements.length = 4 ∧
    [target1585.elements.count 0, target1585.elements.count 1,
      target1585.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1585
def tree1586 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target1586 : Target Nat := ⟨.seq, [0, 2, 1, 2]⟩
theorem chain1586 : accepts tree1586 target1586 = true ∧
    sourceLeaves tree1586 = [0, 2, 1, 2] ∧
    target1586.elements.length = 4 ∧
    [target1586.elements.count 0, target1586.elements.count 1,
      target1586.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1586
def tree1587 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))))
def target1587 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1587 : accepts tree1587 target1587 = true ∧
    sourceLeaves tree1587 = [0, 2, 2, 0] ∧
    target1587.elements.length = 4 ∧
    [target1587.elements.count 0, target1587.elements.count 1,
      target1587.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1587
def tree1588 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)))
def target1588 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1588 : accepts tree1588 target1588 = true ∧
    sourceLeaves tree1588 = [0, 2, 2, 0] ∧
    target1588.elements.length = 4 ∧
    [target1588.elements.count 0, target1588.elements.count 1,
      target1588.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1588
def tree1589 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1589 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1589 : accepts tree1589 target1589 = true ∧
    sourceLeaves tree1589 = [0, 2, 2, 0] ∧
    target1589.elements.length = 4 ∧
    [target1589.elements.count 0, target1589.elements.count 1,
      target1589.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1589
def tree1590 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 0))
def target1590 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1590 : accepts tree1590 target1590 = true ∧
    sourceLeaves tree1590 = [0, 2, 2, 0] ∧
    target1590.elements.length = 4 ∧
    [target1590.elements.count 0, target1590.elements.count 1,
      target1590.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1590
def tree1591 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target1591 : Target Nat := ⟨.seq, [0, 2, 2, 0]⟩
theorem chain1591 : accepts tree1591 target1591 = true ∧
    sourceLeaves tree1591 = [0, 2, 2, 0] ∧
    target1591.elements.length = 4 ∧
    [target1591.elements.count 0, target1591.elements.count 1,
      target1591.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1591
def tree1592 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))))
def target1592 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1592 : accepts tree1592 target1592 = true ∧
    sourceLeaves tree1592 = [0, 2, 2, 1] ∧
    target1592.elements.length = 4 ∧
    [target1592.elements.count 0, target1592.elements.count 1,
      target1592.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1592
def tree1593 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)))
def target1593 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1593 : accepts tree1593 target1593 = true ∧
    sourceLeaves tree1593 = [0, 2, 2, 1] ∧
    target1593.elements.length = 4 ∧
    [target1593.elements.count 0, target1593.elements.count 1,
      target1593.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1593
def tree1594 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1594 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1594 : accepts tree1594 target1594 = true ∧
    sourceLeaves tree1594 = [0, 2, 2, 1] ∧
    target1594.elements.length = 4 ∧
    [target1594.elements.count 0, target1594.elements.count 1,
      target1594.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1594
def tree1595 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 1))
def target1595 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1595 : accepts tree1595 target1595 = true ∧
    sourceLeaves tree1595 = [0, 2, 2, 1] ∧
    target1595.elements.length = 4 ∧
    [target1595.elements.count 0, target1595.elements.count 1,
      target1595.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1595
def tree1596 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target1596 : Target Nat := ⟨.seq, [0, 2, 2, 1]⟩
theorem chain1596 : accepts tree1596 target1596 = true ∧
    sourceLeaves tree1596 = [0, 2, 2, 1] ∧
    target1596.elements.length = 4 ∧
    [target1596.elements.count 0, target1596.elements.count 1,
      target1596.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1596
def tree1597 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))))
def target1597 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1597 : accepts tree1597 target1597 = true ∧
    sourceLeaves tree1597 = [0, 2, 2, 2] ∧
    target1597.elements.length = 4 ∧
    [target1597.elements.count 0, target1597.elements.count 1,
      target1597.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1597
def tree1598 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)))
def target1598 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1598 : accepts tree1598 target1598 = true ∧
    sourceLeaves tree1598 = [0, 2, 2, 2] ∧
    target1598.elements.length = 4 ∧
    [target1598.elements.count 0, target1598.elements.count 1,
      target1598.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1598
def tree1599 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1599 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1599 : accepts tree1599 target1599 = true ∧
    sourceLeaves tree1599 = [0, 2, 2, 2] ∧
    target1599.elements.length = 4 ∧
    [target1599.elements.count 0, target1599.elements.count 1,
      target1599.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1599
def tree1600 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 2))
def target1600 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1600 : accepts tree1600 target1600 = true ∧
    sourceLeaves tree1600 = [0, 2, 2, 2] ∧
    target1600.elements.length = 4 ∧
    [target1600.elements.count 0, target1600.elements.count 1,
      target1600.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1600
def tree1601 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target1601 : Target Nat := ⟨.seq, [0, 2, 2, 2]⟩
theorem chain1601 : accepts tree1601 target1601 = true ∧
    sourceLeaves tree1601 = [0, 2, 2, 2] ∧
    target1601.elements.length = 4 ∧
    [target1601.elements.count 0, target1601.elements.count 1,
      target1601.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1601
def tree1602 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))))
def target1602 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1602 : accepts tree1602 target1602 = true ∧
    sourceLeaves tree1602 = [1, 0, 0, 0] ∧
    target1602.elements.length = 4 ∧
    [target1602.elements.count 0, target1602.elements.count 1,
      target1602.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1602
def tree1603 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)))
def target1603 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1603 : accepts tree1603 target1603 = true ∧
    sourceLeaves tree1603 = [1, 0, 0, 0] ∧
    target1603.elements.length = 4 ∧
    [target1603.elements.count 0, target1603.elements.count 1,
      target1603.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1603
def tree1604 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1604 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1604 : accepts tree1604 target1604 = true ∧
    sourceLeaves tree1604 = [1, 0, 0, 0] ∧
    target1604.elements.length = 4 ∧
    [target1604.elements.count 0, target1604.elements.count 1,
      target1604.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1604
def tree1605 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 0))
def target1605 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1605 : accepts tree1605 target1605 = true ∧
    sourceLeaves tree1605 = [1, 0, 0, 0] ∧
    target1605.elements.length = 4 ∧
    [target1605.elements.count 0, target1605.elements.count 1,
      target1605.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1605
def tree1606 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target1606 : Target Nat := ⟨.seq, [1, 0, 0, 0]⟩
theorem chain1606 : accepts tree1606 target1606 = true ∧
    sourceLeaves tree1606 = [1, 0, 0, 0] ∧
    target1606.elements.length = 4 ∧
    [target1606.elements.count 0, target1606.elements.count 1,
      target1606.elements.count 2] = [3, 1, 0] := by decide
#print axioms chain1606
def tree1607 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))))
def target1607 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1607 : accepts tree1607 target1607 = true ∧
    sourceLeaves tree1607 = [1, 0, 0, 1] ∧
    target1607.elements.length = 4 ∧
    [target1607.elements.count 0, target1607.elements.count 1,
      target1607.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1607
def tree1608 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)))
def target1608 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1608 : accepts tree1608 target1608 = true ∧
    sourceLeaves tree1608 = [1, 0, 0, 1] ∧
    target1608.elements.length = 4 ∧
    [target1608.elements.count 0, target1608.elements.count 1,
      target1608.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1608
def tree1609 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1609 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1609 : accepts tree1609 target1609 = true ∧
    sourceLeaves tree1609 = [1, 0, 0, 1] ∧
    target1609.elements.length = 4 ∧
    [target1609.elements.count 0, target1609.elements.count 1,
      target1609.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1609
def tree1610 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 1))
def target1610 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1610 : accepts tree1610 target1610 = true ∧
    sourceLeaves tree1610 = [1, 0, 0, 1] ∧
    target1610.elements.length = 4 ∧
    [target1610.elements.count 0, target1610.elements.count 1,
      target1610.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1610
def tree1611 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target1611 : Target Nat := ⟨.seq, [1, 0, 0, 1]⟩
theorem chain1611 : accepts tree1611 target1611 = true ∧
    sourceLeaves tree1611 = [1, 0, 0, 1] ∧
    target1611.elements.length = 4 ∧
    [target1611.elements.count 0, target1611.elements.count 1,
      target1611.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1611
def tree1612 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))))
def target1612 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1612 : accepts tree1612 target1612 = true ∧
    sourceLeaves tree1612 = [1, 0, 0, 2] ∧
    target1612.elements.length = 4 ∧
    [target1612.elements.count 0, target1612.elements.count 1,
      target1612.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1612
def tree1613 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)))
def target1613 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1613 : accepts tree1613 target1613 = true ∧
    sourceLeaves tree1613 = [1, 0, 0, 2] ∧
    target1613.elements.length = 4 ∧
    [target1613.elements.count 0, target1613.elements.count 1,
      target1613.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1613
def tree1614 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1614 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1614 : accepts tree1614 target1614 = true ∧
    sourceLeaves tree1614 = [1, 0, 0, 2] ∧
    target1614.elements.length = 4 ∧
    [target1614.elements.count 0, target1614.elements.count 1,
      target1614.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1614
def tree1615 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 2))
def target1615 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1615 : accepts tree1615 target1615 = true ∧
    sourceLeaves tree1615 = [1, 0, 0, 2] ∧
    target1615.elements.length = 4 ∧
    [target1615.elements.count 0, target1615.elements.count 1,
      target1615.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1615
def tree1616 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target1616 : Target Nat := ⟨.seq, [1, 0, 0, 2]⟩
theorem chain1616 : accepts tree1616 target1616 = true ∧
    sourceLeaves tree1616 = [1, 0, 0, 2] ∧
    target1616.elements.length = 4 ∧
    [target1616.elements.count 0, target1616.elements.count 1,
      target1616.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1616
def tree1617 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))))
def target1617 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1617 : accepts tree1617 target1617 = true ∧
    sourceLeaves tree1617 = [1, 0, 1, 0] ∧
    target1617.elements.length = 4 ∧
    [target1617.elements.count 0, target1617.elements.count 1,
      target1617.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1617
def tree1618 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)))
def target1618 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1618 : accepts tree1618 target1618 = true ∧
    sourceLeaves tree1618 = [1, 0, 1, 0] ∧
    target1618.elements.length = 4 ∧
    [target1618.elements.count 0, target1618.elements.count 1,
      target1618.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1618
def tree1619 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1619 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1619 : accepts tree1619 target1619 = true ∧
    sourceLeaves tree1619 = [1, 0, 1, 0] ∧
    target1619.elements.length = 4 ∧
    [target1619.elements.count 0, target1619.elements.count 1,
      target1619.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1619
def tree1620 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 0))
def target1620 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1620 : accepts tree1620 target1620 = true ∧
    sourceLeaves tree1620 = [1, 0, 1, 0] ∧
    target1620.elements.length = 4 ∧
    [target1620.elements.count 0, target1620.elements.count 1,
      target1620.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1620
def tree1621 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target1621 : Target Nat := ⟨.seq, [1, 0, 1, 0]⟩
theorem chain1621 : accepts tree1621 target1621 = true ∧
    sourceLeaves tree1621 = [1, 0, 1, 0] ∧
    target1621.elements.length = 4 ∧
    [target1621.elements.count 0, target1621.elements.count 1,
      target1621.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1621
def tree1622 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))))
def target1622 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1622 : accepts tree1622 target1622 = true ∧
    sourceLeaves tree1622 = [1, 0, 1, 1] ∧
    target1622.elements.length = 4 ∧
    [target1622.elements.count 0, target1622.elements.count 1,
      target1622.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1622
def tree1623 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)))
def target1623 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1623 : accepts tree1623 target1623 = true ∧
    sourceLeaves tree1623 = [1, 0, 1, 1] ∧
    target1623.elements.length = 4 ∧
    [target1623.elements.count 0, target1623.elements.count 1,
      target1623.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1623
def tree1624 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1624 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1624 : accepts tree1624 target1624 = true ∧
    sourceLeaves tree1624 = [1, 0, 1, 1] ∧
    target1624.elements.length = 4 ∧
    [target1624.elements.count 0, target1624.elements.count 1,
      target1624.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1624
def tree1625 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 1))
def target1625 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1625 : accepts tree1625 target1625 = true ∧
    sourceLeaves tree1625 = [1, 0, 1, 1] ∧
    target1625.elements.length = 4 ∧
    [target1625.elements.count 0, target1625.elements.count 1,
      target1625.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1625
def tree1626 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target1626 : Target Nat := ⟨.seq, [1, 0, 1, 1]⟩
theorem chain1626 : accepts tree1626 target1626 = true ∧
    sourceLeaves tree1626 = [1, 0, 1, 1] ∧
    target1626.elements.length = 4 ∧
    [target1626.elements.count 0, target1626.elements.count 1,
      target1626.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1626
def tree1627 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))))
def target1627 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1627 : accepts tree1627 target1627 = true ∧
    sourceLeaves tree1627 = [1, 0, 1, 2] ∧
    target1627.elements.length = 4 ∧
    [target1627.elements.count 0, target1627.elements.count 1,
      target1627.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1627
def tree1628 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)))
def target1628 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1628 : accepts tree1628 target1628 = true ∧
    sourceLeaves tree1628 = [1, 0, 1, 2] ∧
    target1628.elements.length = 4 ∧
    [target1628.elements.count 0, target1628.elements.count 1,
      target1628.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1628
def tree1629 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1629 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1629 : accepts tree1629 target1629 = true ∧
    sourceLeaves tree1629 = [1, 0, 1, 2] ∧
    target1629.elements.length = 4 ∧
    [target1629.elements.count 0, target1629.elements.count 1,
      target1629.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1629
def tree1630 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 2))
def target1630 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1630 : accepts tree1630 target1630 = true ∧
    sourceLeaves tree1630 = [1, 0, 1, 2] ∧
    target1630.elements.length = 4 ∧
    [target1630.elements.count 0, target1630.elements.count 1,
      target1630.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1630
def tree1631 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target1631 : Target Nat := ⟨.seq, [1, 0, 1, 2]⟩
theorem chain1631 : accepts tree1631 target1631 = true ∧
    sourceLeaves tree1631 = [1, 0, 1, 2] ∧
    target1631.elements.length = 4 ∧
    [target1631.elements.count 0, target1631.elements.count 1,
      target1631.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1631
def tree1632 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))))
def target1632 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1632 : accepts tree1632 target1632 = true ∧
    sourceLeaves tree1632 = [1, 0, 2, 0] ∧
    target1632.elements.length = 4 ∧
    [target1632.elements.count 0, target1632.elements.count 1,
      target1632.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1632
def tree1633 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)))
def target1633 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1633 : accepts tree1633 target1633 = true ∧
    sourceLeaves tree1633 = [1, 0, 2, 0] ∧
    target1633.elements.length = 4 ∧
    [target1633.elements.count 0, target1633.elements.count 1,
      target1633.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1633
def tree1634 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1634 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1634 : accepts tree1634 target1634 = true ∧
    sourceLeaves tree1634 = [1, 0, 2, 0] ∧
    target1634.elements.length = 4 ∧
    [target1634.elements.count 0, target1634.elements.count 1,
      target1634.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1634
def tree1635 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 0))
def target1635 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1635 : accepts tree1635 target1635 = true ∧
    sourceLeaves tree1635 = [1, 0, 2, 0] ∧
    target1635.elements.length = 4 ∧
    [target1635.elements.count 0, target1635.elements.count 1,
      target1635.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1635
def tree1636 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target1636 : Target Nat := ⟨.seq, [1, 0, 2, 0]⟩
theorem chain1636 : accepts tree1636 target1636 = true ∧
    sourceLeaves tree1636 = [1, 0, 2, 0] ∧
    target1636.elements.length = 4 ∧
    [target1636.elements.count 0, target1636.elements.count 1,
      target1636.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1636
def tree1637 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))))
def target1637 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1637 : accepts tree1637 target1637 = true ∧
    sourceLeaves tree1637 = [1, 0, 2, 1] ∧
    target1637.elements.length = 4 ∧
    [target1637.elements.count 0, target1637.elements.count 1,
      target1637.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1637
def tree1638 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)))
def target1638 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1638 : accepts tree1638 target1638 = true ∧
    sourceLeaves tree1638 = [1, 0, 2, 1] ∧
    target1638.elements.length = 4 ∧
    [target1638.elements.count 0, target1638.elements.count 1,
      target1638.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1638
def tree1639 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1639 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1639 : accepts tree1639 target1639 = true ∧
    sourceLeaves tree1639 = [1, 0, 2, 1] ∧
    target1639.elements.length = 4 ∧
    [target1639.elements.count 0, target1639.elements.count 1,
      target1639.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1639
def tree1640 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 1))
def target1640 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1640 : accepts tree1640 target1640 = true ∧
    sourceLeaves tree1640 = [1, 0, 2, 1] ∧
    target1640.elements.length = 4 ∧
    [target1640.elements.count 0, target1640.elements.count 1,
      target1640.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1640
def tree1641 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target1641 : Target Nat := ⟨.seq, [1, 0, 2, 1]⟩
theorem chain1641 : accepts tree1641 target1641 = true ∧
    sourceLeaves tree1641 = [1, 0, 2, 1] ∧
    target1641.elements.length = 4 ∧
    [target1641.elements.count 0, target1641.elements.count 1,
      target1641.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1641
def tree1642 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))))
def target1642 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1642 : accepts tree1642 target1642 = true ∧
    sourceLeaves tree1642 = [1, 0, 2, 2] ∧
    target1642.elements.length = 4 ∧
    [target1642.elements.count 0, target1642.elements.count 1,
      target1642.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1642
def tree1643 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)))
def target1643 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1643 : accepts tree1643 target1643 = true ∧
    sourceLeaves tree1643 = [1, 0, 2, 2] ∧
    target1643.elements.length = 4 ∧
    [target1643.elements.count 0, target1643.elements.count 1,
      target1643.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1643
def tree1644 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1644 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1644 : accepts tree1644 target1644 = true ∧
    sourceLeaves tree1644 = [1, 0, 2, 2] ∧
    target1644.elements.length = 4 ∧
    [target1644.elements.count 0, target1644.elements.count 1,
      target1644.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1644
def tree1645 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 2))
def target1645 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1645 : accepts tree1645 target1645 = true ∧
    sourceLeaves tree1645 = [1, 0, 2, 2] ∧
    target1645.elements.length = 4 ∧
    [target1645.elements.count 0, target1645.elements.count 1,
      target1645.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1645
def tree1646 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target1646 : Target Nat := ⟨.seq, [1, 0, 2, 2]⟩
theorem chain1646 : accepts tree1646 target1646 = true ∧
    sourceLeaves tree1646 = [1, 0, 2, 2] ∧
    target1646.elements.length = 4 ∧
    [target1646.elements.count 0, target1646.elements.count 1,
      target1646.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1646
def tree1647 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))))
def target1647 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1647 : accepts tree1647 target1647 = true ∧
    sourceLeaves tree1647 = [1, 1, 0, 0] ∧
    target1647.elements.length = 4 ∧
    [target1647.elements.count 0, target1647.elements.count 1,
      target1647.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1647
def tree1648 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)))
def target1648 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1648 : accepts tree1648 target1648 = true ∧
    sourceLeaves tree1648 = [1, 1, 0, 0] ∧
    target1648.elements.length = 4 ∧
    [target1648.elements.count 0, target1648.elements.count 1,
      target1648.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1648
def tree1649 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1649 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1649 : accepts tree1649 target1649 = true ∧
    sourceLeaves tree1649 = [1, 1, 0, 0] ∧
    target1649.elements.length = 4 ∧
    [target1649.elements.count 0, target1649.elements.count 1,
      target1649.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1649
def tree1650 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 0))
def target1650 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1650 : accepts tree1650 target1650 = true ∧
    sourceLeaves tree1650 = [1, 1, 0, 0] ∧
    target1650.elements.length = 4 ∧
    [target1650.elements.count 0, target1650.elements.count 1,
      target1650.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1650
def tree1651 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target1651 : Target Nat := ⟨.seq, [1, 1, 0, 0]⟩
theorem chain1651 : accepts tree1651 target1651 = true ∧
    sourceLeaves tree1651 = [1, 1, 0, 0] ∧
    target1651.elements.length = 4 ∧
    [target1651.elements.count 0, target1651.elements.count 1,
      target1651.elements.count 2] = [2, 2, 0] := by decide
#print axioms chain1651
def tree1652 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))))
def target1652 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1652 : accepts tree1652 target1652 = true ∧
    sourceLeaves tree1652 = [1, 1, 0, 1] ∧
    target1652.elements.length = 4 ∧
    [target1652.elements.count 0, target1652.elements.count 1,
      target1652.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1652
def tree1653 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)))
def target1653 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1653 : accepts tree1653 target1653 = true ∧
    sourceLeaves tree1653 = [1, 1, 0, 1] ∧
    target1653.elements.length = 4 ∧
    [target1653.elements.count 0, target1653.elements.count 1,
      target1653.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1653
def tree1654 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1654 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1654 : accepts tree1654 target1654 = true ∧
    sourceLeaves tree1654 = [1, 1, 0, 1] ∧
    target1654.elements.length = 4 ∧
    [target1654.elements.count 0, target1654.elements.count 1,
      target1654.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1654
def tree1655 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 1))
def target1655 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1655 : accepts tree1655 target1655 = true ∧
    sourceLeaves tree1655 = [1, 1, 0, 1] ∧
    target1655.elements.length = 4 ∧
    [target1655.elements.count 0, target1655.elements.count 1,
      target1655.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1655
def tree1656 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target1656 : Target Nat := ⟨.seq, [1, 1, 0, 1]⟩
theorem chain1656 : accepts tree1656 target1656 = true ∧
    sourceLeaves tree1656 = [1, 1, 0, 1] ∧
    target1656.elements.length = 4 ∧
    [target1656.elements.count 0, target1656.elements.count 1,
      target1656.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1656
def tree1657 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))))
def target1657 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1657 : accepts tree1657 target1657 = true ∧
    sourceLeaves tree1657 = [1, 1, 0, 2] ∧
    target1657.elements.length = 4 ∧
    [target1657.elements.count 0, target1657.elements.count 1,
      target1657.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1657
def tree1658 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)))
def target1658 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1658 : accepts tree1658 target1658 = true ∧
    sourceLeaves tree1658 = [1, 1, 0, 2] ∧
    target1658.elements.length = 4 ∧
    [target1658.elements.count 0, target1658.elements.count 1,
      target1658.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1658
def tree1659 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1659 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1659 : accepts tree1659 target1659 = true ∧
    sourceLeaves tree1659 = [1, 1, 0, 2] ∧
    target1659.elements.length = 4 ∧
    [target1659.elements.count 0, target1659.elements.count 1,
      target1659.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1659
def tree1660 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 2))
def target1660 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1660 : accepts tree1660 target1660 = true ∧
    sourceLeaves tree1660 = [1, 1, 0, 2] ∧
    target1660.elements.length = 4 ∧
    [target1660.elements.count 0, target1660.elements.count 1,
      target1660.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1660
def tree1661 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target1661 : Target Nat := ⟨.seq, [1, 1, 0, 2]⟩
theorem chain1661 : accepts tree1661 target1661 = true ∧
    sourceLeaves tree1661 = [1, 1, 0, 2] ∧
    target1661.elements.length = 4 ∧
    [target1661.elements.count 0, target1661.elements.count 1,
      target1661.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1661
def tree1662 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))))
def target1662 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1662 : accepts tree1662 target1662 = true ∧
    sourceLeaves tree1662 = [1, 1, 1, 0] ∧
    target1662.elements.length = 4 ∧
    [target1662.elements.count 0, target1662.elements.count 1,
      target1662.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1662
def tree1663 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)))
def target1663 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1663 : accepts tree1663 target1663 = true ∧
    sourceLeaves tree1663 = [1, 1, 1, 0] ∧
    target1663.elements.length = 4 ∧
    [target1663.elements.count 0, target1663.elements.count 1,
      target1663.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1663
def tree1664 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1664 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1664 : accepts tree1664 target1664 = true ∧
    sourceLeaves tree1664 = [1, 1, 1, 0] ∧
    target1664.elements.length = 4 ∧
    [target1664.elements.count 0, target1664.elements.count 1,
      target1664.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1664
def tree1665 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 0))
def target1665 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1665 : accepts tree1665 target1665 = true ∧
    sourceLeaves tree1665 = [1, 1, 1, 0] ∧
    target1665.elements.length = 4 ∧
    [target1665.elements.count 0, target1665.elements.count 1,
      target1665.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1665
def tree1666 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target1666 : Target Nat := ⟨.seq, [1, 1, 1, 0]⟩
theorem chain1666 : accepts tree1666 target1666 = true ∧
    sourceLeaves tree1666 = [1, 1, 1, 0] ∧
    target1666.elements.length = 4 ∧
    [target1666.elements.count 0, target1666.elements.count 1,
      target1666.elements.count 2] = [1, 3, 0] := by decide
#print axioms chain1666
def tree1667 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))))
def target1667 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1667 : accepts tree1667 target1667 = true ∧
    sourceLeaves tree1667 = [1, 1, 1, 1] ∧
    target1667.elements.length = 4 ∧
    [target1667.elements.count 0, target1667.elements.count 1,
      target1667.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1667
def tree1668 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)))
def target1668 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1668 : accepts tree1668 target1668 = true ∧
    sourceLeaves tree1668 = [1, 1, 1, 1] ∧
    target1668.elements.length = 4 ∧
    [target1668.elements.count 0, target1668.elements.count 1,
      target1668.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1668
def tree1669 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1669 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1669 : accepts tree1669 target1669 = true ∧
    sourceLeaves tree1669 = [1, 1, 1, 1] ∧
    target1669.elements.length = 4 ∧
    [target1669.elements.count 0, target1669.elements.count 1,
      target1669.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1669
def tree1670 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 1))
def target1670 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1670 : accepts tree1670 target1670 = true ∧
    sourceLeaves tree1670 = [1, 1, 1, 1] ∧
    target1670.elements.length = 4 ∧
    [target1670.elements.count 0, target1670.elements.count 1,
      target1670.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1670
def tree1671 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target1671 : Target Nat := ⟨.seq, [1, 1, 1, 1]⟩
theorem chain1671 : accepts tree1671 target1671 = true ∧
    sourceLeaves tree1671 = [1, 1, 1, 1] ∧
    target1671.elements.length = 4 ∧
    [target1671.elements.count 0, target1671.elements.count 1,
      target1671.elements.count 2] = [0, 4, 0] := by decide
#print axioms chain1671
def tree1672 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))))
def target1672 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1672 : accepts tree1672 target1672 = true ∧
    sourceLeaves tree1672 = [1, 1, 1, 2] ∧
    target1672.elements.length = 4 ∧
    [target1672.elements.count 0, target1672.elements.count 1,
      target1672.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1672
def tree1673 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)))
def target1673 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1673 : accepts tree1673 target1673 = true ∧
    sourceLeaves tree1673 = [1, 1, 1, 2] ∧
    target1673.elements.length = 4 ∧
    [target1673.elements.count 0, target1673.elements.count 1,
      target1673.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1673
def tree1674 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1674 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1674 : accepts tree1674 target1674 = true ∧
    sourceLeaves tree1674 = [1, 1, 1, 2] ∧
    target1674.elements.length = 4 ∧
    [target1674.elements.count 0, target1674.elements.count 1,
      target1674.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1674
def tree1675 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 2))
def target1675 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1675 : accepts tree1675 target1675 = true ∧
    sourceLeaves tree1675 = [1, 1, 1, 2] ∧
    target1675.elements.length = 4 ∧
    [target1675.elements.count 0, target1675.elements.count 1,
      target1675.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1675
def tree1676 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target1676 : Target Nat := ⟨.seq, [1, 1, 1, 2]⟩
theorem chain1676 : accepts tree1676 target1676 = true ∧
    sourceLeaves tree1676 = [1, 1, 1, 2] ∧
    target1676.elements.length = 4 ∧
    [target1676.elements.count 0, target1676.elements.count 1,
      target1676.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1676
def tree1677 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))))
def target1677 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1677 : accepts tree1677 target1677 = true ∧
    sourceLeaves tree1677 = [1, 1, 2, 0] ∧
    target1677.elements.length = 4 ∧
    [target1677.elements.count 0, target1677.elements.count 1,
      target1677.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1677
def tree1678 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)))
def target1678 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1678 : accepts tree1678 target1678 = true ∧
    sourceLeaves tree1678 = [1, 1, 2, 0] ∧
    target1678.elements.length = 4 ∧
    [target1678.elements.count 0, target1678.elements.count 1,
      target1678.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1678
def tree1679 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1679 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1679 : accepts tree1679 target1679 = true ∧
    sourceLeaves tree1679 = [1, 1, 2, 0] ∧
    target1679.elements.length = 4 ∧
    [target1679.elements.count 0, target1679.elements.count 1,
      target1679.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1679
def tree1680 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 0))
def target1680 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1680 : accepts tree1680 target1680 = true ∧
    sourceLeaves tree1680 = [1, 1, 2, 0] ∧
    target1680.elements.length = 4 ∧
    [target1680.elements.count 0, target1680.elements.count 1,
      target1680.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1680
def tree1681 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target1681 : Target Nat := ⟨.seq, [1, 1, 2, 0]⟩
theorem chain1681 : accepts tree1681 target1681 = true ∧
    sourceLeaves tree1681 = [1, 1, 2, 0] ∧
    target1681.elements.length = 4 ∧
    [target1681.elements.count 0, target1681.elements.count 1,
      target1681.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1681
def tree1682 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))))
def target1682 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1682 : accepts tree1682 target1682 = true ∧
    sourceLeaves tree1682 = [1, 1, 2, 1] ∧
    target1682.elements.length = 4 ∧
    [target1682.elements.count 0, target1682.elements.count 1,
      target1682.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1682
def tree1683 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)))
def target1683 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1683 : accepts tree1683 target1683 = true ∧
    sourceLeaves tree1683 = [1, 1, 2, 1] ∧
    target1683.elements.length = 4 ∧
    [target1683.elements.count 0, target1683.elements.count 1,
      target1683.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1683
def tree1684 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1684 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1684 : accepts tree1684 target1684 = true ∧
    sourceLeaves tree1684 = [1, 1, 2, 1] ∧
    target1684.elements.length = 4 ∧
    [target1684.elements.count 0, target1684.elements.count 1,
      target1684.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1684
def tree1685 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 1))
def target1685 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1685 : accepts tree1685 target1685 = true ∧
    sourceLeaves tree1685 = [1, 1, 2, 1] ∧
    target1685.elements.length = 4 ∧
    [target1685.elements.count 0, target1685.elements.count 1,
      target1685.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1685
def tree1686 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target1686 : Target Nat := ⟨.seq, [1, 1, 2, 1]⟩
theorem chain1686 : accepts tree1686 target1686 = true ∧
    sourceLeaves tree1686 = [1, 1, 2, 1] ∧
    target1686.elements.length = 4 ∧
    [target1686.elements.count 0, target1686.elements.count 1,
      target1686.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1686
def tree1687 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))))
def target1687 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1687 : accepts tree1687 target1687 = true ∧
    sourceLeaves tree1687 = [1, 1, 2, 2] ∧
    target1687.elements.length = 4 ∧
    [target1687.elements.count 0, target1687.elements.count 1,
      target1687.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1687
def tree1688 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)))
def target1688 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1688 : accepts tree1688 target1688 = true ∧
    sourceLeaves tree1688 = [1, 1, 2, 2] ∧
    target1688.elements.length = 4 ∧
    [target1688.elements.count 0, target1688.elements.count 1,
      target1688.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1688
def tree1689 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1689 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1689 : accepts tree1689 target1689 = true ∧
    sourceLeaves tree1689 = [1, 1, 2, 2] ∧
    target1689.elements.length = 4 ∧
    [target1689.elements.count 0, target1689.elements.count 1,
      target1689.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1689
def tree1690 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 2))
def target1690 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1690 : accepts tree1690 target1690 = true ∧
    sourceLeaves tree1690 = [1, 1, 2, 2] ∧
    target1690.elements.length = 4 ∧
    [target1690.elements.count 0, target1690.elements.count 1,
      target1690.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1690
def tree1691 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target1691 : Target Nat := ⟨.seq, [1, 1, 2, 2]⟩
theorem chain1691 : accepts tree1691 target1691 = true ∧
    sourceLeaves tree1691 = [1, 1, 2, 2] ∧
    target1691.elements.length = 4 ∧
    [target1691.elements.count 0, target1691.elements.count 1,
      target1691.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1691
def tree1692 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))))
def target1692 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1692 : accepts tree1692 target1692 = true ∧
    sourceLeaves tree1692 = [1, 2, 0, 0] ∧
    target1692.elements.length = 4 ∧
    [target1692.elements.count 0, target1692.elements.count 1,
      target1692.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1692
def tree1693 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)))
def target1693 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1693 : accepts tree1693 target1693 = true ∧
    sourceLeaves tree1693 = [1, 2, 0, 0] ∧
    target1693.elements.length = 4 ∧
    [target1693.elements.count 0, target1693.elements.count 1,
      target1693.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1693
def tree1694 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1694 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1694 : accepts tree1694 target1694 = true ∧
    sourceLeaves tree1694 = [1, 2, 0, 0] ∧
    target1694.elements.length = 4 ∧
    [target1694.elements.count 0, target1694.elements.count 1,
      target1694.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1694
def tree1695 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 0))
def target1695 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1695 : accepts tree1695 target1695 = true ∧
    sourceLeaves tree1695 = [1, 2, 0, 0] ∧
    target1695.elements.length = 4 ∧
    [target1695.elements.count 0, target1695.elements.count 1,
      target1695.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1695
def tree1696 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target1696 : Target Nat := ⟨.seq, [1, 2, 0, 0]⟩
theorem chain1696 : accepts tree1696 target1696 = true ∧
    sourceLeaves tree1696 = [1, 2, 0, 0] ∧
    target1696.elements.length = 4 ∧
    [target1696.elements.count 0, target1696.elements.count 1,
      target1696.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1696
def tree1697 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))))
def target1697 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1697 : accepts tree1697 target1697 = true ∧
    sourceLeaves tree1697 = [1, 2, 0, 1] ∧
    target1697.elements.length = 4 ∧
    [target1697.elements.count 0, target1697.elements.count 1,
      target1697.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1697
def tree1698 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)))
def target1698 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1698 : accepts tree1698 target1698 = true ∧
    sourceLeaves tree1698 = [1, 2, 0, 1] ∧
    target1698.elements.length = 4 ∧
    [target1698.elements.count 0, target1698.elements.count 1,
      target1698.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1698
def tree1699 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1699 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1699 : accepts tree1699 target1699 = true ∧
    sourceLeaves tree1699 = [1, 2, 0, 1] ∧
    target1699.elements.length = 4 ∧
    [target1699.elements.count 0, target1699.elements.count 1,
      target1699.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1699
def tree1700 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 1))
def target1700 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1700 : accepts tree1700 target1700 = true ∧
    sourceLeaves tree1700 = [1, 2, 0, 1] ∧
    target1700.elements.length = 4 ∧
    [target1700.elements.count 0, target1700.elements.count 1,
      target1700.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1700
def tree1701 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target1701 : Target Nat := ⟨.seq, [1, 2, 0, 1]⟩
theorem chain1701 : accepts tree1701 target1701 = true ∧
    sourceLeaves tree1701 = [1, 2, 0, 1] ∧
    target1701.elements.length = 4 ∧
    [target1701.elements.count 0, target1701.elements.count 1,
      target1701.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1701
def tree1702 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))))
def target1702 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1702 : accepts tree1702 target1702 = true ∧
    sourceLeaves tree1702 = [1, 2, 0, 2] ∧
    target1702.elements.length = 4 ∧
    [target1702.elements.count 0, target1702.elements.count 1,
      target1702.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1702
def tree1703 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)))
def target1703 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1703 : accepts tree1703 target1703 = true ∧
    sourceLeaves tree1703 = [1, 2, 0, 2] ∧
    target1703.elements.length = 4 ∧
    [target1703.elements.count 0, target1703.elements.count 1,
      target1703.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1703
def tree1704 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1704 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1704 : accepts tree1704 target1704 = true ∧
    sourceLeaves tree1704 = [1, 2, 0, 2] ∧
    target1704.elements.length = 4 ∧
    [target1704.elements.count 0, target1704.elements.count 1,
      target1704.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1704
def tree1705 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 2))
def target1705 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1705 : accepts tree1705 target1705 = true ∧
    sourceLeaves tree1705 = [1, 2, 0, 2] ∧
    target1705.elements.length = 4 ∧
    [target1705.elements.count 0, target1705.elements.count 1,
      target1705.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1705
def tree1706 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target1706 : Target Nat := ⟨.seq, [1, 2, 0, 2]⟩
theorem chain1706 : accepts tree1706 target1706 = true ∧
    sourceLeaves tree1706 = [1, 2, 0, 2] ∧
    target1706.elements.length = 4 ∧
    [target1706.elements.count 0, target1706.elements.count 1,
      target1706.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1706
def tree1707 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))))
def target1707 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1707 : accepts tree1707 target1707 = true ∧
    sourceLeaves tree1707 = [1, 2, 1, 0] ∧
    target1707.elements.length = 4 ∧
    [target1707.elements.count 0, target1707.elements.count 1,
      target1707.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1707
def tree1708 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)))
def target1708 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1708 : accepts tree1708 target1708 = true ∧
    sourceLeaves tree1708 = [1, 2, 1, 0] ∧
    target1708.elements.length = 4 ∧
    [target1708.elements.count 0, target1708.elements.count 1,
      target1708.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1708
def tree1709 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1709 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1709 : accepts tree1709 target1709 = true ∧
    sourceLeaves tree1709 = [1, 2, 1, 0] ∧
    target1709.elements.length = 4 ∧
    [target1709.elements.count 0, target1709.elements.count 1,
      target1709.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1709
def tree1710 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 0))
def target1710 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1710 : accepts tree1710 target1710 = true ∧
    sourceLeaves tree1710 = [1, 2, 1, 0] ∧
    target1710.elements.length = 4 ∧
    [target1710.elements.count 0, target1710.elements.count 1,
      target1710.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1710
def tree1711 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target1711 : Target Nat := ⟨.seq, [1, 2, 1, 0]⟩
theorem chain1711 : accepts tree1711 target1711 = true ∧
    sourceLeaves tree1711 = [1, 2, 1, 0] ∧
    target1711.elements.length = 4 ∧
    [target1711.elements.count 0, target1711.elements.count 1,
      target1711.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1711
def tree1712 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))))
def target1712 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1712 : accepts tree1712 target1712 = true ∧
    sourceLeaves tree1712 = [1, 2, 1, 1] ∧
    target1712.elements.length = 4 ∧
    [target1712.elements.count 0, target1712.elements.count 1,
      target1712.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1712
def tree1713 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)))
def target1713 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1713 : accepts tree1713 target1713 = true ∧
    sourceLeaves tree1713 = [1, 2, 1, 1] ∧
    target1713.elements.length = 4 ∧
    [target1713.elements.count 0, target1713.elements.count 1,
      target1713.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1713
def tree1714 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1714 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1714 : accepts tree1714 target1714 = true ∧
    sourceLeaves tree1714 = [1, 2, 1, 1] ∧
    target1714.elements.length = 4 ∧
    [target1714.elements.count 0, target1714.elements.count 1,
      target1714.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1714
def tree1715 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 1))
def target1715 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1715 : accepts tree1715 target1715 = true ∧
    sourceLeaves tree1715 = [1, 2, 1, 1] ∧
    target1715.elements.length = 4 ∧
    [target1715.elements.count 0, target1715.elements.count 1,
      target1715.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1715
def tree1716 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target1716 : Target Nat := ⟨.seq, [1, 2, 1, 1]⟩
theorem chain1716 : accepts tree1716 target1716 = true ∧
    sourceLeaves tree1716 = [1, 2, 1, 1] ∧
    target1716.elements.length = 4 ∧
    [target1716.elements.count 0, target1716.elements.count 1,
      target1716.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1716
def tree1717 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))))
def target1717 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1717 : accepts tree1717 target1717 = true ∧
    sourceLeaves tree1717 = [1, 2, 1, 2] ∧
    target1717.elements.length = 4 ∧
    [target1717.elements.count 0, target1717.elements.count 1,
      target1717.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1717
def tree1718 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)))
def target1718 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1718 : accepts tree1718 target1718 = true ∧
    sourceLeaves tree1718 = [1, 2, 1, 2] ∧
    target1718.elements.length = 4 ∧
    [target1718.elements.count 0, target1718.elements.count 1,
      target1718.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1718
def tree1719 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1719 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1719 : accepts tree1719 target1719 = true ∧
    sourceLeaves tree1719 = [1, 2, 1, 2] ∧
    target1719.elements.length = 4 ∧
    [target1719.elements.count 0, target1719.elements.count 1,
      target1719.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1719
def tree1720 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 2))
def target1720 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1720 : accepts tree1720 target1720 = true ∧
    sourceLeaves tree1720 = [1, 2, 1, 2] ∧
    target1720.elements.length = 4 ∧
    [target1720.elements.count 0, target1720.elements.count 1,
      target1720.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1720
def tree1721 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target1721 : Target Nat := ⟨.seq, [1, 2, 1, 2]⟩
theorem chain1721 : accepts tree1721 target1721 = true ∧
    sourceLeaves tree1721 = [1, 2, 1, 2] ∧
    target1721.elements.length = 4 ∧
    [target1721.elements.count 0, target1721.elements.count 1,
      target1721.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1721
def tree1722 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))))
def target1722 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1722 : accepts tree1722 target1722 = true ∧
    sourceLeaves tree1722 = [1, 2, 2, 0] ∧
    target1722.elements.length = 4 ∧
    [target1722.elements.count 0, target1722.elements.count 1,
      target1722.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1722
def tree1723 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)))
def target1723 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1723 : accepts tree1723 target1723 = true ∧
    sourceLeaves tree1723 = [1, 2, 2, 0] ∧
    target1723.elements.length = 4 ∧
    [target1723.elements.count 0, target1723.elements.count 1,
      target1723.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1723
def tree1724 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1724 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1724 : accepts tree1724 target1724 = true ∧
    sourceLeaves tree1724 = [1, 2, 2, 0] ∧
    target1724.elements.length = 4 ∧
    [target1724.elements.count 0, target1724.elements.count 1,
      target1724.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1724
def tree1725 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 0))
def target1725 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1725 : accepts tree1725 target1725 = true ∧
    sourceLeaves tree1725 = [1, 2, 2, 0] ∧
    target1725.elements.length = 4 ∧
    [target1725.elements.count 0, target1725.elements.count 1,
      target1725.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1725
def tree1726 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target1726 : Target Nat := ⟨.seq, [1, 2, 2, 0]⟩
theorem chain1726 : accepts tree1726 target1726 = true ∧
    sourceLeaves tree1726 = [1, 2, 2, 0] ∧
    target1726.elements.length = 4 ∧
    [target1726.elements.count 0, target1726.elements.count 1,
      target1726.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1726
def tree1727 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))))
def target1727 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1727 : accepts tree1727 target1727 = true ∧
    sourceLeaves tree1727 = [1, 2, 2, 1] ∧
    target1727.elements.length = 4 ∧
    [target1727.elements.count 0, target1727.elements.count 1,
      target1727.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1727
def tree1728 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)))
def target1728 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1728 : accepts tree1728 target1728 = true ∧
    sourceLeaves tree1728 = [1, 2, 2, 1] ∧
    target1728.elements.length = 4 ∧
    [target1728.elements.count 0, target1728.elements.count 1,
      target1728.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1728
def tree1729 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1729 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1729 : accepts tree1729 target1729 = true ∧
    sourceLeaves tree1729 = [1, 2, 2, 1] ∧
    target1729.elements.length = 4 ∧
    [target1729.elements.count 0, target1729.elements.count 1,
      target1729.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1729
def tree1730 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 1))
def target1730 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1730 : accepts tree1730 target1730 = true ∧
    sourceLeaves tree1730 = [1, 2, 2, 1] ∧
    target1730.elements.length = 4 ∧
    [target1730.elements.count 0, target1730.elements.count 1,
      target1730.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1730
def tree1731 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target1731 : Target Nat := ⟨.seq, [1, 2, 2, 1]⟩
theorem chain1731 : accepts tree1731 target1731 = true ∧
    sourceLeaves tree1731 = [1, 2, 2, 1] ∧
    target1731.elements.length = 4 ∧
    [target1731.elements.count 0, target1731.elements.count 1,
      target1731.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1731
def tree1732 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))))
def target1732 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1732 : accepts tree1732 target1732 = true ∧
    sourceLeaves tree1732 = [1, 2, 2, 2] ∧
    target1732.elements.length = 4 ∧
    [target1732.elements.count 0, target1732.elements.count 1,
      target1732.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1732
def tree1733 : SourceTree Nat .arrow := (.app .arrow (.leaf 1) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)))
def target1733 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1733 : accepts tree1733 target1733 = true ∧
    sourceLeaves tree1733 = [1, 2, 2, 2] ∧
    target1733.elements.length = 4 ∧
    [target1733.elements.count 0, target1733.elements.count 1,
      target1733.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1733
def tree1734 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1734 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1734 : accepts tree1734 target1734 = true ∧
    sourceLeaves tree1734 = [1, 2, 2, 2] ∧
    target1734.elements.length = 4 ∧
    [target1734.elements.count 0, target1734.elements.count 1,
      target1734.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1734
def tree1735 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 2))
def target1735 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1735 : accepts tree1735 target1735 = true ∧
    sourceLeaves tree1735 = [1, 2, 2, 2] ∧
    target1735.elements.length = 4 ∧
    [target1735.elements.count 0, target1735.elements.count 1,
      target1735.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1735
def tree1736 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target1736 : Target Nat := ⟨.seq, [1, 2, 2, 2]⟩
theorem chain1736 : accepts tree1736 target1736 = true ∧
    sourceLeaves tree1736 = [1, 2, 2, 2] ∧
    target1736.elements.length = 4 ∧
    [target1736.elements.count 0, target1736.elements.count 1,
      target1736.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1736
def tree1737 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 0))))
def target1737 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1737 : accepts tree1737 target1737 = true ∧
    sourceLeaves tree1737 = [2, 0, 0, 0] ∧
    target1737.elements.length = 4 ∧
    [target1737.elements.count 0, target1737.elements.count 1,
      target1737.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1737
def tree1738 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 0)))
def target1738 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1738 : accepts tree1738 target1738 = true ∧
    sourceLeaves tree1738 = [2, 0, 0, 0] ∧
    target1738.elements.length = 4 ∧
    [target1738.elements.count 0, target1738.elements.count 1,
      target1738.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1738
def tree1739 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1739 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1739 : accepts tree1739 target1739 = true ∧
    sourceLeaves tree1739 = [2, 0, 0, 0] ∧
    target1739.elements.length = 4 ∧
    [target1739.elements.count 0, target1739.elements.count 1,
      target1739.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1739
def tree1740 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 0))
def target1740 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1740 : accepts tree1740 target1740 = true ∧
    sourceLeaves tree1740 = [2, 0, 0, 0] ∧
    target1740.elements.length = 4 ∧
    [target1740.elements.count 0, target1740.elements.count 1,
      target1740.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1740
def tree1741 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 0))
def target1741 : Target Nat := ⟨.seq, [2, 0, 0, 0]⟩
theorem chain1741 : accepts tree1741 target1741 = true ∧
    sourceLeaves tree1741 = [2, 0, 0, 0] ∧
    target1741.elements.length = 4 ∧
    [target1741.elements.count 0, target1741.elements.count 1,
      target1741.elements.count 2] = [3, 0, 1] := by decide
#print axioms chain1741
def tree1742 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 1))))
def target1742 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1742 : accepts tree1742 target1742 = true ∧
    sourceLeaves tree1742 = [2, 0, 0, 1] ∧
    target1742.elements.length = 4 ∧
    [target1742.elements.count 0, target1742.elements.count 1,
      target1742.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1742
def tree1743 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 1)))
def target1743 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1743 : accepts tree1743 target1743 = true ∧
    sourceLeaves tree1743 = [2, 0, 0, 1] ∧
    target1743.elements.length = 4 ∧
    [target1743.elements.count 0, target1743.elements.count 1,
      target1743.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1743
def tree1744 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1744 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1744 : accepts tree1744 target1744 = true ∧
    sourceLeaves tree1744 = [2, 0, 0, 1] ∧
    target1744.elements.length = 4 ∧
    [target1744.elements.count 0, target1744.elements.count 1,
      target1744.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1744
def tree1745 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 1))
def target1745 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1745 : accepts tree1745 target1745 = true ∧
    sourceLeaves tree1745 = [2, 0, 0, 1] ∧
    target1745.elements.length = 4 ∧
    [target1745.elements.count 0, target1745.elements.count 1,
      target1745.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1745
def tree1746 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 1))
def target1746 : Target Nat := ⟨.seq, [2, 0, 0, 1]⟩
theorem chain1746 : accepts tree1746 target1746 = true ∧
    sourceLeaves tree1746 = [2, 0, 0, 1] ∧
    target1746.elements.length = 4 ∧
    [target1746.elements.count 0, target1746.elements.count 1,
      target1746.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1746
def tree1747 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 0) (.leaf 2))))
def target1747 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1747 : accepts tree1747 target1747 = true ∧
    sourceLeaves tree1747 = [2, 0, 0, 2] ∧
    target1747.elements.length = 4 ∧
    [target1747.elements.count 0, target1747.elements.count 1,
      target1747.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1747
def tree1748 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 0)) (.leaf 2)))
def target1748 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1748 : accepts tree1748 target1748 = true ∧
    sourceLeaves tree1748 = [2, 0, 0, 2] ∧
    target1748.elements.length = 4 ∧
    [target1748.elements.count 0, target1748.elements.count 1,
      target1748.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1748
def tree1749 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1749 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1749 : accepts tree1749 target1749 = true ∧
    sourceLeaves tree1749 = [2, 0, 0, 2] ∧
    target1749.elements.length = 4 ∧
    [target1749.elements.count 0, target1749.elements.count 1,
      target1749.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1749
def tree1750 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))) (.leaf 2))
def target1750 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1750 : accepts tree1750 target1750 = true ∧
    sourceLeaves tree1750 = [2, 0, 0, 2] ∧
    target1750.elements.length = 4 ∧
    [target1750.elements.count 0, target1750.elements.count 1,
      target1750.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1750
def tree1751 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)) (.leaf 2))
def target1751 : Target Nat := ⟨.seq, [2, 0, 0, 2]⟩
theorem chain1751 : accepts tree1751 target1751 = true ∧
    sourceLeaves tree1751 = [2, 0, 0, 2] ∧
    target1751.elements.length = 4 ∧
    [target1751.elements.count 0, target1751.elements.count 1,
      target1751.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1751
def tree1752 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0))))
def target1752 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1752 : accepts tree1752 target1752 = true ∧
    sourceLeaves tree1752 = [2, 0, 1, 0] ∧
    target1752.elements.length = 4 ∧
    [target1752.elements.count 0, target1752.elements.count 1,
      target1752.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1752
def tree1753 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0)))
def target1753 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1753 : accepts tree1753 target1753 = true ∧
    sourceLeaves tree1753 = [2, 0, 1, 0] ∧
    target1753.elements.length = 4 ∧
    [target1753.elements.count 0, target1753.elements.count 1,
      target1753.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1753
def tree1754 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1754 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1754 : accepts tree1754 target1754 = true ∧
    sourceLeaves tree1754 = [2, 0, 1, 0] ∧
    target1754.elements.length = 4 ∧
    [target1754.elements.count 0, target1754.elements.count 1,
      target1754.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1754
def tree1755 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 0))
def target1755 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1755 : accepts tree1755 target1755 = true ∧
    sourceLeaves tree1755 = [2, 0, 1, 0] ∧
    target1755.elements.length = 4 ∧
    [target1755.elements.count 0, target1755.elements.count 1,
      target1755.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1755
def tree1756 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 0))
def target1756 : Target Nat := ⟨.seq, [2, 0, 1, 0]⟩
theorem chain1756 : accepts tree1756 target1756 = true ∧
    sourceLeaves tree1756 = [2, 0, 1, 0] ∧
    target1756.elements.length = 4 ∧
    [target1756.elements.count 0, target1756.elements.count 1,
      target1756.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1756
def tree1757 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 1))))
def target1757 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1757 : accepts tree1757 target1757 = true ∧
    sourceLeaves tree1757 = [2, 0, 1, 1] ∧
    target1757.elements.length = 4 ∧
    [target1757.elements.count 0, target1757.elements.count 1,
      target1757.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1757
def tree1758 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1)))
def target1758 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1758 : accepts tree1758 target1758 = true ∧
    sourceLeaves tree1758 = [2, 0, 1, 1] ∧
    target1758.elements.length = 4 ∧
    [target1758.elements.count 0, target1758.elements.count 1,
      target1758.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1758
def tree1759 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1759 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1759 : accepts tree1759 target1759 = true ∧
    sourceLeaves tree1759 = [2, 0, 1, 1] ∧
    target1759.elements.length = 4 ∧
    [target1759.elements.count 0, target1759.elements.count 1,
      target1759.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1759
def tree1760 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 1))
def target1760 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1760 : accepts tree1760 target1760 = true ∧
    sourceLeaves tree1760 = [2, 0, 1, 1] ∧
    target1760.elements.length = 4 ∧
    [target1760.elements.count 0, target1760.elements.count 1,
      target1760.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1760
def tree1761 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 1))
def target1761 : Target Nat := ⟨.seq, [2, 0, 1, 1]⟩
theorem chain1761 : accepts tree1761 target1761 = true ∧
    sourceLeaves tree1761 = [2, 0, 1, 1] ∧
    target1761.elements.length = 4 ∧
    [target1761.elements.count 0, target1761.elements.count 1,
      target1761.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1761
def tree1762 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 2))))
def target1762 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1762 : accepts tree1762 target1762 = true ∧
    sourceLeaves tree1762 = [2, 0, 1, 2] ∧
    target1762.elements.length = 4 ∧
    [target1762.elements.count 0, target1762.elements.count 1,
      target1762.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1762
def tree1763 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 2)))
def target1763 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1763 : accepts tree1763 target1763 = true ∧
    sourceLeaves tree1763 = [2, 0, 1, 2] ∧
    target1763.elements.length = 4 ∧
    [target1763.elements.count 0, target1763.elements.count 1,
      target1763.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1763
def tree1764 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1764 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1764 : accepts tree1764 target1764 = true ∧
    sourceLeaves tree1764 = [2, 0, 1, 2] ∧
    target1764.elements.length = 4 ∧
    [target1764.elements.count 0, target1764.elements.count 1,
      target1764.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1764
def tree1765 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))) (.leaf 2))
def target1765 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1765 : accepts tree1765 target1765 = true ∧
    sourceLeaves tree1765 = [2, 0, 1, 2] ∧
    target1765.elements.length = 4 ∧
    [target1765.elements.count 0, target1765.elements.count 1,
      target1765.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1765
def tree1766 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)) (.leaf 2))
def target1766 : Target Nat := ⟨.seq, [2, 0, 1, 2]⟩
theorem chain1766 : accepts tree1766 target1766 = true ∧
    sourceLeaves tree1766 = [2, 0, 1, 2] ∧
    target1766.elements.length = 4 ∧
    [target1766.elements.count 0, target1766.elements.count 1,
      target1766.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1766
def tree1767 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 0))))
def target1767 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1767 : accepts tree1767 target1767 = true ∧
    sourceLeaves tree1767 = [2, 0, 2, 0] ∧
    target1767.elements.length = 4 ∧
    [target1767.elements.count 0, target1767.elements.count 1,
      target1767.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1767
def tree1768 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 0)))
def target1768 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1768 : accepts tree1768 target1768 = true ∧
    sourceLeaves tree1768 = [2, 0, 2, 0] ∧
    target1768.elements.length = 4 ∧
    [target1768.elements.count 0, target1768.elements.count 1,
      target1768.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1768
def tree1769 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1769 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1769 : accepts tree1769 target1769 = true ∧
    sourceLeaves tree1769 = [2, 0, 2, 0] ∧
    target1769.elements.length = 4 ∧
    [target1769.elements.count 0, target1769.elements.count 1,
      target1769.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1769
def tree1770 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 0))
def target1770 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1770 : accepts tree1770 target1770 = true ∧
    sourceLeaves tree1770 = [2, 0, 2, 0] ∧
    target1770.elements.length = 4 ∧
    [target1770.elements.count 0, target1770.elements.count 1,
      target1770.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1770
def tree1771 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 0))
def target1771 : Target Nat := ⟨.seq, [2, 0, 2, 0]⟩
theorem chain1771 : accepts tree1771 target1771 = true ∧
    sourceLeaves tree1771 = [2, 0, 2, 0] ∧
    target1771.elements.length = 4 ∧
    [target1771.elements.count 0, target1771.elements.count 1,
      target1771.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1771
def tree1772 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 1))))
def target1772 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1772 : accepts tree1772 target1772 = true ∧
    sourceLeaves tree1772 = [2, 0, 2, 1] ∧
    target1772.elements.length = 4 ∧
    [target1772.elements.count 0, target1772.elements.count 1,
      target1772.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1772
def tree1773 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 1)))
def target1773 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1773 : accepts tree1773 target1773 = true ∧
    sourceLeaves tree1773 = [2, 0, 2, 1] ∧
    target1773.elements.length = 4 ∧
    [target1773.elements.count 0, target1773.elements.count 1,
      target1773.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1773
def tree1774 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1774 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1774 : accepts tree1774 target1774 = true ∧
    sourceLeaves tree1774 = [2, 0, 2, 1] ∧
    target1774.elements.length = 4 ∧
    [target1774.elements.count 0, target1774.elements.count 1,
      target1774.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1774
def tree1775 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 1))
def target1775 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1775 : accepts tree1775 target1775 = true ∧
    sourceLeaves tree1775 = [2, 0, 2, 1] ∧
    target1775.elements.length = 4 ∧
    [target1775.elements.count 0, target1775.elements.count 1,
      target1775.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1775
def tree1776 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 1))
def target1776 : Target Nat := ⟨.seq, [2, 0, 2, 1]⟩
theorem chain1776 : accepts tree1776 target1776 = true ∧
    sourceLeaves tree1776 = [2, 0, 2, 1] ∧
    target1776.elements.length = 4 ∧
    [target1776.elements.count 0, target1776.elements.count 1,
      target1776.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1776
def tree1777 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.app .arrow (.leaf 2) (.leaf 2))))
def target1777 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1777 : accepts tree1777 target1777 = true ∧
    sourceLeaves tree1777 = [2, 0, 2, 2] ∧
    target1777.elements.length = 4 ∧
    [target1777.elements.count 0, target1777.elements.count 1,
      target1777.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1777
def tree1778 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 0) (.leaf 2)) (.leaf 2)))
def target1778 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1778 : accepts tree1778 target1778 = true ∧
    sourceLeaves tree1778 = [2, 0, 2, 2] ∧
    target1778.elements.length = 4 ∧
    [target1778.elements.count 0, target1778.elements.count 1,
      target1778.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1778
def tree1779 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1779 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1779 : accepts tree1779 target1779 = true ∧
    sourceLeaves tree1779 = [2, 0, 2, 2] ∧
    target1779.elements.length = 4 ∧
    [target1779.elements.count 0, target1779.elements.count 1,
      target1779.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1779
def tree1780 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))) (.leaf 2))
def target1780 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1780 : accepts tree1780 target1780 = true ∧
    sourceLeaves tree1780 = [2, 0, 2, 2] ∧
    target1780.elements.length = 4 ∧
    [target1780.elements.count 0, target1780.elements.count 1,
      target1780.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1780
def tree1781 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)) (.leaf 2))
def target1781 : Target Nat := ⟨.seq, [2, 0, 2, 2]⟩
theorem chain1781 : accepts tree1781 target1781 = true ∧
    sourceLeaves tree1781 = [2, 0, 2, 2] ∧
    target1781.elements.length = 4 ∧
    [target1781.elements.count 0, target1781.elements.count 1,
      target1781.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1781
def tree1782 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 0))))
def target1782 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1782 : accepts tree1782 target1782 = true ∧
    sourceLeaves tree1782 = [2, 1, 0, 0] ∧
    target1782.elements.length = 4 ∧
    [target1782.elements.count 0, target1782.elements.count 1,
      target1782.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1782
def tree1783 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0)))
def target1783 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1783 : accepts tree1783 target1783 = true ∧
    sourceLeaves tree1783 = [2, 1, 0, 0] ∧
    target1783.elements.length = 4 ∧
    [target1783.elements.count 0, target1783.elements.count 1,
      target1783.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1783
def tree1784 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1784 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1784 : accepts tree1784 target1784 = true ∧
    sourceLeaves tree1784 = [2, 1, 0, 0] ∧
    target1784.elements.length = 4 ∧
    [target1784.elements.count 0, target1784.elements.count 1,
      target1784.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1784
def tree1785 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 0))
def target1785 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1785 : accepts tree1785 target1785 = true ∧
    sourceLeaves tree1785 = [2, 1, 0, 0] ∧
    target1785.elements.length = 4 ∧
    [target1785.elements.count 0, target1785.elements.count 1,
      target1785.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1785
def tree1786 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 0))
def target1786 : Target Nat := ⟨.seq, [2, 1, 0, 0]⟩
theorem chain1786 : accepts tree1786 target1786 = true ∧
    sourceLeaves tree1786 = [2, 1, 0, 0] ∧
    target1786.elements.length = 4 ∧
    [target1786.elements.count 0, target1786.elements.count 1,
      target1786.elements.count 2] = [2, 1, 1] := by decide
#print axioms chain1786
def tree1787 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 1))))
def target1787 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1787 : accepts tree1787 target1787 = true ∧
    sourceLeaves tree1787 = [2, 1, 0, 1] ∧
    target1787.elements.length = 4 ∧
    [target1787.elements.count 0, target1787.elements.count 1,
      target1787.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1787
def tree1788 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 1)))
def target1788 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1788 : accepts tree1788 target1788 = true ∧
    sourceLeaves tree1788 = [2, 1, 0, 1] ∧
    target1788.elements.length = 4 ∧
    [target1788.elements.count 0, target1788.elements.count 1,
      target1788.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1788
def tree1789 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1789 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1789 : accepts tree1789 target1789 = true ∧
    sourceLeaves tree1789 = [2, 1, 0, 1] ∧
    target1789.elements.length = 4 ∧
    [target1789.elements.count 0, target1789.elements.count 1,
      target1789.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1789
def tree1790 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 1))
def target1790 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1790 : accepts tree1790 target1790 = true ∧
    sourceLeaves tree1790 = [2, 1, 0, 1] ∧
    target1790.elements.length = 4 ∧
    [target1790.elements.count 0, target1790.elements.count 1,
      target1790.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1790
def tree1791 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 1))
def target1791 : Target Nat := ⟨.seq, [2, 1, 0, 1]⟩
theorem chain1791 : accepts tree1791 target1791 = true ∧
    sourceLeaves tree1791 = [2, 1, 0, 1] ∧
    target1791.elements.length = 4 ∧
    [target1791.elements.count 0, target1791.elements.count 1,
      target1791.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1791
def tree1792 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 0) (.leaf 2))))
def target1792 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1792 : accepts tree1792 target1792 = true ∧
    sourceLeaves tree1792 = [2, 1, 0, 2] ∧
    target1792.elements.length = 4 ∧
    [target1792.elements.count 0, target1792.elements.count 1,
      target1792.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1792
def tree1793 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 2)))
def target1793 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1793 : accepts tree1793 target1793 = true ∧
    sourceLeaves tree1793 = [2, 1, 0, 2] ∧
    target1793.elements.length = 4 ∧
    [target1793.elements.count 0, target1793.elements.count 1,
      target1793.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1793
def tree1794 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1794 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1794 : accepts tree1794 target1794 = true ∧
    sourceLeaves tree1794 = [2, 1, 0, 2] ∧
    target1794.elements.length = 4 ∧
    [target1794.elements.count 0, target1794.elements.count 1,
      target1794.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1794
def tree1795 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))) (.leaf 2))
def target1795 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1795 : accepts tree1795 target1795 = true ∧
    sourceLeaves tree1795 = [2, 1, 0, 2] ∧
    target1795.elements.length = 4 ∧
    [target1795.elements.count 0, target1795.elements.count 1,
      target1795.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1795
def tree1796 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)) (.leaf 2))
def target1796 : Target Nat := ⟨.seq, [2, 1, 0, 2]⟩
theorem chain1796 : accepts tree1796 target1796 = true ∧
    sourceLeaves tree1796 = [2, 1, 0, 2] ∧
    target1796.elements.length = 4 ∧
    [target1796.elements.count 0, target1796.elements.count 1,
      target1796.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1796
def tree1797 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 0))))
def target1797 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1797 : accepts tree1797 target1797 = true ∧
    sourceLeaves tree1797 = [2, 1, 1, 0] ∧
    target1797.elements.length = 4 ∧
    [target1797.elements.count 0, target1797.elements.count 1,
      target1797.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1797
def tree1798 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 0)))
def target1798 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1798 : accepts tree1798 target1798 = true ∧
    sourceLeaves tree1798 = [2, 1, 1, 0] ∧
    target1798.elements.length = 4 ∧
    [target1798.elements.count 0, target1798.elements.count 1,
      target1798.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1798
def tree1799 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1799 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1799 : accepts tree1799 target1799 = true ∧
    sourceLeaves tree1799 = [2, 1, 1, 0] ∧
    target1799.elements.length = 4 ∧
    [target1799.elements.count 0, target1799.elements.count 1,
      target1799.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1799
def tree1800 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 0))
def target1800 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1800 : accepts tree1800 target1800 = true ∧
    sourceLeaves tree1800 = [2, 1, 1, 0] ∧
    target1800.elements.length = 4 ∧
    [target1800.elements.count 0, target1800.elements.count 1,
      target1800.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1800
def tree1801 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 0))
def target1801 : Target Nat := ⟨.seq, [2, 1, 1, 0]⟩
theorem chain1801 : accepts tree1801 target1801 = true ∧
    sourceLeaves tree1801 = [2, 1, 1, 0] ∧
    target1801.elements.length = 4 ∧
    [target1801.elements.count 0, target1801.elements.count 1,
      target1801.elements.count 2] = [1, 2, 1] := by decide
#print axioms chain1801
def tree1802 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 1))))
def target1802 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1802 : accepts tree1802 target1802 = true ∧
    sourceLeaves tree1802 = [2, 1, 1, 1] ∧
    target1802.elements.length = 4 ∧
    [target1802.elements.count 0, target1802.elements.count 1,
      target1802.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1802
def tree1803 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 1)))
def target1803 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1803 : accepts tree1803 target1803 = true ∧
    sourceLeaves tree1803 = [2, 1, 1, 1] ∧
    target1803.elements.length = 4 ∧
    [target1803.elements.count 0, target1803.elements.count 1,
      target1803.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1803
def tree1804 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1804 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1804 : accepts tree1804 target1804 = true ∧
    sourceLeaves tree1804 = [2, 1, 1, 1] ∧
    target1804.elements.length = 4 ∧
    [target1804.elements.count 0, target1804.elements.count 1,
      target1804.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1804
def tree1805 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 1))
def target1805 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1805 : accepts tree1805 target1805 = true ∧
    sourceLeaves tree1805 = [2, 1, 1, 1] ∧
    target1805.elements.length = 4 ∧
    [target1805.elements.count 0, target1805.elements.count 1,
      target1805.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1805
def tree1806 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 1))
def target1806 : Target Nat := ⟨.seq, [2, 1, 1, 1]⟩
theorem chain1806 : accepts tree1806 target1806 = true ∧
    sourceLeaves tree1806 = [2, 1, 1, 1] ∧
    target1806.elements.length = 4 ∧
    [target1806.elements.count 0, target1806.elements.count 1,
      target1806.elements.count 2] = [0, 3, 1] := by decide
#print axioms chain1806
def tree1807 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 1) (.leaf 2))))
def target1807 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1807 : accepts tree1807 target1807 = true ∧
    sourceLeaves tree1807 = [2, 1, 1, 2] ∧
    target1807.elements.length = 4 ∧
    [target1807.elements.count 0, target1807.elements.count 1,
      target1807.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1807
def tree1808 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 1)) (.leaf 2)))
def target1808 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1808 : accepts tree1808 target1808 = true ∧
    sourceLeaves tree1808 = [2, 1, 1, 2] ∧
    target1808.elements.length = 4 ∧
    [target1808.elements.count 0, target1808.elements.count 1,
      target1808.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1808
def tree1809 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1809 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1809 : accepts tree1809 target1809 = true ∧
    sourceLeaves tree1809 = [2, 1, 1, 2] ∧
    target1809.elements.length = 4 ∧
    [target1809.elements.count 0, target1809.elements.count 1,
      target1809.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1809
def tree1810 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))) (.leaf 2))
def target1810 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1810 : accepts tree1810 target1810 = true ∧
    sourceLeaves tree1810 = [2, 1, 1, 2] ∧
    target1810.elements.length = 4 ∧
    [target1810.elements.count 0, target1810.elements.count 1,
      target1810.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1810
def tree1811 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)) (.leaf 2))
def target1811 : Target Nat := ⟨.seq, [2, 1, 1, 2]⟩
theorem chain1811 : accepts tree1811 target1811 = true ∧
    sourceLeaves tree1811 = [2, 1, 1, 2] ∧
    target1811.elements.length = 4 ∧
    [target1811.elements.count 0, target1811.elements.count 1,
      target1811.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1811
def tree1812 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 0))))
def target1812 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1812 : accepts tree1812 target1812 = true ∧
    sourceLeaves tree1812 = [2, 1, 2, 0] ∧
    target1812.elements.length = 4 ∧
    [target1812.elements.count 0, target1812.elements.count 1,
      target1812.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1812
def tree1813 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 0)))
def target1813 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1813 : accepts tree1813 target1813 = true ∧
    sourceLeaves tree1813 = [2, 1, 2, 0] ∧
    target1813.elements.length = 4 ∧
    [target1813.elements.count 0, target1813.elements.count 1,
      target1813.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1813
def tree1814 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1814 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1814 : accepts tree1814 target1814 = true ∧
    sourceLeaves tree1814 = [2, 1, 2, 0] ∧
    target1814.elements.length = 4 ∧
    [target1814.elements.count 0, target1814.elements.count 1,
      target1814.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1814
def tree1815 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 0))
def target1815 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1815 : accepts tree1815 target1815 = true ∧
    sourceLeaves tree1815 = [2, 1, 2, 0] ∧
    target1815.elements.length = 4 ∧
    [target1815.elements.count 0, target1815.elements.count 1,
      target1815.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1815
def tree1816 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 0))
def target1816 : Target Nat := ⟨.seq, [2, 1, 2, 0]⟩
theorem chain1816 : accepts tree1816 target1816 = true ∧
    sourceLeaves tree1816 = [2, 1, 2, 0] ∧
    target1816.elements.length = 4 ∧
    [target1816.elements.count 0, target1816.elements.count 1,
      target1816.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1816
def tree1817 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 1))))
def target1817 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1817 : accepts tree1817 target1817 = true ∧
    sourceLeaves tree1817 = [2, 1, 2, 1] ∧
    target1817.elements.length = 4 ∧
    [target1817.elements.count 0, target1817.elements.count 1,
      target1817.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1817
def tree1818 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 1)))
def target1818 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1818 : accepts tree1818 target1818 = true ∧
    sourceLeaves tree1818 = [2, 1, 2, 1] ∧
    target1818.elements.length = 4 ∧
    [target1818.elements.count 0, target1818.elements.count 1,
      target1818.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1818
def tree1819 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1819 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1819 : accepts tree1819 target1819 = true ∧
    sourceLeaves tree1819 = [2, 1, 2, 1] ∧
    target1819.elements.length = 4 ∧
    [target1819.elements.count 0, target1819.elements.count 1,
      target1819.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1819
def tree1820 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 1))
def target1820 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1820 : accepts tree1820 target1820 = true ∧
    sourceLeaves tree1820 = [2, 1, 2, 1] ∧
    target1820.elements.length = 4 ∧
    [target1820.elements.count 0, target1820.elements.count 1,
      target1820.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1820
def tree1821 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 1))
def target1821 : Target Nat := ⟨.seq, [2, 1, 2, 1]⟩
theorem chain1821 : accepts tree1821 target1821 = true ∧
    sourceLeaves tree1821 = [2, 1, 2, 1] ∧
    target1821.elements.length = 4 ∧
    [target1821.elements.count 0, target1821.elements.count 1,
      target1821.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1821
def tree1822 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.app .arrow (.leaf 2) (.leaf 2))))
def target1822 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1822 : accepts tree1822 target1822 = true ∧
    sourceLeaves tree1822 = [2, 1, 2, 2] ∧
    target1822.elements.length = 4 ∧
    [target1822.elements.count 0, target1822.elements.count 1,
      target1822.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1822
def tree1823 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 1) (.leaf 2)) (.leaf 2)))
def target1823 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1823 : accepts tree1823 target1823 = true ∧
    sourceLeaves tree1823 = [2, 1, 2, 2] ∧
    target1823.elements.length = 4 ∧
    [target1823.elements.count 0, target1823.elements.count 1,
      target1823.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1823
def tree1824 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1824 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1824 : accepts tree1824 target1824 = true ∧
    sourceLeaves tree1824 = [2, 1, 2, 2] ∧
    target1824.elements.length = 4 ∧
    [target1824.elements.count 0, target1824.elements.count 1,
      target1824.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1824
def tree1825 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))) (.leaf 2))
def target1825 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1825 : accepts tree1825 target1825 = true ∧
    sourceLeaves tree1825 = [2, 1, 2, 2] ∧
    target1825.elements.length = 4 ∧
    [target1825.elements.count 0, target1825.elements.count 1,
      target1825.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1825
def tree1826 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)) (.leaf 2))
def target1826 : Target Nat := ⟨.seq, [2, 1, 2, 2]⟩
theorem chain1826 : accepts tree1826 target1826 = true ∧
    sourceLeaves tree1826 = [2, 1, 2, 2] ∧
    target1826.elements.length = 4 ∧
    [target1826.elements.count 0, target1826.elements.count 1,
      target1826.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1826
def tree1827 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 0))))
def target1827 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1827 : accepts tree1827 target1827 = true ∧
    sourceLeaves tree1827 = [2, 2, 0, 0] ∧
    target1827.elements.length = 4 ∧
    [target1827.elements.count 0, target1827.elements.count 1,
      target1827.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1827
def tree1828 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 0)))
def target1828 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1828 : accepts tree1828 target1828 = true ∧
    sourceLeaves tree1828 = [2, 2, 0, 0] ∧
    target1828.elements.length = 4 ∧
    [target1828.elements.count 0, target1828.elements.count 1,
      target1828.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1828
def tree1829 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 0)))
def target1829 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1829 : accepts tree1829 target1829 = true ∧
    sourceLeaves tree1829 = [2, 2, 0, 0] ∧
    target1829.elements.length = 4 ∧
    [target1829.elements.count 0, target1829.elements.count 1,
      target1829.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1829
def tree1830 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 0))
def target1830 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1830 : accepts tree1830 target1830 = true ∧
    sourceLeaves tree1830 = [2, 2, 0, 0] ∧
    target1830.elements.length = 4 ∧
    [target1830.elements.count 0, target1830.elements.count 1,
      target1830.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1830
def tree1831 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 0))
def target1831 : Target Nat := ⟨.seq, [2, 2, 0, 0]⟩
theorem chain1831 : accepts tree1831 target1831 = true ∧
    sourceLeaves tree1831 = [2, 2, 0, 0] ∧
    target1831.elements.length = 4 ∧
    [target1831.elements.count 0, target1831.elements.count 1,
      target1831.elements.count 2] = [2, 0, 2] := by decide
#print axioms chain1831
def tree1832 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 1))))
def target1832 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1832 : accepts tree1832 target1832 = true ∧
    sourceLeaves tree1832 = [2, 2, 0, 1] ∧
    target1832.elements.length = 4 ∧
    [target1832.elements.count 0, target1832.elements.count 1,
      target1832.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1832
def tree1833 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 1)))
def target1833 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1833 : accepts tree1833 target1833 = true ∧
    sourceLeaves tree1833 = [2, 2, 0, 1] ∧
    target1833.elements.length = 4 ∧
    [target1833.elements.count 0, target1833.elements.count 1,
      target1833.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1833
def tree1834 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 1)))
def target1834 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1834 : accepts tree1834 target1834 = true ∧
    sourceLeaves tree1834 = [2, 2, 0, 1] ∧
    target1834.elements.length = 4 ∧
    [target1834.elements.count 0, target1834.elements.count 1,
      target1834.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1834
def tree1835 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 1))
def target1835 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1835 : accepts tree1835 target1835 = true ∧
    sourceLeaves tree1835 = [2, 2, 0, 1] ∧
    target1835.elements.length = 4 ∧
    [target1835.elements.count 0, target1835.elements.count 1,
      target1835.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1835
def tree1836 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 1))
def target1836 : Target Nat := ⟨.seq, [2, 2, 0, 1]⟩
theorem chain1836 : accepts tree1836 target1836 = true ∧
    sourceLeaves tree1836 = [2, 2, 0, 1] ∧
    target1836.elements.length = 4 ∧
    [target1836.elements.count 0, target1836.elements.count 1,
      target1836.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1836
def tree1837 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 0) (.leaf 2))))
def target1837 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1837 : accepts tree1837 target1837 = true ∧
    sourceLeaves tree1837 = [2, 2, 0, 2] ∧
    target1837.elements.length = 4 ∧
    [target1837.elements.count 0, target1837.elements.count 1,
      target1837.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1837
def tree1838 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 0)) (.leaf 2)))
def target1838 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1838 : accepts tree1838 target1838 = true ∧
    sourceLeaves tree1838 = [2, 2, 0, 2] ∧
    target1838.elements.length = 4 ∧
    [target1838.elements.count 0, target1838.elements.count 1,
      target1838.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1838
def tree1839 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 0) (.leaf 2)))
def target1839 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1839 : accepts tree1839 target1839 = true ∧
    sourceLeaves tree1839 = [2, 2, 0, 2] ∧
    target1839.elements.length = 4 ∧
    [target1839.elements.count 0, target1839.elements.count 1,
      target1839.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1839
def tree1840 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))) (.leaf 2))
def target1840 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1840 : accepts tree1840 target1840 = true ∧
    sourceLeaves tree1840 = [2, 2, 0, 2] ∧
    target1840.elements.length = 4 ∧
    [target1840.elements.count 0, target1840.elements.count 1,
      target1840.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1840
def tree1841 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)) (.leaf 2))
def target1841 : Target Nat := ⟨.seq, [2, 2, 0, 2]⟩
theorem chain1841 : accepts tree1841 target1841 = true ∧
    sourceLeaves tree1841 = [2, 2, 0, 2] ∧
    target1841.elements.length = 4 ∧
    [target1841.elements.count 0, target1841.elements.count 1,
      target1841.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1841
def tree1842 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 0))))
def target1842 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1842 : accepts tree1842 target1842 = true ∧
    sourceLeaves tree1842 = [2, 2, 1, 0] ∧
    target1842.elements.length = 4 ∧
    [target1842.elements.count 0, target1842.elements.count 1,
      target1842.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1842
def tree1843 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 0)))
def target1843 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1843 : accepts tree1843 target1843 = true ∧
    sourceLeaves tree1843 = [2, 2, 1, 0] ∧
    target1843.elements.length = 4 ∧
    [target1843.elements.count 0, target1843.elements.count 1,
      target1843.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1843
def tree1844 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 0)))
def target1844 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1844 : accepts tree1844 target1844 = true ∧
    sourceLeaves tree1844 = [2, 2, 1, 0] ∧
    target1844.elements.length = 4 ∧
    [target1844.elements.count 0, target1844.elements.count 1,
      target1844.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1844
def tree1845 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 0))
def target1845 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1845 : accepts tree1845 target1845 = true ∧
    sourceLeaves tree1845 = [2, 2, 1, 0] ∧
    target1845.elements.length = 4 ∧
    [target1845.elements.count 0, target1845.elements.count 1,
      target1845.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1845
def tree1846 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 0))
def target1846 : Target Nat := ⟨.seq, [2, 2, 1, 0]⟩
theorem chain1846 : accepts tree1846 target1846 = true ∧
    sourceLeaves tree1846 = [2, 2, 1, 0] ∧
    target1846.elements.length = 4 ∧
    [target1846.elements.count 0, target1846.elements.count 1,
      target1846.elements.count 2] = [1, 1, 2] := by decide
#print axioms chain1846
def tree1847 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 1))))
def target1847 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1847 : accepts tree1847 target1847 = true ∧
    sourceLeaves tree1847 = [2, 2, 1, 1] ∧
    target1847.elements.length = 4 ∧
    [target1847.elements.count 0, target1847.elements.count 1,
      target1847.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1847
def tree1848 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 1)))
def target1848 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1848 : accepts tree1848 target1848 = true ∧
    sourceLeaves tree1848 = [2, 2, 1, 1] ∧
    target1848.elements.length = 4 ∧
    [target1848.elements.count 0, target1848.elements.count 1,
      target1848.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1848
def tree1849 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 1)))
def target1849 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1849 : accepts tree1849 target1849 = true ∧
    sourceLeaves tree1849 = [2, 2, 1, 1] ∧
    target1849.elements.length = 4 ∧
    [target1849.elements.count 0, target1849.elements.count 1,
      target1849.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1849
def tree1850 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 1))
def target1850 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1850 : accepts tree1850 target1850 = true ∧
    sourceLeaves tree1850 = [2, 2, 1, 1] ∧
    target1850.elements.length = 4 ∧
    [target1850.elements.count 0, target1850.elements.count 1,
      target1850.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1850
def tree1851 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 1))
def target1851 : Target Nat := ⟨.seq, [2, 2, 1, 1]⟩
theorem chain1851 : accepts tree1851 target1851 = true ∧
    sourceLeaves tree1851 = [2, 2, 1, 1] ∧
    target1851.elements.length = 4 ∧
    [target1851.elements.count 0, target1851.elements.count 1,
      target1851.elements.count 2] = [0, 2, 2] := by decide
#print axioms chain1851
def tree1852 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 1) (.leaf 2))))
def target1852 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1852 : accepts tree1852 target1852 = true ∧
    sourceLeaves tree1852 = [2, 2, 1, 2] ∧
    target1852.elements.length = 4 ∧
    [target1852.elements.count 0, target1852.elements.count 1,
      target1852.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1852
def tree1853 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 1)) (.leaf 2)))
def target1853 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1853 : accepts tree1853 target1853 = true ∧
    sourceLeaves tree1853 = [2, 2, 1, 2] ∧
    target1853.elements.length = 4 ∧
    [target1853.elements.count 0, target1853.elements.count 1,
      target1853.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1853
def tree1854 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 1) (.leaf 2)))
def target1854 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1854 : accepts tree1854 target1854 = true ∧
    sourceLeaves tree1854 = [2, 2, 1, 2] ∧
    target1854.elements.length = 4 ∧
    [target1854.elements.count 0, target1854.elements.count 1,
      target1854.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1854
def tree1855 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))) (.leaf 2))
def target1855 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1855 : accepts tree1855 target1855 = true ∧
    sourceLeaves tree1855 = [2, 2, 1, 2] ∧
    target1855.elements.length = 4 ∧
    [target1855.elements.count 0, target1855.elements.count 1,
      target1855.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1855
def tree1856 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)) (.leaf 2))
def target1856 : Target Nat := ⟨.seq, [2, 2, 1, 2]⟩
theorem chain1856 : accepts tree1856 target1856 = true ∧
    sourceLeaves tree1856 = [2, 2, 1, 2] ∧
    target1856.elements.length = 4 ∧
    [target1856.elements.count 0, target1856.elements.count 1,
      target1856.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1856
def tree1857 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 0))))
def target1857 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1857 : accepts tree1857 target1857 = true ∧
    sourceLeaves tree1857 = [2, 2, 2, 0] ∧
    target1857.elements.length = 4 ∧
    [target1857.elements.count 0, target1857.elements.count 1,
      target1857.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1857
def tree1858 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 0)))
def target1858 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1858 : accepts tree1858 target1858 = true ∧
    sourceLeaves tree1858 = [2, 2, 2, 0] ∧
    target1858.elements.length = 4 ∧
    [target1858.elements.count 0, target1858.elements.count 1,
      target1858.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1858
def tree1859 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 0)))
def target1859 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1859 : accepts tree1859 target1859 = true ∧
    sourceLeaves tree1859 = [2, 2, 2, 0] ∧
    target1859.elements.length = 4 ∧
    [target1859.elements.count 0, target1859.elements.count 1,
      target1859.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1859
def tree1860 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 0))
def target1860 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1860 : accepts tree1860 target1860 = true ∧
    sourceLeaves tree1860 = [2, 2, 2, 0] ∧
    target1860.elements.length = 4 ∧
    [target1860.elements.count 0, target1860.elements.count 1,
      target1860.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1860
def tree1861 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 0))
def target1861 : Target Nat := ⟨.seq, [2, 2, 2, 0]⟩
theorem chain1861 : accepts tree1861 target1861 = true ∧
    sourceLeaves tree1861 = [2, 2, 2, 0] ∧
    target1861.elements.length = 4 ∧
    [target1861.elements.count 0, target1861.elements.count 1,
      target1861.elements.count 2] = [1, 0, 3] := by decide
#print axioms chain1861
def tree1862 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 1))))
def target1862 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1862 : accepts tree1862 target1862 = true ∧
    sourceLeaves tree1862 = [2, 2, 2, 1] ∧
    target1862.elements.length = 4 ∧
    [target1862.elements.count 0, target1862.elements.count 1,
      target1862.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1862
def tree1863 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 1)))
def target1863 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1863 : accepts tree1863 target1863 = true ∧
    sourceLeaves tree1863 = [2, 2, 2, 1] ∧
    target1863.elements.length = 4 ∧
    [target1863.elements.count 0, target1863.elements.count 1,
      target1863.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1863
def tree1864 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 1)))
def target1864 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1864 : accepts tree1864 target1864 = true ∧
    sourceLeaves tree1864 = [2, 2, 2, 1] ∧
    target1864.elements.length = 4 ∧
    [target1864.elements.count 0, target1864.elements.count 1,
      target1864.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1864
def tree1865 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 1))
def target1865 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1865 : accepts tree1865 target1865 = true ∧
    sourceLeaves tree1865 = [2, 2, 2, 1] ∧
    target1865.elements.length = 4 ∧
    [target1865.elements.count 0, target1865.elements.count 1,
      target1865.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1865
def tree1866 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 1))
def target1866 : Target Nat := ⟨.seq, [2, 2, 2, 1]⟩
theorem chain1866 : accepts tree1866 target1866 = true ∧
    sourceLeaves tree1866 = [2, 2, 2, 1] ∧
    target1866.elements.length = 4 ∧
    [target1866.elements.count 0, target1866.elements.count 1,
      target1866.elements.count 2] = [0, 1, 3] := by decide
#print axioms chain1866
def tree1867 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))))
def target1867 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1867 : accepts tree1867 target1867 = true ∧
    sourceLeaves tree1867 = [2, 2, 2, 2] ∧
    target1867.elements.length = 4 ∧
    [target1867.elements.count 0, target1867.elements.count 1,
      target1867.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1867
def tree1868 : SourceTree Nat .arrow := (.app .arrow (.leaf 2) (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)))
def target1868 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1868 : accepts tree1868 target1868 = true ∧
    sourceLeaves tree1868 = [2, 2, 2, 2] ∧
    target1868.elements.length = 4 ∧
    [target1868.elements.count 0, target1868.elements.count 1,
      target1868.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1868
def tree1869 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.app .arrow (.leaf 2) (.leaf 2)))
def target1869 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1869 : accepts tree1869 target1869 = true ∧
    sourceLeaves tree1869 = [2, 2, 2, 2] ∧
    target1869.elements.length = 4 ∧
    [target1869.elements.count 0, target1869.elements.count 1,
      target1869.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1869
def tree1870 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 2) (.app .arrow (.leaf 2) (.leaf 2))) (.leaf 2))
def target1870 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1870 : accepts tree1870 target1870 = true ∧
    sourceLeaves tree1870 = [2, 2, 2, 2] ∧
    target1870.elements.length = 4 ∧
    [target1870.elements.count 0, target1870.elements.count 1,
      target1870.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1870
def tree1871 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.app .arrow (.leaf 2) (.leaf 2)) (.leaf 2)) (.leaf 2))
def target1871 : Target Nat := ⟨.seq, [2, 2, 2, 2]⟩
theorem chain1871 : accepts tree1871 target1871 = true ∧
    sourceLeaves tree1871 = [2, 2, 2, 2] ∧
    target1871.elements.length = 4 ∧
    [target1871.elements.count 0, target1871.elements.count 1,
      target1871.elements.count 2] = [0, 0, 4] := by decide
#print axioms chain1871
def tree1872 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0))
def target1872 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1872 : accepts tree1872 target1872 = true ∧
    sourceLeaves tree1872 = [0, 1, 0] ∧
    target1872.elements.length = 3 ∧
    [target1872.elements.count 0, target1872.elements.count 1,
      target1872.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1872
def tree1873 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0))
def target1873 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1873 : accepts tree1873 target1873 = true ∧
    sourceLeaves tree1873 = [0, 1, 0] ∧
    target1873.elements.length = 3 ∧
    [target1873.elements.count 0, target1873.elements.count 1,
      target1873.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1873
def tree1874 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0)))
def target1874 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1874 : accepts tree1874 target1874 = true ∧
    sourceLeaves tree1874 = [0, 1, 0] ∧
    target1874.elements.length = 3 ∧
    [target1874.elements.count 0, target1874.elements.count 1,
      target1874.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1874
def tree1875 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0)))
def target1875 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1875 : accepts tree1875 target1875 = true ∧
    sourceLeaves tree1875 = [0, 1, 0] ∧
    target1875.elements.length = 3 ∧
    [target1875.elements.count 0, target1875.elements.count 1,
      target1875.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1875
def tree1876 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1))
def target1876 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain1876 : accepts tree1876 target1876 = true ∧
    sourceLeaves tree1876 = [0, 1, 1] ∧
    target1876.elements.length = 3 ∧
    [target1876.elements.count 0, target1876.elements.count 1,
      target1876.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1876
def tree1877 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0))
def target1877 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain1877 : accepts tree1877 target1877 = true ∧
    sourceLeaves tree1877 = [1, 0, 0] ∧
    target1877.elements.length = 3 ∧
    [target1877.elements.count 0, target1877.elements.count 1,
      target1877.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1877
def tree1878 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def target1878 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain1878 : accepts tree1878 target1878 = true ∧
    sourceLeaves tree1878 = [0, 1] ∧
    target1878.elements.length = 2 ∧
    [target1878.elements.count 0, target1878.elements.count 1,
      target1878.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1878
def tree1879 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0))
def target1879 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1879 : accepts tree1879 target1879 = true ∧
    sourceLeaves tree1879 = [0, 1, 0] ∧
    target1879.elements.length = 3 ∧
    [target1879.elements.count 0, target1879.elements.count 1,
      target1879.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1879
def tree1880 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0))
def target1880 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1880 : accepts tree1880 target1880 = true ∧
    sourceLeaves tree1880 = [0, 1, 0] ∧
    target1880.elements.length = 3 ∧
    [target1880.elements.count 0, target1880.elements.count 1,
      target1880.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1880
def tree1881 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0)))
def target1881 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1881 : accepts tree1881 target1881 = true ∧
    sourceLeaves tree1881 = [0, 1, 0] ∧
    target1881.elements.length = 3 ∧
    [target1881.elements.count 0, target1881.elements.count 1,
      target1881.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1881
def tree1882 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0)))
def target1882 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1882 : accepts tree1882 target1882 = true ∧
    sourceLeaves tree1882 = [0, 1, 0] ∧
    target1882.elements.length = 3 ∧
    [target1882.elements.count 0, target1882.elements.count 1,
      target1882.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1882
def tree1883 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1))
def target1883 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain1883 : accepts tree1883 target1883 = true ∧
    sourceLeaves tree1883 = [0, 1, 1] ∧
    target1883.elements.length = 3 ∧
    [target1883.elements.count 0, target1883.elements.count 1,
      target1883.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1883
def tree1884 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0))
def target1884 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain1884 : accepts tree1884 target1884 = true ∧
    sourceLeaves tree1884 = [1, 0, 0] ∧
    target1884.elements.length = 3 ∧
    [target1884.elements.count 0, target1884.elements.count 1,
      target1884.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1884
def tree1885 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 1))
def target1885 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain1885 : accepts tree1885 target1885 = true ∧
    sourceLeaves tree1885 = [0, 1] ∧
    target1885.elements.length = 2 ∧
    [target1885.elements.count 0, target1885.elements.count 1,
      target1885.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1885
def tree1886 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0))
def target1886 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1886 : accepts tree1886 target1886 = true ∧
    sourceLeaves tree1886 = [0, 1, 0] ∧
    target1886.elements.length = 3 ∧
    [target1886.elements.count 0, target1886.elements.count 1,
      target1886.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1886
def tree1887 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 0))
def target1887 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1887 : accepts tree1887 target1887 = true ∧
    sourceLeaves tree1887 = [0, 1, 0] ∧
    target1887.elements.length = 3 ∧
    [target1887.elements.count 0, target1887.elements.count 1,
      target1887.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1887
def tree1888 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0)))
def target1888 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1888 : accepts tree1888 target1888 = true ∧
    sourceLeaves tree1888 = [0, 1, 0] ∧
    target1888.elements.length = 3 ∧
    [target1888.elements.count 0, target1888.elements.count 1,
      target1888.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1888
def tree1889 : SourceTree Nat .join := (.app .join (.leaf 0) (.app .join (.leaf 1) (.leaf 0)))
def target1889 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1889 : accepts tree1889 target1889 = true ∧
    sourceLeaves tree1889 = [0, 1, 0] ∧
    target1889.elements.length = 3 ∧
    [target1889.elements.count 0, target1889.elements.count 1,
      target1889.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1889
def tree1890 : SourceTree Nat .join := (.app .join (.app .join (.leaf 0) (.leaf 1)) (.leaf 1))
def target1890 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain1890 : accepts tree1890 target1890 = true ∧
    sourceLeaves tree1890 = [0, 1, 1] ∧
    target1890.elements.length = 3 ∧
    [target1890.elements.count 0, target1890.elements.count 1,
      target1890.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1890
def tree1891 : SourceTree Nat .join := (.app .join (.app .join (.leaf 1) (.leaf 0)) (.leaf 0))
def target1891 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain1891 : accepts tree1891 target1891 = true ∧
    sourceLeaves tree1891 = [1, 0, 0] ∧
    target1891.elements.length = 3 ∧
    [target1891.elements.count 0, target1891.elements.count 1,
      target1891.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1891
def tree1892 : SourceTree Nat .join := (.app .join (.leaf 0) (.leaf 1))
def target1892 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain1892 : accepts tree1892 target1892 = true ∧
    sourceLeaves tree1892 = [0, 1] ∧
    target1892.elements.length = 2 ∧
    [target1892.elements.count 0, target1892.elements.count 1,
      target1892.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1892
def tree1893 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0))
def target1893 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1893 : accepts tree1893 target1893 = true ∧
    sourceLeaves tree1893 = [0, 1, 0] ∧
    target1893.elements.length = 3 ∧
    [target1893.elements.count 0, target1893.elements.count 1,
      target1893.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1893
def tree1894 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 0))
def target1894 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1894 : accepts tree1894 target1894 = true ∧
    sourceLeaves tree1894 = [0, 1, 0] ∧
    target1894.elements.length = 3 ∧
    [target1894.elements.count 0, target1894.elements.count 1,
      target1894.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1894
def tree1895 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0)))
def target1895 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1895 : accepts tree1895 target1895 = true ∧
    sourceLeaves tree1895 = [0, 1, 0] ∧
    target1895.elements.length = 3 ∧
    [target1895.elements.count 0, target1895.elements.count 1,
      target1895.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1895
def tree1896 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.app .arrow (.leaf 1) (.leaf 0)))
def target1896 : Target Nat := ⟨.seq, [0, 1, 0]⟩
theorem chain1896 : accepts tree1896 target1896 = true ∧
    sourceLeaves tree1896 = [0, 1, 0] ∧
    target1896.elements.length = 3 ∧
    [target1896.elements.count 0, target1896.elements.count 1,
      target1896.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1896
def tree1897 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 0) (.leaf 1)) (.leaf 1))
def target1897 : Target Nat := ⟨.seq, [0, 1, 1]⟩
theorem chain1897 : accepts tree1897 target1897 = true ∧
    sourceLeaves tree1897 = [0, 1, 1] ∧
    target1897.elements.length = 3 ∧
    [target1897.elements.count 0, target1897.elements.count 1,
      target1897.elements.count 2] = [1, 2, 0] := by decide
#print axioms chain1897
def tree1898 : SourceTree Nat .arrow := (.app .arrow (.app .arrow (.leaf 1) (.leaf 0)) (.leaf 0))
def target1898 : Target Nat := ⟨.seq, [1, 0, 0]⟩
theorem chain1898 : accepts tree1898 target1898 = true ∧
    sourceLeaves tree1898 = [1, 0, 0] ∧
    target1898.elements.length = 3 ∧
    [target1898.elements.count 0, target1898.elements.count 1,
      target1898.elements.count 2] = [2, 1, 0] := by decide
#print axioms chain1898
def tree1899 : SourceTree Nat .arrow := (.app .arrow (.leaf 0) (.leaf 1))
def target1899 : Target Nat := ⟨.seq, [0, 1]⟩
theorem chain1899 : accepts tree1899 target1899 = true ∧
    sourceLeaves tree1899 = [0, 1] ∧
    target1899.elements.length = 2 ∧
    [target1899.elements.count 0, target1899.elements.count 1,
      target1899.elements.count 2] = [1, 1, 0] := by decide
#print axioms chain1899
