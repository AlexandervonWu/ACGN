import DependentJoinGuard
open ACGN.BoundedFive.DependentJoinGuard
def producerMinimum : Nat := 2
def verifierMinimum : Nat := 2
theorem guards_exact : producerMinimum = 2 /\ verifierMinimum = 2 := by decide
theorem producer_scan_correct (kind : ChainKind) (xs : List Nat) :
    guardWithMinimum producerMinimum kind xs = true <->
    2 <= xs.length /\ (kind = .JOIN -> AllFrom 2 xs 1) :=
  extracted_guard_iff producerMinimum guards_exact.1 kind xs
theorem verifier_scan_correct (kind : ChainKind) (xs : List Nat) :
    guardWithMinimum verifierMinimum kind xs = true <->
    2 <= xs.length /\ (kind = .JOIN -> AllFrom 2 xs 1) :=
  extracted_guard_iff verifierMinimum guards_exact.2 kind xs
#print axioms guards_exact
#print axioms producer_scan_correct
#print axioms verifier_scan_correct
