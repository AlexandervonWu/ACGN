import ZeroArgumentCall
open ACGN.BoundedFive.ZeroArgumentCall
def observation0 : Observation := (Observation.mk (Capture.mk 0 12 1 (Key.mk "zero" "zlocal/zero" .formula 0 .declaration)) [(Edge.mk 12 1 1 (.callee (Key.mk "zero" "zlocal/zero" .formula 0 .declaration))), (Edge.mk 12 1 2 .endMarker)] 2 "zero" .formula 0 true (BoundaryCall.mk 0 (Key.mk "zero" "zlocal/zero" .formula 0 .declaration) 0 0) 0 (BoundaryCall.mk 0 (Key.mk "zero" "zlocal/zero" .formula 0 .declaration) 0 0) 0)
theorem replay0 : replay observation0 = true := by decide
#print axioms replay0
def observation1 : Observation := (Observation.mk (Capture.mk 1 13 1 (Key.mk "value" "zlocal/value" .expression 0 .declaration)) [(Edge.mk 13 1 1 (.callee (Key.mk "value" "zlocal/value" .expression 0 .declaration))), (Edge.mk 13 1 2 .endMarker)] 2 "value" .expression 0 true (BoundaryCall.mk 1 (Key.mk "value" "zlocal/value" .expression 0 .declaration) 0 0) 0 (BoundaryCall.mk 1 (Key.mk "value" "zlocal/value" .expression 0 .declaration) 0 0) 0)
theorem replay1 : replay observation1 = true := by decide
#print axioms replay1
def observation2 : Observation := (Observation.mk (Capture.mk 0 13 1 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport)) [(Edge.mk 13 1 1 (.callee (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport))), (Edge.mk 13 1 2 .endMarker)] 2 "ord/first" .expression 0 true (BoundaryCall.mk 0 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 0 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay2 : replay observation2 = true := by decide
#print axioms replay2
def observation3 : Observation := (Observation.mk (Capture.mk 1 15 1 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport)) [(Edge.mk 15 1 1 (.callee (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport))), (Edge.mk 15 1 2 .endMarker)] 2 "ord/last" .expression 0 true (BoundaryCall.mk 1 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 1 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay3 : replay observation3 = true := by decide
#print axioms replay3
def observation4 : Observation := (Observation.mk (Capture.mk 0 17 1 (Key.mk "integer/next" "util/integer/next" .expression 0 .typecheckedImport)) [(Edge.mk 17 1 1 (.callee (Key.mk "integer/next" "util/integer/next" .expression 0 .typecheckedImport))), (Edge.mk 17 1 2 .endMarker)] 2 "integer/next" .expression 0 true (BoundaryCall.mk 0 (Key.mk "integer/next" "util/integer/next" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 0 (Key.mk "integer/next" "util/integer/next" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay4 : replay observation4 = true := by decide
#print axioms replay4
def observation5 : Observation := (Observation.mk (Capture.mk 0 11 1 (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration)) [(Edge.mk 11 1 1 (.callee (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration))), (Edge.mk 11 1 2 .endMarker)] 2 "zero" .formula 0 true (BoundaryCall.mk 0 (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration) 0 0) 0 (BoundaryCall.mk 0 (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration) 0 0) 0)
theorem replay5 : replay observation5 = true := by decide
#print axioms replay5
def observation6 : Observation := (Observation.mk (Capture.mk 1 13 1 (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration)) [(Edge.mk 13 1 1 (.callee (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration))), (Edge.mk 13 1 2 .endMarker)] 2 "zero" .formula 0 true (BoundaryCall.mk 1 (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration) 0 0) 0 (BoundaryCall.mk 1 (Key.mk "zero" "zrepeat/zero" .formula 0 .declaration) 0 0) 0)
theorem replay6 : replay observation6 = true := by decide
#print axioms replay6
def observation7 : Observation := (Observation.mk (Capture.mk 2 15 1 (Key.mk "value" "zrepeat/value" .expression 0 .declaration)) [(Edge.mk 15 1 1 (.callee (Key.mk "value" "zrepeat/value" .expression 0 .declaration))), (Edge.mk 15 1 2 .endMarker)] 2 "value" .expression 0 true (BoundaryCall.mk 2 (Key.mk "value" "zrepeat/value" .expression 0 .declaration) 0 0) 0 (BoundaryCall.mk 2 (Key.mk "value" "zrepeat/value" .expression 0 .declaration) 0 0) 0)
theorem replay7 : replay observation7 = true := by decide
#print axioms replay7
def observation8 : Observation := (Observation.mk (Capture.mk 3 18 1 (Key.mk "value" "zrepeat/value" .expression 0 .declaration)) [(Edge.mk 18 1 1 (.callee (Key.mk "value" "zrepeat/value" .expression 0 .declaration))), (Edge.mk 18 1 2 .endMarker)] 2 "value" .expression 0 true (BoundaryCall.mk 3 (Key.mk "value" "zrepeat/value" .expression 0 .declaration) 0 0) 0 (BoundaryCall.mk 3 (Key.mk "value" "zrepeat/value" .expression 0 .declaration) 0 0) 0)
theorem replay8 : replay observation8 = true := by decide
#print axioms replay8
def observation9 : Observation := (Observation.mk (Capture.mk 0 13 1 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport)) [(Edge.mk 13 1 1 (.callee (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport))), (Edge.mk 13 1 2 .endMarker)] 2 "ord/first" .expression 0 true (BoundaryCall.mk 0 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 0 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay9 : replay observation9 = true := by decide
#print axioms replay9
def observation10 : Observation := (Observation.mk (Capture.mk 1 16 1 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport)) [(Edge.mk 16 1 1 (.callee (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport))), (Edge.mk 16 1 2 .endMarker)] 2 "ord/first" .expression 0 true (BoundaryCall.mk 1 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 1 (Key.mk "ord/first" "util/ordering<A>/first" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay10 : replay observation10 = true := by decide
#print axioms replay10
def observation11 : Observation := (Observation.mk (Capture.mk 2 18 1 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport)) [(Edge.mk 18 1 1 (.callee (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport))), (Edge.mk 18 1 2 .endMarker)] 2 "ord/last" .expression 0 true (BoundaryCall.mk 2 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 2 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay11 : replay observation11 = true := by decide
#print axioms replay11
def observation12 : Observation := (Observation.mk (Capture.mk 3 21 1 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport)) [(Edge.mk 21 1 1 (.callee (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport))), (Edge.mk 21 1 2 .endMarker)] 2 "ord/last" .expression 0 true (BoundaryCall.mk 3 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport) 0 0) 0 (BoundaryCall.mk 3 (Key.mk "ord/last" "util/ordering<A>/last" .expression 0 .typecheckedImport) 0 0) 0)
theorem replay12 : replay observation12 = true := by decide
#print axioms replay12
