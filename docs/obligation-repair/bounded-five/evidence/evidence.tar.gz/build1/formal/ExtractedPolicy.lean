import PolicyRepresentation
open ACGN.BoundedFive.PolicyRepresentation
def assignments : List Nat := [0, 1, 2, 3]
def getters : List Nat := [0, 1, 2, 3]
theorem assignments_exact : assignments = [0,1,2,3] := by decide
theorem getters_exact : getters = [0,1,2,3] := by decide
theorem extracted_nominal_product {A S F U : Type} (a : ArityPolicy A)
    (s : SiblingQuotient S) (f : FlatLicense F) (u : UnitLicense U) :
    runSourceProgram (SourceProgram.mk assignments getters) (nominalArguments a s f u) =
    (nominalGetters (construct a s f u)).map some :=
  extracted_program_preserves_nominal_product _ assignments_exact getters_exact a s f u
#print axioms assignments_exact
#print axioms getters_exact
#print axioms extracted_nominal_product
