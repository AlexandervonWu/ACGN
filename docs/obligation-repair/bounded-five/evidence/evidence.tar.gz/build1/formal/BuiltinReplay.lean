import BuiltinIdentity
open ACGN.BoundedFive.BuiltinIdentity
theorem identity0 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity0
theorem solverRow0 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow0
theorem identity1 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity1
theorem solverRow1 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow1
theorem identity2 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity2
theorem solverRow2 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow2
theorem identity3 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity3
theorem solverRow3 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow3
theorem identity4 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity4
theorem solverRow4 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow4
theorem identity5 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity5
theorem solverRow5 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow5
theorem identity6 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity6
theorem solverRow6 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow6
theorem identity7 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity7
theorem solverRow7 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow7
theorem identity8 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity8
theorem solverRow8 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow8
theorem identity9 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity9
theorem solverRow9 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow9
theorem identity10 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity10
theorem solverRow10 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow10
theorem identity11 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity11
theorem solverRow11 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow11
theorem identity12 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity12
theorem solverRow12 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow12
theorem identity13 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity13
theorem solverRow13 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow13
theorem identity14 : ((.builtin .noneSet) : SignatureKind) = (.builtin .noneSet) /\
    "none" = "none" /\
    signatureIdentity (.builtin .noneSet) "none" = "alloy/builtin/none" /\
    "alloy/builtin/none" = "alloy/builtin/none" := by decide
#print axioms identity14
theorem solverRow14 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow14
theorem identity15 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity15
theorem solverRow15 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow15
theorem identity16 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity16
theorem solverRow16 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow16
theorem identity17 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity17
theorem solverRow17 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow17
theorem identity18 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity18
theorem solverRow18 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow18
theorem identity19 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity19
theorem solverRow19 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow19
theorem identity20 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity20
theorem solverRow20 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow20
theorem identity21 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity21
theorem solverRow21 : ([true, true, true, true, true, true, true, true, true, true, true, false, false, false] : List Bool) = [true, true, true, true, true, true, true, true, true, true, true, false, false, false] := by decide
#print axioms solverRow21
theorem identity22 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity22
theorem solverRow22 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow22
theorem identity23 : ((.builtin .univSet) : SignatureKind) = (.builtin .univSet) /\
    "univ" = "univ" /\
    signatureIdentity (.builtin .univSet) "univ" = "alloy/builtin/univ" /\
    "alloy/builtin/univ" = "alloy/builtin/univ" := by decide
#print axioms identity23
theorem solverRow23 : ([true, true, true, true, true, true, true, false, false, false, false, false, false, false] : List Bool) = [true, true, true, true, true, true, true, false, false, false, false, false, false, false] := by decide
#print axioms solverRow23
theorem identity24 : (.user : SignatureKind) = .user /\
    "None" = "None" /\
    signatureIdentity .user "None" = "alloy/signature/None" /\
    "alloy/signature/None" = "alloy/signature/None" := by decide
#print axioms identity24
theorem solverRow24 : ([false, false, false, false, false, false, false, false, false, false, false, false, false, false] : List Bool) = [false, false, false, false, false, false, false, false, false, false, false, false, false, false] := by decide
#print axioms solverRow24
theorem identity25 : (.user : SignatureKind) = .user /\
    "None" = "None" /\
    signatureIdentity .user "None" = "alloy/signature/None" /\
    "alloy/signature/None" = "alloy/signature/None" := by decide
#print axioms identity25
theorem solverRow25 : ([false, false, false, false, false, false, false, false, false, false, false, false, false, false] : List Bool) = [false, false, false, false, false, false, false, false, false, false, false, false, false, false] := by decide
#print axioms solverRow25
theorem identity26 : (.user : SignatureKind) = .user /\
    "None" = "None" /\
    signatureIdentity .user "None" = "alloy/signature/None" /\
    "alloy/signature/None" = "alloy/signature/None" := by decide
#print axioms identity26
theorem solverRow26 : ([false, false, false, false, false, false, false, true, false, true, false, false, false, true] : List Bool) = [false, false, false, false, false, false, false, true, false, true, false, false, false, true] := by decide
#print axioms solverRow26
theorem identity27 : (.user : SignatureKind) = .user /\
    "Univ" = "Univ" /\
    signatureIdentity .user "Univ" = "alloy/signature/Univ" /\
    "alloy/signature/Univ" = "alloy/signature/Univ" := by decide
#print axioms identity27
theorem solverRow27 : ([false, false, false, false, false, false, false, false, false, false, false, false, false, false] : List Bool) = [false, false, false, false, false, false, false, false, false, false, false, false, false, false] := by decide
#print axioms solverRow27
theorem identity28 : (.user : SignatureKind) = .user /\
    "Univ" = "Univ" /\
    signatureIdentity .user "Univ" = "alloy/signature/Univ" /\
    "alloy/signature/Univ" = "alloy/signature/Univ" := by decide
#print axioms identity28
theorem solverRow28 : ([false, false, false, false, false, false, false, false, true, false, true, false, false, true] : List Bool) = [false, false, false, false, false, false, false, false, true, false, true, false, false, true] := by decide
#print axioms solverRow28
theorem identity29 : (.user : SignatureKind) = .user /\
    "Univ" = "Univ" /\
    signatureIdentity .user "Univ" = "alloy/signature/Univ" /\
    "alloy/signature/Univ" = "alloy/signature/Univ" := by decide
#print axioms identity29
theorem solverRow29 : ([false, false, false, false, false, false, false, true, true, true, true, false, false, false] : List Bool) = [false, false, false, false, false, false, false, true, true, true, true, false, false, false] := by decide
#print axioms solverRow29
theorem identity30 : (.user : SignatureKind) = .user /\
    "NoneNear" = "NoneNear" /\
    signatureIdentity .user "NoneNear" = "alloy/signature/NoneNear" /\
    "alloy/signature/NoneNear" = "alloy/signature/NoneNear" := by decide
#print axioms identity30
theorem solverRow30 : ([false, false, false, false, false, false, false, false, false, false, false, false, false, false] : List Bool) = [false, false, false, false, false, false, false, false, false, false, false, false, false, false] := by decide
#print axioms solverRow30
theorem identity31 : (.user : SignatureKind) = .user /\
    "NoneNear" = "NoneNear" /\
    signatureIdentity .user "NoneNear" = "alloy/signature/NoneNear" /\
    "alloy/signature/NoneNear" = "alloy/signature/NoneNear" := by decide
#print axioms identity31
theorem solverRow31 : ([false, false, false, false, false, false, false, false, false, false, false, false, false, false] : List Bool) = [false, false, false, false, false, false, false, false, false, false, false, false, false, false] := by decide
#print axioms solverRow31
theorem identity32 : (.user : SignatureKind) = .user /\
    "NoneNear" = "NoneNear" /\
    signatureIdentity .user "NoneNear" = "alloy/signature/NoneNear" /\
    "alloy/signature/NoneNear" = "alloy/signature/NoneNear" := by decide
#print axioms identity32
theorem solverRow32 : ([false, false, false, false, false, false, false, true, false, true, false, false, false, true] : List Bool) = [false, false, false, false, false, false, false, true, false, true, false, false, false, true] := by decide
#print axioms solverRow32
theorem identity33 : (.user : SignatureKind) = .user /\
    "UnivNear" = "UnivNear" /\
    signatureIdentity .user "UnivNear" = "alloy/signature/UnivNear" /\
    "alloy/signature/UnivNear" = "alloy/signature/UnivNear" := by decide
#print axioms identity33
theorem solverRow33 : ([false, false, false, false, false, false, false, false, false, false, false, false, false, false] : List Bool) = [false, false, false, false, false, false, false, false, false, false, false, false, false, false] := by decide
#print axioms solverRow33
theorem identity34 : (.user : SignatureKind) = .user /\
    "UnivNear" = "UnivNear" /\
    signatureIdentity .user "UnivNear" = "alloy/signature/UnivNear" /\
    "alloy/signature/UnivNear" = "alloy/signature/UnivNear" := by decide
#print axioms identity34
theorem solverRow34 : ([false, false, false, false, false, false, false, false, true, false, true, false, false, true] : List Bool) = [false, false, false, false, false, false, false, false, true, false, true, false, false, true] := by decide
#print axioms solverRow34
theorem identity35 : (.user : SignatureKind) = .user /\
    "UnivNear" = "UnivNear" /\
    signatureIdentity .user "UnivNear" = "alloy/signature/UnivNear" /\
    "alloy/signature/UnivNear" = "alloy/signature/UnivNear" := by decide
#print axioms identity35
theorem solverRow35 : ([false, false, false, false, false, false, false, true, true, true, true, false, false, false] : List Bool) = [false, false, false, false, false, false, false, true, true, true, true, false, false, false] := by decide
#print axioms solverRow35
