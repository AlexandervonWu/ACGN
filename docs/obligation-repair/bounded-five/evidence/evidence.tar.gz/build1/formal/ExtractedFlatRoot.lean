import FlatRootPort
open ACGN.BoundedFive.FlatRootPort
def requiredPortCount : Nat := 1
def rootPortIndex : Int := 0
theorem flat_root_exact : requiredPortCount = 1 /\ rootPortIndex = 0 := by decide
theorem extracted_root_correct (count : Nat) (index : Option Int) :
    runSourceProgram (SourceProgram.mk requiredPortCount rootPortIndex) count index = true <->
    index = none \/ (count = 1 /\ index = some 0) :=
  extracted_guard_iff _ flat_root_exact.1 flat_root_exact.2 count index
#print axioms flat_root_exact
#print axioms extracted_root_correct
