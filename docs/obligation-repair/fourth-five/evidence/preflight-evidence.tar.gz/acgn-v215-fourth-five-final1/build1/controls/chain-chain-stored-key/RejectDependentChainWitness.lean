import DependentChainWitnesses
namespace ACGN.FourthFive.DependentChainWitnessReplay
open ACGN.FourthFive.DependentChainWitnesses
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000
def k0 : Key := .node "type/BOOL" [] []
def k1 : Key := .node "type/TYPE_VARIABLE" ["X"] []
def k2 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] []
def k3 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] [k1]
def k4 : Key := .node "type/CONSTRUCTOR" ["AlloySig:A"] []
def k5 : Key := .node "type/RELATION" [] [k4, k4]
def k6 : Key := .node "type/CONSTRUCTOR" ["AlloySig:B"] []
def k7 : Key := .node "type/RELATION" [] [k4, k6]
def k8 : Key := .node "type/CONSTRUCTOR" ["AlloySig:C"] []
def k9 : Key := .node "type/RELATION" [] [k4, k8]
def k10 : Key := .node "type/RELATION" [] [k6, k8]
def k11 : Key := .node "dependent-index-type-requirements" [] [k5, k7, k9, k10, k4, k6, k8]
def k12 : Key := .node "published-exact-types" [] [k5, k7, k9, k10, k4, k6, k8]
def k13 : Key := .node "direct-parent-path-v1" [] [k4]
def k14 : Key := .node "dependent-column-evidence-v1" [] [k4, k13]
def k15 : Key := .node "dependent-type-product-v1" [] [k14, k14]
def k16 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k15]
def k17 : Key := .node "dependent-type-dag-v1" ["2"] [k16, k5, k5]
def k18 : Key := .node "direct-parent-path-v1" [] [k6]
def k19 : Key := .node "dependent-column-evidence-v1" [] [k6, k18]
def k20 : Key := .node "dependent-type-product-v1" [] [k14, k19]
def k21 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k20]
def k22 : Key := .node "dependent-type-dag-v1" ["2"] [k21, k7, k7]
def k23 : Key := .node "direct-parent-path-v1" [] [k8]
def k24 : Key := .node "dependent-column-evidence-v1" [] [k8, k23]
def k25 : Key := .node "dependent-type-product-v1" [] [k19, k24]
def k26 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k25]
def k27 : Key := .node "dependent-type-dag-v1" ["2"] [k26, k10, k10]
def k28 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k22, k27]
def k29 : Key := .node "dependent-boundary-left-path-v1" [] [k4]
def k30 : Key := .node "dependent-boundary-right-path-v1" [] [k4]
def k31 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k4, k4, k4, k4, k29, k30]
def k32 : Key := .node "dependent-type-case-result-v1" [] [k14, k19]
def k33 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k32]
def k34 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k33]
def k35 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k22, k34, k22]
def k36 : Key := .node "dependent-boundary-left-path-v1" [] [k6]
def k37 : Key := .node "dependent-boundary-right-path-v1" [] [k6]
def k38 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k6, k6, k6, k6, k36, k37]
def k39 : Key := .node "dependent-type-case-result-v1" [] [k14, k24]
def k40 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k39]
def k41 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k40]
def k42 : Key := .node "dependent-type-product-v1" [] [k14, k24]
def k43 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k42]
def k44 : Key := .node "dependent-type-dag-v1" ["2"] [k43, k9, k9]
def k45 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k22, k27, k41, k44]
def k46 : Key := .node "dependent-chain-fold-steps-v1" [] [k35, k45]
def k47 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k28, k46, k44]
def combine97 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k48 : Key := .node "context" [] []
def k49 : Key := .node "certificate-sort" ["TERM"] [k9]
def k50 : Key := .node "semantic-profile" ["4", "FORBID", "alloy-temporal", "repaired-normal-form-v2", "alloy-signature-v2"] []
def k51 : Key := .node "schema/one" [] [k5]
def k52 : Key := .node "eclass" ["0"] [k5, k48]
def k53 : Key := .node "embedding" [] [k48, k48]
def k54 : Key := .node "invocation" [] [k52, k53]
def k55 : Key := .node "port-leaf/invocation" [] [k54]
def k56 : Key := .node "port/one" [] [k51, k48, k55]
def k57 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k5, k5]
def k58 : Key := .node "dependent-chain-leaf-v4" [] [k56, k57, k17]
def k59 : Key := .node "schema/one" [] [k7]
def k60 : Key := .node "eclass" ["1"] [k7, k48]
def k61 : Key := .node "invocation" [] [k60, k53]
def k62 : Key := .node "port-leaf/invocation" [] [k61]
def k63 : Key := .node "port/one" [] [k59, k48, k62]
def k64 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k7, k7]
def k65 : Key := .node "dependent-chain-leaf-v4" [] [k63, k64, k22]
def k66 : Key := .node "dependent-chain-combination-cases-v1" [] [k33]
def k67 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k7, k22, k58, k65, k66]
def k68 : Key := .node "schema/one" [] [k10]
def k69 : Key := .node "eclass" ["2"] [k10, k48]
def k70 : Key := .node "invocation" [] [k69, k53]
def k71 : Key := .node "port-leaf/invocation" [] [k70]
def k72 : Key := .node "port/one" [] [k68, k48, k71]
def k73 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k10, k10]
def k74 : Key := .node "dependent-chain-leaf-v4" [] [k72, k73, k27]
def k75 : Key := .node "dependent-chain-combination-cases-v1" [] [k40]
def k76 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k67, k74, k75]
def k77 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k76]
def k78 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:0:0"] []
def k79 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:0:0"] [k77, k78]
def k80 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k76, k79]
def k81 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k80]
def k82 : Key := .node "arity-policy" ["FINITE", "3"] []
def k83 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k59, k68]
def k84 : Key := .node "flat-license" ["none"] []
def k85 : Key := .node "container-laws" ["SEQ", "false", "false", "false", "ABSENT"] []
def k86 : Key := .node "port-law" ["0/0"] [k85]
def k87 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k83, k9, k84, k86]
def k88 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k87, k83, k9]
def k89 : Key := .node "port/seq" [] [k83, k48, k56, k63, k72]
def k90 : Key := .node "e-node" [] [k88, k48, k89]
def k91 : Key := .node "certificate-term/node" [] [k90]
def k92 : Key := .node "certificate-endpoint" ["NODE"] [k48, k49, k91]
def k93 : Key := .node "certificate-endpoint-type-check" [] [k48, k49]
def k94 : Key := .node "dependent-chain-theory" ["3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8"] []
def k95 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k81, k92, k93, k50, k94, k47, k76, k79, k90]
def k96 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k0, k5]
def combine962 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k97 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k65, k74, k75]
def k98 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k39]
def k99 : Key := .node "dependent-chain-combination-cases-v1" [] [k98]
def k100 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k58, k97, k99]
def k101 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k100]
def k102 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:0:1"] []
def k103 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:0:1"] [k101, k102]
def k104 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k100, k103]
def k105 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k104]
def k106 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k105, k92, k93, k50, k94, k47, k100, k103, k90]
def combine971 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k107 : Key := .node "semantic-profile" ["4", "MODULAR", "alloy-temporal", "repaired-normal-form-v2", "alloy-signature-v2"] []
def k108 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:1:0"] []
def k109 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:1:0"] [k77, k108]
def k110 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k76, k109]
def k111 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k110]
def k112 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k111, k92, k93, k107, k94, k47, k76, k109, k90]
def combine980 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k113 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:1:1"] []
def k114 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:1:1"] [k101, k113]
def k115 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k100, k114]
def k116 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k115]
def k117 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k116, k92, k93, k107, k94, k47, k100, k114, k90]
def k118 : Key := .node "type/RELATION" [] [k4]
def k119 : Key := .node "type/RELATION" [] [k6]
def k120 : Key := .node "type/RELATION" [] [k8]
def k121 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] [k4]
def k122 : Key := .node "dependent-index-type-requirements" [] [k118, k119, k120, k7, k10, k4, k6, k8]
def k123 : Key := .node "published-exact-types" [] [k118, k119, k120, k7, k10, k4, k6, k8, k121]
def k124 : Key := .node "dependent-type-product-v1" [] [k14]
def k125 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k124]
def k126 : Key := .node "dependent-type-dag-v1" ["1"] [k125, k118, k118]
def k127 : Key := .node "dependent-chain-operand-dags-v1" [] [k126, k22, k27]
def k128 : Key := .node "dependent-type-case-result-v1" [] [k19]
def k129 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k128]
def k130 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k129]
def k131 : Key := .node "dependent-type-product-v1" [] [k19]
def k132 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k131]
def k133 : Key := .node "dependent-type-dag-v1" ["1"] [k132, k119, k119]
def k134 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k126, k22, k130, k133]
def k135 : Key := .node "dependent-type-case-result-v1" [] [k24]
def k136 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k135]
def k137 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k136]
def k138 : Key := .node "dependent-type-product-v1" [] [k24]
def k139 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k138]
def k140 : Key := .node "dependent-type-dag-v1" ["1"] [k139, k120, k120]
def k141 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k133, k27, k137, k140]
def k142 : Key := .node "dependent-chain-fold-steps-v1" [] [k134, k141]
def k143 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k127, k142, k140]
def combine989 : Combine := fun l r => if l = k126 /\ r = k22 then some (k133, [k129]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k144 : Key := .node "certificate-sort" ["TERM"] [k120]
def k145 : Key := .node "schema/one" [] [k121]
def k146 : Key := .node "eclass" ["0"] [k121, k48]
def k147 : Key := .node "invocation" [] [k146, k53]
def k148 : Key := .node "port-leaf/invocation" [] [k147]
def k149 : Key := .node "port/one" [] [k145, k48, k148]
def k150 : Key := .node "dependent-chain-leaf-type-proof-v1" ["PRIMITIVE_SET_SINGLETON"] [k121, k118]
def k151 : Key := .node "dependent-chain-leaf-v4" [] [k149, k150, k126]
def k152 : Key := .node "dependent-chain-combination-cases-v1" [] [k129]
def k153 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k133, k151, k65, k152]
def k154 : Key := .node "dependent-chain-combination-cases-v1" [] [k136]
def k155 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k120, k140, k153, k74, k154]
def k156 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k155]
def k157 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:0:0"] []
def k158 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:0:0"] [k156, k157]
def k159 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k155, k158]
def k160 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k159]
def k161 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k145, k59, k68]
def k162 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k161, k120, k84, k86]
def k163 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k162, k161, k120]
def k164 : Key := .node "port/seq" [] [k161, k48, k149, k63, k72]
def k165 : Key := .node "e-node" [] [k163, k48, k164]
def k166 : Key := .node "certificate-term/node" [] [k165]
def k167 : Key := .node "certificate-endpoint" ["NODE"] [k48, k144, k166]
def k168 : Key := .node "certificate-endpoint-type-check" [] [k48, k144]
def k169 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k160, k167, k168, k50, k94, k143, k155, k158, k165]
def k170 : Key := .node "published-exact-types" [] [k118, k119, k120, k7, k9, k10, k4, k6, k8, k121]
def combine1698 : Combine := fun l r => if l = k126 /\ r = k22 then some (k133, [k129]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k171 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k135]
def k172 : Key := .node "dependent-chain-combination-cases-v1" [] [k171]
def k173 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k120, k140, k151, k97, k172]
def k174 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k173]
def k175 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:0:1"] []
def k176 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:0:1"] [k174, k175]
def k177 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k173, k176]
def k178 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k177]
def k179 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k178, k167, k168, k50, k94, k143, k173, k176, k165]
def combine1708 : Combine := fun l r => if l = k126 /\ r = k22 then some (k133, [k129]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k180 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:1:0"] []
def k181 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:1:0"] [k156, k180]
def k182 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k155, k181]
def k183 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k182]
def k184 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k183, k167, k168, k107, k94, k143, k155, k181, k165]
def combine1717 : Combine := fun l r => if l = k126 /\ r = k22 then some (k133, [k129]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k185 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:1:1"] []
def k186 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:1:1"] [k174, k185]
def k187 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k173, k186]
def k188 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k187]
def k189 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k188, k167, k168, k107, k94, k143, k173, k186, k165]
def k190 : Key := .node "type/INT" [] []
def k191 : Key := .node "type/RELATION" [] [k190]
def k192 : Key := .node "type/RELATION" [] [k190, k6]
def k193 : Key := .node "dependent-index-type-requirements" [] [k191, k119, k120, k192, k10, k6, k8, k190]
def k194 : Key := .node "published-exact-types" [] [k191, k119, k120, k192, k10, k6, k8, k190]
def k195 : Key := .node "direct-parent-path-v1" [] [k190]
def k196 : Key := .node "dependent-column-evidence-v1" [] [k190, k195]
def k197 : Key := .node "dependent-type-product-v1" [] [k196]
def k198 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k197]
def k199 : Key := .node "dependent-type-dag-v1" ["1"] [k198, k191, k191]
def k200 : Key := .node "dependent-type-product-v1" [] [k196, k19]
def k201 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k200]
def k202 : Key := .node "dependent-type-dag-v1" ["2"] [k201, k192, k192]
def k203 : Key := .node "dependent-chain-operand-dags-v1" [] [k199, k202, k27]
def k204 : Key := .node "dependent-boundary-left-path-v1" [] [k190]
def k205 : Key := .node "dependent-boundary-right-path-v1" [] [k190]
def k206 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k190, k190, k190, k190, k204, k205]
def k207 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k206, k128]
def k208 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k207]
def k209 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k199, k202, k208, k133]
def k210 : Key := .node "dependent-chain-fold-steps-v1" [] [k209, k141]
def k211 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k203, k210, k140]
def combine1726 : Combine := fun l r => if l = k199 /\ r = k202 then some (k133, [k207]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k212 : Key := .node "schema/one" [] [k190]
def k213 : Key := .node "eclass" ["0"] [k190, k48]
def k214 : Key := .node "invocation" [] [k213, k53]
def k215 : Key := .node "port-leaf/invocation" [] [k214]
def k216 : Key := .node "port/one" [] [k212, k48, k215]
def k217 : Key := .node "dependent-chain-leaf-type-proof-v1" ["PRIMITIVE_SET_SINGLETON"] [k190, k191]
def k218 : Key := .node "dependent-chain-leaf-v4" [] [k216, k217, k199]
def k219 : Key := .node "schema/one" [] [k192]
def k220 : Key := .node "eclass" ["1"] [k192, k48]
def k221 : Key := .node "invocation" [] [k220, k53]
def k222 : Key := .node "port-leaf/invocation" [] [k221]
def k223 : Key := .node "port/one" [] [k219, k48, k222]
def k224 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k192, k192]
def k225 : Key := .node "dependent-chain-leaf-v4" [] [k223, k224, k202]
def k226 : Key := .node "dependent-chain-combination-cases-v1" [] [k207]
def k227 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k133, k218, k225, k226]
def k228 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k120, k140, k227, k74, k154]
def k229 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k228]
def k230 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:0:0"] []
def k231 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:0:0"] [k229, k230]
def k232 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k228, k231]
def k233 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k232]
def k234 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k212, k219, k68]
def k235 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k234, k120, k84, k86]
def k236 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k235, k234, k120]
def k237 : Key := .node "port/seq" [] [k234, k48, k216, k223, k72]
def k238 : Key := .node "e-node" [] [k236, k48, k237]
def k239 : Key := .node "certificate-term/node" [] [k238]
def k240 : Key := .node "certificate-endpoint" ["NODE"] [k48, k144, k239]
def k241 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k233, k240, k168, k50, k94, k211, k228, k231, k238]
def k242 : Key := .node "type/RELATION" [] [k190, k8]
def k243 : Key := .node "published-exact-types" [] [k191, k119, k120, k192, k242, k10, k6, k8, k190]
def combine2406 : Combine := fun l r => if l = k199 /\ r = k202 then some (k133, [k207]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k244 : Key := .node "dependent-type-product-v1" [] [k196, k24]
def k245 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k244]
def k246 : Key := .node "dependent-type-dag-v1" ["2"] [k245, k242, k242]
def k247 : Key := .node "dependent-type-case-result-v1" [] [k196, k24]
def k248 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k247]
def k249 : Key := .node "dependent-chain-combination-cases-v1" [] [k248]
def k250 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k242, k246, k225, k74, k249]
def k251 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k206, k135]
def k252 : Key := .node "dependent-chain-combination-cases-v1" [] [k251]
def k253 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k120, k140, k218, k250, k252]
def k254 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k253]
def k255 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:0:1"] []
def k256 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:0:1"] [k254, k255]
def k257 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k253, k256]
def k258 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k257]
def k259 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k258, k240, k168, k50, k94, k211, k253, k256, k238]
def combine2415 : Combine := fun l r => if l = k199 /\ r = k202 then some (k133, [k207]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k260 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:1:0"] []
def k261 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:1:0"] [k229, k260]
def k262 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k228, k261]
def k263 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k262]
def k264 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k263, k240, k168, k107, k94, k211, k228, k261, k238]
def combine2424 : Combine := fun l r => if l = k199 /\ r = k202 then some (k133, [k207]) else (if l = k133 /\ r = k27 then some (k140, [k136]) else (none))
def k265 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:1:1"] []
def k266 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:1:1"] [k254, k265]
def k267 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k253, k266]
def k268 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k144, k267]
def k269 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k268, k240, k168, k107, k94, k211, k253, k266, k238]
def k270 : Key := .node "type/CONSTRUCTOR" ["AlloySig:univ"] []
def k271 : Key := .node "type/RELATION" [] [k4, k270]
def k272 : Key := .node "type/RELATION" [] [k270, k6]
def k273 : Key := .node "dependent-index-type-requirements" [] [k7, k9, k271, k10, k272, k4, k6, k8, k270]
def k274 : Key := .node "published-exact-types" [] [k7, k9, k271, k10, k272, k4, k6, k8, k270]
def k275 : Key := .node "direct-parent-path-v1" [] [k270]
def k276 : Key := .node "dependent-column-evidence-v1" [] [k270, k275]
def k277 : Key := .node "dependent-type-product-v1" [] [k14, k276]
def k278 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k277]
def k279 : Key := .node "dependent-type-dag-v1" ["2"] [k278, k271, k271]
def k280 : Key := .node "dependent-type-product-v1" [] [k276, k19]
def k281 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k280]
def k282 : Key := .node "dependent-type-dag-v1" ["2"] [k281, k272, k272]
def k283 : Key := .node "dependent-chain-operand-dags-v1" [] [k279, k282, k27]
def k284 : Key := .node "dependent-boundary-left-path-v1" [] [k270]
def k285 : Key := .node "dependent-boundary-right-path-v1" [] [k270]
def k286 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k270, k270, k270, k270, k284, k285]
def k287 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k286, k32]
def k288 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k287]
def k289 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k279, k282, k288, k22]
def k290 : Key := .node "dependent-chain-fold-steps-v1" [] [k289, k45]
def k291 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k283, k290, k44]
def combine2433 : Combine := fun l r => if l = k279 /\ r = k282 then some (k22, [k287]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k292 : Key := .node "schema/one" [] [k271]
def k293 : Key := .node "eclass" ["0"] [k271, k48]
def k294 : Key := .node "invocation" [] [k293, k53]
def k295 : Key := .node "port-leaf/invocation" [] [k294]
def k296 : Key := .node "port/one" [] [k292, k48, k295]
def k297 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k271, k271]
def k298 : Key := .node "dependent-chain-leaf-v4" [] [k296, k297, k279]
def k299 : Key := .node "schema/one" [] [k272]
def k300 : Key := .node "eclass" ["1"] [k272, k48]
def k301 : Key := .node "invocation" [] [k300, k53]
def k302 : Key := .node "port-leaf/invocation" [] [k301]
def k303 : Key := .node "port/one" [] [k299, k48, k302]
def k304 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k272, k272]
def k305 : Key := .node "dependent-chain-leaf-v4" [] [k303, k304, k282]
def k306 : Key := .node "dependent-chain-combination-cases-v1" [] [k287]
def k307 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k7, k22, k298, k305, k306]
def k308 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k307, k74, k75]
def k309 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k308]
def k310 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:0:0"] []
def k311 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:0:0"] [k309, k310]
def k312 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k308, k311]
def k313 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k312]
def k314 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k292, k299, k68]
def k315 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k314, k9, k84, k86]
def k316 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k315, k314, k9]
def k317 : Key := .node "port/seq" [] [k314, k48, k296, k303, k72]
def k318 : Key := .node "e-node" [] [k316, k48, k317]
def k319 : Key := .node "certificate-term/node" [] [k318]
def k320 : Key := .node "certificate-endpoint" ["NODE"] [k48, k49, k319]
def k321 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k313, k320, k93, k50, k94, k291, k308, k311, k318]
def k322 : Key := .node "type/RELATION" [] [k270, k8]
def k323 : Key := .node "published-exact-types" [] [k7, k9, k271, k10, k272, k322, k4, k6, k8, k270]
def combine3308 : Combine := fun l r => if l = k279 /\ r = k282 then some (k22, [k287]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k324 : Key := .node "dependent-type-product-v1" [] [k276, k24]
def k325 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k324]
def k326 : Key := .node "dependent-type-dag-v1" ["2"] [k325, k322, k322]
def k327 : Key := .node "dependent-type-case-result-v1" [] [k276, k24]
def k328 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k327]
def k329 : Key := .node "dependent-chain-combination-cases-v1" [] [k328]
def k330 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k322, k326, k305, k74, k329]
def k331 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k286, k39]
def k332 : Key := .node "dependent-chain-combination-cases-v1" [] [k331]
def k333 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k298, k330, k332]
def k334 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k333]
def k335 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:0:1"] []
def k336 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:0:1"] [k334, k335]
def k337 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k333, k336]
def k338 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k337]
def k339 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k338, k320, k93, k50, k94, k291, k333, k336, k318]
def combine3317 : Combine := fun l r => if l = k279 /\ r = k282 then some (k22, [k287]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k340 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:1:0"] []
def k341 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:1:0"] [k309, k340]
def k342 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k308, k341]
def k343 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k342]
def k344 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k343, k320, k93, k107, k94, k291, k308, k341, k318]
def combine3326 : Combine := fun l r => if l = k279 /\ r = k282 then some (k22, [k287]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k345 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:1:1"] []
def k346 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:1:1"] [k334, k345]
def k347 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k333, k346]
def k348 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k347]
def k349 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k348, k320, k93, k107, k94, k291, k333, k346, k318]
def k350 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=2"] []
def k351 : Key := .node "dependent-index-type-requirements" [] [k5, k10, k4, k6, k8, k350]
def k352 : Key := .node "published-exact-types" [] [k5, k10, k4, k6, k8, k350]
def k353 : Key := .node "dependent-type-correlated-alternatives-v1" [] []
def k354 : Key := .node "dependent-type-no-common-ancestor-v1" ["none"] []
def k355 : Key := .node "dependent-type-dag-v1" ["2"] [k353, k350, k354]
def k356 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k355, k27]
def k357 : Key := .node "dependent-chain-complete-case-matrix-v1" [] []
def k358 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k355, k357, k355]
def k359 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k355, k27, k357, k355]
def k360 : Key := .node "dependent-chain-fold-steps-v1" [] [k358, k359]
def k361 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k356, k360, k355]
def combine3335 : Combine := fun l r => if l = k17 /\ r = k355 then some (k355, []) else (if l = k355 /\ r = k27 then some (k355, []) else (none))
def k362 : Key := .node "certificate-sort" ["TERM"] [k350]
def k363 : Key := .node "schema/one" [] [k350]
def k364 : Key := .node "eclass" ["1"] [k350, k48]
def k365 : Key := .node "invocation" [] [k364, k53]
def k366 : Key := .node "port-leaf/invocation" [] [k365]
def k367 : Key := .node "port/one" [] [k363, k48, k366]
def k368 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k350, k350]
def k369 : Key := .node "dependent-chain-leaf-v4" [] [k367, k368, k355]
def k370 : Key := .node "dependent-chain-combination-cases-v1" [] []
def k371 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k350, k355, k58, k369, k370]
def k372 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k350, k355, k371, k74, k370]
def k373 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k372]
def k374 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:0:0"] []
def k375 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:0:0"] [k373, k374]
def k376 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k372, k375]
def k377 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k362, k376]
def k378 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k363, k68]
def k379 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k378, k350, k84, k86]
def k380 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k379, k378, k350]
def k381 : Key := .node "port/seq" [] [k378, k48, k56, k367, k72]
def k382 : Key := .node "e-node" [] [k380, k48, k381]
def k383 : Key := .node "certificate-term/node" [] [k382]
def k384 : Key := .node "certificate-endpoint" ["NODE"] [k48, k362, k383]
def k385 : Key := .node "certificate-endpoint-type-check" [] [k48, k362]
def k386 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k377, k384, k385, k50, k94, k361, k372, k375, k382]
def combine3786 : Combine := fun l r => if l = k17 /\ r = k355 then some (k355, []) else (if l = k355 /\ r = k27 then some (k355, []) else (none))
def k387 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k350, k355, k369, k74, k370]
def k388 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k350, k355, k58, k387, k370]
def k389 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k388]
def k390 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:0:1"] []
def k391 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:0:1"] [k389, k390]
def k392 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k388, k391]
def k393 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k362, k392]
def k394 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k393, k384, k385, k50, k94, k361, k388, k391, k382]
def combine3795 : Combine := fun l r => if l = k17 /\ r = k355 then some (k355, []) else (if l = k355 /\ r = k27 then some (k355, []) else (none))
def k395 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:1:0"] []
def k396 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:1:0"] [k373, k395]
def k397 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k372, k396]
def k398 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k362, k397]
def k399 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k398, k384, k385, k107, k94, k361, k372, k396, k382]
def combine3804 : Combine := fun l r => if l = k17 /\ r = k355 then some (k355, []) else (if l = k355 /\ r = k27 then some (k355, []) else (none))
def k400 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:1:1"] []
def k401 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:1:1"] [k389, k400]
def k402 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k388, k401]
def k403 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k362, k402]
def k404 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k403, k384, k385, k107, k94, k361, k388, k401, k382]
def k405 : Key := .node "dependent-index-type-requirements" [] [k5, k4]
def k406 : Key := .node "published-exact-types" [] [k5, k4]
def k407 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k17, k17]
def k408 : Key := .node "dependent-type-case-result-v1" [] [k14, k14]
def k409 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k408]
def k410 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k409]
def k411 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k17, k410, k17]
def k412 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k17, k17, k410, k17]
def k413 : Key := .node "dependent-chain-fold-steps-v1" [] [k411, k412]
def k414 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k407, k413, k17]
def combine3813 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k409]) else (if l = k17 /\ r = k17 then some (k17, [k409]) else (none))
def k415 : Key := .node "certificate-sort" ["TERM"] [k5]
def k416 : Key := .node "dependent-chain-combination-cases-v1" [] [k409]
def k417 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k58, k58, k416]
def k418 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k417, k58, k416]
def k419 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k418]
def k420 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:0:0"] []
def k421 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:0:0"] [k419, k420]
def k422 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k418, k421]
def k423 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k415, k422]
def k424 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k51, k51]
def k425 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k424, k5, k84, k86]
def k426 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k425, k424, k5]
def k427 : Key := .node "port/seq" [] [k424, k48, k56, k56, k56]
def k428 : Key := .node "e-node" [] [k426, k48, k427]
def k429 : Key := .node "certificate-term/node" [] [k428]
def k430 : Key := .node "certificate-endpoint" ["NODE"] [k48, k415, k429]
def k431 : Key := .node "certificate-endpoint-type-check" [] [k48, k415]
def k432 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k423, k430, k431, k50, k94, k414, k418, k421, k428]
def combine4639 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k409]) else (if l = k17 /\ r = k17 then some (k17, [k409]) else (none))
def k433 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k58, k417, k416]
def k434 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k433]
def k435 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:0:1"] []
def k436 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:0:1"] [k434, k435]
def k437 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k433, k436]
def k438 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k415, k437]
def k439 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k438, k430, k431, k50, k94, k414, k433, k436, k428]
def combine4648 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k409]) else (if l = k17 /\ r = k17 then some (k17, [k409]) else (none))
def k440 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:1:0"] []
def k441 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:1:0"] [k419, k440]
def k442 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k418, k441]
def k443 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k415, k442]
def k444 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k443, k430, k431, k107, k94, k414, k418, k441, k428]
def combine4657 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k409]) else (if l = k17 /\ r = k17 then some (k17, [k409]) else (none))
def k445 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:1:1"] []
def k446 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:1:1"] [k434, k445]
def k447 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k433, k446]
def k448 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k415, k447]
def k449 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k448, k430, k431, k107, k94, k414, k433, k446, k428]
def k450 : Key := .node "type/RELATION" [] [k4, k6, k8]
def k451 : Key := .node "dependent-index-type-requirements" [] [k118, k119, k120, k7, k450, k4, k6, k8]
def k452 : Key := .node "published-exact-types" [] [k118, k119, k120, k7, k450, k4, k6, k8]
def k453 : Key := .node "dependent-chain-operand-dags-v1" [] [k126, k133, k140]
def k454 : Key := .node "dependent-type-no-boundary-v1" ["arrow"] []
def k455 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k32]
def k456 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k455]
def k457 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k126, k133, k456, k22]
def k458 : Key := .node "dependent-type-case-result-v1" [] [k14, k19, k24]
def k459 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k458]
def k460 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k459]
def k461 : Key := .node "dependent-type-product-v1" [] [k14, k19, k24]
def k462 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k461]
def k463 : Key := .node "dependent-type-dag-v1" ["3"] [k462, k450, k450]
def k464 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k22, k140, k460, k463]
def k465 : Key := .node "dependent-chain-fold-steps-v1" [] [k457, k464]
def k466 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k453, k465, k463]
def combine4666 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k467 : Key := .node "certificate-sort" ["TERM"] [k450]
def k468 : Key := .node "schema/one" [] [k118]
def k469 : Key := .node "eclass" ["0"] [k118, k48]
def k470 : Key := .node "invocation" [] [k469, k53]
def k471 : Key := .node "port-leaf/invocation" [] [k470]
def k472 : Key := .node "port/one" [] [k468, k48, k471]
def k473 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k118, k118]
def k474 : Key := .node "dependent-chain-leaf-v4" [] [k472, k473, k126]
def k475 : Key := .node "schema/one" [] [k119]
def k476 : Key := .node "eclass" ["1"] [k119, k48]
def k477 : Key := .node "invocation" [] [k476, k53]
def k478 : Key := .node "port-leaf/invocation" [] [k477]
def k479 : Key := .node "port/one" [] [k475, k48, k478]
def k480 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k119, k119]
def k481 : Key := .node "dependent-chain-leaf-v4" [] [k479, k480, k133]
def k482 : Key := .node "dependent-chain-combination-cases-v1" [] [k455]
def k483 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k7, k22, k474, k481, k482]
def k484 : Key := .node "schema/one" [] [k120]
def k485 : Key := .node "eclass" ["2"] [k120, k48]
def k486 : Key := .node "invocation" [] [k485, k53]
def k487 : Key := .node "port-leaf/invocation" [] [k486]
def k488 : Key := .node "port/one" [] [k484, k48, k487]
def k489 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k120, k120]
def k490 : Key := .node "dependent-chain-leaf-v4" [] [k488, k489, k140]
def k491 : Key := .node "dependent-chain-combination-cases-v1" [] [k459]
def k492 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k450, k463, k483, k490, k491]
def k493 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k492]
def k494 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:0:0"] []
def k495 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:0:0"] [k493, k494]
def k496 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k492, k495]
def k497 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k496]
def k498 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k468, k475, k484]
def k499 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k498, k450, k84, k86]
def k500 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k499, k498, k450]
def k501 : Key := .node "port/seq" [] [k498, k48, k472, k479, k488]
def k502 : Key := .node "e-node" [] [k500, k48, k501]
def k503 : Key := .node "certificate-term/node" [] [k502]
def k504 : Key := .node "certificate-endpoint" ["NODE"] [k48, k467, k503]
def k505 : Key := .node "certificate-endpoint-type-check" [] [k48, k467]
def k506 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k497, k504, k505, k50, k94, k466, k492, k495, k502]
def k507 : Key := .node "published-exact-types" [] [k118, k119, k120, k7, k10, k450, k4, k6, k8]
def combine5383 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k508 : Key := .node "dependent-type-case-result-v1" [] [k19, k24]
def k509 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k508]
def k510 : Key := .node "dependent-chain-combination-cases-v1" [] [k509]
def k511 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k10, k27, k481, k490, k510]
def k512 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k450, k463, k474, k511, k491]
def k513 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k512]
def k514 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:0:1"] []
def k515 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:0:1"] [k513, k514]
def k516 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k512, k515]
def k517 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k516]
def k518 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k517, k504, k505, k50, k94, k466, k512, k515, k502]
def combine5392 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k519 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:1:0"] []
def k520 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:1:0"] [k493, k519]
def k521 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k492, k520]
def k522 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k521]
def k523 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k522, k504, k505, k107, k94, k466, k492, k520, k502]
def combine5401 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k524 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:1:1"] []
def k525 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:1:1"] [k513, k524]
def k526 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k512, k525]
def k527 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k526]
def k528 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k527, k504, k505, k107, k94, k466, k512, k525, k502]
def k529 : Key := .node "published-exact-types" [] [k118, k119, k120, k7, k450, k4, k6, k8, k121]
def combine5410 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k530 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k7, k22, k151, k481, k482]
def k531 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k450, k463, k530, k490, k491]
def k532 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k531]
def k533 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:0:0"] []
def k534 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:0:0"] [k532, k533]
def k535 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k531, k534]
def k536 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k535]
def k537 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k145, k475, k484]
def k538 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k537, k450, k84, k86]
def k539 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k538, k537, k450]
def k540 : Key := .node "port/seq" [] [k537, k48, k149, k479, k488]
def k541 : Key := .node "e-node" [] [k539, k48, k540]
def k542 : Key := .node "certificate-term/node" [] [k541]
def k543 : Key := .node "certificate-endpoint" ["NODE"] [k48, k467, k542]
def k544 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k536, k543, k505, k50, k94, k466, k531, k534, k541]
def k545 : Key := .node "published-exact-types" [] [k118, k119, k120, k7, k10, k450, k4, k6, k8, k121]
def combine6129 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k546 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k450, k463, k151, k511, k491]
def k547 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k546]
def k548 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:0:1"] []
def k549 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:0:1"] [k547, k548]
def k550 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k546, k549]
def k551 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k550]
def k552 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k551, k543, k505, k50, k94, k466, k546, k549, k541]
def combine6138 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k553 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:1:0"] []
def k554 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:1:0"] [k532, k553]
def k555 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k531, k554]
def k556 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k555]
def k557 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k556, k543, k505, k107, k94, k466, k531, k554, k541]
def combine6147 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k558 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:1:1"] []
def k559 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:1:1"] [k547, k558]
def k560 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k546, k559]
def k561 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k560]
def k562 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k561, k543, k505, k107, k94, k466, k546, k559, k541]
def k563 : Key := .node "type/RELATION" [] [k190, k6, k8]
def k564 : Key := .node "dependent-index-type-requirements" [] [k191, k119, k120, k192, k563, k6, k8, k190]
def k565 : Key := .node "published-exact-types" [] [k191, k119, k120, k192, k563, k6, k8, k190]
def k566 : Key := .node "dependent-chain-operand-dags-v1" [] [k199, k133, k140]
def k567 : Key := .node "dependent-type-case-result-v1" [] [k196, k19]
def k568 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k567]
def k569 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k568]
def k570 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k199, k133, k569, k202]
def k571 : Key := .node "dependent-type-case-result-v1" [] [k196, k19, k24]
def k572 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k571]
def k573 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k572]
def k574 : Key := .node "dependent-type-product-v1" [] [k196, k19, k24]
def k575 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k574]
def k576 : Key := .node "dependent-type-dag-v1" ["3"] [k575, k563, k563]
def k577 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k202, k140, k573, k576]
def k578 : Key := .node "dependent-chain-fold-steps-v1" [] [k570, k577]
def k579 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k566, k578, k576]
def combine6156 : Combine := fun l r => if l = k199 /\ r = k133 then some (k202, [k568]) else (if l = k202 /\ r = k140 then some (k576, [k572]) else (none))
def k580 : Key := .node "certificate-sort" ["TERM"] [k563]
def k581 : Key := .node "dependent-chain-combination-cases-v1" [] [k568]
def k582 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k192, k202, k218, k481, k581]
def k583 : Key := .node "dependent-chain-combination-cases-v1" [] [k572]
def k584 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k563, k576, k582, k490, k583]
def k585 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k584]
def k586 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:0:0"] []
def k587 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:0:0"] [k585, k586]
def k588 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k584, k587]
def k589 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k580, k588]
def k590 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k212, k475, k484]
def k591 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k590, k563, k84, k86]
def k592 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k591, k590, k563]
def k593 : Key := .node "port/seq" [] [k590, k48, k216, k479, k488]
def k594 : Key := .node "e-node" [] [k592, k48, k593]
def k595 : Key := .node "certificate-term/node" [] [k594]
def k596 : Key := .node "certificate-endpoint" ["NODE"] [k48, k580, k595]
def k597 : Key := .node "certificate-endpoint-type-check" [] [k48, k580]
def k598 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k589, k596, k597, k50, k94, k579, k584, k587, k594]
def k599 : Key := .node "published-exact-types" [] [k191, k119, k120, k192, k10, k563, k6, k8, k190]
def combine6842 : Combine := fun l r => if l = k199 /\ r = k133 then some (k202, [k568]) else (if l = k202 /\ r = k140 then some (k576, [k572]) else (none))
def k600 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k563, k576, k218, k511, k583]
def k601 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k600]
def k602 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:0:1"] []
def k603 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:0:1"] [k601, k602]
def k604 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k600, k603]
def k605 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k580, k604]
def k606 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k605, k596, k597, k50, k94, k579, k600, k603, k594]
def combine6851 : Combine := fun l r => if l = k199 /\ r = k133 then some (k202, [k568]) else (if l = k202 /\ r = k140 then some (k576, [k572]) else (none))
def k607 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:1:0"] []
def k608 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:1:0"] [k585, k607]
def k609 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k584, k608]
def k610 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k580, k609]
def k611 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k610, k596, k597, k107, k94, k579, k584, k608, k594]
def combine6860 : Combine := fun l r => if l = k199 /\ r = k133 then some (k202, [k568]) else (if l = k202 /\ r = k140 then some (k576, [k572]) else (none))
def k612 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:1:1"] []
def k613 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:1:1"] [k601, k612]
def k614 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k600, k613]
def k615 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k580, k614]
def k616 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k615, k596, k597, k107, k94, k579, k600, k613, k594]
def k617 : Key := .node "type/RELATION" [] [k270]
def k618 : Key := .node "type/RELATION" [] [k270, k6, k8]
def k619 : Key := .node "dependent-index-type-requirements" [] [k119, k120, k617, k272, k618, k6, k8, k270]
def k620 : Key := .node "published-exact-types" [] [k119, k120, k617, k272, k618, k6, k8, k270]
def k621 : Key := .node "dependent-type-product-v1" [] [k276]
def k622 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k621]
def k623 : Key := .node "dependent-type-dag-v1" ["1"] [k622, k617, k617]
def k624 : Key := .node "dependent-chain-operand-dags-v1" [] [k623, k133, k140]
def k625 : Key := .node "dependent-type-case-result-v1" [] [k276, k19]
def k626 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k625]
def k627 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k626]
def k628 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k623, k133, k627, k282]
def k629 : Key := .node "dependent-type-case-result-v1" [] [k276, k19, k24]
def k630 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k454, k629]
def k631 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k630]
def k632 : Key := .node "dependent-type-product-v1" [] [k276, k19, k24]
def k633 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k632]
def k634 : Key := .node "dependent-type-dag-v1" ["3"] [k633, k618, k618]
def k635 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k282, k140, k631, k634]
def k636 : Key := .node "dependent-chain-fold-steps-v1" [] [k628, k635]
def k637 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k624, k636, k634]
def combine6869 : Combine := fun l r => if l = k623 /\ r = k133 then some (k282, [k626]) else (if l = k282 /\ r = k140 then some (k634, [k630]) else (none))
def k638 : Key := .node "certificate-sort" ["TERM"] [k618]
def k639 : Key := .node "schema/one" [] [k617]
def k640 : Key := .node "eclass" ["0"] [k617, k48]
def k641 : Key := .node "invocation" [] [k640, k53]
def k642 : Key := .node "port-leaf/invocation" [] [k641]
def k643 : Key := .node "port/one" [] [k639, k48, k642]
def k644 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k617, k617]
def k645 : Key := .node "dependent-chain-leaf-v4" [] [k643, k644, k623]
def k646 : Key := .node "dependent-chain-combination-cases-v1" [] [k626]
def k647 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k272, k282, k645, k481, k646]
def k648 : Key := .node "dependent-chain-combination-cases-v1" [] [k630]
def k649 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k618, k634, k647, k490, k648]
def k650 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k649]
def k651 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:0:0"] []
def k652 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:0:0"] [k650, k651]
def k653 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k649, k652]
def k654 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k638, k653]
def k655 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k639, k475, k484]
def k656 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k655, k618, k84, k86]
def k657 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k656, k655, k618]
def k658 : Key := .node "port/seq" [] [k655, k48, k643, k479, k488]
def k659 : Key := .node "e-node" [] [k657, k48, k658]
def k660 : Key := .node "certificate-term/node" [] [k659]
def k661 : Key := .node "certificate-endpoint" ["NODE"] [k48, k638, k660]
def k662 : Key := .node "certificate-endpoint-type-check" [] [k48, k638]
def k663 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k654, k661, k662, k50, k94, k637, k649, k652, k659]
def k664 : Key := .node "published-exact-types" [] [k119, k120, k617, k10, k272, k618, k6, k8, k270]
def combine7586 : Combine := fun l r => if l = k623 /\ r = k133 then some (k282, [k626]) else (if l = k282 /\ r = k140 then some (k634, [k630]) else (none))
def k665 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k618, k634, k645, k511, k648]
def k666 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k665]
def k667 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:0:1"] []
def k668 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:0:1"] [k666, k667]
def k669 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k665, k668]
def k670 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k638, k669]
def k671 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k670, k661, k662, k50, k94, k637, k665, k668, k659]
def combine7595 : Combine := fun l r => if l = k623 /\ r = k133 then some (k282, [k626]) else (if l = k282 /\ r = k140 then some (k634, [k630]) else (none))
def k672 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:1:0"] []
def k673 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:1:0"] [k650, k672]
def k674 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k649, k673]
def k675 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k638, k674]
def k676 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k675, k661, k662, k107, k94, k637, k649, k673, k659]
def combine7604 : Combine := fun l r => if l = k623 /\ r = k133 then some (k282, [k626]) else (if l = k282 /\ r = k140 then some (k634, [k630]) else (none))
def k677 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:1:1"] []
def k678 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:1:1"] [k666, k677]
def k679 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k665, k678]
def k680 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k638, k679]
def k681 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k680, k661, k662, k107, k94, k637, k665, k678, k659]
def k682 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=3"] []
def k683 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=4"] []
def k684 : Key := .node "dependent-index-type-requirements" [] [k118, k120, k4, k8, k350, k682, k683]
def k685 : Key := .node "published-exact-types" [] [k118, k120, k4, k8, k350, k682, k683]
def k686 : Key := .node "dependent-chain-operand-dags-v1" [] [k126, k355, k140]
def k687 : Key := .node "dependent-type-dag-v1" ["3"] [k353, k682, k354]
def k688 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k126, k355, k357, k687]
def k689 : Key := .node "dependent-type-dag-v1" ["4"] [k353, k683, k354]
def k690 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k687, k140, k357, k689]
def k691 : Key := .node "dependent-chain-fold-steps-v1" [] [k688, k690]
def k692 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k686, k691, k689]
def combine7613 : Combine := fun l r => if l = k126 /\ r = k355 then some (k687, []) else (if l = k687 /\ r = k140 then some (k689, []) else (none))
def k693 : Key := .node "certificate-sort" ["TERM"] [k683]
def k694 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k682, k687, k474, k369, k370]
def k695 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k683, k689, k694, k490, k370]
def k696 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k695]
def k697 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:0:0"] []
def k698 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:0:0"] [k696, k697]
def k699 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k695, k698]
def k700 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k693, k699]
def k701 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k468, k363, k484]
def k702 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k701, k683, k84, k86]
def k703 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k702, k701, k683]
def k704 : Key := .node "port/seq" [] [k701, k48, k472, k367, k488]
def k705 : Key := .node "e-node" [] [k703, k48, k704]
def k706 : Key := .node "certificate-term/node" [] [k705]
def k707 : Key := .node "certificate-endpoint" ["NODE"] [k48, k693, k706]
def k708 : Key := .node "certificate-endpoint-type-check" [] [k48, k693]
def k709 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k700, k707, k708, k50, k94, k692, k695, k698, k705]
def combine7971 : Combine := fun l r => if l = k126 /\ r = k355 then some (k687, []) else (if l = k687 /\ r = k140 then some (k689, []) else (none))
def k710 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k682, k687, k369, k490, k370]
def k711 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k683, k689, k474, k710, k370]
def k712 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k711]
def k713 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:0:1"] []
def k714 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:0:1"] [k712, k713]
def k715 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k711, k714]
def k716 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k693, k715]
def k717 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k716, k707, k708, k50, k94, k692, k711, k714, k705]
def combine7980 : Combine := fun l r => if l = k126 /\ r = k355 then some (k687, []) else (if l = k687 /\ r = k140 then some (k689, []) else (none))
def k718 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:1:0"] []
def k719 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:1:0"] [k696, k718]
def k720 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k695, k719]
def k721 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k693, k720]
def k722 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k721, k707, k708, k107, k94, k692, k695, k719, k705]
def combine7989 : Combine := fun l r => if l = k126 /\ r = k355 then some (k687, []) else (if l = k687 /\ r = k140 then some (k689, []) else (none))
def k723 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:1:1"] []
def k724 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:1:1"] [k712, k723]
def k725 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k711, k724]
def k726 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k693, k725]
def k727 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k726, k707, k708, k107, k94, k692, k711, k724, k705]
def combine7998 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k728 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:0:0"] []
def k729 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:0:0"] [k493, k728]
def k730 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k492, k729]
def k731 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k730]
def k732 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k731, k504, k505, k50, k94, k466, k492, k729, k502]
def combine8715 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k733 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:0:1"] []
def k734 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:0:1"] [k513, k733]
def k735 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k512, k734]
def k736 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k735]
def k737 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k736, k504, k505, k50, k94, k466, k512, k734, k502]
def combine8724 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k738 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:1:0"] []
def k739 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:1:0"] [k493, k738]
def k740 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k492, k739]
def k741 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k740]
def k742 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k741, k504, k505, k107, k94, k466, k492, k739, k502]
def combine8733 : Combine := fun l r => if l = k126 /\ r = k133 then some (k22, [k455]) else (if l = k22 /\ r = k140 then some (k463, [k459]) else (none))
def k743 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:1:1"] []
def k744 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:1:1"] [k513, k743]
def k745 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k107, k512, k744]
def k746 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k467, k745]
def k747 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k746, k504, k505, k107, k94, k466, k512, k744, k502]
theorem source0 : "94c4ab8b81db73094f3dbf1987660fa2e662af108973b5c78dca58b82d213aa6" = "94c4ab8b81db73094f3dbf1987660fa2e662af108973b5c78dca58b82d213aa6" /\ "a8dc4e4157b854b38e8d98da97e6bf614c72ac4ffc7f08ef4fd39dc2bce4126d" = "a8dc4e4157b854b38e8d98da97e6bf614c72ac4ffc7f08ef4fd39dc2bce4126d" := by decide
#print axioms source0
theorem source1 : "201590a925c01cd5a6e9f51dd7e9b9a497a7dcea5efbf499780da8dba263e67e" = "201590a925c01cd5a6e9f51dd7e9b9a497a7dcea5efbf499780da8dba263e67e" /\ "c9763fd525bc78c86203a875e0e5063955dbe396d34dd30249b464cdd23da3da" = "c9763fd525bc78c86203a875e0e5063955dbe396d34dd30249b464cdd23da3da" := by decide
#print axioms source1
theorem source2 : "db81a97d3a9553bf83a22b8721205b61e940ec4c6f550ed115206782470a30f5" = "db81a97d3a9553bf83a22b8721205b61e940ec4c6f550ed115206782470a30f5" /\ "90dca62f7db47fe638762cbcb0a617f536bfba19a876012b122842f63e7f25bb" = "90dca62f7db47fe638762cbcb0a617f536bfba19a876012b122842f63e7f25bb" := by decide
#print axioms source2
theorem source3 : "800b128e0f225b68f242d201009689bb5eeded3391250ef4259378dce034c35f" = "800b128e0f225b68f242d201009689bb5eeded3391250ef4259378dce034c35f" /\ "9ab2f002f27397ca2a0df0e45f98eee11a4a6993c73f8986dae6b4d0d91ec4ec" = "9ab2f002f27397ca2a0df0e45f98eee11a4a6993c73f8986dae6b4d0d91ec4ec" := by decide
#print axioms source3
theorem source4 : "64c387d33dc40528ac4b1a9faa8a72237a10f0d049f656731fd5af4b88470fb8" = "64c387d33dc40528ac4b1a9faa8a72237a10f0d049f656731fd5af4b88470fb8" /\ "13f9b2a502d11b0836d7453950bf0e028f8fb3f03cb416013436794fbd25b5a6" = "13f9b2a502d11b0836d7453950bf0e028f8fb3f03cb416013436794fbd25b5a6" := by decide
#print axioms source4
theorem source5 : "325740a2f5587deeb28ab091880d6f2d9ce0894dd659b872103cb13a5cb3c194" = "325740a2f5587deeb28ab091880d6f2d9ce0894dd659b872103cb13a5cb3c194" /\ "e107211d2bfeb3a5a7bca53dc0d0f7db63ffbcf61fe327cdfd405e0d81a72796" = "e107211d2bfeb3a5a7bca53dc0d0f7db63ffbcf61fe327cdfd405e0d81a72796" := by decide
#print axioms source5
theorem source6 : "3aad8a1cfd9aa91431ec46ec25f3dbae94f82d8926e129d5702f9675ee495e54" = "3aad8a1cfd9aa91431ec46ec25f3dbae94f82d8926e129d5702f9675ee495e54" /\ "11cf028d508997595a314cef1f0a36d411d1ba8f799e8c0e125bedecc02e6e47" = "11cf028d508997595a314cef1f0a36d411d1ba8f799e8c0e125bedecc02e6e47" := by decide
#print axioms source6
theorem source7 : "b6c18c3ca66eba2bdaba5385211ab9f557419ac6dc6f807659fef0c33acb5c4e" = "b6c18c3ca66eba2bdaba5385211ab9f557419ac6dc6f807659fef0c33acb5c4e" /\ "b52e7b1c6925e177d91e6202f01cd5ceb4786d0ce26d9c01ec8bf2972be90c42" = "b52e7b1c6925e177d91e6202f01cd5ceb4786d0ce26d9c01ec8bf2972be90c42" := by decide
#print axioms source7
theorem source8 : "1b9144c54170bcd98528f79b4432cb1203057dc2ee1b7fedc0d55c2223120492" = "1b9144c54170bcd98528f79b4432cb1203057dc2ee1b7fedc0d55c2223120492" /\ "3bb8166269c04aa1cb967873088cfdeaefc3bafdbc3399c01122f12e1b99334b" = "3bb8166269c04aa1cb967873088cfdeaefc3bafdbc3399c01122f12e1b99334b" := by decide
#print axioms source8
theorem source9 : "6996cae14018896b70e600cdc3252ba1654f49d0865927feb30626de2bb0be80" = "6996cae14018896b70e600cdc3252ba1654f49d0865927feb30626de2bb0be80" /\ "2e67b77018788888b9be5085d2f4bd8824af0079ee701a86dccf480325f02534" = "2e67b77018788888b9be5085d2f4bd8824af0079ee701a86dccf480325f02534" := by decide
#print axioms source9
theorem source10 : "9592eec198ba9ef3b3073cbef9ecf994dd0a8f8d70fe6eeab7bc218e8703891f" = "9592eec198ba9ef3b3073cbef9ecf994dd0a8f8d70fe6eeab7bc218e8703891f" /\ "a6dbd09bd87ecf04e7139b6c214047614be7324329d3ada157a66d877010399a" = "a6dbd09bd87ecf04e7139b6c214047614be7324329d3ada157a66d877010399a" := by decide
#print axioms source10
theorem source11 : "460176ca8939a4fe2f29a9ad2b1bbe916ffcee7075e48151d55c581d8e6dd916" = "460176ca8939a4fe2f29a9ad2b1bbe916ffcee7075e48151d55c581d8e6dd916" /\ "3fd2cb09eab2671bf23a1d0d1317428eb8b21f65f5e4bfad138813bf7d5fb22e" = "3fd2cb09eab2671bf23a1d0d1317428eb8b21f65f5e4bfad138813bf7d5fb22e" := by decide
#print axioms source11
theorem source12 : "c91040e65f45bfc520051f2ccdba9aa6a609e01c0d597eba731fd613f65743da" = "c91040e65f45bfc520051f2ccdba9aa6a609e01c0d597eba731fd613f65743da" /\ "a96e5e846bc4901abe3350c51da5a02ba7650677d50a176ab88b8390e0660177" = "a96e5e846bc4901abe3350c51da5a02ba7650677d50a176ab88b8390e0660177" := by decide
#print axioms source12
theorem observation0 : derive (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) = some .primitive := by decide
#print axioms observation0
theorem observation1 : derive (.primitive .int) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation1
theorem observation2 : derive (.primitive .int) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation2
theorem observation3 : derive (.primitive .int) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation3
theorem observation4 : derive (.primitive .int) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation4
theorem observation5 : derive (.primitive .int) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation5
theorem observation6 : derive (.primitive .int) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation6
theorem observation7 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7
theorem observation8 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation8
theorem observation9 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .primitive := by decide
#print axioms observation9
theorem observation10 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation10
theorem observation11 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation11
theorem observation12 : derive (.primitive (.sig "A")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation12
theorem observation13 : derive (.primitive (.sig "A")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation13
theorem observation14 : derive (.primitive (.sig "A")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation14
theorem observation15 : "REJECTED" = "REJECTED" := by decide
#print axioms observation15
theorem observation16 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation16
theorem observation17 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation17
theorem observation18 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = some .primitive := by decide
#print axioms observation18
theorem observation19 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation19
theorem observation20 : derive (.primitive (.sig "univ")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation20
theorem observation21 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation21
theorem observation22 : derive (.primitive (.sig "univ")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation22
theorem observation23 : "REJECTED" = "REJECTED" := by decide
#print axioms observation23
theorem observation24 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation24
theorem observation25 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .exact := by decide
#print axioms observation25
theorem observation26 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation26
theorem observation27 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation27
theorem observation28 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation28
theorem observation29 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation29
theorem observation30 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation30
theorem observation31 : "REJECTED" = "REJECTED" := by decide
#print axioms observation31
theorem observation32 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation32
theorem observation33 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation33
theorem observation34 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation34
theorem observation35 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation35
theorem observation36 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = some .exact := by decide
#print axioms observation36
theorem observation37 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation37
theorem observation38 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation38
theorem observation39 : "REJECTED" = "REJECTED" := by decide
#print axioms observation39
theorem observation40 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation40
theorem observation41 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation41
theorem observation42 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation42
theorem observation43 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation43
theorem observation44 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation44
theorem observation45 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [] } : Family) = some .exact := by decide
#print axioms observation45
theorem observation46 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation46
theorem observation47 : "REJECTED" = "REJECTED" := by decide
#print axioms observation47
theorem observation48 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation48
theorem observation49 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation49
theorem observation50 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation50
theorem observation51 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation51
theorem observation52 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation52
theorem observation53 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation53
theorem observation54 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) = some .exact := by decide
#print axioms observation54
theorem observation55 : "REJECTED" = "REJECTED" := by decide
#print axioms observation55
theorem observation56 : derive (.other k0) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation56
theorem observation57 : derive (.other k0) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation57
theorem observation58 : derive (.other k0) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation58
theorem observation59 : derive (.other k0) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation59
theorem observation60 : derive (.other k0) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation60
theorem observation61 : derive (.other k0) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation61
theorem observation62 : derive (.other k0) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation62
theorem observation63 : "REJECTED" = "REJECTED" := by decide
#print axioms observation63
theorem observation64 : derive (.other k1) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation64
theorem observation65 : derive (.other k1) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation65
theorem observation66 : derive (.other k1) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation66
theorem observation67 : derive (.other k1) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation67
theorem observation68 : derive (.other k1) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation68
theorem observation69 : derive (.other k1) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation69
theorem observation70 : derive (.other k1) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation70
theorem observation71 : "REJECTED" = "REJECTED" := by decide
#print axioms observation71
theorem observation72 : derive (.other k2) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation72
theorem observation73 : derive (.other k2) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation73
theorem observation74 : derive (.other k2) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation74
theorem observation75 : derive (.other k2) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation75
theorem observation76 : derive (.other k2) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation76
theorem observation77 : derive (.other k2) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation77
theorem observation78 : derive (.other k2) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation78
theorem observation79 : "REJECTED" = "REJECTED" := by decide
#print axioms observation79
theorem observation80 : derive (.other k3) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation80
theorem observation81 : derive (.other k3) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation81
theorem observation82 : derive (.other k3) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation82
theorem observation83 : derive (.other k3) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation83
theorem observation84 : derive (.other k3) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation84
theorem observation85 : derive (.other k3) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation85
theorem observation86 : derive (.other k3) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation86
theorem observation87 : "REJECTED" = "REJECTED" := by decide
#print axioms observation87
theorem observation88 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation88
theorem observation89 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .primitive := by decide
#print axioms observation89
theorem observation90 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation90
theorem observation91 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation91
theorem observation92 : derive (.primitive (.sig "A")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation92
theorem observation93 : derive (.primitive (.sig "A")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation93
theorem observation94 : derive (.primitive (.sig "A")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation94
theorem observation95 : "REJECTED" = "REJECTED" := by decide
#print axioms observation95
theorem observation96 : k11 = k11 /\ k12 = k12 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k7, k9, k10, k4, k6, k8] k47 = true := by decide
#print axioms observation96
theorem observation97 : k47 = k47 /\ k47 = k47 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine97 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k22, k27] k44 = some k47 := by decide
#print axioms observation97
theorem observation98 : k95 = k95 /\ k95 = k95 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation98
theorem observation99 : k76 = k76 /\ k76 = k76 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation99
theorem observation100 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation100
theorem observation101 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation101
theorem observation102 : k57 = k57 /\ k96 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k96 = true := by decide

end ACGN.FourthFive.DependentChainWitnessReplay
