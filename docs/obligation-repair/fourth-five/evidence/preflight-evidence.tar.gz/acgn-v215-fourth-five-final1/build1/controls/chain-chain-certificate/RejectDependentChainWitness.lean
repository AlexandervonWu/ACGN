import DependentChainWitnesses
namespace ACGN.FourthFive.DependentChainWitnessReplay
open ACGN.FourthFive.DependentChainWitnesses
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000
def k0 : Key := .node "type/BOOL" [] []
def k1 : Key := .node "type/TYPE_VARIABLE" ["X"] []
def k2 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] []
def k3 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] [k1]
def k4 : Key := .node "type/CONSTRUCTOR" ["AlloySig:A"] []
def k5 : Key := .node "type/RELATION" [] [k4, k4]
def k6 : Key := .node "type/CONSTRUCTOR" ["AlloySig:B"] []
def k7 : Key := .node "type/RELATION" [] [k4, k6]
def k8 : Key := .node "type/CONSTRUCTOR" ["AlloySig:C"] []
def k9 : Key := .node "type/RELATION" [] [k4, k8]
def k10 : Key := .node "type/RELATION" [] [k6, k8]
def k11 : Key := .node "dependent-index-type-requirements" [] [k5, k7, k9, k10, k4, k6, k8]
def k12 : Key := .node "published-exact-types" [] [k5, k7, k9, k10, k4, k6, k8]
def k13 : Key := .node "direct-parent-path-v1" [] [k4]
def k14 : Key := .node "dependent-column-evidence-v1" [] [k4, k13]
def k15 : Key := .node "dependent-type-product-v1" [] [k14, k14]
def k16 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k15]
def k17 : Key := .node "dependent-type-dag-v1" ["2"] [k16, k5, k5]
def k18 : Key := .node "direct-parent-path-v1" [] [k6]
def k19 : Key := .node "dependent-column-evidence-v1" [] [k6, k18]
def k20 : Key := .node "dependent-type-product-v1" [] [k14, k19]
def k21 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k20]
def k22 : Key := .node "dependent-type-dag-v1" ["2"] [k21, k7, k7]
def k23 : Key := .node "direct-parent-path-v1" [] [k8]
def k24 : Key := .node "dependent-column-evidence-v1" [] [k8, k23]
def k25 : Key := .node "dependent-type-product-v1" [] [k19, k24]
def k26 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k25]
def k27 : Key := .node "dependent-type-dag-v1" ["2"] [k26, k10, k10]
def k28 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k22, k27]
def k29 : Key := .node "dependent-boundary-left-path-v1" [] [k4]
def k30 : Key := .node "dependent-boundary-right-path-v1" [] [k4]
def k31 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k4, k4, k4, k4, k29, k30]
def k32 : Key := .node "dependent-type-case-result-v1" [] [k14, k19]
def k33 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k32]
def k34 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k33]
def k35 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k22, k34, k22]
def k36 : Key := .node "dependent-boundary-left-path-v1" [] [k6]
def k37 : Key := .node "dependent-boundary-right-path-v1" [] [k6]
def k38 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k6, k6, k6, k6, k36, k37]
def k39 : Key := .node "dependent-type-case-result-v1" [] [k14, k24]
def k40 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k39]
def k41 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k40]
def k42 : Key := .node "dependent-type-product-v1" [] [k14, k24]
def k43 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k42]
def k44 : Key := .node "dependent-type-dag-v1" ["2"] [k43, k9, k9]
def k45 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k22, k27, k41, k44]
def k46 : Key := .node "dependent-chain-fold-steps-v1" [] [k35, k45]
def k47 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k28, k46, k44]
def combine97 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k48 : Key := .node "context" [] []
def k49 : Key := .node "certificate-sort" ["TERM"] [k9]
def k50 : Key := .node "semantic-profile" ["4", "FORBID", "alloy-temporal", "repaired-normal-form-v2", "alloy-signature-v2"] []
def k51 : Key := .node "schema/one" [] [k5]
def k52 : Key := .node "eclass" ["0"] [k5, k48]
def k53 : Key := .node "embedding" [] [k48, k48]
def k54 : Key := .node "invocation" [] [k52, k53]
def k55 : Key := .node "port-leaf/invocation" [] [k54]
def k56 : Key := .node "port/one" [] [k51, k48, k55]
def k57 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k5, k5]
def k58 : Key := .node "dependent-chain-leaf-v4" [] [k56, k57, k17]
def k59 : Key := .node "schema/one" [] [k7]
def k60 : Key := .node "eclass" ["1"] [k7, k48]
def k61 : Key := .node "invocation" [] [k60, k53]
def k62 : Key := .node "port-leaf/invocation" [] [k61]
def k63 : Key := .node "port/one" [] [k59, k48, k62]
def k64 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k7, k7]
def k65 : Key := .node "dependent-chain-leaf-v4" [] [k63, k64, k22]
def k66 : Key := .node "dependent-chain-combination-cases-v1" [] [k33]
def k67 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k7, k22, k58, k65, k66]
def k68 : Key := .node "schema/one" [] [k10]
def k69 : Key := .node "eclass" ["2"] [k10, k48]
def k70 : Key := .node "invocation" [] [k69, k53]
def k71 : Key := .node "port-leaf/invocation" [] [k70]
def k72 : Key := .node "port/one" [] [k68, k48, k71]
def k73 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k10, k10]
def k74 : Key := .node "dependent-chain-leaf-v4" [] [k72, k73, k27]
def k75 : Key := .node "dependent-chain-combination-cases-v1" [] [k40]
def k76 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k67, k74, k75]
def k77 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k76]
def k78 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:0:0"] []
def k79 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:0:0"] [k77, k78]
def k80 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k76, k79]
def k81 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k80]
def k82 : Key := .node "arity-policy" ["FINITE", "3"] []
def k83 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k59, k68]
def k84 : Key := .node "flat-license" ["none"] []
def k85 : Key := .node "container-laws" ["SEQ", "false", "false", "false", "ABSENT"] []
def k86 : Key := .node "port-law" ["0/0"] [k85]
def k87 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k83, k9, k84, k86]
def k88 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k87, k83, k9]
def k89 : Key := .node "port/seq" [] [k83, k48, k56, k63, k72]
def k90 : Key := .node "e-node" [] [k88, k48, k89]
def k91 : Key := .node "certificate-term/node" [] [k90]
def k92 : Key := .node "certificate-endpoint" ["NODE"] [k48, k49, k91]
def k93 : Key := .node "certificate-endpoint-type-check" [] [k48, k49]
def k94 : Key := .node "dependent-chain-theory" ["3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8"] []
def k95 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k81, k92, k93, k50, k94, k47, k76, k79, k90]
def combine962 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k96 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k65, k74, k75]
def k97 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k39]
def k98 : Key := .node "dependent-chain-combination-cases-v1" [] [k97]
def k99 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k58, k96, k98]
def k100 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k99]
def k101 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:0:1"] []
def k102 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:0:1"] [k100, k101]
def k103 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k99, k102]
def k104 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k103]
def k105 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k104, k92, k93, k50, k94, k47, k99, k102, k90]
def combine971 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k106 : Key := .node "semantic-profile" ["4", "MODULAR", "alloy-temporal", "repaired-normal-form-v2", "alloy-signature-v2"] []
def k107 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:1:0"] []
def k108 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:1:0"] [k77, k107]
def k109 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k76, k108]
def k110 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k109]
def k111 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k110, k92, k93, k106, k94, k47, k76, k108, k90]
def combine980 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k112 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:1:1"] []
def k113 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:1:1"] [k100, k112]
def k114 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k99, k113]
def k115 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k114]
def k116 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k115, k92, k93, k106, k94, k47, k99, k113, k90]
def k117 : Key := .node "type/RELATION" [] [k4]
def k118 : Key := .node "type/RELATION" [] [k6]
def k119 : Key := .node "type/RELATION" [] [k8]
def k120 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] [k4]
def k121 : Key := .node "dependent-index-type-requirements" [] [k117, k118, k119, k7, k10, k4, k6, k8]
def k122 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k10, k4, k6, k8, k120]
def k123 : Key := .node "dependent-type-product-v1" [] [k14]
def k124 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k123]
def k125 : Key := .node "dependent-type-dag-v1" ["1"] [k124, k117, k117]
def k126 : Key := .node "dependent-chain-operand-dags-v1" [] [k125, k22, k27]
def k127 : Key := .node "dependent-type-case-result-v1" [] [k19]
def k128 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k127]
def k129 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k128]
def k130 : Key := .node "dependent-type-product-v1" [] [k19]
def k131 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k130]
def k132 : Key := .node "dependent-type-dag-v1" ["1"] [k131, k118, k118]
def k133 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k125, k22, k129, k132]
def k134 : Key := .node "dependent-type-case-result-v1" [] [k24]
def k135 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k134]
def k136 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k135]
def k137 : Key := .node "dependent-type-product-v1" [] [k24]
def k138 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k137]
def k139 : Key := .node "dependent-type-dag-v1" ["1"] [k138, k119, k119]
def k140 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k132, k27, k136, k139]
def k141 : Key := .node "dependent-chain-fold-steps-v1" [] [k133, k140]
def k142 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k126, k141, k139]
def combine989 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k143 : Key := .node "certificate-sort" ["TERM"] [k119]
def k144 : Key := .node "schema/one" [] [k120]
def k145 : Key := .node "eclass" ["0"] [k120, k48]
def k146 : Key := .node "invocation" [] [k145, k53]
def k147 : Key := .node "port-leaf/invocation" [] [k146]
def k148 : Key := .node "port/one" [] [k144, k48, k147]
def k149 : Key := .node "dependent-chain-leaf-type-proof-v1" ["PRIMITIVE_SET_SINGLETON"] [k120, k117]
def k150 : Key := .node "dependent-chain-leaf-v4" [] [k148, k149, k125]
def k151 : Key := .node "dependent-chain-combination-cases-v1" [] [k128]
def k152 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k118, k132, k150, k65, k151]
def k153 : Key := .node "dependent-chain-combination-cases-v1" [] [k135]
def k154 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k152, k74, k153]
def k155 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k154]
def k156 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:0:0"] []
def k157 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:0:0"] [k155, k156]
def k158 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k154, k157]
def k159 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k158]
def k160 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k144, k59, k68]
def k161 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k160, k119, k84, k86]
def k162 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k161, k160, k119]
def k163 : Key := .node "port/seq" [] [k160, k48, k148, k63, k72]
def k164 : Key := .node "e-node" [] [k162, k48, k163]
def k165 : Key := .node "certificate-term/node" [] [k164]
def k166 : Key := .node "certificate-endpoint" ["NODE"] [k48, k143, k165]
def k167 : Key := .node "certificate-endpoint-type-check" [] [k48, k143]
def k168 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k159, k166, k167, k50, k94, k142, k154, k157, k164]
def k169 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k9, k10, k4, k6, k8, k120]
def combine1698 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k170 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k134]
def k171 : Key := .node "dependent-chain-combination-cases-v1" [] [k170]
def k172 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k150, k96, k171]
def k173 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k172]
def k174 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:0:1"] []
def k175 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:0:1"] [k173, k174]
def k176 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k172, k175]
def k177 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k176]
def k178 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k177, k166, k167, k50, k94, k142, k172, k175, k164]
def combine1708 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k179 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:1:0"] []
def k180 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:1:0"] [k155, k179]
def k181 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k154, k180]
def k182 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k181]
def k183 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k182, k166, k167, k106, k94, k142, k154, k180, k164]
def combine1717 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k184 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:1:1"] []
def k185 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:1:1"] [k173, k184]
def k186 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k172, k185]
def k187 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k186]
def k188 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k187, k166, k167, k106, k94, k142, k172, k185, k164]
def k189 : Key := .node "type/INT" [] []
def k190 : Key := .node "type/RELATION" [] [k189]
def k191 : Key := .node "type/RELATION" [] [k189, k6]
def k192 : Key := .node "dependent-index-type-requirements" [] [k190, k118, k119, k191, k10, k6, k8, k189]
def k193 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k10, k6, k8, k189]
def k194 : Key := .node "direct-parent-path-v1" [] [k189]
def k195 : Key := .node "dependent-column-evidence-v1" [] [k189, k194]
def k196 : Key := .node "dependent-type-product-v1" [] [k195]
def k197 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k196]
def k198 : Key := .node "dependent-type-dag-v1" ["1"] [k197, k190, k190]
def k199 : Key := .node "dependent-type-product-v1" [] [k195, k19]
def k200 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k199]
def k201 : Key := .node "dependent-type-dag-v1" ["2"] [k200, k191, k191]
def k202 : Key := .node "dependent-chain-operand-dags-v1" [] [k198, k201, k27]
def k203 : Key := .node "dependent-boundary-left-path-v1" [] [k189]
def k204 : Key := .node "dependent-boundary-right-path-v1" [] [k189]
def k205 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k189, k189, k189, k189, k203, k204]
def k206 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k205, k127]
def k207 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k206]
def k208 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k198, k201, k207, k132]
def k209 : Key := .node "dependent-chain-fold-steps-v1" [] [k208, k140]
def k210 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k202, k209, k139]
def combine1726 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k211 : Key := .node "schema/one" [] [k189]
def k212 : Key := .node "eclass" ["0"] [k189, k48]
def k213 : Key := .node "invocation" [] [k212, k53]
def k214 : Key := .node "port-leaf/invocation" [] [k213]
def k215 : Key := .node "port/one" [] [k211, k48, k214]
def k216 : Key := .node "dependent-chain-leaf-type-proof-v1" ["PRIMITIVE_SET_SINGLETON"] [k189, k190]
def k217 : Key := .node "dependent-chain-leaf-v4" [] [k215, k216, k198]
def k218 : Key := .node "schema/one" [] [k191]
def k219 : Key := .node "eclass" ["1"] [k191, k48]
def k220 : Key := .node "invocation" [] [k219, k53]
def k221 : Key := .node "port-leaf/invocation" [] [k220]
def k222 : Key := .node "port/one" [] [k218, k48, k221]
def k223 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k191, k191]
def k224 : Key := .node "dependent-chain-leaf-v4" [] [k222, k223, k201]
def k225 : Key := .node "dependent-chain-combination-cases-v1" [] [k206]
def k226 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k118, k132, k217, k224, k225]
def k227 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k226, k74, k153]
def k228 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k227]
def k229 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:0:0"] []
def k230 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:0:0"] [k228, k229]
def k231 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k227, k230]
def k232 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k231]
def k233 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k211, k218, k68]
def k234 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k233, k119, k84, k86]
def k235 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k234, k233, k119]
def k236 : Key := .node "port/seq" [] [k233, k48, k215, k222, k72]
def k237 : Key := .node "e-node" [] [k235, k48, k236]
def k238 : Key := .node "certificate-term/node" [] [k237]
def k239 : Key := .node "certificate-endpoint" ["NODE"] [k48, k143, k238]
def k240 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k232, k239, k167, k50, k94, k210, k227, k230, k237]
def k241 : Key := .node "type/RELATION" [] [k189, k8]
def k242 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k241, k10, k6, k8, k189]
def combine2406 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k243 : Key := .node "dependent-type-product-v1" [] [k195, k24]
def k244 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k243]
def k245 : Key := .node "dependent-type-dag-v1" ["2"] [k244, k241, k241]
def k246 : Key := .node "dependent-type-case-result-v1" [] [k195, k24]
def k247 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k246]
def k248 : Key := .node "dependent-chain-combination-cases-v1" [] [k247]
def k249 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k241, k245, k224, k74, k248]
def k250 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k205, k134]
def k251 : Key := .node "dependent-chain-combination-cases-v1" [] [k250]
def k252 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k217, k249, k251]
def k253 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k252]
def k254 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:0:1"] []
def k255 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:0:1"] [k253, k254]
def k256 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k252, k255]
def k257 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k256]
def k258 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k257, k239, k167, k50, k94, k210, k252, k255, k237]
def combine2415 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k259 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:1:0"] []
def k260 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:1:0"] [k228, k259]
def k261 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k227, k260]
def k262 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k261]
def k263 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k262, k239, k167, k106, k94, k210, k227, k260, k237]
def combine2424 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k264 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:1:1"] []
def k265 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:1:1"] [k253, k264]
def k266 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k252, k265]
def k267 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k266]
def k268 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k267, k239, k167, k106, k94, k210, k252, k265, k237]
def k269 : Key := .node "type/CONSTRUCTOR" ["AlloySig:univ"] []
def k270 : Key := .node "type/RELATION" [] [k4, k269]
def k271 : Key := .node "type/RELATION" [] [k269, k6]
def k272 : Key := .node "dependent-index-type-requirements" [] [k7, k9, k270, k10, k271, k4, k6, k8, k269]
def k273 : Key := .node "published-exact-types" [] [k7, k9, k270, k10, k271, k4, k6, k8, k269]
def k274 : Key := .node "direct-parent-path-v1" [] [k269]
def k275 : Key := .node "dependent-column-evidence-v1" [] [k269, k274]
def k276 : Key := .node "dependent-type-product-v1" [] [k14, k275]
def k277 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k276]
def k278 : Key := .node "dependent-type-dag-v1" ["2"] [k277, k270, k270]
def k279 : Key := .node "dependent-type-product-v1" [] [k275, k19]
def k280 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k279]
def k281 : Key := .node "dependent-type-dag-v1" ["2"] [k280, k271, k271]
def k282 : Key := .node "dependent-chain-operand-dags-v1" [] [k278, k281, k27]
def k283 : Key := .node "dependent-boundary-left-path-v1" [] [k269]
def k284 : Key := .node "dependent-boundary-right-path-v1" [] [k269]
def k285 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k269, k269, k269, k269, k283, k284]
def k286 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k285, k32]
def k287 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k286]
def k288 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k278, k281, k287, k22]
def k289 : Key := .node "dependent-chain-fold-steps-v1" [] [k288, k45]
def k290 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k282, k289, k44]
def combine2433 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k291 : Key := .node "schema/one" [] [k270]
def k292 : Key := .node "eclass" ["0"] [k270, k48]
def k293 : Key := .node "invocation" [] [k292, k53]
def k294 : Key := .node "port-leaf/invocation" [] [k293]
def k295 : Key := .node "port/one" [] [k291, k48, k294]
def k296 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k270, k270]
def k297 : Key := .node "dependent-chain-leaf-v4" [] [k295, k296, k278]
def k298 : Key := .node "schema/one" [] [k271]
def k299 : Key := .node "eclass" ["1"] [k271, k48]
def k300 : Key := .node "invocation" [] [k299, k53]
def k301 : Key := .node "port-leaf/invocation" [] [k300]
def k302 : Key := .node "port/one" [] [k298, k48, k301]
def k303 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k271, k271]
def k304 : Key := .node "dependent-chain-leaf-v4" [] [k302, k303, k281]
def k305 : Key := .node "dependent-chain-combination-cases-v1" [] [k286]
def k306 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k7, k22, k297, k304, k305]
def k307 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k306, k74, k75]
def k308 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k307]
def k309 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:0:0"] []
def k310 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:0:0"] [k308, k309]
def k311 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k307, k310]
def k312 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k311]
def k313 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k291, k298, k68]
def k314 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k313, k9, k84, k86]
def k315 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k314, k313, k9]
def k316 : Key := .node "port/seq" [] [k313, k48, k295, k302, k72]
def k317 : Key := .node "e-node" [] [k315, k48, k316]
def k318 : Key := .node "certificate-term/node" [] [k317]
def k319 : Key := .node "certificate-endpoint" ["NODE"] [k48, k49, k318]
def k320 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k312, k319, k93, k50, k94, k290, k307, k310, k317]
def k321 : Key := .node "type/RELATION" [] [k269, k8]
def k322 : Key := .node "published-exact-types" [] [k7, k9, k270, k10, k271, k321, k4, k6, k8, k269]
def combine3308 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k323 : Key := .node "dependent-type-product-v1" [] [k275, k24]
def k324 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k323]
def k325 : Key := .node "dependent-type-dag-v1" ["2"] [k324, k321, k321]
def k326 : Key := .node "dependent-type-case-result-v1" [] [k275, k24]
def k327 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k326]
def k328 : Key := .node "dependent-chain-combination-cases-v1" [] [k327]
def k329 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k321, k325, k304, k74, k328]
def k330 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k285, k39]
def k331 : Key := .node "dependent-chain-combination-cases-v1" [] [k330]
def k332 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k297, k329, k331]
def k333 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k332]
def k334 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:0:1"] []
def k335 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:0:1"] [k333, k334]
def k336 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k332, k335]
def k337 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k336]
def k338 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k337, k319, k93, k50, k94, k290, k332, k335, k317]
def combine3317 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k339 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:1:0"] []
def k340 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:1:0"] [k308, k339]
def k341 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k307, k340]
def k342 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k341]
def k343 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k342, k319, k93, k106, k94, k290, k307, k340, k317]
def combine3326 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k344 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:1:1"] []
def k345 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:1:1"] [k333, k344]
def k346 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k332, k345]
def k347 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k346]
def k348 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k347, k319, k93, k106, k94, k290, k332, k345, k317]
def k349 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=2"] []
def k350 : Key := .node "dependent-index-type-requirements" [] [k5, k10, k4, k6, k8, k349]
def k351 : Key := .node "published-exact-types" [] [k5, k10, k4, k6, k8, k349]
def k352 : Key := .node "dependent-type-correlated-alternatives-v1" [] []
def k353 : Key := .node "dependent-type-no-common-ancestor-v1" ["none"] []
def k354 : Key := .node "dependent-type-dag-v1" ["2"] [k352, k349, k353]
def k355 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k354, k27]
def k356 : Key := .node "dependent-chain-complete-case-matrix-v1" [] []
def k357 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k354, k356, k354]
def k358 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k354, k27, k356, k354]
def k359 : Key := .node "dependent-chain-fold-steps-v1" [] [k357, k358]
def k360 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k355, k359, k354]
def combine3335 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k361 : Key := .node "certificate-sort" ["TERM"] [k349]
def k362 : Key := .node "schema/one" [] [k349]
def k363 : Key := .node "eclass" ["1"] [k349, k48]
def k364 : Key := .node "invocation" [] [k363, k53]
def k365 : Key := .node "port-leaf/invocation" [] [k364]
def k366 : Key := .node "port/one" [] [k362, k48, k365]
def k367 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k349, k349]
def k368 : Key := .node "dependent-chain-leaf-v4" [] [k366, k367, k354]
def k369 : Key := .node "dependent-chain-combination-cases-v1" [] []
def k370 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k58, k368, k369]
def k371 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k370, k74, k369]
def k372 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k371]
def k373 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:0:0"] []
def k374 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:0:0"] [k372, k373]
def k375 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k371, k374]
def k376 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k375]
def k377 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k362, k68]
def k378 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k377, k349, k84, k86]
def k379 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k378, k377, k349]
def k380 : Key := .node "port/seq" [] [k377, k48, k56, k366, k72]
def k381 : Key := .node "e-node" [] [k379, k48, k380]
def k382 : Key := .node "certificate-term/node" [] [k381]
def k383 : Key := .node "certificate-endpoint" ["NODE"] [k48, k361, k382]
def k384 : Key := .node "certificate-endpoint-type-check" [] [k48, k361]
def k385 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k376, k383, k384, k50, k94, k360, k371, k374, k381]
def combine3786 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k386 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k368, k74, k369]
def k387 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k58, k386, k369]
def k388 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k387]
def k389 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:0:1"] []
def k390 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:0:1"] [k388, k389]
def k391 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k387, k390]
def k392 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k391]
def k393 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k392, k383, k384, k50, k94, k360, k387, k390, k381]
def combine3795 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k394 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:1:0"] []
def k395 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:1:0"] [k372, k394]
def k396 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k371, k395]
def k397 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k396]
def k398 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k397, k383, k384, k106, k94, k360, k371, k395, k381]
def combine3804 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k399 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:1:1"] []
def k400 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:1:1"] [k388, k399]
def k401 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k387, k400]
def k402 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k401]
def k403 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k402, k383, k384, k106, k94, k360, k387, k400, k381]
def k404 : Key := .node "dependent-index-type-requirements" [] [k5, k4]
def k405 : Key := .node "published-exact-types" [] [k5, k4]
def k406 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k17, k17]
def k407 : Key := .node "dependent-type-case-result-v1" [] [k14, k14]
def k408 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k407]
def k409 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k408]
def k410 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k17, k409, k17]
def k411 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k17, k17, k409, k17]
def k412 : Key := .node "dependent-chain-fold-steps-v1" [] [k410, k411]
def k413 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k406, k412, k17]
def combine3813 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k414 : Key := .node "certificate-sort" ["TERM"] [k5]
def k415 : Key := .node "dependent-chain-combination-cases-v1" [] [k408]
def k416 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k58, k58, k415]
def k417 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k416, k58, k415]
def k418 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k417]
def k419 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:0:0"] []
def k420 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:0:0"] [k418, k419]
def k421 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k417, k420]
def k422 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k421]
def k423 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k51, k51]
def k424 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k423, k5, k84, k86]
def k425 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k424, k423, k5]
def k426 : Key := .node "port/seq" [] [k423, k48, k56, k56, k56]
def k427 : Key := .node "e-node" [] [k425, k48, k426]
def k428 : Key := .node "certificate-term/node" [] [k427]
def k429 : Key := .node "certificate-endpoint" ["NODE"] [k48, k414, k428]
def k430 : Key := .node "certificate-endpoint-type-check" [] [k48, k414]
def k431 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k422, k429, k430, k50, k94, k413, k417, k420, k427]
def combine4639 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k432 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k58, k416, k415]
def k433 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k432]
def k434 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:0:1"] []
def k435 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:0:1"] [k433, k434]
def k436 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k432, k435]
def k437 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k436]
def k438 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k437, k429, k430, k50, k94, k413, k432, k435, k427]
def combine4648 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k439 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:1:0"] []
def k440 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:1:0"] [k418, k439]
def k441 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k417, k440]
def k442 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k441]
def k443 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k442, k429, k430, k106, k94, k413, k417, k440, k427]
def combine4657 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k444 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:1:1"] []
def k445 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:1:1"] [k433, k444]
def k446 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k432, k445]
def k447 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k446]
def k448 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k447, k429, k430, k106, k94, k413, k432, k445, k427]
def k449 : Key := .node "type/RELATION" [] [k4, k6, k8]
def k450 : Key := .node "dependent-index-type-requirements" [] [k117, k118, k119, k7, k449, k4, k6, k8]
def k451 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k449, k4, k6, k8]
def k452 : Key := .node "dependent-chain-operand-dags-v1" [] [k125, k132, k139]
def k453 : Key := .node "dependent-type-no-boundary-v1" ["arrow"] []
def k454 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k32]
def k455 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k454]
def k456 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k125, k132, k455, k22]
def k457 : Key := .node "dependent-type-case-result-v1" [] [k14, k19, k24]
def k458 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k457]
def k459 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k458]
def k460 : Key := .node "dependent-type-product-v1" [] [k14, k19, k24]
def k461 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k460]
def k462 : Key := .node "dependent-type-dag-v1" ["3"] [k461, k449, k449]
def k463 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k22, k139, k459, k462]
def k464 : Key := .node "dependent-chain-fold-steps-v1" [] [k456, k463]
def k465 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k452, k464, k462]
def combine4666 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k466 : Key := .node "certificate-sort" ["TERM"] [k449]
def k467 : Key := .node "schema/one" [] [k117]
def k468 : Key := .node "eclass" ["0"] [k117, k48]
def k469 : Key := .node "invocation" [] [k468, k53]
def k470 : Key := .node "port-leaf/invocation" [] [k469]
def k471 : Key := .node "port/one" [] [k467, k48, k470]
def k472 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k117, k117]
def k473 : Key := .node "dependent-chain-leaf-v4" [] [k471, k472, k125]
def k474 : Key := .node "schema/one" [] [k118]
def k475 : Key := .node "eclass" ["1"] [k118, k48]
def k476 : Key := .node "invocation" [] [k475, k53]
def k477 : Key := .node "port-leaf/invocation" [] [k476]
def k478 : Key := .node "port/one" [] [k474, k48, k477]
def k479 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k118, k118]
def k480 : Key := .node "dependent-chain-leaf-v4" [] [k478, k479, k132]
def k481 : Key := .node "dependent-chain-combination-cases-v1" [] [k454]
def k482 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k7, k22, k473, k480, k481]
def k483 : Key := .node "schema/one" [] [k119]
def k484 : Key := .node "eclass" ["2"] [k119, k48]
def k485 : Key := .node "invocation" [] [k484, k53]
def k486 : Key := .node "port-leaf/invocation" [] [k485]
def k487 : Key := .node "port/one" [] [k483, k48, k486]
def k488 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k119, k119]
def k489 : Key := .node "dependent-chain-leaf-v4" [] [k487, k488, k139]
def k490 : Key := .node "dependent-chain-combination-cases-v1" [] [k458]
def k491 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k482, k489, k490]
def k492 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k491]
def k493 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:0:0"] []
def k494 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:0:0"] [k492, k493]
def k495 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k491, k494]
def k496 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k495]
def k497 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k467, k474, k483]
def k498 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k497, k449, k84, k86]
def k499 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k498, k497, k449]
def k500 : Key := .node "port/seq" [] [k497, k48, k471, k478, k487]
def k501 : Key := .node "e-node" [] [k499, k48, k500]
def k502 : Key := .node "certificate-term/node" [] [k501]
def k503 : Key := .node "certificate-endpoint" ["NODE"] [k48, k466, k502]
def k504 : Key := .node "certificate-endpoint-type-check" [] [k48, k466]
def k505 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k496, k503, k504, k50, k94, k465, k491, k494, k501]
def k506 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k10, k449, k4, k6, k8]
def combine5383 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k507 : Key := .node "dependent-type-case-result-v1" [] [k19, k24]
def k508 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k507]
def k509 : Key := .node "dependent-chain-combination-cases-v1" [] [k508]
def k510 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k10, k27, k480, k489, k509]
def k511 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k473, k510, k490]
def k512 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k511]
def k513 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:0:1"] []
def k514 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:0:1"] [k512, k513]
def k515 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k511, k514]
def k516 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k515]
def k517 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k516, k503, k504, k50, k94, k465, k511, k514, k501]
def combine5392 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k518 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:1:0"] []
def k519 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:1:0"] [k492, k518]
def k520 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k491, k519]
def k521 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k520]
def k522 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k521, k503, k504, k106, k94, k465, k491, k519, k501]
def combine5401 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k523 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:1:1"] []
def k524 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:1:1"] [k512, k523]
def k525 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k511, k524]
def k526 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k525]
def k527 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k526, k503, k504, k106, k94, k465, k511, k524, k501]
def k528 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k449, k4, k6, k8, k120]
def combine5410 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k529 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k7, k22, k150, k480, k481]
def k530 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k529, k489, k490]
def k531 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k530]
def k532 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:0:0"] []
def k533 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:0:0"] [k531, k532]
def k534 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k530, k533]
def k535 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k534]
def k536 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k144, k474, k483]
def k537 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k536, k449, k84, k86]
def k538 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k537, k536, k449]
def k539 : Key := .node "port/seq" [] [k536, k48, k148, k478, k487]
def k540 : Key := .node "e-node" [] [k538, k48, k539]
def k541 : Key := .node "certificate-term/node" [] [k540]
def k542 : Key := .node "certificate-endpoint" ["NODE"] [k48, k466, k541]
def k543 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k535, k542, k504, k50, k94, k465, k530, k533, k540]
def k544 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k10, k449, k4, k6, k8, k120]
def combine6129 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k545 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k150, k510, k490]
def k546 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k545]
def k547 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:0:1"] []
def k548 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:0:1"] [k546, k547]
def k549 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k545, k548]
def k550 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k549]
def k551 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k550, k542, k504, k50, k94, k465, k545, k548, k540]
def combine6138 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k552 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:1:0"] []
def k553 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:1:0"] [k531, k552]
def k554 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k530, k553]
def k555 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k554]
def k556 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k555, k542, k504, k106, k94, k465, k530, k553, k540]
def combine6147 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k557 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:1:1"] []
def k558 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:1:1"] [k546, k557]
def k559 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k545, k558]
def k560 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k559]
def k561 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k560, k542, k504, k106, k94, k465, k545, k558, k540]
def k562 : Key := .node "type/RELATION" [] [k189, k6, k8]
def k563 : Key := .node "dependent-index-type-requirements" [] [k190, k118, k119, k191, k562, k6, k8, k189]
def k564 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k562, k6, k8, k189]
def k565 : Key := .node "dependent-chain-operand-dags-v1" [] [k198, k132, k139]
def k566 : Key := .node "dependent-type-case-result-v1" [] [k195, k19]
def k567 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k566]
def k568 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k567]
def k569 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k198, k132, k568, k201]
def k570 : Key := .node "dependent-type-case-result-v1" [] [k195, k19, k24]
def k571 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k570]
def k572 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k571]
def k573 : Key := .node "dependent-type-product-v1" [] [k195, k19, k24]
def k574 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k573]
def k575 : Key := .node "dependent-type-dag-v1" ["3"] [k574, k562, k562]
def k576 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k201, k139, k572, k575]
def k577 : Key := .node "dependent-chain-fold-steps-v1" [] [k569, k576]
def k578 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k565, k577, k575]
def combine6156 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k579 : Key := .node "certificate-sort" ["TERM"] [k562]
def k580 : Key := .node "dependent-chain-combination-cases-v1" [] [k567]
def k581 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k191, k201, k217, k480, k580]
def k582 : Key := .node "dependent-chain-combination-cases-v1" [] [k571]
def k583 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k562, k575, k581, k489, k582]
def k584 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k583]
def k585 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:0:0"] []
def k586 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:0:0"] [k584, k585]
def k587 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k583, k586]
def k588 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k587]
def k589 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k211, k474, k483]
def k590 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k589, k562, k84, k86]
def k591 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k590, k589, k562]
def k592 : Key := .node "port/seq" [] [k589, k48, k215, k478, k487]
def k593 : Key := .node "e-node" [] [k591, k48, k592]
def k594 : Key := .node "certificate-term/node" [] [k593]
def k595 : Key := .node "certificate-endpoint" ["NODE"] [k48, k579, k594]
def k596 : Key := .node "certificate-endpoint-type-check" [] [k48, k579]
def k597 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k588, k595, k596, k50, k94, k578, k583, k586, k593]
def k598 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k10, k562, k6, k8, k189]
def combine6842 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k599 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k562, k575, k217, k510, k582]
def k600 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k599]
def k601 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:0:1"] []
def k602 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:0:1"] [k600, k601]
def k603 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k599, k602]
def k604 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k603]
def k605 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k604, k595, k596, k50, k94, k578, k599, k602, k593]
def combine6851 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k606 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:1:0"] []
def k607 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:1:0"] [k584, k606]
def k608 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k583, k607]
def k609 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k608]
def k610 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k609, k595, k596, k106, k94, k578, k583, k607, k593]
def combine6860 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k611 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:1:1"] []
def k612 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:1:1"] [k600, k611]
def k613 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k599, k612]
def k614 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k613]
def k615 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k614, k595, k596, k106, k94, k578, k599, k612, k593]
def k616 : Key := .node "type/RELATION" [] [k269]
def k617 : Key := .node "type/RELATION" [] [k269, k6, k8]
def k618 : Key := .node "dependent-index-type-requirements" [] [k118, k119, k616, k271, k617, k6, k8, k269]
def k619 : Key := .node "published-exact-types" [] [k118, k119, k616, k271, k617, k6, k8, k269]
def k620 : Key := .node "dependent-type-product-v1" [] [k275]
def k621 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k620]
def k622 : Key := .node "dependent-type-dag-v1" ["1"] [k621, k616, k616]
def k623 : Key := .node "dependent-chain-operand-dags-v1" [] [k622, k132, k139]
def k624 : Key := .node "dependent-type-case-result-v1" [] [k275, k19]
def k625 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k624]
def k626 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k625]
def k627 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k622, k132, k626, k281]
def k628 : Key := .node "dependent-type-case-result-v1" [] [k275, k19, k24]
def k629 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k628]
def k630 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k629]
def k631 : Key := .node "dependent-type-product-v1" [] [k275, k19, k24]
def k632 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k631]
def k633 : Key := .node "dependent-type-dag-v1" ["3"] [k632, k617, k617]
def k634 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k281, k139, k630, k633]
def k635 : Key := .node "dependent-chain-fold-steps-v1" [] [k627, k634]
def k636 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k623, k635, k633]
def combine6869 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k637 : Key := .node "certificate-sort" ["TERM"] [k617]
def k638 : Key := .node "schema/one" [] [k616]
def k639 : Key := .node "eclass" ["0"] [k616, k48]
def k640 : Key := .node "invocation" [] [k639, k53]
def k641 : Key := .node "port-leaf/invocation" [] [k640]
def k642 : Key := .node "port/one" [] [k638, k48, k641]
def k643 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k616, k616]
def k644 : Key := .node "dependent-chain-leaf-v4" [] [k642, k643, k622]
def k645 : Key := .node "dependent-chain-combination-cases-v1" [] [k625]
def k646 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k271, k281, k644, k480, k645]
def k647 : Key := .node "dependent-chain-combination-cases-v1" [] [k629]
def k648 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k617, k633, k646, k489, k647]
def k649 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k648]
def k650 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:0:0"] []
def k651 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:0:0"] [k649, k650]
def k652 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k648, k651]
def k653 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k652]
def k654 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k638, k474, k483]
def k655 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k654, k617, k84, k86]
def k656 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k655, k654, k617]
def k657 : Key := .node "port/seq" [] [k654, k48, k642, k478, k487]
def k658 : Key := .node "e-node" [] [k656, k48, k657]
def k659 : Key := .node "certificate-term/node" [] [k658]
def k660 : Key := .node "certificate-endpoint" ["NODE"] [k48, k637, k659]
def k661 : Key := .node "certificate-endpoint-type-check" [] [k48, k637]
def k662 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k653, k660, k661, k50, k94, k636, k648, k651, k658]
def k663 : Key := .node "published-exact-types" [] [k118, k119, k616, k10, k271, k617, k6, k8, k269]
def combine7586 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k664 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k617, k633, k644, k510, k647]
def k665 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k664]
def k666 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:0:1"] []
def k667 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:0:1"] [k665, k666]
def k668 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k664, k667]
def k669 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k668]
def k670 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k669, k660, k661, k50, k94, k636, k664, k667, k658]
def combine7595 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k671 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:1:0"] []
def k672 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:1:0"] [k649, k671]
def k673 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k648, k672]
def k674 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k673]
def k675 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k674, k660, k661, k106, k94, k636, k648, k672, k658]
def combine7604 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k676 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:1:1"] []
def k677 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:1:1"] [k665, k676]
def k678 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k664, k677]
def k679 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k678]
def k680 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k679, k660, k661, k106, k94, k636, k664, k677, k658]
def k681 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=3"] []
def k682 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=4"] []
def k683 : Key := .node "dependent-index-type-requirements" [] [k117, k119, k4, k8, k349, k681, k682]
def k684 : Key := .node "published-exact-types" [] [k117, k119, k4, k8, k349, k681, k682]
def k685 : Key := .node "dependent-chain-operand-dags-v1" [] [k125, k354, k139]
def k686 : Key := .node "dependent-type-dag-v1" ["3"] [k352, k681, k353]
def k687 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k125, k354, k356, k686]
def k688 : Key := .node "dependent-type-dag-v1" ["4"] [k352, k682, k353]
def k689 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k686, k139, k356, k688]
def k690 : Key := .node "dependent-chain-fold-steps-v1" [] [k687, k689]
def k691 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k685, k690, k688]
def combine7613 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k692 : Key := .node "certificate-sort" ["TERM"] [k682]
def k693 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k681, k686, k473, k368, k369]
def k694 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k682, k688, k693, k489, k369]
def k695 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k694]
def k696 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:0:0"] []
def k697 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:0:0"] [k695, k696]
def k698 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k694, k697]
def k699 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k698]
def k700 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k467, k362, k483]
def k701 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k700, k682, k84, k86]
def k702 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k701, k700, k682]
def k703 : Key := .node "port/seq" [] [k700, k48, k471, k366, k487]
def k704 : Key := .node "e-node" [] [k702, k48, k703]
def k705 : Key := .node "certificate-term/node" [] [k704]
def k706 : Key := .node "certificate-endpoint" ["NODE"] [k48, k692, k705]
def k707 : Key := .node "certificate-endpoint-type-check" [] [k48, k692]
def k708 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k699, k706, k707, k50, k94, k691, k694, k697, k704]
def combine7971 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k709 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k681, k686, k368, k489, k369]
def k710 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k682, k688, k473, k709, k369]
def k711 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k710]
def k712 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:0:1"] []
def k713 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:0:1"] [k711, k712]
def k714 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k710, k713]
def k715 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k714]
def k716 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k715, k706, k707, k50, k94, k691, k710, k713, k704]
def combine7980 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k717 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:1:0"] []
def k718 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:1:0"] [k695, k717]
def k719 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k694, k718]
def k720 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k719]
def k721 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k720, k706, k707, k106, k94, k691, k694, k718, k704]
def combine7989 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k722 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:1:1"] []
def k723 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:1:1"] [k711, k722]
def k724 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k710, k723]
def k725 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k724]
def k726 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k725, k706, k707, k106, k94, k691, k710, k723, k704]
def combine7998 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k727 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:0:0"] []
def k728 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:0:0"] [k492, k727]
def k729 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k491, k728]
def k730 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k729]
def k731 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k730, k503, k504, k50, k94, k465, k491, k728, k501]
def combine8715 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k732 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:0:1"] []
def k733 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:0:1"] [k512, k732]
def k734 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k511, k733]
def k735 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k734]
def k736 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k735, k503, k504, k50, k94, k465, k511, k733, k501]
def combine8724 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k737 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:1:0"] []
def k738 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:1:0"] [k492, k737]
def k739 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k491, k738]
def k740 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k739]
def k741 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k740, k503, k504, k106, k94, k465, k491, k738, k501]
def combine8733 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k742 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:1:1"] []
def k743 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:1:1"] [k512, k742]
def k744 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k511, k743]
def k745 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k744]
def k746 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k745, k503, k504, k106, k94, k465, k511, k743, k501]
theorem source0 : "94c4ab8b81db73094f3dbf1987660fa2e662af108973b5c78dca58b82d213aa6" = "94c4ab8b81db73094f3dbf1987660fa2e662af108973b5c78dca58b82d213aa6" /\ "a8dc4e4157b854b38e8d98da97e6bf614c72ac4ffc7f08ef4fd39dc2bce4126d" = "a8dc4e4157b854b38e8d98da97e6bf614c72ac4ffc7f08ef4fd39dc2bce4126d" := by decide
#print axioms source0
theorem source1 : "201590a925c01cd5a6e9f51dd7e9b9a497a7dcea5efbf499780da8dba263e67e" = "201590a925c01cd5a6e9f51dd7e9b9a497a7dcea5efbf499780da8dba263e67e" /\ "c9763fd525bc78c86203a875e0e5063955dbe396d34dd30249b464cdd23da3da" = "c9763fd525bc78c86203a875e0e5063955dbe396d34dd30249b464cdd23da3da" := by decide
#print axioms source1
theorem source2 : "db81a97d3a9553bf83a22b8721205b61e940ec4c6f550ed115206782470a30f5" = "db81a97d3a9553bf83a22b8721205b61e940ec4c6f550ed115206782470a30f5" /\ "90dca62f7db47fe638762cbcb0a617f536bfba19a876012b122842f63e7f25bb" = "90dca62f7db47fe638762cbcb0a617f536bfba19a876012b122842f63e7f25bb" := by decide
#print axioms source2
theorem source3 : "800b128e0f225b68f242d201009689bb5eeded3391250ef4259378dce034c35f" = "800b128e0f225b68f242d201009689bb5eeded3391250ef4259378dce034c35f" /\ "9ab2f002f27397ca2a0df0e45f98eee11a4a6993c73f8986dae6b4d0d91ec4ec" = "9ab2f002f27397ca2a0df0e45f98eee11a4a6993c73f8986dae6b4d0d91ec4ec" := by decide
#print axioms source3
theorem source4 : "64c387d33dc40528ac4b1a9faa8a72237a10f0d049f656731fd5af4b88470fb8" = "64c387d33dc40528ac4b1a9faa8a72237a10f0d049f656731fd5af4b88470fb8" /\ "13f9b2a502d11b0836d7453950bf0e028f8fb3f03cb416013436794fbd25b5a6" = "13f9b2a502d11b0836d7453950bf0e028f8fb3f03cb416013436794fbd25b5a6" := by decide
#print axioms source4
theorem source5 : "325740a2f5587deeb28ab091880d6f2d9ce0894dd659b872103cb13a5cb3c194" = "325740a2f5587deeb28ab091880d6f2d9ce0894dd659b872103cb13a5cb3c194" /\ "e107211d2bfeb3a5a7bca53dc0d0f7db63ffbcf61fe327cdfd405e0d81a72796" = "e107211d2bfeb3a5a7bca53dc0d0f7db63ffbcf61fe327cdfd405e0d81a72796" := by decide
#print axioms source5
theorem source6 : "3aad8a1cfd9aa91431ec46ec25f3dbae94f82d8926e129d5702f9675ee495e54" = "3aad8a1cfd9aa91431ec46ec25f3dbae94f82d8926e129d5702f9675ee495e54" /\ "11cf028d508997595a314cef1f0a36d411d1ba8f799e8c0e125bedecc02e6e47" = "11cf028d508997595a314cef1f0a36d411d1ba8f799e8c0e125bedecc02e6e47" := by decide
#print axioms source6
theorem source7 : "b6c18c3ca66eba2bdaba5385211ab9f557419ac6dc6f807659fef0c33acb5c4e" = "b6c18c3ca66eba2bdaba5385211ab9f557419ac6dc6f807659fef0c33acb5c4e" /\ "b52e7b1c6925e177d91e6202f01cd5ceb4786d0ce26d9c01ec8bf2972be90c42" = "b52e7b1c6925e177d91e6202f01cd5ceb4786d0ce26d9c01ec8bf2972be90c42" := by decide
#print axioms source7
theorem source8 : "1b9144c54170bcd98528f79b4432cb1203057dc2ee1b7fedc0d55c2223120492" = "1b9144c54170bcd98528f79b4432cb1203057dc2ee1b7fedc0d55c2223120492" /\ "3bb8166269c04aa1cb967873088cfdeaefc3bafdbc3399c01122f12e1b99334b" = "3bb8166269c04aa1cb967873088cfdeaefc3bafdbc3399c01122f12e1b99334b" := by decide
#print axioms source8
theorem source9 : "6996cae14018896b70e600cdc3252ba1654f49d0865927feb30626de2bb0be80" = "6996cae14018896b70e600cdc3252ba1654f49d0865927feb30626de2bb0be80" /\ "2e67b77018788888b9be5085d2f4bd8824af0079ee701a86dccf480325f02534" = "2e67b77018788888b9be5085d2f4bd8824af0079ee701a86dccf480325f02534" := by decide
#print axioms source9
theorem source10 : "9592eec198ba9ef3b3073cbef9ecf994dd0a8f8d70fe6eeab7bc218e8703891f" = "9592eec198ba9ef3b3073cbef9ecf994dd0a8f8d70fe6eeab7bc218e8703891f" /\ "a6dbd09bd87ecf04e7139b6c214047614be7324329d3ada157a66d877010399a" = "a6dbd09bd87ecf04e7139b6c214047614be7324329d3ada157a66d877010399a" := by decide
#print axioms source10
theorem source11 : "460176ca8939a4fe2f29a9ad2b1bbe916ffcee7075e48151d55c581d8e6dd916" = "460176ca8939a4fe2f29a9ad2b1bbe916ffcee7075e48151d55c581d8e6dd916" /\ "3fd2cb09eab2671bf23a1d0d1317428eb8b21f65f5e4bfad138813bf7d5fb22e" = "3fd2cb09eab2671bf23a1d0d1317428eb8b21f65f5e4bfad138813bf7d5fb22e" := by decide
#print axioms source11
theorem source12 : "c91040e65f45bfc520051f2ccdba9aa6a609e01c0d597eba731fd613f65743da" = "c91040e65f45bfc520051f2ccdba9aa6a609e01c0d597eba731fd613f65743da" /\ "a96e5e846bc4901abe3350c51da5a02ba7650677d50a176ab88b8390e0660177" = "a96e5e846bc4901abe3350c51da5a02ba7650677d50a176ab88b8390e0660177" := by decide
#print axioms source12
theorem observation0 : derive (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) = some .primitive := by decide
#print axioms observation0
theorem observation1 : derive (.primitive .int) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation1
theorem observation2 : derive (.primitive .int) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation2
theorem observation3 : derive (.primitive .int) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation3
theorem observation4 : derive (.primitive .int) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation4
theorem observation5 : derive (.primitive .int) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation5
theorem observation6 : derive (.primitive .int) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation6
theorem observation7 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7
theorem observation8 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation8
theorem observation9 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .primitive := by decide
#print axioms observation9
theorem observation10 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation10
theorem observation11 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation11
theorem observation12 : derive (.primitive (.sig "A")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation12
theorem observation13 : derive (.primitive (.sig "A")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation13
theorem observation14 : derive (.primitive (.sig "A")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation14
theorem observation15 : "REJECTED" = "REJECTED" := by decide
#print axioms observation15
theorem observation16 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation16
theorem observation17 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation17
theorem observation18 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = some .primitive := by decide
#print axioms observation18
theorem observation19 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation19
theorem observation20 : derive (.primitive (.sig "univ")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation20
theorem observation21 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation21
theorem observation22 : derive (.primitive (.sig "univ")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation22
theorem observation23 : "REJECTED" = "REJECTED" := by decide
#print axioms observation23
theorem observation24 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation24
theorem observation25 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .exact := by decide
#print axioms observation25
theorem observation26 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation26
theorem observation27 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation27
theorem observation28 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation28
theorem observation29 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation29
theorem observation30 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation30
theorem observation31 : "REJECTED" = "REJECTED" := by decide
#print axioms observation31
theorem observation32 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation32
theorem observation33 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation33
theorem observation34 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation34
theorem observation35 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation35
theorem observation36 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = some .exact := by decide
#print axioms observation36
theorem observation37 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation37
theorem observation38 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation38
theorem observation39 : "REJECTED" = "REJECTED" := by decide
#print axioms observation39
theorem observation40 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation40
theorem observation41 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation41
theorem observation42 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation42
theorem observation43 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation43
theorem observation44 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation44
theorem observation45 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [] } : Family) = some .exact := by decide
#print axioms observation45
theorem observation46 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation46
theorem observation47 : "REJECTED" = "REJECTED" := by decide
#print axioms observation47
theorem observation48 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation48
theorem observation49 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation49
theorem observation50 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation50
theorem observation51 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation51
theorem observation52 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation52
theorem observation53 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation53
theorem observation54 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) = some .exact := by decide
#print axioms observation54
theorem observation55 : "REJECTED" = "REJECTED" := by decide
#print axioms observation55
theorem observation56 : derive (.other k0) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation56
theorem observation57 : derive (.other k0) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation57
theorem observation58 : derive (.other k0) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation58
theorem observation59 : derive (.other k0) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation59
theorem observation60 : derive (.other k0) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation60
theorem observation61 : derive (.other k0) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation61
theorem observation62 : derive (.other k0) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation62
theorem observation63 : "REJECTED" = "REJECTED" := by decide
#print axioms observation63
theorem observation64 : derive (.other k1) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation64
theorem observation65 : derive (.other k1) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation65
theorem observation66 : derive (.other k1) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation66
theorem observation67 : derive (.other k1) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation67
theorem observation68 : derive (.other k1) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation68
theorem observation69 : derive (.other k1) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation69
theorem observation70 : derive (.other k1) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation70
theorem observation71 : "REJECTED" = "REJECTED" := by decide
#print axioms observation71
theorem observation72 : derive (.other k2) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation72
theorem observation73 : derive (.other k2) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation73
theorem observation74 : derive (.other k2) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation74
theorem observation75 : derive (.other k2) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation75
theorem observation76 : derive (.other k2) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation76
theorem observation77 : derive (.other k2) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation77
theorem observation78 : derive (.other k2) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation78
theorem observation79 : "REJECTED" = "REJECTED" := by decide
#print axioms observation79
theorem observation80 : derive (.other k3) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation80
theorem observation81 : derive (.other k3) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation81
theorem observation82 : derive (.other k3) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation82
theorem observation83 : derive (.other k3) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation83
theorem observation84 : derive (.other k3) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation84
theorem observation85 : derive (.other k3) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation85
theorem observation86 : derive (.other k3) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation86
theorem observation87 : "REJECTED" = "REJECTED" := by decide
#print axioms observation87
theorem observation88 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation88
theorem observation89 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .primitive := by decide
#print axioms observation89
theorem observation90 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation90
theorem observation91 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation91
theorem observation92 : derive (.primitive (.sig "A")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation92
theorem observation93 : derive (.primitive (.sig "A")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation93
theorem observation94 : derive (.primitive (.sig "A")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation94
theorem observation95 : "REJECTED" = "REJECTED" := by decide
#print axioms observation95
theorem observation96 : k11 = k11 /\ k12 = k12 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k7, k9, k10, k4, k6, k8] k47 = true := by decide
#print axioms observation96
theorem observation97 : k47 = k47 /\ k47 = k47 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine97 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k22, k27] k44 = some k47 := by decide
#print axioms observation97
theorem observation98 : k95 = k95 /\ k95 = k95 /\ "REJECTED" = "VERIFIED" := by decide

end ACGN.FourthFive.DependentChainWitnessReplay
