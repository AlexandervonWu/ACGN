import SemanticProfileWire
namespace ACGN.FourthFive.ProfileReplay
open ACGN.FourthFive.SemanticProfileWire
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem observation0 : encode (Profile.mk (ofCodepoints [48]) (ofCodepoints [70, 79, 82, 66, 73, 68]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110])) = (ofCodepoints [119, 114, 111, 110, 103]) ∧
    (ofCodepoints [119, 114, 111, 110, 103]) = (ofCodepoints [49, 54, 58, 115, 101, 109, 97, 110, 116, 105, 99, 45, 112, 114, 111, 102, 105, 108, 101, 91, 53, 58, 49, 58, 48, 54, 58, 70, 79, 82, 66, 73, 68, 53, 58, 112, 108, 97, 105, 110, 53, 58, 112, 108, 97, 105, 110, 53, 58, 112, 108, 97, 105, 110, 93, 123, 48, 58, 125]) ∧
    verifierEncoding [(ofCodepoints [48]), (ofCodepoints [70, 79, 82, 66, 73, 68]), (ofCodepoints [112, 108, 97, 105, 110]), (ofCodepoints [112, 108, 97, 105, 110]), (ofCodepoints [112, 108, 97, 105, 110])] = some (encode (Profile.mk (ofCodepoints [48]) (ofCodepoints [70, 79, 82, 66, 73, 68]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]))) ∧
    reconstruct [(ofCodepoints [48]), (ofCodepoints [70, 79, 82, 66, 73, 68]), (ofCodepoints [112, 108, 97, 105, 110]), (ofCodepoints [112, 108, 97, 105, 110]), (ofCodepoints [112, 108, 97, 105, 110])] = some (Profile.mk (ofCodepoints [48]) (ofCodepoints [70, 79, 82, 66, 73, 68]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110])) ∧
    (ofCodepoints [102, 50, 102, 50, 97, 99, 51, 100, 50, 53, 51, 54, 54, 101, 54, 56, 56, 50, 57, 48, 54, 102, 52, 100, 102, 52, 102, 55, 52, 100, 48, 56, 55, 100, 53, 97, 56, 49, 52, 53, 98, 99, 57, 55, 51, 100, 51, 53, 97, 49, 99, 49, 98, 99, 54, 52, 56, 53, 56, 51, 49, 56, 49, 48]) = (ofCodepoints [102, 50, 102, 50, 97, 99, 51, 100, 50, 53, 51, 54, 54, 101, 54, 56, 56, 50, 57, 48, 54, 102, 52, 100, 102, 52, 102, 55, 52, 100, 48, 56, 55, 100, 53, 97, 56, 49, 52, 53, 98, 99, 57, 55, 51, 100, 51, 53, 97, 49, 99, 49, 98, 99, 54, 52, 56, 53, 56, 51, 49, 56, 49, 48]) ∧
    (ofCodepoints [85, 78, 69, 88, 80, 79, 82, 84, 69, 68]) = (ofCodepoints [85, 78, 69, 88, 80, 79, 82, 84, 69, 68]) ∧
    (ofCodepoints []) = (ofCodepoints []) ∧
    exportAllowed .custom false = false := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · decide +kernel
  · first | rfl | decide +kernel
  · exact encoding_agreement (Profile.mk (ofCodepoints [48]) (ofCodepoints [70, 79, 82, 66, 73, 68]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]))
  · exact reconstruct_fields (Profile.mk (ofCodepoints [48]) (ofCodepoints [70, 79, 82, 66, 73, 68]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]) (ofCodepoints [112, 108, 97, 105, 110]))
  · first | rfl | decide +kernel
  · first | rfl | decide +kernel
  · first | rfl | decide +kernel
  · first | rfl | decide +kernel

end ACGN.FourthFive.ProfileReplay
