import DependentChainWitnesses
namespace ACGN.FourthFive.DependentChainWitnessReplay
open ACGN.FourthFive.DependentChainWitnesses
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000
def k0 : Key := .node "type/BOOL" [] []
def k1 : Key := .node "type/TYPE_VARIABLE" ["X"] []
def k2 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] []
def k3 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] [k1]
def k4 : Key := .node "type/CONSTRUCTOR" ["AlloySig:A"] []
def k5 : Key := .node "type/RELATION" [] [k4, k4]
def k6 : Key := .node "type/CONSTRUCTOR" ["AlloySig:B"] []
def k7 : Key := .node "type/RELATION" [] [k4, k6]
def k8 : Key := .node "type/CONSTRUCTOR" ["AlloySig:C"] []
def k9 : Key := .node "type/RELATION" [] [k4, k8]
def k10 : Key := .node "type/RELATION" [] [k6, k8]
def k11 : Key := .node "dependent-index-type-requirements" [] [k5, k7, k9, k10, k4, k6, k8]
def k12 : Key := .node "published-exact-types" [] [k5, k7, k9, k10, k4, k6, k8]
def k13 : Key := .node "direct-parent-path-v1" [] [k4]
def k14 : Key := .node "dependent-column-evidence-v1" [] [k4, k13]
def k15 : Key := .node "dependent-type-product-v1" [] [k14, k14]
def k16 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k15]
def k17 : Key := .node "dependent-type-dag-v1" ["2"] [k16, k5, k5]
def k18 : Key := .node "direct-parent-path-v1" [] [k6]
def k19 : Key := .node "dependent-column-evidence-v1" [] [k6, k18]
def k20 : Key := .node "dependent-type-product-v1" [] [k14, k19]
def k21 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k20]
def k22 : Key := .node "dependent-type-dag-v1" ["2"] [k21, k7, k7]
def k23 : Key := .node "direct-parent-path-v1" [] [k8]
def k24 : Key := .node "dependent-column-evidence-v1" [] [k8, k23]
def k25 : Key := .node "dependent-type-product-v1" [] [k19, k24]
def k26 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k25]
def k27 : Key := .node "dependent-type-dag-v1" ["2"] [k26, k10, k10]
def k28 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k22, k27]
def k29 : Key := .node "dependent-boundary-left-path-v1" [] [k4]
def k30 : Key := .node "dependent-boundary-right-path-v1" [] [k4]
def k31 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k4, k4, k4, k4, k29, k30]
def k32 : Key := .node "dependent-type-case-result-v1" [] [k14, k19]
def k33 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k32]
def k34 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k33]
def k35 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k22, k34, k22]
def k36 : Key := .node "dependent-boundary-left-path-v1" [] [k6]
def k37 : Key := .node "dependent-boundary-right-path-v1" [] [k6]
def k38 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k6, k6, k6, k6, k36, k37]
def k39 : Key := .node "dependent-type-case-result-v1" [] [k14, k24]
def k40 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k39]
def k41 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k40]
def k42 : Key := .node "dependent-type-product-v1" [] [k14, k24]
def k43 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k42]
def k44 : Key := .node "dependent-type-dag-v1" ["2"] [k43, k9, k9]
def k45 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k22, k27, k41, k44]
def k46 : Key := .node "dependent-chain-fold-steps-v1" [] [k35, k45]
def k47 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k28, k46, k44]
def combine97 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k48 : Key := .node "context" [] []
def k49 : Key := .node "certificate-sort" ["TERM"] [k9]
def k50 : Key := .node "semantic-profile" ["4", "FORBID", "alloy-temporal", "repaired-normal-form-v2", "alloy-signature-v2"] []
def k51 : Key := .node "schema/one" [] [k5]
def k52 : Key := .node "eclass" ["0"] [k5, k48]
def k53 : Key := .node "embedding" [] [k48, k48]
def k54 : Key := .node "invocation" [] [k52, k53]
def k55 : Key := .node "port-leaf/invocation" [] [k54]
def k56 : Key := .node "port/one" [] [k51, k48, k55]
def k57 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k5, k5]
def k58 : Key := .node "dependent-chain-leaf-v4" [] [k56, k57, k17]
def k59 : Key := .node "schema/one" [] [k7]
def k60 : Key := .node "eclass" ["1"] [k7, k48]
def k61 : Key := .node "invocation" [] [k60, k53]
def k62 : Key := .node "port-leaf/invocation" [] [k61]
def k63 : Key := .node "port/one" [] [k59, k48, k62]
def k64 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k7, k7]
def k65 : Key := .node "dependent-chain-leaf-v4" [] [k63, k64, k22]
def k66 : Key := .node "dependent-chain-combination-cases-v1" [] [k33]
def k67 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k7, k22, k58, k65, k66]
def k68 : Key := .node "schema/one" [] [k10]
def k69 : Key := .node "eclass" ["2"] [k10, k48]
def k70 : Key := .node "invocation" [] [k69, k53]
def k71 : Key := .node "port-leaf/invocation" [] [k70]
def k72 : Key := .node "port/one" [] [k68, k48, k71]
def k73 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k10, k10]
def k74 : Key := .node "dependent-chain-leaf-v4" [] [k72, k73, k27]
def k75 : Key := .node "dependent-chain-combination-cases-v1" [] [k40]
def k76 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k67, k74, k75]
def k77 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k76]
def k78 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:0:0"] []
def k79 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:0:0"] [k77, k78]
def k80 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k76, k79]
def k81 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k80]
def k82 : Key := .node "arity-policy" ["FINITE", "3"] []
def k83 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k59, k68]
def k84 : Key := .node "flat-license" ["none"] []
def k85 : Key := .node "container-laws" ["SEQ", "false", "false", "false", "ABSENT"] []
def k86 : Key := .node "port-law" ["0/0"] [k85]
def k87 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k83, k9, k84, k86]
def k88 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k87, k83, k9]
def k89 : Key := .node "port/seq" [] [k83, k48, k56, k63, k72]
def k90 : Key := .node "e-node" [] [k88, k48, k89]
def k91 : Key := .node "certificate-term/node" [] [k90]
def k92 : Key := .node "certificate-endpoint" ["NODE"] [k48, k49, k91]
def k93 : Key := .node "certificate-endpoint-type-check" [] [k48, k49]
def k94 : Key := .node "dependent-chain-theory" ["3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8"] []
def k95 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k81, k92, k93, k50, k94, k47, k76, k79, k90]
def combine962 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k96 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k65, k74, k75]
def k97 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k39]
def k98 : Key := .node "dependent-chain-combination-cases-v1" [] [k97]
def k99 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k58, k96, k98]
def k100 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k99]
def k101 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:0:1"] []
def k102 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:0:1"] [k100, k101]
def k103 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k99, k102]
def k104 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k103]
def k105 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k104, k92, k93, k50, k94, k47, k99, k102, k90]
def combine971 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k106 : Key := .node "semantic-profile" ["4", "MODULAR", "alloy-temporal", "repaired-normal-form-v2", "alloy-signature-v2"] []
def k107 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:1:0"] []
def k108 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:1:0"] [k77, k107]
def k109 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k76, k108]
def k110 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k109]
def k111 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k110, k92, k93, k106, k94, k47, k76, k108, k90]
def combine980 : Combine := fun l r => if l = k17 /\ r = k22 then some (k22, [k33]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k112 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:exact:1:1"] []
def k113 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:exact:1:1"] [k100, k112]
def k114 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k99, k113]
def k115 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k114]
def k116 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k115, k92, k93, k106, k94, k47, k99, k113, k90]
def k117 : Key := .node "type/RELATION" [] [k4]
def k118 : Key := .node "type/RELATION" [] [k6]
def k119 : Key := .node "type/RELATION" [] [k8]
def k120 : Key := .node "type/CONSTRUCTOR" ["AlloyCarrier"] [k4]
def k121 : Key := .node "dependent-index-type-requirements" [] [k117, k118, k119, k7, k10, k4, k6, k8]
def k122 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k10, k4, k6, k8, k120]
def k123 : Key := .node "dependent-type-product-v1" [] [k14]
def k124 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k123]
def k125 : Key := .node "dependent-type-dag-v1" ["1"] [k124, k117, k117]
def k126 : Key := .node "dependent-chain-operand-dags-v1" [] [k125, k22, k27]
def k127 : Key := .node "dependent-type-case-result-v1" [] [k19]
def k128 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k127]
def k129 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k128]
def k130 : Key := .node "dependent-type-product-v1" [] [k19]
def k131 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k130]
def k132 : Key := .node "dependent-type-dag-v1" ["1"] [k131, k118, k118]
def k133 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k125, k22, k129, k132]
def k134 : Key := .node "dependent-type-case-result-v1" [] [k24]
def k135 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k134]
def k136 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k135]
def k137 : Key := .node "dependent-type-product-v1" [] [k24]
def k138 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k137]
def k139 : Key := .node "dependent-type-dag-v1" ["1"] [k138, k119, k119]
def k140 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k132, k27, k136, k139]
def k141 : Key := .node "dependent-chain-fold-steps-v1" [] [k133, k140]
def k142 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k126, k141, k139]
def combine989 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k143 : Key := .node "certificate-sort" ["TERM"] [k119]
def k144 : Key := .node "schema/one" [] [k120]
def k145 : Key := .node "eclass" ["0"] [k120, k48]
def k146 : Key := .node "invocation" [] [k145, k53]
def k147 : Key := .node "port-leaf/invocation" [] [k146]
def k148 : Key := .node "port/one" [] [k144, k48, k147]
def k149 : Key := .node "dependent-chain-leaf-type-proof-v1" ["PRIMITIVE_SET_SINGLETON"] [k120, k117]
def k150 : Key := .node "dependent-chain-leaf-v4" [] [k148, k149, k125]
def k151 : Key := .node "dependent-chain-combination-cases-v1" [] [k128]
def k152 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k118, k132, k150, k65, k151]
def k153 : Key := .node "dependent-chain-combination-cases-v1" [] [k135]
def k154 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k152, k74, k153]
def k155 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k154]
def k156 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:0:0"] []
def k157 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:0:0"] [k155, k156]
def k158 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k154, k157]
def k159 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k158]
def k160 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k144, k59, k68]
def k161 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k160, k119, k84, k86]
def k162 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k161, k160, k119]
def k163 : Key := .node "port/seq" [] [k160, k48, k148, k63, k72]
def k164 : Key := .node "e-node" [] [k162, k48, k163]
def k165 : Key := .node "certificate-term/node" [] [k164]
def k166 : Key := .node "certificate-endpoint" ["NODE"] [k48, k143, k165]
def k167 : Key := .node "certificate-endpoint-type-check" [] [k48, k143]
def k168 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k159, k166, k167, k50, k94, k142, k154, k157, k164]
def k169 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k9, k10, k4, k6, k8, k120]
def combine1698 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k170 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k134]
def k171 : Key := .node "dependent-chain-combination-cases-v1" [] [k170]
def k172 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k150, k96, k171]
def k173 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k172]
def k174 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:0:1"] []
def k175 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:0:1"] [k173, k174]
def k176 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k172, k175]
def k177 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k176]
def k178 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k177, k166, k167, k50, k94, k142, k172, k175, k164]
def combine1708 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k179 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:1:0"] []
def k180 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:1:0"] [k155, k179]
def k181 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k154, k180]
def k182 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k181]
def k183 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k182, k166, k167, k106, k94, k142, k154, k180, k164]
def combine1717 : Combine := fun l r => if l = k125 /\ r = k22 then some (k132, [k128]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k184 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:primitive:1:1"] []
def k185 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:primitive:1:1"] [k173, k184]
def k186 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k172, k185]
def k187 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k186]
def k188 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k187, k166, k167, k106, k94, k142, k172, k185, k164]
def k189 : Key := .node "type/INT" [] []
def k190 : Key := .node "type/RELATION" [] [k189]
def k191 : Key := .node "type/RELATION" [] [k189, k6]
def k192 : Key := .node "dependent-index-type-requirements" [] [k190, k118, k119, k191, k10, k6, k8, k189]
def k193 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k10, k6, k8, k189]
def k194 : Key := .node "direct-parent-path-v1" [] [k189]
def k195 : Key := .node "dependent-column-evidence-v1" [] [k189, k194]
def k196 : Key := .node "dependent-type-product-v1" [] [k195]
def k197 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k196]
def k198 : Key := .node "dependent-type-dag-v1" ["1"] [k197, k190, k190]
def k199 : Key := .node "dependent-type-product-v1" [] [k195, k19]
def k200 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k199]
def k201 : Key := .node "dependent-type-dag-v1" ["2"] [k200, k191, k191]
def k202 : Key := .node "dependent-chain-operand-dags-v1" [] [k198, k201, k27]
def k203 : Key := .node "dependent-boundary-left-path-v1" [] [k189]
def k204 : Key := .node "dependent-boundary-right-path-v1" [] [k189]
def k205 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k189, k189, k189, k189, k203, k204]
def k206 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k205, k127]
def k207 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k206]
def k208 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k198, k201, k207, k132]
def k209 : Key := .node "dependent-chain-fold-steps-v1" [] [k208, k140]
def k210 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k202, k209, k139]
def combine1726 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k211 : Key := .node "schema/one" [] [k189]
def k212 : Key := .node "eclass" ["0"] [k189, k48]
def k213 : Key := .node "invocation" [] [k212, k53]
def k214 : Key := .node "port-leaf/invocation" [] [k213]
def k215 : Key := .node "port/one" [] [k211, k48, k214]
def k216 : Key := .node "dependent-chain-leaf-type-proof-v1" ["PRIMITIVE_SET_SINGLETON"] [k189, k190]
def k217 : Key := .node "dependent-chain-leaf-v4" [] [k215, k216, k198]
def k218 : Key := .node "schema/one" [] [k191]
def k219 : Key := .node "eclass" ["1"] [k191, k48]
def k220 : Key := .node "invocation" [] [k219, k53]
def k221 : Key := .node "port-leaf/invocation" [] [k220]
def k222 : Key := .node "port/one" [] [k218, k48, k221]
def k223 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k191, k191]
def k224 : Key := .node "dependent-chain-leaf-v4" [] [k222, k223, k201]
def k225 : Key := .node "dependent-chain-combination-cases-v1" [] [k206]
def k226 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k118, k132, k217, k224, k225]
def k227 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k226, k74, k153]
def k228 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k227]
def k229 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:0:0"] []
def k230 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:0:0"] [k228, k229]
def k231 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k227, k230]
def k232 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k231]
def k233 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k211, k218, k68]
def k234 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k233, k119, k84, k86]
def k235 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k234, k233, k119]
def k236 : Key := .node "port/seq" [] [k233, k48, k215, k222, k72]
def k237 : Key := .node "e-node" [] [k235, k48, k236]
def k238 : Key := .node "certificate-term/node" [] [k237]
def k239 : Key := .node "certificate-endpoint" ["NODE"] [k48, k143, k238]
def k240 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k232, k239, k167, k50, k94, k210, k227, k230, k237]
def k241 : Key := .node "type/RELATION" [] [k189, k8]
def k242 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k241, k10, k6, k8, k189]
def combine2406 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k243 : Key := .node "dependent-type-product-v1" [] [k195, k24]
def k244 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k243]
def k245 : Key := .node "dependent-type-dag-v1" ["2"] [k244, k241, k241]
def k246 : Key := .node "dependent-type-case-result-v1" [] [k195, k24]
def k247 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k246]
def k248 : Key := .node "dependent-chain-combination-cases-v1" [] [k247]
def k249 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k241, k245, k224, k74, k248]
def k250 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k205, k134]
def k251 : Key := .node "dependent-chain-combination-cases-v1" [] [k250]
def k252 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k119, k139, k217, k249, k251]
def k253 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k252]
def k254 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:0:1"] []
def k255 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:0:1"] [k253, k254]
def k256 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k252, k255]
def k257 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k256]
def k258 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k257, k239, k167, k50, k94, k210, k252, k255, k237]
def combine2415 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k259 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:1:0"] []
def k260 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:1:0"] [k228, k259]
def k261 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k227, k260]
def k262 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k261]
def k263 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k262, k239, k167, k106, k94, k210, k227, k260, k237]
def combine2424 : Combine := fun l r => if l = k198 /\ r = k201 then some (k132, [k206]) else (if l = k132 /\ r = k27 then some (k139, [k135]) else (none))
def k264 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:int:1:1"] []
def k265 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:int:1:1"] [k253, k264]
def k266 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k252, k265]
def k267 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k143, k266]
def k268 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k267, k239, k167, k106, k94, k210, k252, k265, k237]
def k269 : Key := .node "type/CONSTRUCTOR" ["AlloySig:univ"] []
def k270 : Key := .node "type/RELATION" [] [k4, k269]
def k271 : Key := .node "type/RELATION" [] [k269, k6]
def k272 : Key := .node "dependent-index-type-requirements" [] [k7, k9, k270, k10, k271, k4, k6, k8, k269]
def k273 : Key := .node "published-exact-types" [] [k7, k9, k270, k10, k271, k4, k6, k8, k269]
def k274 : Key := .node "direct-parent-path-v1" [] [k269]
def k275 : Key := .node "dependent-column-evidence-v1" [] [k269, k274]
def k276 : Key := .node "dependent-type-product-v1" [] [k14, k275]
def k277 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k276]
def k278 : Key := .node "dependent-type-dag-v1" ["2"] [k277, k270, k270]
def k279 : Key := .node "dependent-type-product-v1" [] [k275, k19]
def k280 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k279]
def k281 : Key := .node "dependent-type-dag-v1" ["2"] [k280, k271, k271]
def k282 : Key := .node "dependent-chain-operand-dags-v1" [] [k278, k281, k27]
def k283 : Key := .node "dependent-boundary-left-path-v1" [] [k269]
def k284 : Key := .node "dependent-boundary-right-path-v1" [] [k269]
def k285 : Key := .node "dependent-boundary-correspondence-v2" ["EXACT"] [k269, k269, k269, k269, k283, k284]
def k286 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k285, k32]
def k287 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k286]
def k288 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k278, k281, k287, k22]
def k289 : Key := .node "dependent-chain-fold-steps-v1" [] [k288, k45]
def k290 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k282, k289, k44]
def combine2433 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k291 : Key := .node "schema/one" [] [k270]
def k292 : Key := .node "eclass" ["0"] [k270, k48]
def k293 : Key := .node "invocation" [] [k292, k53]
def k294 : Key := .node "port-leaf/invocation" [] [k293]
def k295 : Key := .node "port/one" [] [k291, k48, k294]
def k296 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k270, k270]
def k297 : Key := .node "dependent-chain-leaf-v4" [] [k295, k296, k278]
def k298 : Key := .node "schema/one" [] [k271]
def k299 : Key := .node "eclass" ["1"] [k271, k48]
def k300 : Key := .node "invocation" [] [k299, k53]
def k301 : Key := .node "port-leaf/invocation" [] [k300]
def k302 : Key := .node "port/one" [] [k298, k48, k301]
def k303 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k271, k271]
def k304 : Key := .node "dependent-chain-leaf-v4" [] [k302, k303, k281]
def k305 : Key := .node "dependent-chain-combination-cases-v1" [] [k286]
def k306 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k7, k22, k297, k304, k305]
def k307 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k306, k74, k75]
def k308 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k307]
def k309 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:0:0"] []
def k310 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:0:0"] [k308, k309]
def k311 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k307, k310]
def k312 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k311]
def k313 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k291, k298, k68]
def k314 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k313, k9, k84, k86]
def k315 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k314, k313, k9]
def k316 : Key := .node "port/seq" [] [k313, k48, k295, k302, k72]
def k317 : Key := .node "e-node" [] [k315, k48, k316]
def k318 : Key := .node "certificate-term/node" [] [k317]
def k319 : Key := .node "certificate-endpoint" ["NODE"] [k48, k49, k318]
def k320 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k312, k319, k93, k50, k94, k290, k307, k310, k317]
def k321 : Key := .node "type/RELATION" [] [k269, k8]
def k322 : Key := .node "published-exact-types" [] [k7, k9, k270, k10, k271, k321, k4, k6, k8, k269]
def combine3308 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k323 : Key := .node "dependent-type-product-v1" [] [k275, k24]
def k324 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k323]
def k325 : Key := .node "dependent-type-dag-v1" ["2"] [k324, k321, k321]
def k326 : Key := .node "dependent-type-case-result-v1" [] [k275, k24]
def k327 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k38, k326]
def k328 : Key := .node "dependent-chain-combination-cases-v1" [] [k327]
def k329 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k321, k325, k304, k74, k328]
def k330 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k285, k39]
def k331 : Key := .node "dependent-chain-combination-cases-v1" [] [k330]
def k332 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k9, k44, k297, k329, k331]
def k333 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k332]
def k334 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:0:1"] []
def k335 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:0:1"] [k333, k334]
def k336 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k332, k335]
def k337 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k336]
def k338 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k337, k319, k93, k50, k94, k290, k332, k335, k317]
def combine3317 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k339 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:1:0"] []
def k340 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:1:0"] [k308, k339]
def k341 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k307, k340]
def k342 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k341]
def k343 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k342, k319, k93, k106, k94, k290, k307, k340, k317]
def combine3326 : Combine := fun l r => if l = k278 /\ r = k281 then some (k22, [k286]) else (if l = k22 /\ r = k27 then some (k44, [k40]) else (none))
def k344 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:univ:1:1"] []
def k345 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:univ:1:1"] [k333, k344]
def k346 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k332, k345]
def k347 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k49, k346]
def k348 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k347, k319, k93, k106, k94, k290, k332, k345, k317]
def k349 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=2"] []
def k350 : Key := .node "dependent-index-type-requirements" [] [k5, k10, k4, k6, k8, k349]
def k351 : Key := .node "published-exact-types" [] [k5, k10, k4, k6, k8, k349]
def k352 : Key := .node "dependent-type-correlated-alternatives-v1" [] []
def k353 : Key := .node "dependent-type-no-common-ancestor-v1" ["none"] []
def k354 : Key := .node "dependent-type-dag-v1" ["2"] [k352, k349, k353]
def k355 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k354, k27]
def k356 : Key := .node "dependent-chain-complete-case-matrix-v1" [] []
def k357 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k354, k356, k354]
def k358 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k354, k27, k356, k354]
def k359 : Key := .node "dependent-chain-fold-steps-v1" [] [k357, k358]
def k360 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k355, k359, k354]
def combine3335 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k361 : Key := .node "certificate-sort" ["TERM"] [k349]
def k362 : Key := .node "schema/one" [] [k349]
def k363 : Key := .node "eclass" ["1"] [k349, k48]
def k364 : Key := .node "invocation" [] [k363, k53]
def k365 : Key := .node "port-leaf/invocation" [] [k364]
def k366 : Key := .node "port/one" [] [k362, k48, k365]
def k367 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k349, k349]
def k368 : Key := .node "dependent-chain-leaf-v4" [] [k366, k367, k354]
def k369 : Key := .node "dependent-chain-combination-cases-v1" [] []
def k370 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k58, k368, k369]
def k371 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k370, k74, k369]
def k372 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k371]
def k373 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:0:0"] []
def k374 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:0:0"] [k372, k373]
def k375 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k371, k374]
def k376 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k375]
def k377 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k362, k68]
def k378 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k377, k349, k84, k86]
def k379 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k378, k377, k349]
def k380 : Key := .node "port/seq" [] [k377, k48, k56, k366, k72]
def k381 : Key := .node "e-node" [] [k379, k48, k380]
def k382 : Key := .node "certificate-term/node" [] [k381]
def k383 : Key := .node "certificate-endpoint" ["NODE"] [k48, k361, k382]
def k384 : Key := .node "certificate-endpoint-type-check" [] [k48, k361]
def k385 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k376, k383, k384, k50, k94, k360, k371, k374, k381]
def combine3786 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k386 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k368, k74, k369]
def k387 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k349, k354, k58, k386, k369]
def k388 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k387]
def k389 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:0:1"] []
def k390 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:0:1"] [k388, k389]
def k391 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k387, k390]
def k392 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k391]
def k393 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k392, k383, k384, k50, k94, k360, k387, k390, k381]
def combine3795 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k394 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:1:0"] []
def k395 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:1:0"] [k372, k394]
def k396 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k371, k395]
def k397 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k396]
def k398 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k397, k383, k384, k106, k94, k360, k371, k395, k381]
def combine3804 : Combine := fun l r => if l = k17 /\ r = k354 then some (k354, []) else (if l = k354 /\ r = k27 then some (k354, []) else (none))
def k399 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:empty:1:1"] []
def k400 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:empty:1:1"] [k388, k399]
def k401 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k387, k400]
def k402 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k361, k401]
def k403 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k402, k383, k384, k106, k94, k360, k387, k400, k381]
def k404 : Key := .node "dependent-index-type-requirements" [] [k5, k4]
def k405 : Key := .node "published-exact-types" [] [k5, k4]
def k406 : Key := .node "dependent-chain-operand-dags-v1" [] [k17, k17, k17]
def k407 : Key := .node "dependent-type-case-result-v1" [] [k14, k14]
def k408 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "JOIN_OVERLAP"] [k31, k407]
def k409 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k408]
def k410 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k17, k17, k409, k17]
def k411 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k17, k17, k409, k17]
def k412 : Key := .node "dependent-chain-fold-steps-v1" [] [k410, k411]
def k413 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "JOIN"] [k406, k412, k17]
def combine3813 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k414 : Key := .node "certificate-sort" ["TERM"] [k5]
def k415 : Key := .node "dependent-chain-combination-cases-v1" [] [k408]
def k416 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k58, k58, k415]
def k417 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k416, k58, k415]
def k418 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k417]
def k419 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:0:0"] []
def k420 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:0:0"] [k418, k419]
def k421 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k417, k420]
def k422 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k421]
def k423 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k51, k51, k51]
def k424 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/JOIN", "nonflat"] [k423, k5, k84, k86]
def k425 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/JOIN"] [k424, k423, k5]
def k426 : Key := .node "port/seq" [] [k423, k48, k56, k56, k56]
def k427 : Key := .node "e-node" [] [k425, k48, k426]
def k428 : Key := .node "certificate-term/node" [] [k427]
def k429 : Key := .node "certificate-endpoint" ["NODE"] [k48, k414, k428]
def k430 : Key := .node "certificate-endpoint-type-check" [] [k48, k414]
def k431 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k422, k429, k430, k50, k94, k413, k417, k420, k427]
def combine4639 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k432 : Key := .node "dependent-chain-application-v3" ["JOIN"] [k48, k5, k17, k58, k416, k415]
def k433 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k432]
def k434 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:0:1"] []
def k435 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:0:1"] [k433, k434]
def k436 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k432, k435]
def k437 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k436]
def k438 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k437, k429, k430, k50, k94, k413, k432, k435, k427]
def combine4648 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k439 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:1:0"] []
def k440 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:1:0"] [k418, k439]
def k441 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k417, k440]
def k442 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k441]
def k443 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k442, k429, k430, k106, k94, k413, k417, k440, k427]
def combine4657 : Combine := fun l r => if l = k17 /\ r = k17 then some (k17, [k408]) else (if l = k17 /\ r = k17 then some (k17, [k408]) else (none))
def k444 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:JOIN:repeat:1:1"] []
def k445 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/JOIN:repeat:1:1"] [k433, k444]
def k446 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k432, k445]
def k447 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k414, k446]
def k448 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k447, k429, k430, k106, k94, k413, k432, k445, k427]
def k449 : Key := .node "type/RELATION" [] [k4, k6, k8]
def k450 : Key := .node "dependent-index-type-requirements" [] [k117, k118, k119, k7, k449, k4, k6, k8]
def k451 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k449, k4, k6, k8]
def k452 : Key := .node "dependent-chain-operand-dags-v1" [] [k125, k132, k139]
def k453 : Key := .node "dependent-type-no-boundary-v1" ["arrow"] []
def k454 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k32]
def k455 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k454]
def k456 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k125, k132, k455, k22]
def k457 : Key := .node "dependent-type-case-result-v1" [] [k14, k19, k24]
def k458 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k457]
def k459 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k458]
def k460 : Key := .node "dependent-type-product-v1" [] [k14, k19, k24]
def k461 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k460]
def k462 : Key := .node "dependent-type-dag-v1" ["3"] [k461, k449, k449]
def k463 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k22, k139, k459, k462]
def k464 : Key := .node "dependent-chain-fold-steps-v1" [] [k456, k463]
def k465 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k452, k464, k462]
def combine4666 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k466 : Key := .node "certificate-sort" ["TERM"] [k449]
def k467 : Key := .node "schema/one" [] [k117]
def k468 : Key := .node "eclass" ["0"] [k117, k48]
def k469 : Key := .node "invocation" [] [k468, k53]
def k470 : Key := .node "port-leaf/invocation" [] [k469]
def k471 : Key := .node "port/one" [] [k467, k48, k470]
def k472 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k117, k117]
def k473 : Key := .node "dependent-chain-leaf-v4" [] [k471, k472, k125]
def k474 : Key := .node "schema/one" [] [k118]
def k475 : Key := .node "eclass" ["1"] [k118, k48]
def k476 : Key := .node "invocation" [] [k475, k53]
def k477 : Key := .node "port-leaf/invocation" [] [k476]
def k478 : Key := .node "port/one" [] [k474, k48, k477]
def k479 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k118, k118]
def k480 : Key := .node "dependent-chain-leaf-v4" [] [k478, k479, k132]
def k481 : Key := .node "dependent-chain-combination-cases-v1" [] [k454]
def k482 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k7, k22, k473, k480, k481]
def k483 : Key := .node "schema/one" [] [k119]
def k484 : Key := .node "eclass" ["2"] [k119, k48]
def k485 : Key := .node "invocation" [] [k484, k53]
def k486 : Key := .node "port-leaf/invocation" [] [k485]
def k487 : Key := .node "port/one" [] [k483, k48, k486]
def k488 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k119, k119]
def k489 : Key := .node "dependent-chain-leaf-v4" [] [k487, k488, k139]
def k490 : Key := .node "dependent-chain-combination-cases-v1" [] [k458]
def k491 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k482, k489, k490]
def k492 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k491]
def k493 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:0:0"] []
def k494 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:0:0"] [k492, k493]
def k495 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k491, k494]
def k496 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k495]
def k497 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k467, k474, k483]
def k498 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k497, k449, k84, k86]
def k499 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k498, k497, k449]
def k500 : Key := .node "port/seq" [] [k497, k48, k471, k478, k487]
def k501 : Key := .node "e-node" [] [k499, k48, k500]
def k502 : Key := .node "certificate-term/node" [] [k501]
def k503 : Key := .node "certificate-endpoint" ["NODE"] [k48, k466, k502]
def k504 : Key := .node "certificate-endpoint-type-check" [] [k48, k466]
def k505 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k496, k503, k504, k50, k94, k465, k491, k494, k501]
def k506 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k10, k449, k4, k6, k8]
def combine5383 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k507 : Key := .node "dependent-type-case-result-v1" [] [k19, k24]
def k508 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k507]
def k509 : Key := .node "dependent-chain-combination-cases-v1" [] [k508]
def k510 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k10, k27, k480, k489, k509]
def k511 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k473, k510, k490]
def k512 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k511]
def k513 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:0:1"] []
def k514 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:0:1"] [k512, k513]
def k515 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k511, k514]
def k516 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k515]
def k517 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k516, k503, k504, k50, k94, k465, k511, k514, k501]
def combine5392 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k518 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:1:0"] []
def k519 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:1:0"] [k492, k518]
def k520 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k491, k519]
def k521 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k520]
def k522 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k521, k503, k504, k106, k94, k465, k491, k519, k501]
def combine5401 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k523 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:exact:1:1"] []
def k524 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:exact:1:1"] [k512, k523]
def k525 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k511, k524]
def k526 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k525]
def k527 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k526, k503, k504, k106, k94, k465, k511, k524, k501]
def k528 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k449, k4, k6, k8, k120]
def combine5410 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k529 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k7, k22, k150, k480, k481]
def k530 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k529, k489, k490]
def k531 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k530]
def k532 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:0:0"] []
def k533 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:0:0"] [k531, k532]
def k534 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k530, k533]
def k535 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k534]
def k536 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k144, k474, k483]
def k537 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k536, k449, k84, k86]
def k538 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k537, k536, k449]
def k539 : Key := .node "port/seq" [] [k536, k48, k148, k478, k487]
def k540 : Key := .node "e-node" [] [k538, k48, k539]
def k541 : Key := .node "certificate-term/node" [] [k540]
def k542 : Key := .node "certificate-endpoint" ["NODE"] [k48, k466, k541]
def k543 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k535, k542, k504, k50, k94, k465, k530, k533, k540]
def k544 : Key := .node "published-exact-types" [] [k117, k118, k119, k7, k10, k449, k4, k6, k8, k120]
def combine6129 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k545 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k449, k462, k150, k510, k490]
def k546 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k545]
def k547 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:0:1"] []
def k548 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:0:1"] [k546, k547]
def k549 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k545, k548]
def k550 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k549]
def k551 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k550, k542, k504, k50, k94, k465, k545, k548, k540]
def combine6138 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k552 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:1:0"] []
def k553 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:1:0"] [k531, k552]
def k554 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k530, k553]
def k555 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k554]
def k556 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k555, k542, k504, k106, k94, k465, k530, k553, k540]
def combine6147 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k557 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:primitive:1:1"] []
def k558 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:primitive:1:1"] [k546, k557]
def k559 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k545, k558]
def k560 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k559]
def k561 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k560, k542, k504, k106, k94, k465, k545, k558, k540]
def k562 : Key := .node "type/RELATION" [] [k189, k6, k8]
def k563 : Key := .node "dependent-index-type-requirements" [] [k190, k118, k119, k191, k562, k6, k8, k189]
def k564 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k562, k6, k8, k189]
def k565 : Key := .node "dependent-chain-operand-dags-v1" [] [k198, k132, k139]
def k566 : Key := .node "dependent-type-case-result-v1" [] [k195, k19]
def k567 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k566]
def k568 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k567]
def k569 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k198, k132, k568, k201]
def k570 : Key := .node "dependent-type-case-result-v1" [] [k195, k19, k24]
def k571 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k570]
def k572 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k571]
def k573 : Key := .node "dependent-type-product-v1" [] [k195, k19, k24]
def k574 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k573]
def k575 : Key := .node "dependent-type-dag-v1" ["3"] [k574, k562, k562]
def k576 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k201, k139, k572, k575]
def k577 : Key := .node "dependent-chain-fold-steps-v1" [] [k569, k576]
def k578 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k565, k577, k575]
def combine6156 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k579 : Key := .node "certificate-sort" ["TERM"] [k562]
def k580 : Key := .node "dependent-chain-combination-cases-v1" [] [k567]
def k581 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k191, k201, k217, k480, k580]
def k582 : Key := .node "dependent-chain-combination-cases-v1" [] [k571]
def k583 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k562, k575, k581, k489, k582]
def k584 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k583]
def k585 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:0:0"] []
def k586 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:0:0"] [k584, k585]
def k587 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k583, k586]
def k588 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k587]
def k589 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k211, k474, k483]
def k590 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k589, k562, k84, k86]
def k591 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k590, k589, k562]
def k592 : Key := .node "port/seq" [] [k589, k48, k215, k478, k487]
def k593 : Key := .node "e-node" [] [k591, k48, k592]
def k594 : Key := .node "certificate-term/node" [] [k593]
def k595 : Key := .node "certificate-endpoint" ["NODE"] [k48, k579, k594]
def k596 : Key := .node "certificate-endpoint-type-check" [] [k48, k579]
def k597 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k588, k595, k596, k50, k94, k578, k583, k586, k593]
def k598 : Key := .node "published-exact-types" [] [k190, k118, k119, k191, k10, k562, k6, k8, k189]
def combine6842 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k599 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k562, k575, k217, k510, k582]
def k600 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k599]
def k601 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:0:1"] []
def k602 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:0:1"] [k600, k601]
def k603 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k599, k602]
def k604 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k603]
def k605 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k604, k595, k596, k50, k94, k578, k599, k602, k593]
def combine6851 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k606 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:1:0"] []
def k607 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:1:0"] [k584, k606]
def k608 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k583, k607]
def k609 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k608]
def k610 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k609, k595, k596, k106, k94, k578, k583, k607, k593]
def combine6860 : Combine := fun l r => if l = k198 /\ r = k132 then some (k201, [k567]) else (if l = k201 /\ r = k139 then some (k575, [k571]) else (none))
def k611 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:int:1:1"] []
def k612 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:int:1:1"] [k600, k611]
def k613 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k599, k612]
def k614 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k579, k613]
def k615 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k614, k595, k596, k106, k94, k578, k599, k612, k593]
def k616 : Key := .node "type/RELATION" [] [k269]
def k617 : Key := .node "type/RELATION" [] [k269, k6, k8]
def k618 : Key := .node "dependent-index-type-requirements" [] [k118, k119, k616, k271, k617, k6, k8, k269]
def k619 : Key := .node "published-exact-types" [] [k118, k119, k616, k271, k617, k6, k8, k269]
def k620 : Key := .node "dependent-type-product-v1" [] [k275]
def k621 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k620]
def k622 : Key := .node "dependent-type-dag-v1" ["1"] [k621, k616, k616]
def k623 : Key := .node "dependent-chain-operand-dags-v1" [] [k622, k132, k139]
def k624 : Key := .node "dependent-type-case-result-v1" [] [k275, k19]
def k625 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k624]
def k626 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k625]
def k627 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k622, k132, k626, k281]
def k628 : Key := .node "dependent-type-case-result-v1" [] [k275, k19, k24]
def k629 : Key := .node "dependent-type-combination-case-v1" ["0", "0", "ARROW_PRODUCT"] [k453, k628]
def k630 : Key := .node "dependent-chain-complete-case-matrix-v1" [] [k629]
def k631 : Key := .node "dependent-type-product-v1" [] [k275, k19, k24]
def k632 : Key := .node "dependent-type-correlated-alternatives-v1" [] [k631]
def k633 : Key := .node "dependent-type-dag-v1" ["3"] [k632, k617, k617]
def k634 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k281, k139, k630, k633]
def k635 : Key := .node "dependent-chain-fold-steps-v1" [] [k627, k634]
def k636 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k623, k635, k633]
def combine6869 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k637 : Key := .node "certificate-sort" ["TERM"] [k617]
def k638 : Key := .node "schema/one" [] [k616]
def k639 : Key := .node "eclass" ["0"] [k616, k48]
def k640 : Key := .node "invocation" [] [k639, k53]
def k641 : Key := .node "port-leaf/invocation" [] [k640]
def k642 : Key := .node "port/one" [] [k638, k48, k641]
def k643 : Key := .node "dependent-chain-leaf-type-proof-v1" ["EXACT_RELATION"] [k616, k616]
def k644 : Key := .node "dependent-chain-leaf-v4" [] [k642, k643, k622]
def k645 : Key := .node "dependent-chain-combination-cases-v1" [] [k625]
def k646 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k271, k281, k644, k480, k645]
def k647 : Key := .node "dependent-chain-combination-cases-v1" [] [k629]
def k648 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k617, k633, k646, k489, k647]
def k649 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k648]
def k650 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:0:0"] []
def k651 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:0:0"] [k649, k650]
def k652 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k648, k651]
def k653 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k652]
def k654 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k638, k474, k483]
def k655 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k654, k617, k84, k86]
def k656 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k655, k654, k617]
def k657 : Key := .node "port/seq" [] [k654, k48, k642, k478, k487]
def k658 : Key := .node "e-node" [] [k656, k48, k657]
def k659 : Key := .node "certificate-term/node" [] [k658]
def k660 : Key := .node "certificate-endpoint" ["NODE"] [k48, k637, k659]
def k661 : Key := .node "certificate-endpoint-type-check" [] [k48, k637]
def k662 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k653, k660, k661, k50, k94, k636, k648, k651, k658]
def k663 : Key := .node "published-exact-types" [] [k118, k119, k616, k10, k271, k617, k6, k8, k269]
def combine7586 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k664 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k617, k633, k644, k510, k647]
def k665 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k664]
def k666 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:0:1"] []
def k667 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:0:1"] [k665, k666]
def k668 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k664, k667]
def k669 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k668]
def k670 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k669, k660, k661, k50, k94, k636, k664, k667, k658]
def combine7595 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k671 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:1:0"] []
def k672 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:1:0"] [k649, k671]
def k673 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k648, k672]
def k674 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k673]
def k675 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k674, k660, k661, k106, k94, k636, k648, k672, k658]
def combine7604 : Combine := fun l r => if l = k622 /\ r = k132 then some (k281, [k625]) else (if l = k281 /\ r = k139 then some (k633, [k629]) else (none))
def k676 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:univ:1:1"] []
def k677 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:univ:1:1"] [k665, k676]
def k678 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k664, k677]
def k679 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k637, k678]
def k680 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k679, k660, k661, k106, k94, k636, k664, k677, k658]
def k681 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=3"] []
def k682 : Key := .node "type/CONSTRUCTOR" ["AlloyEmptyRelation$arity=4"] []
def k683 : Key := .node "dependent-index-type-requirements" [] [k117, k119, k4, k8, k349, k681, k682]
def k684 : Key := .node "published-exact-types" [] [k117, k119, k4, k8, k349, k681, k682]
def k685 : Key := .node "dependent-chain-operand-dags-v1" [] [k125, k354, k139]
def k686 : Key := .node "dependent-type-dag-v1" ["3"] [k352, k681, k353]
def k687 : Key := .node "dependent-chain-fold-step-v1" ["1"] [k125, k354, k356, k686]
def k688 : Key := .node "dependent-type-dag-v1" ["4"] [k352, k682, k353]
def k689 : Key := .node "dependent-chain-fold-step-v1" ["2"] [k686, k139, k356, k688]
def k690 : Key := .node "dependent-chain-fold-steps-v1" [] [k687, k689]
def k691 : Key := .node "dependent-chain-theory-index-v3" ["alloy-dependent-chain-theory-v11", "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8", "ARROW"] [k685, k690, k688]
def combine7613 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k692 : Key := .node "certificate-sort" ["TERM"] [k682]
def k693 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k681, k686, k473, k368, k369]
def k694 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k682, k688, k693, k489, k369]
def k695 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k694]
def k696 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:0:0"] []
def k697 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:0:0"] [k695, k696]
def k698 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k694, k697]
def k699 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k698]
def k700 : Key := .node "schema/dependent-seq" ["ORDERED_SEQUENCE"] [k82, k467, k362, k483]
def k701 : Key := .node "operator-declaration" ["ALLOY/DEPENDENT-CHAIN/ARROW", "nonflat"] [k700, k682, k84, k86]
def k702 : Key := .node "instantiated-operator" ["ALLOY/DEPENDENT-CHAIN/ARROW"] [k701, k700, k682]
def k703 : Key := .node "port/seq" [] [k700, k48, k471, k366, k487]
def k704 : Key := .node "e-node" [] [k702, k48, k703]
def k705 : Key := .node "certificate-term/node" [] [k704]
def k706 : Key := .node "certificate-endpoint" ["NODE"] [k48, k692, k705]
def k707 : Key := .node "certificate-endpoint-type-check" [] [k48, k692]
def k708 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k699, k706, k707, k50, k94, k691, k694, k697, k704]
def combine7971 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k709 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k681, k686, k368, k489, k369]
def k710 : Key := .node "dependent-chain-application-v3" ["ARROW"] [k48, k682, k688, k473, k709, k369]
def k711 : Key := .node "alloy-dependent-chain-typed-source-v1" [] [k710]
def k712 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:0:1"] []
def k713 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:0:1"] [k711, k712]
def k714 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k710, k713]
def k715 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k714]
def k716 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k715, k706, k707, k50, k94, k691, k710, k713, k704]
def combine7980 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k717 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:1:0"] []
def k718 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:1:0"] [k695, k717]
def k719 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k694, k718]
def k720 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k719]
def k721 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k720, k706, k707, k106, k94, k691, k694, k718, k704]
def combine7989 : Combine := fun l r => if l = k125 /\ r = k354 then some (k686, []) else (if l = k686 /\ r = k139 then some (k688, []) else (none))
def k722 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:empty:1:1"] []
def k723 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:empty:1:1"] [k711, k722]
def k724 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k710, k723]
def k725 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k692, k724]
def k726 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k725, k706, k707, k106, k94, k691, k710, k723, k704]
def combine7998 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k727 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:0:0"] []
def k728 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:0:0"] [k492, k727]
def k729 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k491, k728]
def k730 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k729]
def k731 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k730, k503, k504, k50, k94, k465, k491, k728, k501]
def combine8715 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k732 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:0:1"] []
def k733 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:0:1"] [k512, k732]
def k734 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k50, k511, k733]
def k735 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k734]
def k736 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k735, k503, k504, k50, k94, k465, k511, k733, k501]
def combine8724 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k737 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:1:0"] []
def k738 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:1:0"] [k492, k737]
def k739 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k491, k738]
def k740 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k739]
def k741 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k740, k503, k504, k106, k94, k465, k491, k738, k501]
def combine8733 : Combine := fun l r => if l = k125 /\ r = k132 then some (k22, [k454]) else (if l = k22 /\ r = k139 then some (k462, [k458]) else (none))
def k742 : Key := .node "alloy-dependent-chain-source-content-v1" ["TEST_ONLY:ARROW:repeat:1:1"] []
def k743 : Key := .node "alloy-dependent-chain-source-occurrence-v1" ["fixture/chain-witness/ARROW:repeat:1:1"] [k512, k742]
def k744 : Key := .node "certificate-term/dependent-chain-application-v1" [] [k106, k511, k743]
def k745 : Key := .node "certificate-endpoint" ["DEPENDENT_CHAIN_APPLICATION"] [k48, k466, k744]
def k746 : Key := .node "typed-equality-certificate" ["DEPENDENT_CHAIN_NORMALIZATION"] [k745, k503, k504, k106, k94, k465, k511, k743, k501]
theorem source0 : "94c4ab8b81db73094f3dbf1987660fa2e662af108973b5c78dca58b82d213aa6" = "94c4ab8b81db73094f3dbf1987660fa2e662af108973b5c78dca58b82d213aa6" /\ "a8dc4e4157b854b38e8d98da97e6bf614c72ac4ffc7f08ef4fd39dc2bce4126d" = "a8dc4e4157b854b38e8d98da97e6bf614c72ac4ffc7f08ef4fd39dc2bce4126d" := by decide
#print axioms source0
theorem source1 : "201590a925c01cd5a6e9f51dd7e9b9a497a7dcea5efbf499780da8dba263e67e" = "201590a925c01cd5a6e9f51dd7e9b9a497a7dcea5efbf499780da8dba263e67e" /\ "c9763fd525bc78c86203a875e0e5063955dbe396d34dd30249b464cdd23da3da" = "c9763fd525bc78c86203a875e0e5063955dbe396d34dd30249b464cdd23da3da" := by decide
#print axioms source1
theorem source2 : "db81a97d3a9553bf83a22b8721205b61e940ec4c6f550ed115206782470a30f5" = "db81a97d3a9553bf83a22b8721205b61e940ec4c6f550ed115206782470a30f5" /\ "90dca62f7db47fe638762cbcb0a617f536bfba19a876012b122842f63e7f25bb" = "90dca62f7db47fe638762cbcb0a617f536bfba19a876012b122842f63e7f25bb" := by decide
#print axioms source2
theorem source3 : "800b128e0f225b68f242d201009689bb5eeded3391250ef4259378dce034c35f" = "800b128e0f225b68f242d201009689bb5eeded3391250ef4259378dce034c35f" /\ "9ab2f002f27397ca2a0df0e45f98eee11a4a6993c73f8986dae6b4d0d91ec4ec" = "9ab2f002f27397ca2a0df0e45f98eee11a4a6993c73f8986dae6b4d0d91ec4ec" := by decide
#print axioms source3
theorem source4 : "64c387d33dc40528ac4b1a9faa8a72237a10f0d049f656731fd5af4b88470fb8" = "64c387d33dc40528ac4b1a9faa8a72237a10f0d049f656731fd5af4b88470fb8" /\ "13f9b2a502d11b0836d7453950bf0e028f8fb3f03cb416013436794fbd25b5a6" = "13f9b2a502d11b0836d7453950bf0e028f8fb3f03cb416013436794fbd25b5a6" := by decide
#print axioms source4
theorem source5 : "325740a2f5587deeb28ab091880d6f2d9ce0894dd659b872103cb13a5cb3c194" = "325740a2f5587deeb28ab091880d6f2d9ce0894dd659b872103cb13a5cb3c194" /\ "e107211d2bfeb3a5a7bca53dc0d0f7db63ffbcf61fe327cdfd405e0d81a72796" = "e107211d2bfeb3a5a7bca53dc0d0f7db63ffbcf61fe327cdfd405e0d81a72796" := by decide
#print axioms source5
theorem source6 : "3aad8a1cfd9aa91431ec46ec25f3dbae94f82d8926e129d5702f9675ee495e54" = "3aad8a1cfd9aa91431ec46ec25f3dbae94f82d8926e129d5702f9675ee495e54" /\ "11cf028d508997595a314cef1f0a36d411d1ba8f799e8c0e125bedecc02e6e47" = "11cf028d508997595a314cef1f0a36d411d1ba8f799e8c0e125bedecc02e6e47" := by decide
#print axioms source6
theorem source7 : "b6c18c3ca66eba2bdaba5385211ab9f557419ac6dc6f807659fef0c33acb5c4e" = "b6c18c3ca66eba2bdaba5385211ab9f557419ac6dc6f807659fef0c33acb5c4e" /\ "b52e7b1c6925e177d91e6202f01cd5ceb4786d0ce26d9c01ec8bf2972be90c42" = "b52e7b1c6925e177d91e6202f01cd5ceb4786d0ce26d9c01ec8bf2972be90c42" := by decide
#print axioms source7
theorem source8 : "1b9144c54170bcd98528f79b4432cb1203057dc2ee1b7fedc0d55c2223120492" = "1b9144c54170bcd98528f79b4432cb1203057dc2ee1b7fedc0d55c2223120492" /\ "3bb8166269c04aa1cb967873088cfdeaefc3bafdbc3399c01122f12e1b99334b" = "3bb8166269c04aa1cb967873088cfdeaefc3bafdbc3399c01122f12e1b99334b" := by decide
#print axioms source8
theorem source9 : "6996cae14018896b70e600cdc3252ba1654f49d0865927feb30626de2bb0be80" = "6996cae14018896b70e600cdc3252ba1654f49d0865927feb30626de2bb0be80" /\ "2e67b77018788888b9be5085d2f4bd8824af0079ee701a86dccf480325f02534" = "2e67b77018788888b9be5085d2f4bd8824af0079ee701a86dccf480325f02534" := by decide
#print axioms source9
theorem source10 : "9592eec198ba9ef3b3073cbef9ecf994dd0a8f8d70fe6eeab7bc218e8703891f" = "9592eec198ba9ef3b3073cbef9ecf994dd0a8f8d70fe6eeab7bc218e8703891f" /\ "a6dbd09bd87ecf04e7139b6c214047614be7324329d3ada157a66d877010399a" = "a6dbd09bd87ecf04e7139b6c214047614be7324329d3ada157a66d877010399a" := by decide
#print axioms source10
theorem source11 : "460176ca8939a4fe2f29a9ad2b1bbe916ffcee7075e48151d55c581d8e6dd916" = "460176ca8939a4fe2f29a9ad2b1bbe916ffcee7075e48151d55c581d8e6dd916" /\ "3fd2cb09eab2671bf23a1d0d1317428eb8b21f65f5e4bfad138813bf7d5fb22e" = "3fd2cb09eab2671bf23a1d0d1317428eb8b21f65f5e4bfad138813bf7d5fb22e" := by decide
#print axioms source11
theorem source12 : "c91040e65f45bfc520051f2ccdba9aa6a609e01c0d597eba731fd613f65743da" = "c91040e65f45bfc520051f2ccdba9aa6a609e01c0d597eba731fd613f65743da" /\ "a96e5e846bc4901abe3350c51da5a02ba7650677d50a176ab88b8390e0660177" = "a96e5e846bc4901abe3350c51da5a02ba7650677d50a176ab88b8390e0660177" := by decide
#print axioms source12
theorem observation0 : derive (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) = some .primitive := by decide
#print axioms observation0
theorem observation1 : derive (.primitive .int) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation1
theorem observation2 : derive (.primitive .int) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation2
theorem observation3 : derive (.primitive .int) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation3
theorem observation4 : derive (.primitive .int) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation4
theorem observation5 : derive (.primitive .int) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation5
theorem observation6 : derive (.primitive .int) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation6
theorem observation7 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7
theorem observation8 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation8
theorem observation9 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .primitive := by decide
#print axioms observation9
theorem observation10 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation10
theorem observation11 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation11
theorem observation12 : derive (.primitive (.sig "A")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation12
theorem observation13 : derive (.primitive (.sig "A")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation13
theorem observation14 : derive (.primitive (.sig "A")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation14
theorem observation15 : "REJECTED" = "REJECTED" := by decide
#print axioms observation15
theorem observation16 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation16
theorem observation17 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation17
theorem observation18 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = some .primitive := by decide
#print axioms observation18
theorem observation19 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation19
theorem observation20 : derive (.primitive (.sig "univ")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation20
theorem observation21 : derive (.primitive (.sig "univ")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation21
theorem observation22 : derive (.primitive (.sig "univ")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation22
theorem observation23 : "REJECTED" = "REJECTED" := by decide
#print axioms observation23
theorem observation24 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation24
theorem observation25 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .exact := by decide
#print axioms observation25
theorem observation26 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation26
theorem observation27 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation27
theorem observation28 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation28
theorem observation29 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation29
theorem observation30 : derive (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation30
theorem observation31 : "REJECTED" = "REJECTED" := by decide
#print axioms observation31
theorem observation32 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation32
theorem observation33 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation33
theorem observation34 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation34
theorem observation35 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation35
theorem observation36 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = some .exact := by decide
#print axioms observation36
theorem observation37 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation37
theorem observation38 : derive (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation38
theorem observation39 : "REJECTED" = "REJECTED" := by decide
#print axioms observation39
theorem observation40 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation40
theorem observation41 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation41
theorem observation42 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation42
theorem observation43 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation43
theorem observation44 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation44
theorem observation45 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 1, products := [] } : Family) = some .exact := by decide
#print axioms observation45
theorem observation46 : derive (.relation ({ arity := 1, products := [] } : Family)) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation46
theorem observation47 : "REJECTED" = "REJECTED" := by decide
#print axioms observation47
theorem observation48 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation48
theorem observation49 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation49
theorem observation50 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation50
theorem observation51 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation51
theorem observation52 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation52
theorem observation53 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation53
theorem observation54 : derive (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) = some .exact := by decide
#print axioms observation54
theorem observation55 : "REJECTED" = "REJECTED" := by decide
#print axioms observation55
theorem observation56 : derive (.other k0) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation56
theorem observation57 : derive (.other k0) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation57
theorem observation58 : derive (.other k0) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation58
theorem observation59 : derive (.other k0) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation59
theorem observation60 : derive (.other k0) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation60
theorem observation61 : derive (.other k0) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation61
theorem observation62 : derive (.other k0) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation62
theorem observation63 : "REJECTED" = "REJECTED" := by decide
#print axioms observation63
theorem observation64 : derive (.other k1) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation64
theorem observation65 : derive (.other k1) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation65
theorem observation66 : derive (.other k1) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation66
theorem observation67 : derive (.other k1) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation67
theorem observation68 : derive (.other k1) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation68
theorem observation69 : derive (.other k1) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation69
theorem observation70 : derive (.other k1) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation70
theorem observation71 : "REJECTED" = "REJECTED" := by decide
#print axioms observation71
theorem observation72 : derive (.other k2) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation72
theorem observation73 : derive (.other k2) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation73
theorem observation74 : derive (.other k2) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation74
theorem observation75 : derive (.other k2) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation75
theorem observation76 : derive (.other k2) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation76
theorem observation77 : derive (.other k2) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation77
theorem observation78 : derive (.other k2) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation78
theorem observation79 : "REJECTED" = "REJECTED" := by decide
#print axioms observation79
theorem observation80 : derive (.other k3) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation80
theorem observation81 : derive (.other k3) ({ arity := 1, products := [[.sig "A"]] } : Family) = none := by decide
#print axioms observation81
theorem observation82 : derive (.other k3) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation82
theorem observation83 : derive (.other k3) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation83
theorem observation84 : derive (.other k3) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation84
theorem observation85 : derive (.other k3) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation85
theorem observation86 : derive (.other k3) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation86
theorem observation87 : "REJECTED" = "REJECTED" := by decide
#print axioms observation87
theorem observation88 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.int]] } : Family) = none := by decide
#print axioms observation88
theorem observation89 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) = some .primitive := by decide
#print axioms observation89
theorem observation90 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "univ"]] } : Family) = none := by decide
#print axioms observation90
theorem observation91 : derive (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "B"]] } : Family) = none := by decide
#print axioms observation91
theorem observation92 : derive (.primitive (.sig "A")) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) = none := by decide
#print axioms observation92
theorem observation93 : derive (.primitive (.sig "A")) ({ arity := 1, products := [] } : Family) = none := by decide
#print axioms observation93
theorem observation94 : derive (.primitive (.sig "A")) ({ arity := 2, products := [] } : Family) = none := by decide
#print axioms observation94
theorem observation95 : "REJECTED" = "REJECTED" := by decide
#print axioms observation95
theorem observation96 : k11 = k11 /\ k12 = k12 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k7, k9, k10, k4, k6, k8] k47 = true := by decide
#print axioms observation96
theorem observation97 : k47 = k47 /\ k47 = k47 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine97 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k22, k27] k44 = some k47 := by decide
#print axioms observation97
theorem observation98 : k95 = k95 /\ k95 = k95 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation98
theorem observation99 : k76 = k76 /\ k76 = k76 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation99
theorem observation100 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation100
theorem observation101 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation101
theorem observation102 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation102
theorem observation103 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation103
theorem observation104 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation104
theorem observation105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation105
theorem observation106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation106
theorem observation107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation107
theorem observation108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation108
theorem observation109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation109
theorem observation110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation110
theorem observation111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation111
theorem observation112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation112
theorem observation113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation113
theorem observation114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation114
theorem observation115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation115
theorem observation116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation116
theorem observation117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation117
theorem observation118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation118
theorem observation119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation119
theorem observation120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation120
theorem observation121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation121
theorem observation122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation122
theorem observation123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation123
theorem observation124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation124
theorem observation125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation125
theorem observation126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation126
theorem observation127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation127
theorem observation128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation128
theorem observation129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation129
theorem observation130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation130
theorem observation131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation131
theorem observation132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation132
theorem observation133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation133
theorem observation134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation134
theorem observation135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation135
theorem observation136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation136
theorem observation137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation137
theorem observation138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation138
theorem observation139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation139
theorem observation140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation140
theorem observation141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation141
theorem observation142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation142
theorem observation143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation143
theorem observation144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation144
theorem observation145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation145
theorem observation146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation146
theorem observation147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation147
theorem observation148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation148
theorem observation149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation149
theorem observation150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation150
theorem observation151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation151
theorem observation152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation152
theorem observation153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation153
theorem observation154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation154
theorem observation155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation155
theorem observation156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation156
theorem observation157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation157
theorem observation158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation158
theorem observation159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation159
theorem observation160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation160
theorem observation161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation161
theorem observation162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation162
theorem observation163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation163
theorem observation164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation164
theorem observation165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation165
theorem observation166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation166
theorem observation167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation167
theorem observation168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation168
theorem observation169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation169
theorem observation170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation170
theorem observation171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation171
theorem observation172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation172
theorem observation173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation173
theorem observation174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation174
theorem observation175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation175
theorem observation176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation176
theorem observation177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation177
theorem observation178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation178
theorem observation179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation179
theorem observation180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation180
theorem observation181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation181
theorem observation182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation182
theorem observation183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation183
theorem observation184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation184
theorem observation185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation185
theorem observation186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation186
theorem observation187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation187
theorem observation188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation188
theorem observation189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation189
theorem observation190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation190
theorem observation191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation191
theorem observation192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation192
theorem observation193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation193
theorem observation194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation194
theorem observation195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation195
theorem observation196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation196
theorem observation197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation197
theorem observation198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation198
theorem observation199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation199
theorem observation200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation200
theorem observation201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation201
theorem observation202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation202
theorem observation203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation203
theorem observation204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation204
theorem observation205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation205
theorem observation206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation206
theorem observation207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation207
theorem observation208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation208
theorem observation209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation209
theorem observation210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation210
theorem observation211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation211
theorem observation212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation212
theorem observation213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation213
theorem observation214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation214
theorem observation215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation215
theorem observation216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation216
theorem observation217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation217
theorem observation218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation218
theorem observation219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation219
theorem observation220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation220
theorem observation221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation221
theorem observation222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation222
theorem observation223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation223
theorem observation224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation224
theorem observation225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation225
theorem observation226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation226
theorem observation227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation227
theorem observation228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation228
theorem observation229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation229
theorem observation230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation230
theorem observation231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation231
theorem observation232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation232
theorem observation233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation233
theorem observation234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation234
theorem observation235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation235
theorem observation236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation236
theorem observation237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation237
theorem observation238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation238
theorem observation239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation239
theorem observation240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation240
theorem observation241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation241
theorem observation242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation242
theorem observation243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation243
theorem observation244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation244
theorem observation245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation245
theorem observation246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation246
theorem observation247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation247
theorem observation248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation248
theorem observation249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation249
theorem observation250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation250
theorem observation251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation251
theorem observation252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation252
theorem observation253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation253
theorem observation254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation254
theorem observation255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation255
theorem observation256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation256
theorem observation257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation257
theorem observation258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation258
theorem observation259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation259
theorem observation260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation260
theorem observation261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation261
theorem observation262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation262
theorem observation263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation263
theorem observation264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation264
theorem observation265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation265
theorem observation266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation266
theorem observation267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation267
theorem observation268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation268
theorem observation269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation269
theorem observation270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation270
theorem observation271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation271
theorem observation272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation272
theorem observation273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation273
theorem observation274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation274
theorem observation275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation275
theorem observation276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation276
theorem observation277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation277
theorem observation278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation278
theorem observation279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation279
theorem observation280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation280
theorem observation281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation281
theorem observation282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation282
theorem observation283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation283
theorem observation284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation284
theorem observation285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation285
theorem observation286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation286
theorem observation287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation287
theorem observation288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation288
theorem observation289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation289
theorem observation290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation290
theorem observation291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation291
theorem observation292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation292
theorem observation293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation293
theorem observation294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation294
theorem observation295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation295
theorem observation296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation296
theorem observation297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation297
theorem observation298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation298
theorem observation299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation299
theorem observation300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation300
theorem observation301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation301
theorem observation302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation302
theorem observation303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation303
theorem observation304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation304
theorem observation305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation305
theorem observation306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation306
theorem observation307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation307
theorem observation308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation308
theorem observation309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation309
theorem observation310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation310
theorem observation311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation311
theorem observation312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation312
theorem observation313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation313
theorem observation314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation314
theorem observation315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation315
theorem observation316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation316
theorem observation317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation317
theorem observation318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation318
theorem observation319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation319
theorem observation320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation320
theorem observation321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation321
theorem observation322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation322
theorem observation323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation323
theorem observation324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation324
theorem observation325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation325
theorem observation326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation326
theorem observation327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation327
theorem observation328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation328
theorem observation329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation329
theorem observation330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation330
theorem observation331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation331
theorem observation332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation332
theorem observation333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation333
theorem observation334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation334
theorem observation335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation335
theorem observation336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation336
theorem observation337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation337
theorem observation338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation338
theorem observation339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation339
theorem observation340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation340
theorem observation341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation341
theorem observation342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation342
theorem observation343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation343
theorem observation344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation344
theorem observation345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation345
theorem observation346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation346
theorem observation347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation347
theorem observation348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation348
theorem observation349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation349
theorem observation350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation350
theorem observation351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation351
theorem observation352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation352
theorem observation353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation353
theorem observation354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation354
theorem observation355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation355
theorem observation356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation356
theorem observation357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation357
theorem observation358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation358
theorem observation359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation359
theorem observation360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation360
theorem observation361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation361
theorem observation362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation362
theorem observation363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation363
theorem observation364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation364
theorem observation365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation365
theorem observation366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation366
theorem observation367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation367
theorem observation368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation368
theorem observation369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation369
theorem observation370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation370
theorem observation371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation371
theorem observation372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation372
theorem observation373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation373
theorem observation374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation374
theorem observation375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation375
theorem observation376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation376
theorem observation377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation377
theorem observation378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation378
theorem observation379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation379
theorem observation380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation380
theorem observation381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation381
theorem observation382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation382
theorem observation383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation383
theorem observation384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation384
theorem observation385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation385
theorem observation386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation386
theorem observation387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation387
theorem observation388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation388
theorem observation389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation389
theorem observation390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation390
theorem observation391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation391
theorem observation392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation392
theorem observation393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation393
theorem observation394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation394
theorem observation395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation395
theorem observation396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation396
theorem observation397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation397
theorem observation398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation398
theorem observation399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation399
theorem observation400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation400
theorem observation401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation401
theorem observation402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation402
theorem observation403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation403
theorem observation404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation404
theorem observation405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation405
theorem observation406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation406
theorem observation407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation407
theorem observation408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation408
theorem observation409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation409
theorem observation410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation410
theorem observation411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation411
theorem observation412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation412
theorem observation413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation413
theorem observation414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation414
theorem observation415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation415
theorem observation416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation416
theorem observation417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation417
theorem observation418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation418
theorem observation419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation419
theorem observation420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation420
theorem observation421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation421
theorem observation422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation422
theorem observation423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation423
theorem observation424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation424
theorem observation425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation425
theorem observation426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation426
theorem observation427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation427
theorem observation428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation428
theorem observation429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation429
theorem observation430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation430
theorem observation431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation431
theorem observation432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation432
theorem observation433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation433
theorem observation434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation434
theorem observation435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation435
theorem observation436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation436
theorem observation437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation437
theorem observation438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation438
theorem observation439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation439
theorem observation440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation440
theorem observation441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation441
theorem observation442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation442
theorem observation443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation443
theorem observation444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation444
theorem observation445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation445
theorem observation446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation446
theorem observation447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation447
theorem observation448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation448
theorem observation449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation449
theorem observation450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation450
theorem observation451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation451
theorem observation452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation452
theorem observation453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation453
theorem observation454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation454
theorem observation455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation455
theorem observation456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation456
theorem observation457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation457
theorem observation458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation458
theorem observation459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation459
theorem observation460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation460
theorem observation461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation461
theorem observation462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation462
theorem observation463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation463
theorem observation464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation464
theorem observation465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation465
theorem observation466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation466
theorem observation467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation467
theorem observation468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation468
theorem observation469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation469
theorem observation470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation470
theorem observation471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation471
theorem observation472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation472
theorem observation473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation473
theorem observation474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation474
theorem observation475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation475
theorem observation476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation476
theorem observation477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation477
theorem observation478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation478
theorem observation479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation479
theorem observation480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation480
theorem observation481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation481
theorem observation482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation482
theorem observation483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation483
theorem observation484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation484
theorem observation485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation485
theorem observation486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation486
theorem observation487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation487
theorem observation488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation488
theorem observation489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation489
theorem observation490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation490
theorem observation491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation491
theorem observation492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation492
theorem observation493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation493
theorem observation494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation494
theorem observation495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation495
theorem observation496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation496
theorem observation497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation497
theorem observation498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation498
theorem observation499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation499
theorem observation500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation500
theorem observation501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation501
theorem observation502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation502
theorem observation503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation503
theorem observation504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation504
theorem observation505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation505
theorem observation506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation506
theorem observation507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation507
theorem observation508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation508
theorem observation509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation509
theorem observation510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation510
theorem observation511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation511
theorem observation512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation512
theorem observation513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation513
theorem observation514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation514
theorem observation515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation515
theorem observation516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation516
theorem observation517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation517
theorem observation518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation518
theorem observation519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation519
theorem observation520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation520
theorem observation521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation521
theorem observation522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation522
theorem observation523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation523
theorem observation524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation524
theorem observation525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation525
theorem observation526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation526
theorem observation527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation527
theorem observation528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation528
theorem observation529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation529
theorem observation530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation530
theorem observation531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation531
theorem observation532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation532
theorem observation533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation533
theorem observation534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation534
theorem observation535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation535
theorem observation536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation536
theorem observation537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation537
theorem observation538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation538
theorem observation539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation539
theorem observation540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation540
theorem observation541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation541
theorem observation542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation542
theorem observation543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation543
theorem observation544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation544
theorem observation545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation545
theorem observation546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation546
theorem observation547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation547
theorem observation548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation548
theorem observation549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation549
theorem observation550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation550
theorem observation551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation551
theorem observation552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation552
theorem observation553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation553
theorem observation554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation554
theorem observation555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation555
theorem observation556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation556
theorem observation557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation557
theorem observation558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation558
theorem observation559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation559
theorem observation560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation560
theorem observation561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation561
theorem observation562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation562
theorem observation563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation563
theorem observation564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation564
theorem observation565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation565
theorem observation566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation566
theorem observation567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation567
theorem observation568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation568
theorem observation569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation569
theorem observation570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation570
theorem observation571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation571
theorem observation572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation572
theorem observation573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation573
theorem observation574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation574
theorem observation575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation575
theorem observation576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation576
theorem observation577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation577
theorem observation578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation578
theorem observation579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation579
theorem observation580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation580
theorem observation581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation581
theorem observation582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation582
theorem observation583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation583
theorem observation584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation584
theorem observation585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation585
theorem observation586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation586
theorem observation587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation587
theorem observation588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation588
theorem observation589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation589
theorem observation590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation590
theorem observation591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation591
theorem observation592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation592
theorem observation593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation593
theorem observation594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation594
theorem observation595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation595
theorem observation596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation596
theorem observation597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation597
theorem observation598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation598
theorem observation599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation599
theorem observation600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation600
theorem observation601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation601
theorem observation602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation602
theorem observation603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation603
theorem observation604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation604
theorem observation605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation605
theorem observation606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation606
theorem observation607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation607
theorem observation608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation608
theorem observation609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation609
theorem observation610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation610
theorem observation611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation611
theorem observation612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation612
theorem observation613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation613
theorem observation614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation614
theorem observation615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation615
theorem observation616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation616
theorem observation617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation617
theorem observation618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation618
theorem observation619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation619
theorem observation620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation620
theorem observation621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation621
theorem observation622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation622
theorem observation623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation623
theorem observation624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation624
theorem observation625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation625
theorem observation626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation626
theorem observation627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation627
theorem observation628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation628
theorem observation629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation629
theorem observation630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation630
theorem observation631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation631
theorem observation632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation632
theorem observation633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation633
theorem observation634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation634
theorem observation635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation635
theorem observation636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation636
theorem observation637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation637
theorem observation638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation638
theorem observation639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation639
theorem observation640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation640
theorem observation641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation641
theorem observation642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation642
theorem observation643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation643
theorem observation644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation644
theorem observation645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation645
theorem observation646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation646
theorem observation647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation647
theorem observation648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation648
theorem observation649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation649
theorem observation650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation650
theorem observation651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation651
theorem observation652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation652
theorem observation653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation653
theorem observation654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation654
theorem observation655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation655
theorem observation656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation656
theorem observation657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation657
theorem observation658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation658
theorem observation659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation659
theorem observation660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation660
theorem observation661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation661
theorem observation662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation662
theorem observation663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation663
theorem observation664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation664
theorem observation665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation665
theorem observation666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation666
theorem observation667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation667
theorem observation668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation668
theorem observation669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation669
theorem observation670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation670
theorem observation671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation671
theorem observation672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation672
theorem observation673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation673
theorem observation674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation674
theorem observation675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation675
theorem observation676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation676
theorem observation677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation677
theorem observation678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation678
theorem observation679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation679
theorem observation680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation680
theorem observation681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation681
theorem observation682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation682
theorem observation683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation683
theorem observation684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation684
theorem observation685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation685
theorem observation686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation686
theorem observation687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation687
theorem observation688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation688
theorem observation689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation689
theorem observation690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation690
theorem observation691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation691
theorem observation692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation692
theorem observation693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation693
theorem observation694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation694
theorem observation695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation695
theorem observation696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation696
theorem observation697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation697
theorem observation698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation698
theorem observation699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation699
theorem observation700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation700
theorem observation701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation701
theorem observation702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation702
theorem observation703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation703
theorem observation704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation704
theorem observation705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation705
theorem observation706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation706
theorem observation707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation707
theorem observation708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation708
theorem observation709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation709
theorem observation710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation710
theorem observation711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation711
theorem observation712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation712
theorem observation713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation713
theorem observation714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation714
theorem observation715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation715
theorem observation716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation716
theorem observation717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation717
theorem observation718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation718
theorem observation719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation719
theorem observation720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation720
theorem observation721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation721
theorem observation722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation722
theorem observation723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation723
theorem observation724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation724
theorem observation725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation725
theorem observation726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation726
theorem observation727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation727
theorem observation728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation728
theorem observation729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation729
theorem observation730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation730
theorem observation731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation731
theorem observation732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation732
theorem observation733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation733
theorem observation734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation734
theorem observation735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation735
theorem observation736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation736
theorem observation737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation737
theorem observation738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation738
theorem observation739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation739
theorem observation740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation740
theorem observation741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation741
theorem observation742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation742
theorem observation743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation743
theorem observation744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation744
theorem observation745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation745
theorem observation746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation746
theorem observation747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation747
theorem observation748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation748
theorem observation749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation749
theorem observation750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation750
theorem observation751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation751
theorem observation752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation752
theorem observation753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation753
theorem observation754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation754
theorem observation755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation755
theorem observation756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation756
theorem observation757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation757
theorem observation758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation758
theorem observation759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation759
theorem observation760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation760
theorem observation761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation761
theorem observation762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation762
theorem observation763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation763
theorem observation764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation764
theorem observation765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation765
theorem observation766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation766
theorem observation767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation767
theorem observation768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation768
theorem observation769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation769
theorem observation770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation770
theorem observation771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation771
theorem observation772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation772
theorem observation773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation773
theorem observation774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation774
theorem observation775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation775
theorem observation776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation776
theorem observation777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation777
theorem observation778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation778
theorem observation779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation779
theorem observation780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation780
theorem observation781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation781
theorem observation782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation782
theorem observation783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation783
theorem observation784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation784
theorem observation785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation785
theorem observation786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation786
theorem observation787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation787
theorem observation788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation788
theorem observation789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation789
theorem observation790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation790
theorem observation791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation791
theorem observation792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation792
theorem observation793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation793
theorem observation794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation794
theorem observation795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation795
theorem observation796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation796
theorem observation797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation797
theorem observation798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation798
theorem observation799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation799
theorem observation800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation800
theorem observation801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation801
theorem observation802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation802
theorem observation803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation803
theorem observation804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation804
theorem observation805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation805
theorem observation806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation806
theorem observation807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation807
theorem observation808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation808
theorem observation809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation809
theorem observation810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation810
theorem observation811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation811
theorem observation812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation812
theorem observation813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation813
theorem observation814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation814
theorem observation815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation815
theorem observation816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation816
theorem observation817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation817
theorem observation818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation818
theorem observation819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation819
theorem observation820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation820
theorem observation821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation821
theorem observation822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation822
theorem observation823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation823
theorem observation824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation824
theorem observation825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation825
theorem observation826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation826
theorem observation827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation827
theorem observation828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation828
theorem observation829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation829
theorem observation830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation830
theorem observation831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation831
theorem observation832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation832
theorem observation833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation833
theorem observation834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation834
theorem observation835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation835
theorem observation836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation836
theorem observation837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation837
theorem observation838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation838
theorem observation839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation839
theorem observation840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation840
theorem observation841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation841
theorem observation842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation842
theorem observation843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation843
theorem observation844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation844
theorem observation845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation845
theorem observation846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation846
theorem observation847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation847
theorem observation848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation848
theorem observation849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation849
theorem observation850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation850
theorem observation851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation851
theorem observation852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation852
theorem observation853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation853
theorem observation854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation854
theorem observation855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation855
theorem observation856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation856
theorem observation857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation857
theorem observation858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation858
theorem observation859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation859
theorem observation860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation860
theorem observation861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation861
theorem observation862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation862
theorem observation863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation863
theorem observation864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation864
theorem observation865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation865
theorem observation866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation866
theorem observation867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation867
theorem observation868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation868
theorem observation869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation869
theorem observation870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation870
theorem observation871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation871
theorem observation872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation872
theorem observation873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation873
theorem observation874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation874
theorem observation875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation875
theorem observation876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation876
theorem observation877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation877
theorem observation878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation878
theorem observation879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation879
theorem observation880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation880
theorem observation881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation881
theorem observation882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation882
theorem observation883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation883
theorem observation884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation884
theorem observation885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation885
theorem observation886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation886
theorem observation887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation887
theorem observation888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation888
theorem observation889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation889
theorem observation890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation890
theorem observation891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation891
theorem observation892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation892
theorem observation893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation893
theorem observation894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation894
theorem observation895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation895
theorem observation896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation896
theorem observation897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation897
theorem observation898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation898
theorem observation899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation899
theorem observation900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation900
theorem observation901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation901
theorem observation902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation902
theorem observation903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation903
theorem observation904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation904
theorem observation905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation905
theorem observation906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation906
theorem observation907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation907
theorem observation908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation908
theorem observation909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation909
theorem observation910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation910
theorem observation911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation911
theorem observation912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation912
theorem observation913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation913
theorem observation914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation914
theorem observation915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation915
theorem observation916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation916
theorem observation917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation917
theorem observation918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation918
theorem observation919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation919
theorem observation920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation920
theorem observation921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation921
theorem observation922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation922
theorem observation923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation923
theorem observation924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation924
theorem observation925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation925
theorem observation926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation926
theorem observation927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation927
theorem observation928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation928
theorem observation929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation929
theorem observation930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation930
theorem observation931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation931
theorem observation932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation932
theorem observation933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation933
theorem observation934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation934
theorem observation935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation935
theorem observation936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation936
theorem observation937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation937
theorem observation938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation938
theorem observation939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation939
theorem observation940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation940
theorem observation941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation941
theorem observation942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation942
theorem observation943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation943
theorem observation944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation944
theorem observation945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation945
theorem observation946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation946
theorem observation947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation947
theorem observation948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation948
theorem observation949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation949
theorem observation950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation950
theorem observation951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation951
theorem observation952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation952
theorem observation953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation953
theorem observation954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation954
theorem observation955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation955
theorem observation956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation956
theorem observation957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation957
theorem observation958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation958
theorem observation959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation959
theorem observation960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation960
theorem observation961 : k11 = k11 /\ k12 = k12 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k7, k9, k10, k4, k6, k8] k47 = true := by decide
#print axioms observation961
theorem observation962 : k47 = k47 /\ k47 = k47 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine962 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k22, k27] k44 = some k47 := by decide
#print axioms observation962
theorem observation963 : k105 = k105 /\ k105 = k105 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation963
theorem observation964 : k99 = k99 /\ k99 = k99 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation964
theorem observation965 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation965
theorem observation966 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation966
theorem observation967 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation967
theorem observation968 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation968
theorem observation969 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation969
theorem observation970 : k11 = k11 /\ k12 = k12 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k7, k9, k10, k4, k6, k8] k47 = true := by decide
#print axioms observation970
theorem observation971 : k47 = k47 /\ k47 = k47 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine971 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k22, k27] k44 = some k47 := by decide
#print axioms observation971
theorem observation972 : k111 = k111 /\ k111 = k111 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation972
theorem observation973 : k76 = k76 /\ k76 = k76 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation973
theorem observation974 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation974
theorem observation975 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation975
theorem observation976 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation976
theorem observation977 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation977
theorem observation978 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation978
theorem observation979 : k11 = k11 /\ k12 = k12 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k7, k9, k10, k4, k6, k8] k47 = true := by decide
#print axioms observation979
theorem observation980 : k47 = k47 /\ k47 = k47 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine980 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k22, k27] k44 = some k47 := by decide
#print axioms observation980
theorem observation981 : k116 = k116 /\ k116 = k116 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation981
theorem observation982 : k99 = k99 /\ k99 = k99 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation982
theorem observation983 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation983
theorem observation984 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation984
theorem observation985 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation985
theorem observation986 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation986
theorem observation987 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation987
theorem observation988 : k121 = k121 /\ k122 = k122 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k4, k6, k8, k120] k142 = true := by decide
#print axioms observation988
theorem observation989 : k142 = k142 /\ k142 = k142 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine989 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k125, k22, k27] k139 = some k142 := by decide
#print axioms observation989
theorem observation990 : k168 = k168 /\ k168 = k168 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation990
theorem observation991 : k154 = k154 /\ k154 = k154 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation991
theorem observation992 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation992
theorem observation993 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation993
theorem observation994 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation994
theorem observation995 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation995
theorem observation996 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation996
theorem observation997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation997
theorem observation998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation998
theorem observation999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation999
theorem observation1000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1000
theorem observation1001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1001
theorem observation1002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1002
theorem observation1003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1003
theorem observation1004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1004
theorem observation1005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1005
theorem observation1006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1006
theorem observation1007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1007
theorem observation1008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1008
theorem observation1009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1009
theorem observation1010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1010
theorem observation1011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1011
theorem observation1012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1012
theorem observation1013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1013
theorem observation1014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1014
theorem observation1015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1015
theorem observation1016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1016
theorem observation1017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1017
theorem observation1018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1018
theorem observation1019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1019
theorem observation1020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1020
theorem observation1021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1021
theorem observation1022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1022
theorem observation1023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1023
theorem observation1024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1024
theorem observation1025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1025
theorem observation1026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1026
theorem observation1027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1027
theorem observation1028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1028
theorem observation1029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1029
theorem observation1030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1030
theorem observation1031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1031
theorem observation1032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1032
theorem observation1033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1033
theorem observation1034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1034
theorem observation1035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1035
theorem observation1036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1036
theorem observation1037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1037
theorem observation1038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1038
theorem observation1039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1039
theorem observation1040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1040
theorem observation1041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1041
theorem observation1042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1042
theorem observation1043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1043
theorem observation1044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1044
theorem observation1045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1045
theorem observation1046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1046
theorem observation1047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1047
theorem observation1048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1048
theorem observation1049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1049
theorem observation1050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1050
theorem observation1051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1051
theorem observation1052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1052
theorem observation1053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1053
theorem observation1054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1054
theorem observation1055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1055
theorem observation1056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1056
theorem observation1057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1057
theorem observation1058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1058
theorem observation1059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1059
theorem observation1060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1060
theorem observation1061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1061
theorem observation1062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1062
theorem observation1063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1063
theorem observation1064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1064
theorem observation1065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1065
theorem observation1066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1066
theorem observation1067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1067
theorem observation1068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1068
theorem observation1069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1069
theorem observation1070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1070
theorem observation1071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1071
theorem observation1072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1072
theorem observation1073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1073
theorem observation1074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1074
theorem observation1075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1075
theorem observation1076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1076
theorem observation1077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1077
theorem observation1078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1078
theorem observation1079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1079
theorem observation1080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1080
theorem observation1081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1081
theorem observation1082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1082
theorem observation1083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1083
theorem observation1084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1084
theorem observation1085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1085
theorem observation1086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1086
theorem observation1087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1087
theorem observation1088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1088
theorem observation1089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1089
theorem observation1090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1090
theorem observation1091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1091
theorem observation1092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1092
theorem observation1093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1093
theorem observation1094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1094
theorem observation1095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1095
theorem observation1096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1096
theorem observation1097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1097
theorem observation1098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1098
theorem observation1099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1099
theorem observation1100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1100
theorem observation1101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1101
theorem observation1102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1102
theorem observation1103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1103
theorem observation1104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1104
theorem observation1105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1105
theorem observation1106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1106
theorem observation1107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1107
theorem observation1108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1108
theorem observation1109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1109
theorem observation1110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1110
theorem observation1111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1111
theorem observation1112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1112
theorem observation1113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1113
theorem observation1114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1114
theorem observation1115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1115
theorem observation1116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1116
theorem observation1117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1117
theorem observation1118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1118
theorem observation1119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1119
theorem observation1120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1120
theorem observation1121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1121
theorem observation1122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1122
theorem observation1123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1123
theorem observation1124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1124
theorem observation1125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1125
theorem observation1126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1126
theorem observation1127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1127
theorem observation1128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1128
theorem observation1129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1129
theorem observation1130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1130
theorem observation1131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1131
theorem observation1132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1132
theorem observation1133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1133
theorem observation1134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1134
theorem observation1135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1135
theorem observation1136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1136
theorem observation1137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1137
theorem observation1138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1138
theorem observation1139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1139
theorem observation1140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1140
theorem observation1141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1141
theorem observation1142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1142
theorem observation1143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1143
theorem observation1144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1144
theorem observation1145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1145
theorem observation1146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1146
theorem observation1147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1147
theorem observation1148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1148
theorem observation1149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1149
theorem observation1150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1150
theorem observation1151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1151
theorem observation1152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1152
theorem observation1153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1153
theorem observation1154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1154
theorem observation1155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1155
theorem observation1156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1156
theorem observation1157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1157
theorem observation1158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1158
theorem observation1159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1159
theorem observation1160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1160
theorem observation1161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1161
theorem observation1162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1162
theorem observation1163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1163
theorem observation1164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1164
theorem observation1165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1165
theorem observation1166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1166
theorem observation1167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1167
theorem observation1168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1168
theorem observation1169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1169
theorem observation1170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1170
theorem observation1171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1171
theorem observation1172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1172
theorem observation1173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1173
theorem observation1174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1174
theorem observation1175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1175
theorem observation1176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1176
theorem observation1177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1177
theorem observation1178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1178
theorem observation1179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1179
theorem observation1180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1180
theorem observation1181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1181
theorem observation1182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1182
theorem observation1183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1183
theorem observation1184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1184
theorem observation1185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1185
theorem observation1186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1186
theorem observation1187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1187
theorem observation1188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1188
theorem observation1189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1189
theorem observation1190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1190
theorem observation1191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1191
theorem observation1192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1192
theorem observation1193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1193
theorem observation1194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1194
theorem observation1195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1195
theorem observation1196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1196
theorem observation1197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1197
theorem observation1198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1198
theorem observation1199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1199
theorem observation1200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1200
theorem observation1201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1201
theorem observation1202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1202
theorem observation1203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1203
theorem observation1204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1204
theorem observation1205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1205
theorem observation1206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1206
theorem observation1207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1207
theorem observation1208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1208
theorem observation1209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1209
theorem observation1210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1210
theorem observation1211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1211
theorem observation1212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1212
theorem observation1213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1213
theorem observation1214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1214
theorem observation1215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1215
theorem observation1216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1216
theorem observation1217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1217
theorem observation1218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1218
theorem observation1219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1219
theorem observation1220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1220
theorem observation1221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1221
theorem observation1222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1222
theorem observation1223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1223
theorem observation1224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1224
theorem observation1225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1225
theorem observation1226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1226
theorem observation1227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1227
theorem observation1228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1228
theorem observation1229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1229
theorem observation1230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1230
theorem observation1231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1231
theorem observation1232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1232
theorem observation1233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1233
theorem observation1234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1234
theorem observation1235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1235
theorem observation1236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1236
theorem observation1237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1237
theorem observation1238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1238
theorem observation1239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1239
theorem observation1240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1240
theorem observation1241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1241
theorem observation1242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1242
theorem observation1243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1243
theorem observation1244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1244
theorem observation1245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1245
theorem observation1246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1246
theorem observation1247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1247
theorem observation1248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1248
theorem observation1249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1249
theorem observation1250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1250
theorem observation1251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1251
theorem observation1252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1252
theorem observation1253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1253
theorem observation1254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1254
theorem observation1255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1255
theorem observation1256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1256
theorem observation1257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1257
theorem observation1258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1258
theorem observation1259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1259
theorem observation1260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1260
theorem observation1261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1261
theorem observation1262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1262
theorem observation1263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1263
theorem observation1264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1264
theorem observation1265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1265
theorem observation1266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1266
theorem observation1267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1267
theorem observation1268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1268
theorem observation1269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1269
theorem observation1270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1270
theorem observation1271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1271
theorem observation1272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1272
theorem observation1273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1273
theorem observation1274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1274
theorem observation1275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1275
theorem observation1276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1276
theorem observation1277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1277
theorem observation1278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1278
theorem observation1279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1279
theorem observation1280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1280
theorem observation1281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1281
theorem observation1282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1282
theorem observation1283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1283
theorem observation1284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1284
theorem observation1285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1285
theorem observation1286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1286
theorem observation1287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1287
theorem observation1288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1288
theorem observation1289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1289
theorem observation1290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1290
theorem observation1291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1291
theorem observation1292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1292
theorem observation1293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1293
theorem observation1294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1294
theorem observation1295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1295
theorem observation1296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1296
theorem observation1297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1297
theorem observation1298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1298
theorem observation1299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1299
theorem observation1300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1300
theorem observation1301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1301
theorem observation1302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1302
theorem observation1303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1303
theorem observation1304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1304
theorem observation1305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1305
theorem observation1306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1306
theorem observation1307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1307
theorem observation1308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1308
theorem observation1309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1309
theorem observation1310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1310
theorem observation1311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1311
theorem observation1312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1312
theorem observation1313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1313
theorem observation1314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1314
theorem observation1315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1315
theorem observation1316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1316
theorem observation1317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1317
theorem observation1318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1318
theorem observation1319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1319
theorem observation1320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1320
theorem observation1321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1321
theorem observation1322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1322
theorem observation1323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1323
theorem observation1324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1324
theorem observation1325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1325
theorem observation1326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1326
theorem observation1327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1327
theorem observation1328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1328
theorem observation1329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1329
theorem observation1330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1330
theorem observation1331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1331
theorem observation1332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1332
theorem observation1333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1333
theorem observation1334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1334
theorem observation1335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1335
theorem observation1336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1336
theorem observation1337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1337
theorem observation1338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1338
theorem observation1339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1339
theorem observation1340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1340
theorem observation1341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1341
theorem observation1342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1342
theorem observation1343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1343
theorem observation1344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1344
theorem observation1345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1345
theorem observation1346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1346
theorem observation1347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1347
theorem observation1348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1348
theorem observation1349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1349
theorem observation1350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1350
theorem observation1351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1351
theorem observation1352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1352
theorem observation1353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1353
theorem observation1354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1354
theorem observation1355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1355
theorem observation1356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1356
theorem observation1357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1357
theorem observation1358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1358
theorem observation1359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1359
theorem observation1360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1360
theorem observation1361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1361
theorem observation1362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1362
theorem observation1363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1363
theorem observation1364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1364
theorem observation1365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1365
theorem observation1366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1366
theorem observation1367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1367
theorem observation1368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1368
theorem observation1369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1369
theorem observation1370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1370
theorem observation1371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1371
theorem observation1372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1372
theorem observation1373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1373
theorem observation1374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1374
theorem observation1375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1375
theorem observation1376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1376
theorem observation1377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1377
theorem observation1378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1378
theorem observation1379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1379
theorem observation1380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1380
theorem observation1381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1381
theorem observation1382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1382
theorem observation1383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1383
theorem observation1384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1384
theorem observation1385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1385
theorem observation1386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1386
theorem observation1387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1387
theorem observation1388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1388
theorem observation1389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1389
theorem observation1390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1390
theorem observation1391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1391
theorem observation1392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1392
theorem observation1393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1393
theorem observation1394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1394
theorem observation1395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1395
theorem observation1396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1396
theorem observation1397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1397
theorem observation1398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1398
theorem observation1399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1399
theorem observation1400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1400
theorem observation1401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1401
theorem observation1402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1402
theorem observation1403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1403
theorem observation1404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1404
theorem observation1405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1405
theorem observation1406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1406
theorem observation1407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1407
theorem observation1408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1408
theorem observation1409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1409
theorem observation1410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1410
theorem observation1411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1411
theorem observation1412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1412
theorem observation1413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1413
theorem observation1414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1414
theorem observation1415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1415
theorem observation1416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1416
theorem observation1417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1417
theorem observation1418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1418
theorem observation1419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1419
theorem observation1420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1420
theorem observation1421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1421
theorem observation1422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1422
theorem observation1423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1423
theorem observation1424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1424
theorem observation1425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1425
theorem observation1426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1426
theorem observation1427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1427
theorem observation1428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1428
theorem observation1429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1429
theorem observation1430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1430
theorem observation1431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1431
theorem observation1432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1432
theorem observation1433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1433
theorem observation1434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1434
theorem observation1435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1435
theorem observation1436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1436
theorem observation1437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1437
theorem observation1438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1438
theorem observation1439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1439
theorem observation1440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1440
theorem observation1441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1441
theorem observation1442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1442
theorem observation1443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1443
theorem observation1444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1444
theorem observation1445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1445
theorem observation1446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1446
theorem observation1447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1447
theorem observation1448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1448
theorem observation1449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1449
theorem observation1450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1450
theorem observation1451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1451
theorem observation1452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1452
theorem observation1453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1453
theorem observation1454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1454
theorem observation1455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1455
theorem observation1456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1456
theorem observation1457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1457
theorem observation1458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1458
theorem observation1459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1459
theorem observation1460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1460
theorem observation1461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1461
theorem observation1462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1462
theorem observation1463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1463
theorem observation1464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1464
theorem observation1465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1465
theorem observation1466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1466
theorem observation1467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1467
theorem observation1468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1468
theorem observation1469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1469
theorem observation1470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1470
theorem observation1471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1471
theorem observation1472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1472
theorem observation1473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1473
theorem observation1474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1474
theorem observation1475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1475
theorem observation1476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1476
theorem observation1477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1477
theorem observation1478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1478
theorem observation1479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1479
theorem observation1480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1480
theorem observation1481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1481
theorem observation1482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1482
theorem observation1483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1483
theorem observation1484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1484
theorem observation1485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1485
theorem observation1486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1486
theorem observation1487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1487
theorem observation1488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1488
theorem observation1489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1489
theorem observation1490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1490
theorem observation1491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1491
theorem observation1492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1492
theorem observation1493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1493
theorem observation1494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1494
theorem observation1495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1495
theorem observation1496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1496
theorem observation1497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1497
theorem observation1498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1498
theorem observation1499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1499
theorem observation1500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1500
theorem observation1501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1501
theorem observation1502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1502
theorem observation1503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1503
theorem observation1504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1504
theorem observation1505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1505
theorem observation1506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1506
theorem observation1507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1507
theorem observation1508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1508
theorem observation1509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1509
theorem observation1510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1510
theorem observation1511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1511
theorem observation1512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1512
theorem observation1513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1513
theorem observation1514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1514
theorem observation1515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1515
theorem observation1516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1516
theorem observation1517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1517
theorem observation1518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1518
theorem observation1519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1519
theorem observation1520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1520
theorem observation1521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1521
theorem observation1522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1522
theorem observation1523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1523
theorem observation1524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1524
theorem observation1525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1525
theorem observation1526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1526
theorem observation1527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1527
theorem observation1528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1528
theorem observation1529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1529
theorem observation1530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1530
theorem observation1531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1531
theorem observation1532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1532
theorem observation1533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1533
theorem observation1534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1534
theorem observation1535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1535
theorem observation1536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1536
theorem observation1537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1537
theorem observation1538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1538
theorem observation1539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1539
theorem observation1540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1540
theorem observation1541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1541
theorem observation1542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1542
theorem observation1543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1543
theorem observation1544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1544
theorem observation1545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1545
theorem observation1546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1546
theorem observation1547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1547
theorem observation1548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1548
theorem observation1549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1549
theorem observation1550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1550
theorem observation1551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1551
theorem observation1552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1552
theorem observation1553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1553
theorem observation1554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1554
theorem observation1555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1555
theorem observation1556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1556
theorem observation1557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1557
theorem observation1558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1558
theorem observation1559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1559
theorem observation1560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1560
theorem observation1561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1561
theorem observation1562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1562
theorem observation1563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1563
theorem observation1564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1564
theorem observation1565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1565
theorem observation1566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1566
theorem observation1567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1567
theorem observation1568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1568
theorem observation1569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1569
theorem observation1570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1570
theorem observation1571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1571
theorem observation1572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1572
theorem observation1573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1573
theorem observation1574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1574
theorem observation1575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1575
theorem observation1576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1576
theorem observation1577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1577
theorem observation1578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1578
theorem observation1579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1579
theorem observation1580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1580
theorem observation1581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1581
theorem observation1582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1582
theorem observation1583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1583
theorem observation1584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1584
theorem observation1585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1585
theorem observation1586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1586
theorem observation1587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1587
theorem observation1588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1588
theorem observation1589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1589
theorem observation1590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1590
theorem observation1591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1591
theorem observation1592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1592
theorem observation1593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1593
theorem observation1594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1594
theorem observation1595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1595
theorem observation1596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1596
theorem observation1597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1597
theorem observation1598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1598
theorem observation1599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1599
theorem observation1600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1600
theorem observation1601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1601
theorem observation1602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1602
theorem observation1603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1603
theorem observation1604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1604
theorem observation1605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1605
theorem observation1606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1606
theorem observation1607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1607
theorem observation1608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1608
theorem observation1609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1609
theorem observation1610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1610
theorem observation1611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1611
theorem observation1612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1612
theorem observation1613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1613
theorem observation1614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1614
theorem observation1615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1615
theorem observation1616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1616
theorem observation1617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1617
theorem observation1618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1618
theorem observation1619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1619
theorem observation1620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1620
theorem observation1621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1621
theorem observation1622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1622
theorem observation1623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1623
theorem observation1624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1624
theorem observation1625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1625
theorem observation1626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1626
theorem observation1627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1627
theorem observation1628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1628
theorem observation1629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1629
theorem observation1630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1630
theorem observation1631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1631
theorem observation1632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1632
theorem observation1633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1633
theorem observation1634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1634
theorem observation1635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1635
theorem observation1636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1636
theorem observation1637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1637
theorem observation1638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1638
theorem observation1639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1639
theorem observation1640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1640
theorem observation1641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1641
theorem observation1642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1642
theorem observation1643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1643
theorem observation1644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1644
theorem observation1645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1645
theorem observation1646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1646
theorem observation1647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1647
theorem observation1648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1648
theorem observation1649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1649
theorem observation1650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1650
theorem observation1651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1651
theorem observation1652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1652
theorem observation1653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1653
theorem observation1654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1654
theorem observation1655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1655
theorem observation1656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1656
theorem observation1657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1657
theorem observation1658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1658
theorem observation1659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1659
theorem observation1660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1660
theorem observation1661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1661
theorem observation1662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1662
theorem observation1663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1663
theorem observation1664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1664
theorem observation1665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1665
theorem observation1666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1666
theorem observation1667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1667
theorem observation1668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1668
theorem observation1669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1669
theorem observation1670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1670
theorem observation1671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1671
theorem observation1672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1672
theorem observation1673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1673
theorem observation1674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1674
theorem observation1675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1675
theorem observation1676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1676
theorem observation1677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1677
theorem observation1678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1678
theorem observation1679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1679
theorem observation1680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1680
theorem observation1681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1681
theorem observation1682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1682
theorem observation1683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1683
theorem observation1684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1684
theorem observation1685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1685
theorem observation1686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1686
theorem observation1687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1687
theorem observation1688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1688
theorem observation1689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1689
theorem observation1690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1690
theorem observation1691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1691
theorem observation1692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1692
theorem observation1693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1693
theorem observation1694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1694
theorem observation1695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1695
theorem observation1696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1696
theorem observation1697 : k121 = k121 /\ k169 = k169 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k9, k10, k4, k6, k8, k120] k142 = true := by decide
#print axioms observation1697
theorem observation1698 : k142 = k142 /\ k142 = k142 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine1698 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k125, k22, k27] k139 = some k142 := by decide
#print axioms observation1698
theorem observation1699 : k178 = k178 /\ k178 = k178 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1699
theorem observation1700 : k172 = k172 /\ k172 = k172 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1700
theorem observation1701 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1701
theorem observation1702 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation1702
theorem observation1703 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation1703
theorem observation1704 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation1704
theorem observation1705 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation1705
theorem observation1706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1706
theorem observation1707 : k121 = k121 /\ k122 = k122 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k4, k6, k8, k120] k142 = true := by decide
#print axioms observation1707
theorem observation1708 : k142 = k142 /\ k142 = k142 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine1708 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k125, k22, k27] k139 = some k142 := by decide
#print axioms observation1708
theorem observation1709 : k183 = k183 /\ k183 = k183 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1709
theorem observation1710 : k154 = k154 /\ k154 = k154 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1710
theorem observation1711 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1711
theorem observation1712 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation1712
theorem observation1713 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation1713
theorem observation1714 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation1714
theorem observation1715 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation1715
theorem observation1716 : k121 = k121 /\ k169 = k169 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k9, k10, k4, k6, k8, k120] k142 = true := by decide
#print axioms observation1716
theorem observation1717 : k142 = k142 /\ k142 = k142 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine1717 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k125, k22, k27] k139 = some k142 := by decide
#print axioms observation1717
theorem observation1718 : k188 = k188 /\ k188 = k188 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1718
theorem observation1719 : k172 = k172 /\ k172 = k172 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1719
theorem observation1720 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1720
theorem observation1721 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation1721
theorem observation1722 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation1722
theorem observation1723 : k64 = k64 /\ k64 = k64 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "B"]] } : Family) .exact k64 = true := by decide
#print axioms observation1723
theorem observation1724 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation1724
theorem observation1725 : k192 = k192 /\ k193 = k193 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k10, k6, k8, k189] k210 = true := by decide
#print axioms observation1725
theorem observation1726 : k210 = k210 /\ k210 = k210 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine1726 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k198, k201, k27] k139 = some k210 := by decide
#print axioms observation1726
theorem observation1727 : k240 = k240 /\ k240 = k240 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1727
theorem observation1728 : k227 = k227 /\ k227 = k227 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1728
theorem observation1729 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation1729
theorem observation1730 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation1730
theorem observation1731 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation1731
theorem observation1732 : k223 = k223 /\ k223 = k223 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.int, .sig "B"]] } : Family)) ({ arity := 2, products := [[.int, .sig "B"]] } : Family) .exact k223 = true := by decide
#print axioms observation1732
theorem observation1733 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation1733
theorem observation1734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1734
theorem observation1735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1735
theorem observation1736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1736
theorem observation1737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1737
theorem observation1738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1738
theorem observation1739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1739
theorem observation1740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1740
theorem observation1741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1741
theorem observation1742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1742
theorem observation1743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1743
theorem observation1744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1744
theorem observation1745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1745
theorem observation1746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1746
theorem observation1747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1747
theorem observation1748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1748
theorem observation1749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1749
theorem observation1750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1750
theorem observation1751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1751
theorem observation1752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1752
theorem observation1753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1753
theorem observation1754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1754
theorem observation1755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1755
theorem observation1756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1756
theorem observation1757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1757
theorem observation1758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1758
theorem observation1759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1759
theorem observation1760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1760
theorem observation1761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1761
theorem observation1762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1762
theorem observation1763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1763
theorem observation1764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1764
theorem observation1765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1765
theorem observation1766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1766
theorem observation1767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1767
theorem observation1768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1768
theorem observation1769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1769
theorem observation1770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1770
theorem observation1771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1771
theorem observation1772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1772
theorem observation1773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1773
theorem observation1774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1774
theorem observation1775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1775
theorem observation1776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1776
theorem observation1777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1777
theorem observation1778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1778
theorem observation1779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1779
theorem observation1780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1780
theorem observation1781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1781
theorem observation1782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1782
theorem observation1783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1783
theorem observation1784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1784
theorem observation1785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1785
theorem observation1786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1786
theorem observation1787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1787
theorem observation1788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1788
theorem observation1789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1789
theorem observation1790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1790
theorem observation1791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1791
theorem observation1792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1792
theorem observation1793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1793
theorem observation1794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1794
theorem observation1795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1795
theorem observation1796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1796
theorem observation1797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1797
theorem observation1798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1798
theorem observation1799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1799
theorem observation1800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1800
theorem observation1801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1801
theorem observation1802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1802
theorem observation1803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1803
theorem observation1804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1804
theorem observation1805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1805
theorem observation1806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1806
theorem observation1807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1807
theorem observation1808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1808
theorem observation1809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1809
theorem observation1810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1810
theorem observation1811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1811
theorem observation1812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1812
theorem observation1813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1813
theorem observation1814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1814
theorem observation1815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1815
theorem observation1816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1816
theorem observation1817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1817
theorem observation1818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1818
theorem observation1819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1819
theorem observation1820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1820
theorem observation1821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1821
theorem observation1822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1822
theorem observation1823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1823
theorem observation1824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1824
theorem observation1825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1825
theorem observation1826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1826
theorem observation1827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1827
theorem observation1828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1828
theorem observation1829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1829
theorem observation1830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1830
theorem observation1831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1831
theorem observation1832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1832
theorem observation1833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1833
theorem observation1834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1834
theorem observation1835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1835
theorem observation1836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1836
theorem observation1837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1837
theorem observation1838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1838
theorem observation1839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1839
theorem observation1840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1840
theorem observation1841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1841
theorem observation1842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1842
theorem observation1843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1843
theorem observation1844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1844
theorem observation1845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1845
theorem observation1846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1846
theorem observation1847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1847
theorem observation1848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1848
theorem observation1849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1849
theorem observation1850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1850
theorem observation1851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1851
theorem observation1852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1852
theorem observation1853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1853
theorem observation1854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1854
theorem observation1855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1855
theorem observation1856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1856
theorem observation1857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1857
theorem observation1858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1858
theorem observation1859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1859
theorem observation1860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1860
theorem observation1861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1861
theorem observation1862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1862
theorem observation1863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1863
theorem observation1864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1864
theorem observation1865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1865
theorem observation1866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1866
theorem observation1867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1867
theorem observation1868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1868
theorem observation1869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1869
theorem observation1870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1870
theorem observation1871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1871
theorem observation1872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1872
theorem observation1873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1873
theorem observation1874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1874
theorem observation1875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1875
theorem observation1876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1876
theorem observation1877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1877
theorem observation1878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1878
theorem observation1879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1879
theorem observation1880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1880
theorem observation1881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1881
theorem observation1882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1882
theorem observation1883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1883
theorem observation1884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1884
theorem observation1885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1885
theorem observation1886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1886
theorem observation1887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1887
theorem observation1888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1888
theorem observation1889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1889
theorem observation1890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1890
theorem observation1891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1891
theorem observation1892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1892
theorem observation1893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1893
theorem observation1894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1894
theorem observation1895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1895
theorem observation1896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1896
theorem observation1897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1897
theorem observation1898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1898
theorem observation1899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1899
theorem observation1900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1900
theorem observation1901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1901
theorem observation1902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1902
theorem observation1903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1903
theorem observation1904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1904
theorem observation1905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1905
theorem observation1906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1906
theorem observation1907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1907
theorem observation1908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1908
theorem observation1909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1909
theorem observation1910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1910
theorem observation1911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1911
theorem observation1912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1912
theorem observation1913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1913
theorem observation1914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1914
theorem observation1915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1915
theorem observation1916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1916
theorem observation1917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1917
theorem observation1918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1918
theorem observation1919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1919
theorem observation1920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1920
theorem observation1921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1921
theorem observation1922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1922
theorem observation1923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1923
theorem observation1924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1924
theorem observation1925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1925
theorem observation1926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1926
theorem observation1927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1927
theorem observation1928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1928
theorem observation1929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1929
theorem observation1930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1930
theorem observation1931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1931
theorem observation1932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1932
theorem observation1933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1933
theorem observation1934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1934
theorem observation1935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1935
theorem observation1936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1936
theorem observation1937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1937
theorem observation1938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1938
theorem observation1939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1939
theorem observation1940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1940
theorem observation1941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1941
theorem observation1942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1942
theorem observation1943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1943
theorem observation1944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1944
theorem observation1945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1945
theorem observation1946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1946
theorem observation1947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1947
theorem observation1948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1948
theorem observation1949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1949
theorem observation1950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1950
theorem observation1951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1951
theorem observation1952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1952
theorem observation1953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1953
theorem observation1954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1954
theorem observation1955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1955
theorem observation1956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1956
theorem observation1957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1957
theorem observation1958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1958
theorem observation1959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1959
theorem observation1960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1960
theorem observation1961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1961
theorem observation1962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1962
theorem observation1963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1963
theorem observation1964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1964
theorem observation1965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1965
theorem observation1966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1966
theorem observation1967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1967
theorem observation1968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1968
theorem observation1969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1969
theorem observation1970 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1970
theorem observation1971 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1971
theorem observation1972 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1972
theorem observation1973 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1973
theorem observation1974 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1974
theorem observation1975 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1975
theorem observation1976 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1976
theorem observation1977 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1977
theorem observation1978 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1978
theorem observation1979 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1979
theorem observation1980 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1980
theorem observation1981 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1981
theorem observation1982 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1982
theorem observation1983 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1983
theorem observation1984 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1984
theorem observation1985 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1985
theorem observation1986 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1986
theorem observation1987 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1987
theorem observation1988 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1988
theorem observation1989 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1989
theorem observation1990 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1990
theorem observation1991 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1991
theorem observation1992 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1992
theorem observation1993 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1993
theorem observation1994 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1994
theorem observation1995 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1995
theorem observation1996 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1996
theorem observation1997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1997
theorem observation1998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1998
theorem observation1999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation1999
theorem observation2000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2000
theorem observation2001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2001
theorem observation2002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2002
theorem observation2003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2003
theorem observation2004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2004
theorem observation2005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2005
theorem observation2006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2006
theorem observation2007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2007
theorem observation2008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2008
theorem observation2009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2009
theorem observation2010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2010
theorem observation2011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2011
theorem observation2012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2012
theorem observation2013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2013
theorem observation2014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2014
theorem observation2015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2015
theorem observation2016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2016
theorem observation2017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2017
theorem observation2018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2018
theorem observation2019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2019
theorem observation2020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2020
theorem observation2021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2021
theorem observation2022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2022
theorem observation2023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2023
theorem observation2024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2024
theorem observation2025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2025
theorem observation2026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2026
theorem observation2027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2027
theorem observation2028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2028
theorem observation2029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2029
theorem observation2030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2030
theorem observation2031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2031
theorem observation2032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2032
theorem observation2033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2033
theorem observation2034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2034
theorem observation2035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2035
theorem observation2036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2036
theorem observation2037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2037
theorem observation2038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2038
theorem observation2039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2039
theorem observation2040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2040
theorem observation2041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2041
theorem observation2042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2042
theorem observation2043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2043
theorem observation2044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2044
theorem observation2045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2045
theorem observation2046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2046
theorem observation2047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2047
theorem observation2048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2048
theorem observation2049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2049
theorem observation2050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2050
theorem observation2051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2051
theorem observation2052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2052
theorem observation2053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2053
theorem observation2054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2054
theorem observation2055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2055
theorem observation2056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2056
theorem observation2057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2057
theorem observation2058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2058
theorem observation2059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2059
theorem observation2060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2060
theorem observation2061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2061
theorem observation2062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2062
theorem observation2063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2063
theorem observation2064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2064
theorem observation2065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2065
theorem observation2066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2066
theorem observation2067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2067
theorem observation2068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2068
theorem observation2069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2069
theorem observation2070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2070
theorem observation2071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2071
theorem observation2072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2072
theorem observation2073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2073
theorem observation2074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2074
theorem observation2075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2075
theorem observation2076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2076
theorem observation2077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2077
theorem observation2078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2078
theorem observation2079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2079
theorem observation2080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2080
theorem observation2081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2081
theorem observation2082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2082
theorem observation2083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2083
theorem observation2084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2084
theorem observation2085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2085
theorem observation2086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2086
theorem observation2087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2087
theorem observation2088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2088
theorem observation2089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2089
theorem observation2090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2090
theorem observation2091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2091
theorem observation2092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2092
theorem observation2093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2093
theorem observation2094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2094
theorem observation2095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2095
theorem observation2096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2096
theorem observation2097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2097
theorem observation2098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2098
theorem observation2099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2099
theorem observation2100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2100
theorem observation2101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2101
theorem observation2102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2102
theorem observation2103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2103
theorem observation2104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2104
theorem observation2105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2105
theorem observation2106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2106
theorem observation2107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2107
theorem observation2108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2108
theorem observation2109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2109
theorem observation2110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2110
theorem observation2111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2111
theorem observation2112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2112
theorem observation2113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2113
theorem observation2114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2114
theorem observation2115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2115
theorem observation2116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2116
theorem observation2117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2117
theorem observation2118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2118
theorem observation2119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2119
theorem observation2120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2120
theorem observation2121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2121
theorem observation2122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2122
theorem observation2123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2123
theorem observation2124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2124
theorem observation2125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2125
theorem observation2126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2126
theorem observation2127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2127
theorem observation2128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2128
theorem observation2129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2129
theorem observation2130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2130
theorem observation2131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2131
theorem observation2132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2132
theorem observation2133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2133
theorem observation2134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2134
theorem observation2135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2135
theorem observation2136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2136
theorem observation2137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2137
theorem observation2138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2138
theorem observation2139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2139
theorem observation2140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2140
theorem observation2141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2141
theorem observation2142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2142
theorem observation2143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2143
theorem observation2144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2144
theorem observation2145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2145
theorem observation2146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2146
theorem observation2147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2147
theorem observation2148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2148
theorem observation2149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2149
theorem observation2150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2150
theorem observation2151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2151
theorem observation2152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2152
theorem observation2153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2153
theorem observation2154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2154
theorem observation2155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2155
theorem observation2156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2156
theorem observation2157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2157
theorem observation2158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2158
theorem observation2159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2159
theorem observation2160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2160
theorem observation2161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2161
theorem observation2162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2162
theorem observation2163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2163
theorem observation2164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2164
theorem observation2165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2165
theorem observation2166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2166
theorem observation2167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2167
theorem observation2168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2168
theorem observation2169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2169
theorem observation2170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2170
theorem observation2171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2171
theorem observation2172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2172
theorem observation2173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2173
theorem observation2174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2174
theorem observation2175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2175
theorem observation2176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2176
theorem observation2177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2177
theorem observation2178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2178
theorem observation2179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2179
theorem observation2180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2180
theorem observation2181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2181
theorem observation2182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2182
theorem observation2183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2183
theorem observation2184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2184
theorem observation2185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2185
theorem observation2186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2186
theorem observation2187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2187
theorem observation2188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2188
theorem observation2189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2189
theorem observation2190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2190
theorem observation2191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2191
theorem observation2192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2192
theorem observation2193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2193
theorem observation2194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2194
theorem observation2195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2195
theorem observation2196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2196
theorem observation2197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2197
theorem observation2198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2198
theorem observation2199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2199
theorem observation2200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2200
theorem observation2201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2201
theorem observation2202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2202
theorem observation2203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2203
theorem observation2204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2204
theorem observation2205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2205
theorem observation2206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2206
theorem observation2207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2207
theorem observation2208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2208
theorem observation2209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2209
theorem observation2210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2210
theorem observation2211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2211
theorem observation2212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2212
theorem observation2213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2213
theorem observation2214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2214
theorem observation2215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2215
theorem observation2216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2216
theorem observation2217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2217
theorem observation2218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2218
theorem observation2219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2219
theorem observation2220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2220
theorem observation2221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2221
theorem observation2222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2222
theorem observation2223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2223
theorem observation2224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2224
theorem observation2225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2225
theorem observation2226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2226
theorem observation2227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2227
theorem observation2228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2228
theorem observation2229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2229
theorem observation2230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2230
theorem observation2231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2231
theorem observation2232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2232
theorem observation2233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2233
theorem observation2234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2234
theorem observation2235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2235
theorem observation2236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2236
theorem observation2237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2237
theorem observation2238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2238
theorem observation2239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2239
theorem observation2240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2240
theorem observation2241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2241
theorem observation2242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2242
theorem observation2243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2243
theorem observation2244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2244
theorem observation2245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2245
theorem observation2246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2246
theorem observation2247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2247
theorem observation2248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2248
theorem observation2249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2249
theorem observation2250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2250
theorem observation2251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2251
theorem observation2252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2252
theorem observation2253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2253
theorem observation2254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2254
theorem observation2255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2255
theorem observation2256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2256
theorem observation2257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2257
theorem observation2258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2258
theorem observation2259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2259
theorem observation2260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2260
theorem observation2261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2261
theorem observation2262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2262
theorem observation2263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2263
theorem observation2264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2264
theorem observation2265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2265
theorem observation2266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2266
theorem observation2267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2267
theorem observation2268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2268
theorem observation2269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2269
theorem observation2270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2270
theorem observation2271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2271
theorem observation2272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2272
theorem observation2273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2273
theorem observation2274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2274
theorem observation2275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2275
theorem observation2276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2276
theorem observation2277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2277
theorem observation2278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2278
theorem observation2279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2279
theorem observation2280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2280
theorem observation2281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2281
theorem observation2282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2282
theorem observation2283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2283
theorem observation2284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2284
theorem observation2285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2285
theorem observation2286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2286
theorem observation2287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2287
theorem observation2288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2288
theorem observation2289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2289
theorem observation2290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2290
theorem observation2291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2291
theorem observation2292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2292
theorem observation2293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2293
theorem observation2294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2294
theorem observation2295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2295
theorem observation2296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2296
theorem observation2297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2297
theorem observation2298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2298
theorem observation2299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2299
theorem observation2300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2300
theorem observation2301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2301
theorem observation2302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2302
theorem observation2303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2303
theorem observation2304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2304
theorem observation2305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2305
theorem observation2306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2306
theorem observation2307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2307
theorem observation2308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2308
theorem observation2309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2309
theorem observation2310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2310
theorem observation2311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2311
theorem observation2312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2312
theorem observation2313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2313
theorem observation2314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2314
theorem observation2315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2315
theorem observation2316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2316
theorem observation2317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2317
theorem observation2318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2318
theorem observation2319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2319
theorem observation2320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2320
theorem observation2321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2321
theorem observation2322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2322
theorem observation2323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2323
theorem observation2324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2324
theorem observation2325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2325
theorem observation2326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2326
theorem observation2327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2327
theorem observation2328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2328
theorem observation2329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2329
theorem observation2330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2330
theorem observation2331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2331
theorem observation2332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2332
theorem observation2333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2333
theorem observation2334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2334
theorem observation2335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2335
theorem observation2336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2336
theorem observation2337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2337
theorem observation2338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2338
theorem observation2339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2339
theorem observation2340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2340
theorem observation2341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2341
theorem observation2342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2342
theorem observation2343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2343
theorem observation2344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2344
theorem observation2345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2345
theorem observation2346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2346
theorem observation2347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2347
theorem observation2348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2348
theorem observation2349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2349
theorem observation2350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2350
theorem observation2351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2351
theorem observation2352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2352
theorem observation2353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2353
theorem observation2354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2354
theorem observation2355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2355
theorem observation2356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2356
theorem observation2357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2357
theorem observation2358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2358
theorem observation2359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2359
theorem observation2360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2360
theorem observation2361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2361
theorem observation2362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2362
theorem observation2363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2363
theorem observation2364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2364
theorem observation2365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2365
theorem observation2366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2366
theorem observation2367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2367
theorem observation2368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2368
theorem observation2369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2369
theorem observation2370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2370
theorem observation2371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2371
theorem observation2372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2372
theorem observation2373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2373
theorem observation2374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2374
theorem observation2375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2375
theorem observation2376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2376
theorem observation2377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2377
theorem observation2378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2378
theorem observation2379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2379
theorem observation2380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2380
theorem observation2381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2381
theorem observation2382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2382
theorem observation2383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2383
theorem observation2384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2384
theorem observation2385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2385
theorem observation2386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2386
theorem observation2387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2387
theorem observation2388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2388
theorem observation2389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2389
theorem observation2390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2390
theorem observation2391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2391
theorem observation2392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2392
theorem observation2393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2393
theorem observation2394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2394
theorem observation2395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2395
theorem observation2396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2396
theorem observation2397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2397
theorem observation2398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2398
theorem observation2399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2399
theorem observation2400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2400
theorem observation2401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2401
theorem observation2402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2402
theorem observation2403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2403
theorem observation2404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2404
theorem observation2405 : k192 = k192 /\ k242 = k242 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k241, k10, k6, k8, k189] k210 = true := by decide
#print axioms observation2405
theorem observation2406 : k210 = k210 /\ k210 = k210 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine2406 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k198, k201, k27] k139 = some k210 := by decide
#print axioms observation2406
theorem observation2407 : k258 = k258 /\ k258 = k258 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2407
theorem observation2408 : k252 = k252 /\ k252 = k252 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2408
theorem observation2409 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2409
theorem observation2410 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation2410
theorem observation2411 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation2411
theorem observation2412 : k223 = k223 /\ k223 = k223 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.int, .sig "B"]] } : Family)) ({ arity := 2, products := [[.int, .sig "B"]] } : Family) .exact k223 = true := by decide
#print axioms observation2412
theorem observation2413 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation2413
theorem observation2414 : k192 = k192 /\ k193 = k193 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k10, k6, k8, k189] k210 = true := by decide
#print axioms observation2414
theorem observation2415 : k210 = k210 /\ k210 = k210 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine2415 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k198, k201, k27] k139 = some k210 := by decide
#print axioms observation2415
theorem observation2416 : k263 = k263 /\ k263 = k263 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2416
theorem observation2417 : k227 = k227 /\ k227 = k227 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2417
theorem observation2418 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2418
theorem observation2419 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation2419
theorem observation2420 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation2420
theorem observation2421 : k223 = k223 /\ k223 = k223 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.int, .sig "B"]] } : Family)) ({ arity := 2, products := [[.int, .sig "B"]] } : Family) .exact k223 = true := by decide
#print axioms observation2421
theorem observation2422 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation2422
theorem observation2423 : k192 = k192 /\ k242 = k242 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k241, k10, k6, k8, k189] k210 = true := by decide
#print axioms observation2423
theorem observation2424 : k210 = k210 /\ k210 = k210 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine2424 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k198, k201, k27] k139 = some k210 := by decide
#print axioms observation2424
theorem observation2425 : k268 = k268 /\ k268 = k268 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2425
theorem observation2426 : k252 = k252 /\ k252 = k252 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2426
theorem observation2427 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2427
theorem observation2428 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation2428
theorem observation2429 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation2429
theorem observation2430 : k223 = k223 /\ k223 = k223 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.int, .sig "B"]] } : Family)) ({ arity := 2, products := [[.int, .sig "B"]] } : Family) .exact k223 = true := by decide
#print axioms observation2430
theorem observation2431 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation2431
theorem observation2432 : k272 = k272 /\ k273 = k273 /\ "VERIFIED" = "VERIFIED" /\ publishes [k7, k9, k270, k10, k271, k4, k6, k8, k269] k290 = true := by decide
#print axioms observation2432
theorem observation2433 : k290 = k290 /\ k290 = k290 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine2433 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k278, k281, k27] k44 = some k290 := by decide
#print axioms observation2433
theorem observation2434 : k320 = k320 /\ k320 = k320 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2434
theorem observation2435 : k307 = k307 /\ k307 = k307 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2435
theorem observation2436 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation2436
theorem observation2437 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation2437
theorem observation2438 : k296 = k296 /\ k296 = k296 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family) .exact k296 = true := by decide
#print axioms observation2438
theorem observation2439 : k303 = k303 /\ k303 = k303 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family) .exact k303 = true := by decide
#print axioms observation2439
theorem observation2440 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation2440
theorem observation2441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2441
theorem observation2442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2442
theorem observation2443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2443
theorem observation2444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2444
theorem observation2445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2445
theorem observation2446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2446
theorem observation2447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2447
theorem observation2448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2448
theorem observation2449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2449
theorem observation2450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2450
theorem observation2451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2451
theorem observation2452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2452
theorem observation2453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2453
theorem observation2454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2454
theorem observation2455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2455
theorem observation2456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2456
theorem observation2457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2457
theorem observation2458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2458
theorem observation2459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2459
theorem observation2460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2460
theorem observation2461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2461
theorem observation2462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2462
theorem observation2463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2463
theorem observation2464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2464
theorem observation2465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2465
theorem observation2466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2466
theorem observation2467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2467
theorem observation2468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2468
theorem observation2469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2469
theorem observation2470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2470
theorem observation2471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2471
theorem observation2472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2472
theorem observation2473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2473
theorem observation2474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2474
theorem observation2475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2475
theorem observation2476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2476
theorem observation2477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2477
theorem observation2478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2478
theorem observation2479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2479
theorem observation2480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2480
theorem observation2481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2481
theorem observation2482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2482
theorem observation2483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2483
theorem observation2484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2484
theorem observation2485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2485
theorem observation2486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2486
theorem observation2487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2487
theorem observation2488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2488
theorem observation2489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2489
theorem observation2490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2490
theorem observation2491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2491
theorem observation2492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2492
theorem observation2493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2493
theorem observation2494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2494
theorem observation2495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2495
theorem observation2496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2496
theorem observation2497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2497
theorem observation2498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2498
theorem observation2499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2499
theorem observation2500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2500
theorem observation2501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2501
theorem observation2502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2502
theorem observation2503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2503
theorem observation2504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2504
theorem observation2505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2505
theorem observation2506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2506
theorem observation2507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2507
theorem observation2508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2508
theorem observation2509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2509
theorem observation2510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2510
theorem observation2511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2511
theorem observation2512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2512
theorem observation2513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2513
theorem observation2514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2514
theorem observation2515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2515
theorem observation2516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2516
theorem observation2517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2517
theorem observation2518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2518
theorem observation2519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2519
theorem observation2520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2520
theorem observation2521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2521
theorem observation2522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2522
theorem observation2523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2523
theorem observation2524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2524
theorem observation2525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2525
theorem observation2526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2526
theorem observation2527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2527
theorem observation2528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2528
theorem observation2529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2529
theorem observation2530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2530
theorem observation2531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2531
theorem observation2532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2532
theorem observation2533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2533
theorem observation2534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2534
theorem observation2535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2535
theorem observation2536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2536
theorem observation2537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2537
theorem observation2538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2538
theorem observation2539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2539
theorem observation2540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2540
theorem observation2541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2541
theorem observation2542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2542
theorem observation2543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2543
theorem observation2544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2544
theorem observation2545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2545
theorem observation2546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2546
theorem observation2547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2547
theorem observation2548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2548
theorem observation2549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2549
theorem observation2550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2550
theorem observation2551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2551
theorem observation2552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2552
theorem observation2553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2553
theorem observation2554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2554
theorem observation2555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2555
theorem observation2556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2556
theorem observation2557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2557
theorem observation2558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2558
theorem observation2559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2559
theorem observation2560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2560
theorem observation2561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2561
theorem observation2562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2562
theorem observation2563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2563
theorem observation2564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2564
theorem observation2565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2565
theorem observation2566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2566
theorem observation2567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2567
theorem observation2568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2568
theorem observation2569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2569
theorem observation2570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2570
theorem observation2571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2571
theorem observation2572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2572
theorem observation2573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2573
theorem observation2574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2574
theorem observation2575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2575
theorem observation2576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2576
theorem observation2577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2577
theorem observation2578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2578
theorem observation2579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2579
theorem observation2580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2580
theorem observation2581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2581
theorem observation2582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2582
theorem observation2583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2583
theorem observation2584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2584
theorem observation2585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2585
theorem observation2586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2586
theorem observation2587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2587
theorem observation2588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2588
theorem observation2589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2589
theorem observation2590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2590
theorem observation2591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2591
theorem observation2592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2592
theorem observation2593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2593
theorem observation2594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2594
theorem observation2595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2595
theorem observation2596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2596
theorem observation2597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2597
theorem observation2598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2598
theorem observation2599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2599
theorem observation2600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2600
theorem observation2601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2601
theorem observation2602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2602
theorem observation2603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2603
theorem observation2604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2604
theorem observation2605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2605
theorem observation2606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2606
theorem observation2607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2607
theorem observation2608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2608
theorem observation2609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2609
theorem observation2610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2610
theorem observation2611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2611
theorem observation2612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2612
theorem observation2613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2613
theorem observation2614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2614
theorem observation2615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2615
theorem observation2616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2616
theorem observation2617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2617
theorem observation2618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2618
theorem observation2619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2619
theorem observation2620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2620
theorem observation2621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2621
theorem observation2622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2622
theorem observation2623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2623
theorem observation2624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2624
theorem observation2625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2625
theorem observation2626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2626
theorem observation2627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2627
theorem observation2628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2628
theorem observation2629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2629
theorem observation2630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2630
theorem observation2631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2631
theorem observation2632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2632
theorem observation2633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2633
theorem observation2634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2634
theorem observation2635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2635
theorem observation2636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2636
theorem observation2637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2637
theorem observation2638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2638
theorem observation2639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2639
theorem observation2640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2640
theorem observation2641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2641
theorem observation2642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2642
theorem observation2643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2643
theorem observation2644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2644
theorem observation2645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2645
theorem observation2646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2646
theorem observation2647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2647
theorem observation2648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2648
theorem observation2649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2649
theorem observation2650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2650
theorem observation2651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2651
theorem observation2652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2652
theorem observation2653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2653
theorem observation2654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2654
theorem observation2655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2655
theorem observation2656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2656
theorem observation2657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2657
theorem observation2658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2658
theorem observation2659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2659
theorem observation2660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2660
theorem observation2661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2661
theorem observation2662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2662
theorem observation2663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2663
theorem observation2664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2664
theorem observation2665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2665
theorem observation2666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2666
theorem observation2667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2667
theorem observation2668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2668
theorem observation2669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2669
theorem observation2670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2670
theorem observation2671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2671
theorem observation2672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2672
theorem observation2673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2673
theorem observation2674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2674
theorem observation2675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2675
theorem observation2676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2676
theorem observation2677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2677
theorem observation2678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2678
theorem observation2679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2679
theorem observation2680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2680
theorem observation2681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2681
theorem observation2682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2682
theorem observation2683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2683
theorem observation2684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2684
theorem observation2685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2685
theorem observation2686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2686
theorem observation2687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2687
theorem observation2688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2688
theorem observation2689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2689
theorem observation2690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2690
theorem observation2691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2691
theorem observation2692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2692
theorem observation2693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2693
theorem observation2694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2694
theorem observation2695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2695
theorem observation2696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2696
theorem observation2697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2697
theorem observation2698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2698
theorem observation2699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2699
theorem observation2700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2700
theorem observation2701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2701
theorem observation2702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2702
theorem observation2703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2703
theorem observation2704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2704
theorem observation2705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2705
theorem observation2706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2706
theorem observation2707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2707
theorem observation2708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2708
theorem observation2709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2709
theorem observation2710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2710
theorem observation2711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2711
theorem observation2712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2712
theorem observation2713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2713
theorem observation2714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2714
theorem observation2715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2715
theorem observation2716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2716
theorem observation2717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2717
theorem observation2718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2718
theorem observation2719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2719
theorem observation2720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2720
theorem observation2721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2721
theorem observation2722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2722
theorem observation2723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2723
theorem observation2724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2724
theorem observation2725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2725
theorem observation2726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2726
theorem observation2727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2727
theorem observation2728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2728
theorem observation2729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2729
theorem observation2730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2730
theorem observation2731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2731
theorem observation2732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2732
theorem observation2733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2733
theorem observation2734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2734
theorem observation2735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2735
theorem observation2736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2736
theorem observation2737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2737
theorem observation2738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2738
theorem observation2739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2739
theorem observation2740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2740
theorem observation2741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2741
theorem observation2742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2742
theorem observation2743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2743
theorem observation2744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2744
theorem observation2745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2745
theorem observation2746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2746
theorem observation2747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2747
theorem observation2748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2748
theorem observation2749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2749
theorem observation2750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2750
theorem observation2751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2751
theorem observation2752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2752
theorem observation2753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2753
theorem observation2754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2754
theorem observation2755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2755
theorem observation2756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2756
theorem observation2757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2757
theorem observation2758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2758
theorem observation2759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2759
theorem observation2760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2760
theorem observation2761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2761
theorem observation2762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2762
theorem observation2763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2763
theorem observation2764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2764
theorem observation2765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2765
theorem observation2766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2766
theorem observation2767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2767
theorem observation2768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2768
theorem observation2769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2769
theorem observation2770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2770
theorem observation2771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2771
theorem observation2772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2772
theorem observation2773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2773
theorem observation2774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2774
theorem observation2775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2775
theorem observation2776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2776
theorem observation2777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2777
theorem observation2778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2778
theorem observation2779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2779
theorem observation2780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2780
theorem observation2781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2781
theorem observation2782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2782
theorem observation2783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2783
theorem observation2784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2784
theorem observation2785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2785
theorem observation2786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2786
theorem observation2787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2787
theorem observation2788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2788
theorem observation2789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2789
theorem observation2790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2790
theorem observation2791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2791
theorem observation2792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2792
theorem observation2793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2793
theorem observation2794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2794
theorem observation2795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2795
theorem observation2796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2796
theorem observation2797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2797
theorem observation2798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2798
theorem observation2799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2799
theorem observation2800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2800
theorem observation2801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2801
theorem observation2802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2802
theorem observation2803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2803
theorem observation2804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2804
theorem observation2805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2805
theorem observation2806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2806
theorem observation2807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2807
theorem observation2808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2808
theorem observation2809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2809
theorem observation2810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2810
theorem observation2811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2811
theorem observation2812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2812
theorem observation2813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2813
theorem observation2814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2814
theorem observation2815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2815
theorem observation2816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2816
theorem observation2817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2817
theorem observation2818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2818
theorem observation2819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2819
theorem observation2820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2820
theorem observation2821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2821
theorem observation2822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2822
theorem observation2823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2823
theorem observation2824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2824
theorem observation2825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2825
theorem observation2826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2826
theorem observation2827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2827
theorem observation2828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2828
theorem observation2829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2829
theorem observation2830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2830
theorem observation2831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2831
theorem observation2832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2832
theorem observation2833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2833
theorem observation2834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2834
theorem observation2835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2835
theorem observation2836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2836
theorem observation2837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2837
theorem observation2838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2838
theorem observation2839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2839
theorem observation2840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2840
theorem observation2841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2841
theorem observation2842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2842
theorem observation2843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2843
theorem observation2844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2844
theorem observation2845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2845
theorem observation2846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2846
theorem observation2847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2847
theorem observation2848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2848
theorem observation2849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2849
theorem observation2850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2850
theorem observation2851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2851
theorem observation2852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2852
theorem observation2853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2853
theorem observation2854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2854
theorem observation2855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2855
theorem observation2856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2856
theorem observation2857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2857
theorem observation2858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2858
theorem observation2859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2859
theorem observation2860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2860
theorem observation2861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2861
theorem observation2862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2862
theorem observation2863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2863
theorem observation2864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2864
theorem observation2865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2865
theorem observation2866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2866
theorem observation2867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2867
theorem observation2868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2868
theorem observation2869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2869
theorem observation2870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2870
theorem observation2871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2871
theorem observation2872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2872
theorem observation2873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2873
theorem observation2874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2874
theorem observation2875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2875
theorem observation2876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2876
theorem observation2877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2877
theorem observation2878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2878
theorem observation2879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2879
theorem observation2880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2880
theorem observation2881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2881
theorem observation2882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2882
theorem observation2883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2883
theorem observation2884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2884
theorem observation2885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2885
theorem observation2886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2886
theorem observation2887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2887
theorem observation2888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2888
theorem observation2889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2889
theorem observation2890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2890
theorem observation2891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2891
theorem observation2892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2892
theorem observation2893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2893
theorem observation2894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2894
theorem observation2895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2895
theorem observation2896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2896
theorem observation2897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2897
theorem observation2898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2898
theorem observation2899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2899
theorem observation2900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2900
theorem observation2901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2901
theorem observation2902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2902
theorem observation2903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2903
theorem observation2904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2904
theorem observation2905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2905
theorem observation2906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2906
theorem observation2907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2907
theorem observation2908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2908
theorem observation2909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2909
theorem observation2910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2910
theorem observation2911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2911
theorem observation2912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2912
theorem observation2913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2913
theorem observation2914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2914
theorem observation2915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2915
theorem observation2916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2916
theorem observation2917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2917
theorem observation2918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2918
theorem observation2919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2919
theorem observation2920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2920
theorem observation2921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2921
theorem observation2922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2922
theorem observation2923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2923
theorem observation2924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2924
theorem observation2925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2925
theorem observation2926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2926
theorem observation2927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2927
theorem observation2928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2928
theorem observation2929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2929
theorem observation2930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2930
theorem observation2931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2931
theorem observation2932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2932
theorem observation2933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2933
theorem observation2934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2934
theorem observation2935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2935
theorem observation2936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2936
theorem observation2937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2937
theorem observation2938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2938
theorem observation2939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2939
theorem observation2940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2940
theorem observation2941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2941
theorem observation2942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2942
theorem observation2943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2943
theorem observation2944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2944
theorem observation2945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2945
theorem observation2946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2946
theorem observation2947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2947
theorem observation2948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2948
theorem observation2949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2949
theorem observation2950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2950
theorem observation2951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2951
theorem observation2952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2952
theorem observation2953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2953
theorem observation2954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2954
theorem observation2955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2955
theorem observation2956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2956
theorem observation2957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2957
theorem observation2958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2958
theorem observation2959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2959
theorem observation2960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2960
theorem observation2961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2961
theorem observation2962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2962
theorem observation2963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2963
theorem observation2964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2964
theorem observation2965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2965
theorem observation2966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2966
theorem observation2967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2967
theorem observation2968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2968
theorem observation2969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2969
theorem observation2970 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2970
theorem observation2971 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2971
theorem observation2972 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2972
theorem observation2973 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2973
theorem observation2974 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2974
theorem observation2975 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2975
theorem observation2976 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2976
theorem observation2977 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2977
theorem observation2978 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2978
theorem observation2979 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2979
theorem observation2980 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2980
theorem observation2981 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2981
theorem observation2982 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2982
theorem observation2983 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2983
theorem observation2984 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2984
theorem observation2985 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2985
theorem observation2986 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2986
theorem observation2987 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2987
theorem observation2988 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2988
theorem observation2989 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2989
theorem observation2990 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2990
theorem observation2991 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2991
theorem observation2992 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2992
theorem observation2993 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2993
theorem observation2994 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2994
theorem observation2995 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2995
theorem observation2996 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2996
theorem observation2997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2997
theorem observation2998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2998
theorem observation2999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation2999
theorem observation3000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3000
theorem observation3001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3001
theorem observation3002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3002
theorem observation3003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3003
theorem observation3004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3004
theorem observation3005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3005
theorem observation3006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3006
theorem observation3007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3007
theorem observation3008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3008
theorem observation3009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3009
theorem observation3010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3010
theorem observation3011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3011
theorem observation3012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3012
theorem observation3013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3013
theorem observation3014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3014
theorem observation3015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3015
theorem observation3016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3016
theorem observation3017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3017
theorem observation3018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3018
theorem observation3019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3019
theorem observation3020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3020
theorem observation3021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3021
theorem observation3022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3022
theorem observation3023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3023
theorem observation3024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3024
theorem observation3025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3025
theorem observation3026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3026
theorem observation3027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3027
theorem observation3028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3028
theorem observation3029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3029
theorem observation3030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3030
theorem observation3031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3031
theorem observation3032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3032
theorem observation3033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3033
theorem observation3034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3034
theorem observation3035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3035
theorem observation3036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3036
theorem observation3037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3037
theorem observation3038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3038
theorem observation3039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3039
theorem observation3040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3040
theorem observation3041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3041
theorem observation3042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3042
theorem observation3043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3043
theorem observation3044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3044
theorem observation3045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3045
theorem observation3046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3046
theorem observation3047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3047
theorem observation3048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3048
theorem observation3049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3049
theorem observation3050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3050
theorem observation3051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3051
theorem observation3052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3052
theorem observation3053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3053
theorem observation3054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3054
theorem observation3055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3055
theorem observation3056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3056
theorem observation3057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3057
theorem observation3058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3058
theorem observation3059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3059
theorem observation3060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3060
theorem observation3061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3061
theorem observation3062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3062
theorem observation3063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3063
theorem observation3064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3064
theorem observation3065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3065
theorem observation3066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3066
theorem observation3067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3067
theorem observation3068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3068
theorem observation3069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3069
theorem observation3070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3070
theorem observation3071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3071
theorem observation3072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3072
theorem observation3073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3073
theorem observation3074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3074
theorem observation3075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3075
theorem observation3076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3076
theorem observation3077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3077
theorem observation3078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3078
theorem observation3079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3079
theorem observation3080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3080
theorem observation3081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3081
theorem observation3082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3082
theorem observation3083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3083
theorem observation3084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3084
theorem observation3085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3085
theorem observation3086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3086
theorem observation3087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3087
theorem observation3088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3088
theorem observation3089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3089
theorem observation3090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3090
theorem observation3091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3091
theorem observation3092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3092
theorem observation3093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3093
theorem observation3094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3094
theorem observation3095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3095
theorem observation3096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3096
theorem observation3097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3097
theorem observation3098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3098
theorem observation3099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3099
theorem observation3100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3100
theorem observation3101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3101
theorem observation3102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3102
theorem observation3103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3103
theorem observation3104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3104
theorem observation3105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3105
theorem observation3106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3106
theorem observation3107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3107
theorem observation3108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3108
theorem observation3109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3109
theorem observation3110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3110
theorem observation3111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3111
theorem observation3112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3112
theorem observation3113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3113
theorem observation3114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3114
theorem observation3115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3115
theorem observation3116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3116
theorem observation3117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3117
theorem observation3118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3118
theorem observation3119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3119
theorem observation3120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3120
theorem observation3121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3121
theorem observation3122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3122
theorem observation3123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3123
theorem observation3124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3124
theorem observation3125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3125
theorem observation3126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3126
theorem observation3127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3127
theorem observation3128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3128
theorem observation3129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3129
theorem observation3130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3130
theorem observation3131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3131
theorem observation3132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3132
theorem observation3133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3133
theorem observation3134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3134
theorem observation3135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3135
theorem observation3136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3136
theorem observation3137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3137
theorem observation3138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3138
theorem observation3139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3139
theorem observation3140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3140
theorem observation3141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3141
theorem observation3142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3142
theorem observation3143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3143
theorem observation3144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3144
theorem observation3145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3145
theorem observation3146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3146
theorem observation3147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3147
theorem observation3148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3148
theorem observation3149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3149
theorem observation3150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3150
theorem observation3151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3151
theorem observation3152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3152
theorem observation3153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3153
theorem observation3154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3154
theorem observation3155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3155
theorem observation3156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3156
theorem observation3157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3157
theorem observation3158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3158
theorem observation3159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3159
theorem observation3160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3160
theorem observation3161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3161
theorem observation3162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3162
theorem observation3163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3163
theorem observation3164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3164
theorem observation3165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3165
theorem observation3166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3166
theorem observation3167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3167
theorem observation3168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3168
theorem observation3169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3169
theorem observation3170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3170
theorem observation3171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3171
theorem observation3172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3172
theorem observation3173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3173
theorem observation3174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3174
theorem observation3175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3175
theorem observation3176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3176
theorem observation3177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3177
theorem observation3178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3178
theorem observation3179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3179
theorem observation3180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3180
theorem observation3181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3181
theorem observation3182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3182
theorem observation3183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3183
theorem observation3184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3184
theorem observation3185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3185
theorem observation3186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3186
theorem observation3187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3187
theorem observation3188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3188
theorem observation3189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3189
theorem observation3190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3190
theorem observation3191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3191
theorem observation3192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3192
theorem observation3193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3193
theorem observation3194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3194
theorem observation3195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3195
theorem observation3196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3196
theorem observation3197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3197
theorem observation3198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3198
theorem observation3199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3199
theorem observation3200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3200
theorem observation3201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3201
theorem observation3202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3202
theorem observation3203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3203
theorem observation3204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3204
theorem observation3205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3205
theorem observation3206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3206
theorem observation3207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3207
theorem observation3208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3208
theorem observation3209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3209
theorem observation3210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3210
theorem observation3211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3211
theorem observation3212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3212
theorem observation3213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3213
theorem observation3214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3214
theorem observation3215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3215
theorem observation3216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3216
theorem observation3217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3217
theorem observation3218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3218
theorem observation3219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3219
theorem observation3220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3220
theorem observation3221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3221
theorem observation3222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3222
theorem observation3223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3223
theorem observation3224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3224
theorem observation3225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3225
theorem observation3226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3226
theorem observation3227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3227
theorem observation3228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3228
theorem observation3229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3229
theorem observation3230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3230
theorem observation3231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3231
theorem observation3232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3232
theorem observation3233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3233
theorem observation3234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3234
theorem observation3235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3235
theorem observation3236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3236
theorem observation3237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3237
theorem observation3238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3238
theorem observation3239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3239
theorem observation3240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3240
theorem observation3241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3241
theorem observation3242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3242
theorem observation3243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3243
theorem observation3244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3244
theorem observation3245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3245
theorem observation3246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3246
theorem observation3247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3247
theorem observation3248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3248
theorem observation3249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3249
theorem observation3250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3250
theorem observation3251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3251
theorem observation3252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3252
theorem observation3253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3253
theorem observation3254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3254
theorem observation3255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3255
theorem observation3256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3256
theorem observation3257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3257
theorem observation3258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3258
theorem observation3259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3259
theorem observation3260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3260
theorem observation3261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3261
theorem observation3262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3262
theorem observation3263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3263
theorem observation3264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3264
theorem observation3265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3265
theorem observation3266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3266
theorem observation3267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3267
theorem observation3268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3268
theorem observation3269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3269
theorem observation3270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3270
theorem observation3271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3271
theorem observation3272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3272
theorem observation3273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3273
theorem observation3274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3274
theorem observation3275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3275
theorem observation3276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3276
theorem observation3277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3277
theorem observation3278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3278
theorem observation3279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3279
theorem observation3280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3280
theorem observation3281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3281
theorem observation3282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3282
theorem observation3283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3283
theorem observation3284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3284
theorem observation3285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3285
theorem observation3286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3286
theorem observation3287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3287
theorem observation3288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3288
theorem observation3289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3289
theorem observation3290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3290
theorem observation3291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3291
theorem observation3292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3292
theorem observation3293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3293
theorem observation3294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3294
theorem observation3295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3295
theorem observation3296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3296
theorem observation3297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3297
theorem observation3298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3298
theorem observation3299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3299
theorem observation3300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3300
theorem observation3301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3301
theorem observation3302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3302
theorem observation3303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3303
theorem observation3304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3304
theorem observation3305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3305
theorem observation3306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3306
theorem observation3307 : k272 = k272 /\ k322 = k322 /\ "VERIFIED" = "VERIFIED" /\ publishes [k7, k9, k270, k10, k271, k321, k4, k6, k8, k269] k290 = true := by decide
#print axioms observation3307
theorem observation3308 : k290 = k290 /\ k290 = k290 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3308 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k278, k281, k27] k44 = some k290 := by decide
#print axioms observation3308
theorem observation3309 : k338 = k338 /\ k338 = k338 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3309
theorem observation3310 : k332 = k332 /\ k332 = k332 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3310
theorem observation3311 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3311
theorem observation3312 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3312
theorem observation3313 : k296 = k296 /\ k296 = k296 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family) .exact k296 = true := by decide
#print axioms observation3313
theorem observation3314 : k303 = k303 /\ k303 = k303 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family) .exact k303 = true := by decide
#print axioms observation3314
theorem observation3315 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3315
theorem observation3316 : k272 = k272 /\ k273 = k273 /\ "VERIFIED" = "VERIFIED" /\ publishes [k7, k9, k270, k10, k271, k4, k6, k8, k269] k290 = true := by decide
#print axioms observation3316
theorem observation3317 : k290 = k290 /\ k290 = k290 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3317 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k278, k281, k27] k44 = some k290 := by decide
#print axioms observation3317
theorem observation3318 : k343 = k343 /\ k343 = k343 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3318
theorem observation3319 : k307 = k307 /\ k307 = k307 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3319
theorem observation3320 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3320
theorem observation3321 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3321
theorem observation3322 : k296 = k296 /\ k296 = k296 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family) .exact k296 = true := by decide
#print axioms observation3322
theorem observation3323 : k303 = k303 /\ k303 = k303 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family) .exact k303 = true := by decide
#print axioms observation3323
theorem observation3324 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3324
theorem observation3325 : k272 = k272 /\ k322 = k322 /\ "VERIFIED" = "VERIFIED" /\ publishes [k7, k9, k270, k10, k271, k321, k4, k6, k8, k269] k290 = true := by decide
#print axioms observation3325
theorem observation3326 : k290 = k290 /\ k290 = k290 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3326 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k278, k281, k27] k44 = some k290 := by decide
#print axioms observation3326
theorem observation3327 : k348 = k348 /\ k348 = k348 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3327
theorem observation3328 : k332 = k332 /\ k332 = k332 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3328
theorem observation3329 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3329
theorem observation3330 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3330
theorem observation3331 : k296 = k296 /\ k296 = k296 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "univ"]] } : Family) .exact k296 = true := by decide
#print axioms observation3331
theorem observation3332 : k303 = k303 /\ k303 = k303 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family)) ({ arity := 2, products := [[.sig "univ", .sig "B"]] } : Family) .exact k303 = true := by decide
#print axioms observation3332
theorem observation3333 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3333
theorem observation3334 : k350 = k350 /\ k351 = k351 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k10, k4, k6, k8, k349] k360 = true := by decide
#print axioms observation3334
theorem observation3335 : k360 = k360 /\ k360 = k360 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3335 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k354, k27] k354 = some k360 := by decide
#print axioms observation3335
theorem observation3336 : k385 = k385 /\ k385 = k385 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3336
theorem observation3337 : k371 = k371 /\ k371 = k371 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3337
theorem observation3338 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3338
theorem observation3339 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3339
theorem observation3340 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3340
theorem observation3341 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation3341
theorem observation3342 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3342
theorem observation3343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3343
theorem observation3344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3344
theorem observation3345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3345
theorem observation3346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3346
theorem observation3347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3347
theorem observation3348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3348
theorem observation3349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3349
theorem observation3350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3350
theorem observation3351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3351
theorem observation3352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3352
theorem observation3353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3353
theorem observation3354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3354
theorem observation3355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3355
theorem observation3356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3356
theorem observation3357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3357
theorem observation3358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3358
theorem observation3359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3359
theorem observation3360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3360
theorem observation3361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3361
theorem observation3362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3362
theorem observation3363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3363
theorem observation3364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3364
theorem observation3365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3365
theorem observation3366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3366
theorem observation3367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3367
theorem observation3368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3368
theorem observation3369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3369
theorem observation3370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3370
theorem observation3371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3371
theorem observation3372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3372
theorem observation3373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3373
theorem observation3374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3374
theorem observation3375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3375
theorem observation3376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3376
theorem observation3377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3377
theorem observation3378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3378
theorem observation3379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3379
theorem observation3380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3380
theorem observation3381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3381
theorem observation3382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3382
theorem observation3383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3383
theorem observation3384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3384
theorem observation3385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3385
theorem observation3386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3386
theorem observation3387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3387
theorem observation3388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3388
theorem observation3389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3389
theorem observation3390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3390
theorem observation3391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3391
theorem observation3392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3392
theorem observation3393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3393
theorem observation3394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3394
theorem observation3395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3395
theorem observation3396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3396
theorem observation3397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3397
theorem observation3398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3398
theorem observation3399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3399
theorem observation3400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3400
theorem observation3401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3401
theorem observation3402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3402
theorem observation3403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3403
theorem observation3404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3404
theorem observation3405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3405
theorem observation3406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3406
theorem observation3407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3407
theorem observation3408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3408
theorem observation3409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3409
theorem observation3410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3410
theorem observation3411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3411
theorem observation3412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3412
theorem observation3413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3413
theorem observation3414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3414
theorem observation3415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3415
theorem observation3416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3416
theorem observation3417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3417
theorem observation3418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3418
theorem observation3419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3419
theorem observation3420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3420
theorem observation3421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3421
theorem observation3422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3422
theorem observation3423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3423
theorem observation3424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3424
theorem observation3425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3425
theorem observation3426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3426
theorem observation3427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3427
theorem observation3428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3428
theorem observation3429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3429
theorem observation3430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3430
theorem observation3431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3431
theorem observation3432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3432
theorem observation3433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3433
theorem observation3434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3434
theorem observation3435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3435
theorem observation3436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3436
theorem observation3437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3437
theorem observation3438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3438
theorem observation3439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3439
theorem observation3440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3440
theorem observation3441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3441
theorem observation3442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3442
theorem observation3443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3443
theorem observation3444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3444
theorem observation3445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3445
theorem observation3446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3446
theorem observation3447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3447
theorem observation3448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3448
theorem observation3449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3449
theorem observation3450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3450
theorem observation3451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3451
theorem observation3452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3452
theorem observation3453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3453
theorem observation3454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3454
theorem observation3455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3455
theorem observation3456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3456
theorem observation3457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3457
theorem observation3458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3458
theorem observation3459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3459
theorem observation3460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3460
theorem observation3461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3461
theorem observation3462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3462
theorem observation3463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3463
theorem observation3464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3464
theorem observation3465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3465
theorem observation3466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3466
theorem observation3467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3467
theorem observation3468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3468
theorem observation3469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3469
theorem observation3470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3470
theorem observation3471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3471
theorem observation3472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3472
theorem observation3473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3473
theorem observation3474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3474
theorem observation3475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3475
theorem observation3476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3476
theorem observation3477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3477
theorem observation3478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3478
theorem observation3479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3479
theorem observation3480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3480
theorem observation3481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3481
theorem observation3482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3482
theorem observation3483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3483
theorem observation3484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3484
theorem observation3485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3485
theorem observation3486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3486
theorem observation3487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3487
theorem observation3488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3488
theorem observation3489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3489
theorem observation3490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3490
theorem observation3491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3491
theorem observation3492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3492
theorem observation3493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3493
theorem observation3494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3494
theorem observation3495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3495
theorem observation3496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3496
theorem observation3497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3497
theorem observation3498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3498
theorem observation3499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3499
theorem observation3500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3500
theorem observation3501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3501
theorem observation3502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3502
theorem observation3503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3503
theorem observation3504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3504
theorem observation3505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3505
theorem observation3506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3506
theorem observation3507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3507
theorem observation3508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3508
theorem observation3509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3509
theorem observation3510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3510
theorem observation3511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3511
theorem observation3512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3512
theorem observation3513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3513
theorem observation3514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3514
theorem observation3515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3515
theorem observation3516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3516
theorem observation3517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3517
theorem observation3518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3518
theorem observation3519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3519
theorem observation3520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3520
theorem observation3521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3521
theorem observation3522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3522
theorem observation3523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3523
theorem observation3524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3524
theorem observation3525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3525
theorem observation3526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3526
theorem observation3527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3527
theorem observation3528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3528
theorem observation3529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3529
theorem observation3530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3530
theorem observation3531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3531
theorem observation3532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3532
theorem observation3533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3533
theorem observation3534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3534
theorem observation3535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3535
theorem observation3536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3536
theorem observation3537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3537
theorem observation3538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3538
theorem observation3539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3539
theorem observation3540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3540
theorem observation3541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3541
theorem observation3542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3542
theorem observation3543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3543
theorem observation3544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3544
theorem observation3545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3545
theorem observation3546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3546
theorem observation3547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3547
theorem observation3548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3548
theorem observation3549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3549
theorem observation3550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3550
theorem observation3551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3551
theorem observation3552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3552
theorem observation3553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3553
theorem observation3554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3554
theorem observation3555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3555
theorem observation3556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3556
theorem observation3557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3557
theorem observation3558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3558
theorem observation3559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3559
theorem observation3560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3560
theorem observation3561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3561
theorem observation3562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3562
theorem observation3563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3563
theorem observation3564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3564
theorem observation3565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3565
theorem observation3566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3566
theorem observation3567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3567
theorem observation3568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3568
theorem observation3569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3569
theorem observation3570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3570
theorem observation3571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3571
theorem observation3572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3572
theorem observation3573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3573
theorem observation3574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3574
theorem observation3575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3575
theorem observation3576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3576
theorem observation3577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3577
theorem observation3578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3578
theorem observation3579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3579
theorem observation3580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3580
theorem observation3581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3581
theorem observation3582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3582
theorem observation3583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3583
theorem observation3584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3584
theorem observation3585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3585
theorem observation3586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3586
theorem observation3587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3587
theorem observation3588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3588
theorem observation3589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3589
theorem observation3590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3590
theorem observation3591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3591
theorem observation3592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3592
theorem observation3593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3593
theorem observation3594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3594
theorem observation3595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3595
theorem observation3596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3596
theorem observation3597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3597
theorem observation3598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3598
theorem observation3599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3599
theorem observation3600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3600
theorem observation3601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3601
theorem observation3602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3602
theorem observation3603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3603
theorem observation3604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3604
theorem observation3605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3605
theorem observation3606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3606
theorem observation3607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3607
theorem observation3608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3608
theorem observation3609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3609
theorem observation3610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3610
theorem observation3611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3611
theorem observation3612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3612
theorem observation3613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3613
theorem observation3614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3614
theorem observation3615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3615
theorem observation3616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3616
theorem observation3617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3617
theorem observation3618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3618
theorem observation3619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3619
theorem observation3620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3620
theorem observation3621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3621
theorem observation3622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3622
theorem observation3623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3623
theorem observation3624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3624
theorem observation3625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3625
theorem observation3626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3626
theorem observation3627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3627
theorem observation3628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3628
theorem observation3629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3629
theorem observation3630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3630
theorem observation3631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3631
theorem observation3632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3632
theorem observation3633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3633
theorem observation3634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3634
theorem observation3635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3635
theorem observation3636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3636
theorem observation3637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3637
theorem observation3638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3638
theorem observation3639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3639
theorem observation3640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3640
theorem observation3641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3641
theorem observation3642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3642
theorem observation3643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3643
theorem observation3644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3644
theorem observation3645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3645
theorem observation3646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3646
theorem observation3647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3647
theorem observation3648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3648
theorem observation3649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3649
theorem observation3650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3650
theorem observation3651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3651
theorem observation3652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3652
theorem observation3653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3653
theorem observation3654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3654
theorem observation3655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3655
theorem observation3656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3656
theorem observation3657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3657
theorem observation3658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3658
theorem observation3659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3659
theorem observation3660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3660
theorem observation3661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3661
theorem observation3662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3662
theorem observation3663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3663
theorem observation3664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3664
theorem observation3665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3665
theorem observation3666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3666
theorem observation3667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3667
theorem observation3668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3668
theorem observation3669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3669
theorem observation3670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3670
theorem observation3671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3671
theorem observation3672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3672
theorem observation3673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3673
theorem observation3674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3674
theorem observation3675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3675
theorem observation3676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3676
theorem observation3677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3677
theorem observation3678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3678
theorem observation3679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3679
theorem observation3680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3680
theorem observation3681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3681
theorem observation3682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3682
theorem observation3683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3683
theorem observation3684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3684
theorem observation3685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3685
theorem observation3686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3686
theorem observation3687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3687
theorem observation3688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3688
theorem observation3689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3689
theorem observation3690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3690
theorem observation3691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3691
theorem observation3692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3692
theorem observation3693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3693
theorem observation3694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3694
theorem observation3695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3695
theorem observation3696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3696
theorem observation3697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3697
theorem observation3698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3698
theorem observation3699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3699
theorem observation3700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3700
theorem observation3701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3701
theorem observation3702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3702
theorem observation3703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3703
theorem observation3704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3704
theorem observation3705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3705
theorem observation3706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3706
theorem observation3707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3707
theorem observation3708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3708
theorem observation3709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3709
theorem observation3710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3710
theorem observation3711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3711
theorem observation3712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3712
theorem observation3713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3713
theorem observation3714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3714
theorem observation3715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3715
theorem observation3716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3716
theorem observation3717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3717
theorem observation3718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3718
theorem observation3719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3719
theorem observation3720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3720
theorem observation3721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3721
theorem observation3722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3722
theorem observation3723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3723
theorem observation3724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3724
theorem observation3725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3725
theorem observation3726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3726
theorem observation3727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3727
theorem observation3728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3728
theorem observation3729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3729
theorem observation3730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3730
theorem observation3731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3731
theorem observation3732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3732
theorem observation3733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3733
theorem observation3734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3734
theorem observation3735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3735
theorem observation3736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3736
theorem observation3737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3737
theorem observation3738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3738
theorem observation3739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3739
theorem observation3740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3740
theorem observation3741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3741
theorem observation3742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3742
theorem observation3743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3743
theorem observation3744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3744
theorem observation3745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3745
theorem observation3746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3746
theorem observation3747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3747
theorem observation3748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3748
theorem observation3749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3749
theorem observation3750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3750
theorem observation3751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3751
theorem observation3752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3752
theorem observation3753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3753
theorem observation3754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3754
theorem observation3755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3755
theorem observation3756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3756
theorem observation3757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3757
theorem observation3758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3758
theorem observation3759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3759
theorem observation3760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3760
theorem observation3761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3761
theorem observation3762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3762
theorem observation3763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3763
theorem observation3764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3764
theorem observation3765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3765
theorem observation3766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3766
theorem observation3767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3767
theorem observation3768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3768
theorem observation3769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3769
theorem observation3770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3770
theorem observation3771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3771
theorem observation3772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3772
theorem observation3773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3773
theorem observation3774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3774
theorem observation3775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3775
theorem observation3776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3776
theorem observation3777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3777
theorem observation3778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3778
theorem observation3779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3779
theorem observation3780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3780
theorem observation3781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3781
theorem observation3782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3782
theorem observation3783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3783
theorem observation3784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3784
theorem observation3785 : k350 = k350 /\ k351 = k351 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k10, k4, k6, k8, k349] k360 = true := by decide
#print axioms observation3785
theorem observation3786 : k360 = k360 /\ k360 = k360 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3786 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k354, k27] k354 = some k360 := by decide
#print axioms observation3786
theorem observation3787 : k393 = k393 /\ k393 = k393 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3787
theorem observation3788 : k387 = k387 /\ k387 = k387 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3788
theorem observation3789 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3789
theorem observation3790 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3790
theorem observation3791 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3791
theorem observation3792 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation3792
theorem observation3793 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3793
theorem observation3794 : k350 = k350 /\ k351 = k351 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k10, k4, k6, k8, k349] k360 = true := by decide
#print axioms observation3794
theorem observation3795 : k360 = k360 /\ k360 = k360 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3795 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k354, k27] k354 = some k360 := by decide
#print axioms observation3795
theorem observation3796 : k398 = k398 /\ k398 = k398 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3796
theorem observation3797 : k371 = k371 /\ k371 = k371 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3797
theorem observation3798 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3798
theorem observation3799 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3799
theorem observation3800 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3800
theorem observation3801 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation3801
theorem observation3802 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3802
theorem observation3803 : k350 = k350 /\ k351 = k351 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k10, k4, k6, k8, k349] k360 = true := by decide
#print axioms observation3803
theorem observation3804 : k360 = k360 /\ k360 = k360 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3804 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k354, k27] k354 = some k360 := by decide
#print axioms observation3804
theorem observation3805 : k403 = k403 /\ k403 = k403 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3805
theorem observation3806 : k387 = k387 /\ k387 = k387 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3806
theorem observation3807 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3807
theorem observation3808 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3808
theorem observation3809 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3809
theorem observation3810 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation3810
theorem observation3811 : k73 = k73 /\ k73 = k73 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family)) ({ arity := 2, products := [[.sig "B", .sig "C"]] } : Family) .exact k73 = true := by decide
#print axioms observation3811
theorem observation3812 : k404 = k404 /\ k405 = k405 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k4] k413 = true := by decide
#print axioms observation3812
theorem observation3813 : k413 = k413 /\ k413 = k413 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine3813 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k17, k17] k17 = some k413 := by decide
#print axioms observation3813
theorem observation3814 : k431 = k431 /\ k431 = k431 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3814
theorem observation3815 : k417 = k417 /\ k417 = k417 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3815
theorem observation3816 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation3816
theorem observation3817 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation3817
theorem observation3818 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3818
theorem observation3819 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3819
theorem observation3820 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation3820
theorem observation3821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3821
theorem observation3822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3822
theorem observation3823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3823
theorem observation3824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3824
theorem observation3825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3825
theorem observation3826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3826
theorem observation3827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3827
theorem observation3828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3828
theorem observation3829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3829
theorem observation3830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3830
theorem observation3831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3831
theorem observation3832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3832
theorem observation3833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3833
theorem observation3834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3834
theorem observation3835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3835
theorem observation3836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3836
theorem observation3837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3837
theorem observation3838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3838
theorem observation3839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3839
theorem observation3840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3840
theorem observation3841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3841
theorem observation3842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3842
theorem observation3843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3843
theorem observation3844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3844
theorem observation3845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3845
theorem observation3846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3846
theorem observation3847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3847
theorem observation3848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3848
theorem observation3849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3849
theorem observation3850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3850
theorem observation3851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3851
theorem observation3852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3852
theorem observation3853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3853
theorem observation3854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3854
theorem observation3855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3855
theorem observation3856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3856
theorem observation3857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3857
theorem observation3858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3858
theorem observation3859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3859
theorem observation3860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3860
theorem observation3861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3861
theorem observation3862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3862
theorem observation3863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3863
theorem observation3864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3864
theorem observation3865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3865
theorem observation3866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3866
theorem observation3867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3867
theorem observation3868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3868
theorem observation3869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3869
theorem observation3870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3870
theorem observation3871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3871
theorem observation3872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3872
theorem observation3873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3873
theorem observation3874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3874
theorem observation3875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3875
theorem observation3876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3876
theorem observation3877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3877
theorem observation3878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3878
theorem observation3879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3879
theorem observation3880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3880
theorem observation3881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3881
theorem observation3882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3882
theorem observation3883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3883
theorem observation3884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3884
theorem observation3885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3885
theorem observation3886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3886
theorem observation3887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3887
theorem observation3888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3888
theorem observation3889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3889
theorem observation3890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3890
theorem observation3891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3891
theorem observation3892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3892
theorem observation3893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3893
theorem observation3894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3894
theorem observation3895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3895
theorem observation3896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3896
theorem observation3897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3897
theorem observation3898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3898
theorem observation3899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3899
theorem observation3900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3900
theorem observation3901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3901
theorem observation3902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3902
theorem observation3903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3903
theorem observation3904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3904
theorem observation3905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3905
theorem observation3906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3906
theorem observation3907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3907
theorem observation3908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3908
theorem observation3909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3909
theorem observation3910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3910
theorem observation3911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3911
theorem observation3912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3912
theorem observation3913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3913
theorem observation3914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3914
theorem observation3915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3915
theorem observation3916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3916
theorem observation3917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3917
theorem observation3918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3918
theorem observation3919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3919
theorem observation3920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3920
theorem observation3921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3921
theorem observation3922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3922
theorem observation3923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3923
theorem observation3924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3924
theorem observation3925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3925
theorem observation3926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3926
theorem observation3927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3927
theorem observation3928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3928
theorem observation3929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3929
theorem observation3930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3930
theorem observation3931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3931
theorem observation3932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3932
theorem observation3933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3933
theorem observation3934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3934
theorem observation3935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3935
theorem observation3936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3936
theorem observation3937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3937
theorem observation3938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3938
theorem observation3939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3939
theorem observation3940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3940
theorem observation3941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3941
theorem observation3942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3942
theorem observation3943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3943
theorem observation3944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3944
theorem observation3945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3945
theorem observation3946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3946
theorem observation3947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3947
theorem observation3948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3948
theorem observation3949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3949
theorem observation3950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3950
theorem observation3951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3951
theorem observation3952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3952
theorem observation3953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3953
theorem observation3954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3954
theorem observation3955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3955
theorem observation3956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3956
theorem observation3957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3957
theorem observation3958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3958
theorem observation3959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3959
theorem observation3960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3960
theorem observation3961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3961
theorem observation3962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3962
theorem observation3963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3963
theorem observation3964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3964
theorem observation3965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3965
theorem observation3966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3966
theorem observation3967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3967
theorem observation3968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3968
theorem observation3969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3969
theorem observation3970 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3970
theorem observation3971 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3971
theorem observation3972 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3972
theorem observation3973 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3973
theorem observation3974 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3974
theorem observation3975 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3975
theorem observation3976 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3976
theorem observation3977 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3977
theorem observation3978 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3978
theorem observation3979 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3979
theorem observation3980 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3980
theorem observation3981 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3981
theorem observation3982 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3982
theorem observation3983 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3983
theorem observation3984 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3984
theorem observation3985 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3985
theorem observation3986 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3986
theorem observation3987 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3987
theorem observation3988 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3988
theorem observation3989 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3989
theorem observation3990 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3990
theorem observation3991 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3991
theorem observation3992 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3992
theorem observation3993 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3993
theorem observation3994 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3994
theorem observation3995 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3995
theorem observation3996 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3996
theorem observation3997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3997
theorem observation3998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3998
theorem observation3999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation3999
theorem observation4000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4000
theorem observation4001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4001
theorem observation4002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4002
theorem observation4003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4003
theorem observation4004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4004
theorem observation4005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4005
theorem observation4006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4006
theorem observation4007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4007
theorem observation4008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4008
theorem observation4009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4009
theorem observation4010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4010
theorem observation4011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4011
theorem observation4012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4012
theorem observation4013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4013
theorem observation4014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4014
theorem observation4015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4015
theorem observation4016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4016
theorem observation4017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4017
theorem observation4018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4018
theorem observation4019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4019
theorem observation4020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4020
theorem observation4021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4021
theorem observation4022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4022
theorem observation4023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4023
theorem observation4024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4024
theorem observation4025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4025
theorem observation4026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4026
theorem observation4027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4027
theorem observation4028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4028
theorem observation4029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4029
theorem observation4030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4030
theorem observation4031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4031
theorem observation4032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4032
theorem observation4033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4033
theorem observation4034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4034
theorem observation4035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4035
theorem observation4036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4036
theorem observation4037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4037
theorem observation4038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4038
theorem observation4039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4039
theorem observation4040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4040
theorem observation4041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4041
theorem observation4042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4042
theorem observation4043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4043
theorem observation4044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4044
theorem observation4045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4045
theorem observation4046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4046
theorem observation4047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4047
theorem observation4048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4048
theorem observation4049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4049
theorem observation4050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4050
theorem observation4051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4051
theorem observation4052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4052
theorem observation4053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4053
theorem observation4054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4054
theorem observation4055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4055
theorem observation4056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4056
theorem observation4057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4057
theorem observation4058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4058
theorem observation4059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4059
theorem observation4060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4060
theorem observation4061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4061
theorem observation4062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4062
theorem observation4063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4063
theorem observation4064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4064
theorem observation4065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4065
theorem observation4066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4066
theorem observation4067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4067
theorem observation4068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4068
theorem observation4069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4069
theorem observation4070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4070
theorem observation4071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4071
theorem observation4072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4072
theorem observation4073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4073
theorem observation4074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4074
theorem observation4075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4075
theorem observation4076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4076
theorem observation4077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4077
theorem observation4078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4078
theorem observation4079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4079
theorem observation4080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4080
theorem observation4081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4081
theorem observation4082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4082
theorem observation4083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4083
theorem observation4084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4084
theorem observation4085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4085
theorem observation4086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4086
theorem observation4087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4087
theorem observation4088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4088
theorem observation4089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4089
theorem observation4090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4090
theorem observation4091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4091
theorem observation4092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4092
theorem observation4093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4093
theorem observation4094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4094
theorem observation4095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4095
theorem observation4096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4096
theorem observation4097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4097
theorem observation4098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4098
theorem observation4099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4099
theorem observation4100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4100
theorem observation4101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4101
theorem observation4102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4102
theorem observation4103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4103
theorem observation4104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4104
theorem observation4105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4105
theorem observation4106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4106
theorem observation4107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4107
theorem observation4108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4108
theorem observation4109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4109
theorem observation4110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4110
theorem observation4111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4111
theorem observation4112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4112
theorem observation4113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4113
theorem observation4114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4114
theorem observation4115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4115
theorem observation4116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4116
theorem observation4117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4117
theorem observation4118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4118
theorem observation4119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4119
theorem observation4120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4120
theorem observation4121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4121
theorem observation4122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4122
theorem observation4123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4123
theorem observation4124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4124
theorem observation4125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4125
theorem observation4126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4126
theorem observation4127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4127
theorem observation4128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4128
theorem observation4129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4129
theorem observation4130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4130
theorem observation4131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4131
theorem observation4132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4132
theorem observation4133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4133
theorem observation4134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4134
theorem observation4135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4135
theorem observation4136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4136
theorem observation4137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4137
theorem observation4138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4138
theorem observation4139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4139
theorem observation4140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4140
theorem observation4141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4141
theorem observation4142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4142
theorem observation4143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4143
theorem observation4144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4144
theorem observation4145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4145
theorem observation4146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4146
theorem observation4147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4147
theorem observation4148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4148
theorem observation4149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4149
theorem observation4150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4150
theorem observation4151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4151
theorem observation4152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4152
theorem observation4153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4153
theorem observation4154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4154
theorem observation4155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4155
theorem observation4156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4156
theorem observation4157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4157
theorem observation4158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4158
theorem observation4159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4159
theorem observation4160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4160
theorem observation4161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4161
theorem observation4162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4162
theorem observation4163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4163
theorem observation4164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4164
theorem observation4165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4165
theorem observation4166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4166
theorem observation4167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4167
theorem observation4168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4168
theorem observation4169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4169
theorem observation4170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4170
theorem observation4171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4171
theorem observation4172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4172
theorem observation4173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4173
theorem observation4174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4174
theorem observation4175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4175
theorem observation4176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4176
theorem observation4177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4177
theorem observation4178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4178
theorem observation4179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4179
theorem observation4180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4180
theorem observation4181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4181
theorem observation4182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4182
theorem observation4183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4183
theorem observation4184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4184
theorem observation4185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4185
theorem observation4186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4186
theorem observation4187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4187
theorem observation4188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4188
theorem observation4189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4189
theorem observation4190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4190
theorem observation4191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4191
theorem observation4192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4192
theorem observation4193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4193
theorem observation4194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4194
theorem observation4195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4195
theorem observation4196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4196
theorem observation4197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4197
theorem observation4198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4198
theorem observation4199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4199
theorem observation4200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4200
theorem observation4201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4201
theorem observation4202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4202
theorem observation4203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4203
theorem observation4204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4204
theorem observation4205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4205
theorem observation4206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4206
theorem observation4207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4207
theorem observation4208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4208
theorem observation4209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4209
theorem observation4210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4210
theorem observation4211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4211
theorem observation4212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4212
theorem observation4213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4213
theorem observation4214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4214
theorem observation4215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4215
theorem observation4216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4216
theorem observation4217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4217
theorem observation4218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4218
theorem observation4219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4219
theorem observation4220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4220
theorem observation4221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4221
theorem observation4222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4222
theorem observation4223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4223
theorem observation4224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4224
theorem observation4225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4225
theorem observation4226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4226
theorem observation4227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4227
theorem observation4228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4228
theorem observation4229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4229
theorem observation4230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4230
theorem observation4231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4231
theorem observation4232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4232
theorem observation4233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4233
theorem observation4234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4234
theorem observation4235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4235
theorem observation4236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4236
theorem observation4237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4237
theorem observation4238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4238
theorem observation4239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4239
theorem observation4240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4240
theorem observation4241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4241
theorem observation4242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4242
theorem observation4243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4243
theorem observation4244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4244
theorem observation4245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4245
theorem observation4246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4246
theorem observation4247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4247
theorem observation4248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4248
theorem observation4249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4249
theorem observation4250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4250
theorem observation4251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4251
theorem observation4252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4252
theorem observation4253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4253
theorem observation4254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4254
theorem observation4255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4255
theorem observation4256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4256
theorem observation4257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4257
theorem observation4258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4258
theorem observation4259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4259
theorem observation4260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4260
theorem observation4261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4261
theorem observation4262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4262
theorem observation4263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4263
theorem observation4264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4264
theorem observation4265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4265
theorem observation4266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4266
theorem observation4267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4267
theorem observation4268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4268
theorem observation4269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4269
theorem observation4270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4270
theorem observation4271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4271
theorem observation4272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4272
theorem observation4273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4273
theorem observation4274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4274
theorem observation4275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4275
theorem observation4276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4276
theorem observation4277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4277
theorem observation4278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4278
theorem observation4279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4279
theorem observation4280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4280
theorem observation4281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4281
theorem observation4282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4282
theorem observation4283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4283
theorem observation4284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4284
theorem observation4285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4285
theorem observation4286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4286
theorem observation4287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4287
theorem observation4288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4288
theorem observation4289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4289
theorem observation4290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4290
theorem observation4291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4291
theorem observation4292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4292
theorem observation4293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4293
theorem observation4294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4294
theorem observation4295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4295
theorem observation4296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4296
theorem observation4297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4297
theorem observation4298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4298
theorem observation4299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4299
theorem observation4300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4300
theorem observation4301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4301
theorem observation4302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4302
theorem observation4303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4303
theorem observation4304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4304
theorem observation4305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4305
theorem observation4306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4306
theorem observation4307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4307
theorem observation4308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4308
theorem observation4309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4309
theorem observation4310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4310
theorem observation4311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4311
theorem observation4312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4312
theorem observation4313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4313
theorem observation4314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4314
theorem observation4315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4315
theorem observation4316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4316
theorem observation4317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4317
theorem observation4318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4318
theorem observation4319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4319
theorem observation4320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4320
theorem observation4321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4321
theorem observation4322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4322
theorem observation4323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4323
theorem observation4324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4324
theorem observation4325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4325
theorem observation4326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4326
theorem observation4327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4327
theorem observation4328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4328
theorem observation4329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4329
theorem observation4330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4330
theorem observation4331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4331
theorem observation4332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4332
theorem observation4333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4333
theorem observation4334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4334
theorem observation4335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4335
theorem observation4336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4336
theorem observation4337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4337
theorem observation4338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4338
theorem observation4339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4339
theorem observation4340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4340
theorem observation4341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4341
theorem observation4342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4342
theorem observation4343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4343
theorem observation4344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4344
theorem observation4345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4345
theorem observation4346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4346
theorem observation4347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4347
theorem observation4348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4348
theorem observation4349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4349
theorem observation4350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4350
theorem observation4351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4351
theorem observation4352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4352
theorem observation4353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4353
theorem observation4354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4354
theorem observation4355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4355
theorem observation4356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4356
theorem observation4357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4357
theorem observation4358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4358
theorem observation4359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4359
theorem observation4360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4360
theorem observation4361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4361
theorem observation4362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4362
theorem observation4363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4363
theorem observation4364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4364
theorem observation4365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4365
theorem observation4366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4366
theorem observation4367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4367
theorem observation4368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4368
theorem observation4369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4369
theorem observation4370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4370
theorem observation4371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4371
theorem observation4372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4372
theorem observation4373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4373
theorem observation4374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4374
theorem observation4375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4375
theorem observation4376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4376
theorem observation4377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4377
theorem observation4378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4378
theorem observation4379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4379
theorem observation4380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4380
theorem observation4381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4381
theorem observation4382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4382
theorem observation4383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4383
theorem observation4384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4384
theorem observation4385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4385
theorem observation4386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4386
theorem observation4387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4387
theorem observation4388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4388
theorem observation4389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4389
theorem observation4390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4390
theorem observation4391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4391
theorem observation4392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4392
theorem observation4393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4393
theorem observation4394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4394
theorem observation4395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4395
theorem observation4396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4396
theorem observation4397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4397
theorem observation4398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4398
theorem observation4399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4399
theorem observation4400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4400
theorem observation4401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4401
theorem observation4402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4402
theorem observation4403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4403
theorem observation4404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4404
theorem observation4405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4405
theorem observation4406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4406
theorem observation4407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4407
theorem observation4408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4408
theorem observation4409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4409
theorem observation4410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4410
theorem observation4411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4411
theorem observation4412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4412
theorem observation4413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4413
theorem observation4414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4414
theorem observation4415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4415
theorem observation4416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4416
theorem observation4417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4417
theorem observation4418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4418
theorem observation4419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4419
theorem observation4420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4420
theorem observation4421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4421
theorem observation4422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4422
theorem observation4423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4423
theorem observation4424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4424
theorem observation4425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4425
theorem observation4426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4426
theorem observation4427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4427
theorem observation4428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4428
theorem observation4429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4429
theorem observation4430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4430
theorem observation4431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4431
theorem observation4432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4432
theorem observation4433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4433
theorem observation4434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4434
theorem observation4435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4435
theorem observation4436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4436
theorem observation4437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4437
theorem observation4438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4438
theorem observation4439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4439
theorem observation4440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4440
theorem observation4441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4441
theorem observation4442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4442
theorem observation4443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4443
theorem observation4444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4444
theorem observation4445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4445
theorem observation4446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4446
theorem observation4447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4447
theorem observation4448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4448
theorem observation4449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4449
theorem observation4450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4450
theorem observation4451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4451
theorem observation4452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4452
theorem observation4453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4453
theorem observation4454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4454
theorem observation4455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4455
theorem observation4456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4456
theorem observation4457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4457
theorem observation4458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4458
theorem observation4459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4459
theorem observation4460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4460
theorem observation4461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4461
theorem observation4462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4462
theorem observation4463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4463
theorem observation4464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4464
theorem observation4465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4465
theorem observation4466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4466
theorem observation4467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4467
theorem observation4468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4468
theorem observation4469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4469
theorem observation4470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4470
theorem observation4471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4471
theorem observation4472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4472
theorem observation4473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4473
theorem observation4474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4474
theorem observation4475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4475
theorem observation4476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4476
theorem observation4477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4477
theorem observation4478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4478
theorem observation4479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4479
theorem observation4480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4480
theorem observation4481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4481
theorem observation4482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4482
theorem observation4483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4483
theorem observation4484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4484
theorem observation4485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4485
theorem observation4486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4486
theorem observation4487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4487
theorem observation4488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4488
theorem observation4489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4489
theorem observation4490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4490
theorem observation4491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4491
theorem observation4492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4492
theorem observation4493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4493
theorem observation4494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4494
theorem observation4495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4495
theorem observation4496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4496
theorem observation4497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4497
theorem observation4498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4498
theorem observation4499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4499
theorem observation4500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4500
theorem observation4501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4501
theorem observation4502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4502
theorem observation4503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4503
theorem observation4504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4504
theorem observation4505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4505
theorem observation4506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4506
theorem observation4507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4507
theorem observation4508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4508
theorem observation4509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4509
theorem observation4510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4510
theorem observation4511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4511
theorem observation4512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4512
theorem observation4513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4513
theorem observation4514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4514
theorem observation4515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4515
theorem observation4516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4516
theorem observation4517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4517
theorem observation4518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4518
theorem observation4519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4519
theorem observation4520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4520
theorem observation4521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4521
theorem observation4522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4522
theorem observation4523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4523
theorem observation4524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4524
theorem observation4525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4525
theorem observation4526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4526
theorem observation4527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4527
theorem observation4528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4528
theorem observation4529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4529
theorem observation4530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4530
theorem observation4531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4531
theorem observation4532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4532
theorem observation4533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4533
theorem observation4534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4534
theorem observation4535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4535
theorem observation4536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4536
theorem observation4537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4537
theorem observation4538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4538
theorem observation4539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4539
theorem observation4540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4540
theorem observation4541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4541
theorem observation4542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4542
theorem observation4543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4543
theorem observation4544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4544
theorem observation4545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4545
theorem observation4546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4546
theorem observation4547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4547
theorem observation4548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4548
theorem observation4549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4549
theorem observation4550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4550
theorem observation4551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4551
theorem observation4552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4552
theorem observation4553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4553
theorem observation4554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4554
theorem observation4555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4555
theorem observation4556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4556
theorem observation4557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4557
theorem observation4558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4558
theorem observation4559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4559
theorem observation4560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4560
theorem observation4561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4561
theorem observation4562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4562
theorem observation4563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4563
theorem observation4564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4564
theorem observation4565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4565
theorem observation4566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4566
theorem observation4567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4567
theorem observation4568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4568
theorem observation4569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4569
theorem observation4570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4570
theorem observation4571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4571
theorem observation4572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4572
theorem observation4573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4573
theorem observation4574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4574
theorem observation4575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4575
theorem observation4576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4576
theorem observation4577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4577
theorem observation4578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4578
theorem observation4579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4579
theorem observation4580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4580
theorem observation4581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4581
theorem observation4582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4582
theorem observation4583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4583
theorem observation4584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4584
theorem observation4585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4585
theorem observation4586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4586
theorem observation4587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4587
theorem observation4588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4588
theorem observation4589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4589
theorem observation4590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4590
theorem observation4591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4591
theorem observation4592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4592
theorem observation4593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4593
theorem observation4594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4594
theorem observation4595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4595
theorem observation4596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4596
theorem observation4597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4597
theorem observation4598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4598
theorem observation4599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4599
theorem observation4600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4600
theorem observation4601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4601
theorem observation4602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4602
theorem observation4603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4603
theorem observation4604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4604
theorem observation4605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4605
theorem observation4606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4606
theorem observation4607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4607
theorem observation4608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4608
theorem observation4609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4609
theorem observation4610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4610
theorem observation4611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4611
theorem observation4612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4612
theorem observation4613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4613
theorem observation4614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4614
theorem observation4615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4615
theorem observation4616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4616
theorem observation4617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4617
theorem observation4618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4618
theorem observation4619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4619
theorem observation4620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4620
theorem observation4621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4621
theorem observation4622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4622
theorem observation4623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4623
theorem observation4624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4624
theorem observation4625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4625
theorem observation4626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4626
theorem observation4627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4627
theorem observation4628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4628
theorem observation4629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4629
theorem observation4630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4630
theorem observation4631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4631
theorem observation4632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4632
theorem observation4633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4633
theorem observation4634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4634
theorem observation4635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4635
theorem observation4636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4636
theorem observation4637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4637
theorem observation4638 : k404 = k404 /\ k405 = k405 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k4] k413 = true := by decide
#print axioms observation4638
theorem observation4639 : k413 = k413 /\ k413 = k413 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine4639 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k17, k17] k17 = some k413 := by decide
#print axioms observation4639
theorem observation4640 : k438 = k438 /\ k438 = k438 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4640
theorem observation4641 : k432 = k432 /\ k432 = k432 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4641
theorem observation4642 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4642
theorem observation4643 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation4643
theorem observation4644 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4644
theorem observation4645 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4645
theorem observation4646 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4646
theorem observation4647 : k404 = k404 /\ k405 = k405 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k4] k413 = true := by decide
#print axioms observation4647
theorem observation4648 : k413 = k413 /\ k413 = k413 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine4648 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k17, k17] k17 = some k413 := by decide
#print axioms observation4648
theorem observation4649 : k443 = k443 /\ k443 = k443 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4649
theorem observation4650 : k417 = k417 /\ k417 = k417 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4650
theorem observation4651 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4651
theorem observation4652 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation4652
theorem observation4653 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4653
theorem observation4654 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4654
theorem observation4655 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4655
theorem observation4656 : k404 = k404 /\ k405 = k405 /\ "VERIFIED" = "VERIFIED" /\ publishes [k5, k4] k413 = true := by decide
#print axioms observation4656
theorem observation4657 : k413 = k413 /\ k413 = k413 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine4657 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "JOIN" [k17, k17, k17] k17 = some k413 := by decide
#print axioms observation4657
theorem observation4658 : k448 = k448 /\ k448 = k448 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4658
theorem observation4659 : k432 = k432 /\ k432 = k432 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4659
theorem observation4660 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4660
theorem observation4661 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation4661
theorem observation4662 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4662
theorem observation4663 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4663
theorem observation4664 : k57 = k57 /\ k57 = k57 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family)) ({ arity := 2, products := [[.sig "A", .sig "A"]] } : Family) .exact k57 = true := by decide
#print axioms observation4664
theorem observation4665 : k450 = k450 /\ k451 = k451 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation4665
theorem observation4666 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine4666 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation4666
theorem observation4667 : k505 = k505 /\ k505 = k505 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4667
theorem observation4668 : k491 = k491 /\ k491 = k491 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4668
theorem observation4669 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation4669
theorem observation4670 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation4670
theorem observation4671 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation4671
theorem observation4672 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation4672
theorem observation4673 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation4673
theorem observation4674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4674
theorem observation4675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4675
theorem observation4676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4676
theorem observation4677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4677
theorem observation4678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4678
theorem observation4679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4679
theorem observation4680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4680
theorem observation4681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4681
theorem observation4682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4682
theorem observation4683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4683
theorem observation4684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4684
theorem observation4685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4685
theorem observation4686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4686
theorem observation4687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4687
theorem observation4688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4688
theorem observation4689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4689
theorem observation4690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4690
theorem observation4691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4691
theorem observation4692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4692
theorem observation4693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4693
theorem observation4694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4694
theorem observation4695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4695
theorem observation4696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4696
theorem observation4697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4697
theorem observation4698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4698
theorem observation4699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4699
theorem observation4700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4700
theorem observation4701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4701
theorem observation4702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4702
theorem observation4703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4703
theorem observation4704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4704
theorem observation4705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4705
theorem observation4706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4706
theorem observation4707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4707
theorem observation4708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4708
theorem observation4709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4709
theorem observation4710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4710
theorem observation4711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4711
theorem observation4712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4712
theorem observation4713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4713
theorem observation4714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4714
theorem observation4715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4715
theorem observation4716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4716
theorem observation4717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4717
theorem observation4718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4718
theorem observation4719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4719
theorem observation4720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4720
theorem observation4721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4721
theorem observation4722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4722
theorem observation4723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4723
theorem observation4724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4724
theorem observation4725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4725
theorem observation4726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4726
theorem observation4727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4727
theorem observation4728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4728
theorem observation4729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4729
theorem observation4730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4730
theorem observation4731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4731
theorem observation4732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4732
theorem observation4733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4733
theorem observation4734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4734
theorem observation4735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4735
theorem observation4736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4736
theorem observation4737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4737
theorem observation4738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4738
theorem observation4739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4739
theorem observation4740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4740
theorem observation4741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4741
theorem observation4742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4742
theorem observation4743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4743
theorem observation4744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4744
theorem observation4745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4745
theorem observation4746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4746
theorem observation4747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4747
theorem observation4748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4748
theorem observation4749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4749
theorem observation4750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4750
theorem observation4751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4751
theorem observation4752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4752
theorem observation4753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4753
theorem observation4754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4754
theorem observation4755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4755
theorem observation4756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4756
theorem observation4757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4757
theorem observation4758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4758
theorem observation4759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4759
theorem observation4760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4760
theorem observation4761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4761
theorem observation4762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4762
theorem observation4763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4763
theorem observation4764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4764
theorem observation4765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4765
theorem observation4766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4766
theorem observation4767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4767
theorem observation4768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4768
theorem observation4769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4769
theorem observation4770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4770
theorem observation4771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4771
theorem observation4772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4772
theorem observation4773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4773
theorem observation4774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4774
theorem observation4775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4775
theorem observation4776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4776
theorem observation4777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4777
theorem observation4778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4778
theorem observation4779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4779
theorem observation4780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4780
theorem observation4781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4781
theorem observation4782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4782
theorem observation4783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4783
theorem observation4784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4784
theorem observation4785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4785
theorem observation4786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4786
theorem observation4787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4787
theorem observation4788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4788
theorem observation4789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4789
theorem observation4790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4790
theorem observation4791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4791
theorem observation4792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4792
theorem observation4793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4793
theorem observation4794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4794
theorem observation4795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4795
theorem observation4796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4796
theorem observation4797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4797
theorem observation4798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4798
theorem observation4799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4799
theorem observation4800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4800
theorem observation4801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4801
theorem observation4802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4802
theorem observation4803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4803
theorem observation4804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4804
theorem observation4805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4805
theorem observation4806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4806
theorem observation4807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4807
theorem observation4808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4808
theorem observation4809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4809
theorem observation4810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4810
theorem observation4811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4811
theorem observation4812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4812
theorem observation4813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4813
theorem observation4814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4814
theorem observation4815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4815
theorem observation4816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4816
theorem observation4817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4817
theorem observation4818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4818
theorem observation4819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4819
theorem observation4820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4820
theorem observation4821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4821
theorem observation4822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4822
theorem observation4823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4823
theorem observation4824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4824
theorem observation4825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4825
theorem observation4826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4826
theorem observation4827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4827
theorem observation4828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4828
theorem observation4829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4829
theorem observation4830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4830
theorem observation4831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4831
theorem observation4832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4832
theorem observation4833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4833
theorem observation4834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4834
theorem observation4835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4835
theorem observation4836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4836
theorem observation4837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4837
theorem observation4838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4838
theorem observation4839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4839
theorem observation4840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4840
theorem observation4841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4841
theorem observation4842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4842
theorem observation4843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4843
theorem observation4844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4844
theorem observation4845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4845
theorem observation4846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4846
theorem observation4847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4847
theorem observation4848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4848
theorem observation4849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4849
theorem observation4850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4850
theorem observation4851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4851
theorem observation4852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4852
theorem observation4853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4853
theorem observation4854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4854
theorem observation4855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4855
theorem observation4856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4856
theorem observation4857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4857
theorem observation4858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4858
theorem observation4859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4859
theorem observation4860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4860
theorem observation4861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4861
theorem observation4862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4862
theorem observation4863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4863
theorem observation4864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4864
theorem observation4865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4865
theorem observation4866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4866
theorem observation4867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4867
theorem observation4868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4868
theorem observation4869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4869
theorem observation4870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4870
theorem observation4871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4871
theorem observation4872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4872
theorem observation4873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4873
theorem observation4874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4874
theorem observation4875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4875
theorem observation4876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4876
theorem observation4877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4877
theorem observation4878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4878
theorem observation4879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4879
theorem observation4880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4880
theorem observation4881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4881
theorem observation4882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4882
theorem observation4883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4883
theorem observation4884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4884
theorem observation4885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4885
theorem observation4886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4886
theorem observation4887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4887
theorem observation4888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4888
theorem observation4889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4889
theorem observation4890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4890
theorem observation4891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4891
theorem observation4892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4892
theorem observation4893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4893
theorem observation4894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4894
theorem observation4895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4895
theorem observation4896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4896
theorem observation4897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4897
theorem observation4898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4898
theorem observation4899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4899
theorem observation4900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4900
theorem observation4901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4901
theorem observation4902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4902
theorem observation4903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4903
theorem observation4904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4904
theorem observation4905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4905
theorem observation4906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4906
theorem observation4907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4907
theorem observation4908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4908
theorem observation4909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4909
theorem observation4910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4910
theorem observation4911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4911
theorem observation4912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4912
theorem observation4913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4913
theorem observation4914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4914
theorem observation4915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4915
theorem observation4916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4916
theorem observation4917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4917
theorem observation4918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4918
theorem observation4919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4919
theorem observation4920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4920
theorem observation4921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4921
theorem observation4922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4922
theorem observation4923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4923
theorem observation4924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4924
theorem observation4925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4925
theorem observation4926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4926
theorem observation4927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4927
theorem observation4928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4928
theorem observation4929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4929
theorem observation4930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4930
theorem observation4931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4931
theorem observation4932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4932
theorem observation4933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4933
theorem observation4934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4934
theorem observation4935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4935
theorem observation4936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4936
theorem observation4937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4937
theorem observation4938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4938
theorem observation4939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4939
theorem observation4940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4940
theorem observation4941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4941
theorem observation4942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4942
theorem observation4943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4943
theorem observation4944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4944
theorem observation4945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4945
theorem observation4946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4946
theorem observation4947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4947
theorem observation4948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4948
theorem observation4949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4949
theorem observation4950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4950
theorem observation4951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4951
theorem observation4952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4952
theorem observation4953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4953
theorem observation4954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4954
theorem observation4955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4955
theorem observation4956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4956
theorem observation4957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4957
theorem observation4958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4958
theorem observation4959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4959
theorem observation4960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4960
theorem observation4961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4961
theorem observation4962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4962
theorem observation4963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4963
theorem observation4964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4964
theorem observation4965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4965
theorem observation4966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4966
theorem observation4967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4967
theorem observation4968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4968
theorem observation4969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4969
theorem observation4970 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4970
theorem observation4971 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4971
theorem observation4972 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4972
theorem observation4973 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4973
theorem observation4974 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4974
theorem observation4975 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4975
theorem observation4976 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4976
theorem observation4977 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4977
theorem observation4978 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4978
theorem observation4979 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4979
theorem observation4980 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4980
theorem observation4981 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4981
theorem observation4982 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4982
theorem observation4983 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4983
theorem observation4984 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4984
theorem observation4985 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4985
theorem observation4986 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4986
theorem observation4987 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4987
theorem observation4988 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4988
theorem observation4989 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4989
theorem observation4990 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4990
theorem observation4991 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4991
theorem observation4992 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4992
theorem observation4993 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4993
theorem observation4994 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4994
theorem observation4995 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4995
theorem observation4996 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4996
theorem observation4997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4997
theorem observation4998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4998
theorem observation4999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation4999
theorem observation5000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5000
theorem observation5001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5001
theorem observation5002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5002
theorem observation5003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5003
theorem observation5004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5004
theorem observation5005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5005
theorem observation5006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5006
theorem observation5007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5007
theorem observation5008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5008
theorem observation5009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5009
theorem observation5010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5010
theorem observation5011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5011
theorem observation5012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5012
theorem observation5013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5013
theorem observation5014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5014
theorem observation5015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5015
theorem observation5016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5016
theorem observation5017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5017
theorem observation5018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5018
theorem observation5019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5019
theorem observation5020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5020
theorem observation5021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5021
theorem observation5022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5022
theorem observation5023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5023
theorem observation5024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5024
theorem observation5025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5025
theorem observation5026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5026
theorem observation5027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5027
theorem observation5028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5028
theorem observation5029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5029
theorem observation5030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5030
theorem observation5031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5031
theorem observation5032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5032
theorem observation5033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5033
theorem observation5034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5034
theorem observation5035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5035
theorem observation5036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5036
theorem observation5037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5037
theorem observation5038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5038
theorem observation5039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5039
theorem observation5040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5040
theorem observation5041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5041
theorem observation5042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5042
theorem observation5043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5043
theorem observation5044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5044
theorem observation5045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5045
theorem observation5046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5046
theorem observation5047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5047
theorem observation5048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5048
theorem observation5049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5049
theorem observation5050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5050
theorem observation5051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5051
theorem observation5052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5052
theorem observation5053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5053
theorem observation5054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5054
theorem observation5055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5055
theorem observation5056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5056
theorem observation5057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5057
theorem observation5058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5058
theorem observation5059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5059
theorem observation5060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5060
theorem observation5061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5061
theorem observation5062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5062
theorem observation5063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5063
theorem observation5064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5064
theorem observation5065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5065
theorem observation5066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5066
theorem observation5067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5067
theorem observation5068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5068
theorem observation5069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5069
theorem observation5070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5070
theorem observation5071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5071
theorem observation5072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5072
theorem observation5073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5073
theorem observation5074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5074
theorem observation5075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5075
theorem observation5076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5076
theorem observation5077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5077
theorem observation5078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5078
theorem observation5079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5079
theorem observation5080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5080
theorem observation5081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5081
theorem observation5082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5082
theorem observation5083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5083
theorem observation5084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5084
theorem observation5085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5085
theorem observation5086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5086
theorem observation5087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5087
theorem observation5088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5088
theorem observation5089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5089
theorem observation5090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5090
theorem observation5091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5091
theorem observation5092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5092
theorem observation5093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5093
theorem observation5094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5094
theorem observation5095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5095
theorem observation5096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5096
theorem observation5097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5097
theorem observation5098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5098
theorem observation5099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5099
theorem observation5100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5100
theorem observation5101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5101
theorem observation5102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5102
theorem observation5103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5103
theorem observation5104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5104
theorem observation5105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5105
theorem observation5106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5106
theorem observation5107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5107
theorem observation5108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5108
theorem observation5109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5109
theorem observation5110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5110
theorem observation5111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5111
theorem observation5112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5112
theorem observation5113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5113
theorem observation5114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5114
theorem observation5115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5115
theorem observation5116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5116
theorem observation5117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5117
theorem observation5118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5118
theorem observation5119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5119
theorem observation5120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5120
theorem observation5121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5121
theorem observation5122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5122
theorem observation5123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5123
theorem observation5124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5124
theorem observation5125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5125
theorem observation5126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5126
theorem observation5127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5127
theorem observation5128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5128
theorem observation5129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5129
theorem observation5130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5130
theorem observation5131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5131
theorem observation5132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5132
theorem observation5133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5133
theorem observation5134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5134
theorem observation5135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5135
theorem observation5136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5136
theorem observation5137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5137
theorem observation5138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5138
theorem observation5139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5139
theorem observation5140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5140
theorem observation5141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5141
theorem observation5142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5142
theorem observation5143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5143
theorem observation5144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5144
theorem observation5145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5145
theorem observation5146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5146
theorem observation5147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5147
theorem observation5148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5148
theorem observation5149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5149
theorem observation5150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5150
theorem observation5151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5151
theorem observation5152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5152
theorem observation5153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5153
theorem observation5154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5154
theorem observation5155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5155
theorem observation5156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5156
theorem observation5157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5157
theorem observation5158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5158
theorem observation5159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5159
theorem observation5160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5160
theorem observation5161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5161
theorem observation5162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5162
theorem observation5163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5163
theorem observation5164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5164
theorem observation5165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5165
theorem observation5166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5166
theorem observation5167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5167
theorem observation5168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5168
theorem observation5169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5169
theorem observation5170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5170
theorem observation5171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5171
theorem observation5172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5172
theorem observation5173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5173
theorem observation5174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5174
theorem observation5175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5175
theorem observation5176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5176
theorem observation5177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5177
theorem observation5178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5178
theorem observation5179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5179
theorem observation5180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5180
theorem observation5181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5181
theorem observation5182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5182
theorem observation5183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5183
theorem observation5184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5184
theorem observation5185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5185
theorem observation5186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5186
theorem observation5187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5187
theorem observation5188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5188
theorem observation5189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5189
theorem observation5190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5190
theorem observation5191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5191
theorem observation5192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5192
theorem observation5193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5193
theorem observation5194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5194
theorem observation5195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5195
theorem observation5196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5196
theorem observation5197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5197
theorem observation5198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5198
theorem observation5199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5199
theorem observation5200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5200
theorem observation5201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5201
theorem observation5202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5202
theorem observation5203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5203
theorem observation5204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5204
theorem observation5205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5205
theorem observation5206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5206
theorem observation5207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5207
theorem observation5208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5208
theorem observation5209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5209
theorem observation5210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5210
theorem observation5211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5211
theorem observation5212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5212
theorem observation5213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5213
theorem observation5214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5214
theorem observation5215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5215
theorem observation5216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5216
theorem observation5217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5217
theorem observation5218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5218
theorem observation5219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5219
theorem observation5220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5220
theorem observation5221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5221
theorem observation5222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5222
theorem observation5223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5223
theorem observation5224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5224
theorem observation5225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5225
theorem observation5226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5226
theorem observation5227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5227
theorem observation5228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5228
theorem observation5229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5229
theorem observation5230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5230
theorem observation5231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5231
theorem observation5232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5232
theorem observation5233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5233
theorem observation5234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5234
theorem observation5235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5235
theorem observation5236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5236
theorem observation5237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5237
theorem observation5238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5238
theorem observation5239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5239
theorem observation5240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5240
theorem observation5241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5241
theorem observation5242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5242
theorem observation5243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5243
theorem observation5244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5244
theorem observation5245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5245
theorem observation5246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5246
theorem observation5247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5247
theorem observation5248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5248
theorem observation5249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5249
theorem observation5250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5250
theorem observation5251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5251
theorem observation5252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5252
theorem observation5253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5253
theorem observation5254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5254
theorem observation5255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5255
theorem observation5256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5256
theorem observation5257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5257
theorem observation5258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5258
theorem observation5259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5259
theorem observation5260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5260
theorem observation5261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5261
theorem observation5262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5262
theorem observation5263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5263
theorem observation5264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5264
theorem observation5265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5265
theorem observation5266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5266
theorem observation5267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5267
theorem observation5268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5268
theorem observation5269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5269
theorem observation5270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5270
theorem observation5271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5271
theorem observation5272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5272
theorem observation5273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5273
theorem observation5274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5274
theorem observation5275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5275
theorem observation5276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5276
theorem observation5277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5277
theorem observation5278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5278
theorem observation5279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5279
theorem observation5280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5280
theorem observation5281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5281
theorem observation5282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5282
theorem observation5283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5283
theorem observation5284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5284
theorem observation5285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5285
theorem observation5286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5286
theorem observation5287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5287
theorem observation5288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5288
theorem observation5289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5289
theorem observation5290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5290
theorem observation5291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5291
theorem observation5292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5292
theorem observation5293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5293
theorem observation5294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5294
theorem observation5295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5295
theorem observation5296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5296
theorem observation5297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5297
theorem observation5298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5298
theorem observation5299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5299
theorem observation5300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5300
theorem observation5301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5301
theorem observation5302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5302
theorem observation5303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5303
theorem observation5304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5304
theorem observation5305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5305
theorem observation5306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5306
theorem observation5307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5307
theorem observation5308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5308
theorem observation5309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5309
theorem observation5310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5310
theorem observation5311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5311
theorem observation5312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5312
theorem observation5313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5313
theorem observation5314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5314
theorem observation5315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5315
theorem observation5316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5316
theorem observation5317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5317
theorem observation5318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5318
theorem observation5319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5319
theorem observation5320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5320
theorem observation5321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5321
theorem observation5322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5322
theorem observation5323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5323
theorem observation5324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5324
theorem observation5325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5325
theorem observation5326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5326
theorem observation5327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5327
theorem observation5328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5328
theorem observation5329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5329
theorem observation5330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5330
theorem observation5331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5331
theorem observation5332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5332
theorem observation5333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5333
theorem observation5334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5334
theorem observation5335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5335
theorem observation5336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5336
theorem observation5337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5337
theorem observation5338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5338
theorem observation5339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5339
theorem observation5340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5340
theorem observation5341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5341
theorem observation5342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5342
theorem observation5343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5343
theorem observation5344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5344
theorem observation5345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5345
theorem observation5346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5346
theorem observation5347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5347
theorem observation5348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5348
theorem observation5349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5349
theorem observation5350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5350
theorem observation5351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5351
theorem observation5352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5352
theorem observation5353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5353
theorem observation5354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5354
theorem observation5355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5355
theorem observation5356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5356
theorem observation5357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5357
theorem observation5358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5358
theorem observation5359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5359
theorem observation5360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5360
theorem observation5361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5361
theorem observation5362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5362
theorem observation5363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5363
theorem observation5364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5364
theorem observation5365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5365
theorem observation5366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5366
theorem observation5367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5367
theorem observation5368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5368
theorem observation5369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5369
theorem observation5370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5370
theorem observation5371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5371
theorem observation5372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5372
theorem observation5373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5373
theorem observation5374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5374
theorem observation5375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5375
theorem observation5376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5376
theorem observation5377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5377
theorem observation5378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5378
theorem observation5379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5379
theorem observation5380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5380
theorem observation5381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5381
theorem observation5382 : k450 = k450 /\ k506 = k506 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation5382
theorem observation5383 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine5383 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation5383
theorem observation5384 : k517 = k517 /\ k517 = k517 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5384
theorem observation5385 : k511 = k511 /\ k511 = k511 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5385
theorem observation5386 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5386
theorem observation5387 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation5387
theorem observation5388 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation5388
theorem observation5389 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation5389
theorem observation5390 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation5390
theorem observation5391 : k450 = k450 /\ k451 = k451 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation5391
theorem observation5392 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine5392 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation5392
theorem observation5393 : k522 = k522 /\ k522 = k522 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5393
theorem observation5394 : k491 = k491 /\ k491 = k491 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5394
theorem observation5395 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5395
theorem observation5396 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation5396
theorem observation5397 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation5397
theorem observation5398 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation5398
theorem observation5399 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation5399
theorem observation5400 : k450 = k450 /\ k506 = k506 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation5400
theorem observation5401 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine5401 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation5401
theorem observation5402 : k527 = k527 /\ k527 = k527 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5402
theorem observation5403 : k511 = k511 /\ k511 = k511 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5403
theorem observation5404 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5404
theorem observation5405 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation5405
theorem observation5406 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation5406
theorem observation5407 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation5407
theorem observation5408 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation5408
theorem observation5409 : k450 = k450 /\ k528 = k528 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k449, k4, k6, k8, k120] k465 = true := by decide
#print axioms observation5409
theorem observation5410 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine5410 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation5410
theorem observation5411 : k543 = k543 /\ k543 = k543 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5411
theorem observation5412 : k530 = k530 /\ k530 = k530 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5412
theorem observation5413 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation5413
theorem observation5414 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation5414
theorem observation5415 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation5415
theorem observation5416 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation5416
theorem observation5417 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation5417
theorem observation5418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5418
theorem observation5419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5419
theorem observation5420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5420
theorem observation5421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5421
theorem observation5422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5422
theorem observation5423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5423
theorem observation5424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5424
theorem observation5425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5425
theorem observation5426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5426
theorem observation5427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5427
theorem observation5428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5428
theorem observation5429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5429
theorem observation5430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5430
theorem observation5431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5431
theorem observation5432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5432
theorem observation5433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5433
theorem observation5434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5434
theorem observation5435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5435
theorem observation5436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5436
theorem observation5437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5437
theorem observation5438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5438
theorem observation5439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5439
theorem observation5440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5440
theorem observation5441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5441
theorem observation5442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5442
theorem observation5443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5443
theorem observation5444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5444
theorem observation5445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5445
theorem observation5446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5446
theorem observation5447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5447
theorem observation5448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5448
theorem observation5449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5449
theorem observation5450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5450
theorem observation5451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5451
theorem observation5452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5452
theorem observation5453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5453
theorem observation5454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5454
theorem observation5455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5455
theorem observation5456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5456
theorem observation5457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5457
theorem observation5458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5458
theorem observation5459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5459
theorem observation5460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5460
theorem observation5461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5461
theorem observation5462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5462
theorem observation5463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5463
theorem observation5464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5464
theorem observation5465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5465
theorem observation5466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5466
theorem observation5467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5467
theorem observation5468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5468
theorem observation5469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5469
theorem observation5470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5470
theorem observation5471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5471
theorem observation5472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5472
theorem observation5473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5473
theorem observation5474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5474
theorem observation5475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5475
theorem observation5476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5476
theorem observation5477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5477
theorem observation5478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5478
theorem observation5479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5479
theorem observation5480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5480
theorem observation5481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5481
theorem observation5482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5482
theorem observation5483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5483
theorem observation5484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5484
theorem observation5485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5485
theorem observation5486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5486
theorem observation5487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5487
theorem observation5488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5488
theorem observation5489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5489
theorem observation5490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5490
theorem observation5491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5491
theorem observation5492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5492
theorem observation5493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5493
theorem observation5494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5494
theorem observation5495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5495
theorem observation5496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5496
theorem observation5497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5497
theorem observation5498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5498
theorem observation5499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5499
theorem observation5500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5500
theorem observation5501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5501
theorem observation5502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5502
theorem observation5503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5503
theorem observation5504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5504
theorem observation5505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5505
theorem observation5506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5506
theorem observation5507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5507
theorem observation5508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5508
theorem observation5509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5509
theorem observation5510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5510
theorem observation5511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5511
theorem observation5512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5512
theorem observation5513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5513
theorem observation5514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5514
theorem observation5515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5515
theorem observation5516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5516
theorem observation5517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5517
theorem observation5518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5518
theorem observation5519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5519
theorem observation5520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5520
theorem observation5521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5521
theorem observation5522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5522
theorem observation5523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5523
theorem observation5524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5524
theorem observation5525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5525
theorem observation5526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5526
theorem observation5527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5527
theorem observation5528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5528
theorem observation5529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5529
theorem observation5530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5530
theorem observation5531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5531
theorem observation5532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5532
theorem observation5533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5533
theorem observation5534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5534
theorem observation5535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5535
theorem observation5536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5536
theorem observation5537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5537
theorem observation5538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5538
theorem observation5539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5539
theorem observation5540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5540
theorem observation5541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5541
theorem observation5542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5542
theorem observation5543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5543
theorem observation5544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5544
theorem observation5545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5545
theorem observation5546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5546
theorem observation5547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5547
theorem observation5548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5548
theorem observation5549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5549
theorem observation5550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5550
theorem observation5551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5551
theorem observation5552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5552
theorem observation5553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5553
theorem observation5554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5554
theorem observation5555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5555
theorem observation5556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5556
theorem observation5557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5557
theorem observation5558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5558
theorem observation5559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5559
theorem observation5560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5560
theorem observation5561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5561
theorem observation5562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5562
theorem observation5563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5563
theorem observation5564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5564
theorem observation5565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5565
theorem observation5566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5566
theorem observation5567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5567
theorem observation5568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5568
theorem observation5569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5569
theorem observation5570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5570
theorem observation5571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5571
theorem observation5572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5572
theorem observation5573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5573
theorem observation5574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5574
theorem observation5575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5575
theorem observation5576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5576
theorem observation5577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5577
theorem observation5578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5578
theorem observation5579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5579
theorem observation5580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5580
theorem observation5581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5581
theorem observation5582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5582
theorem observation5583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5583
theorem observation5584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5584
theorem observation5585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5585
theorem observation5586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5586
theorem observation5587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5587
theorem observation5588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5588
theorem observation5589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5589
theorem observation5590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5590
theorem observation5591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5591
theorem observation5592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5592
theorem observation5593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5593
theorem observation5594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5594
theorem observation5595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5595
theorem observation5596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5596
theorem observation5597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5597
theorem observation5598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5598
theorem observation5599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5599
theorem observation5600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5600
theorem observation5601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5601
theorem observation5602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5602
theorem observation5603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5603
theorem observation5604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5604
theorem observation5605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5605
theorem observation5606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5606
theorem observation5607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5607
theorem observation5608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5608
theorem observation5609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5609
theorem observation5610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5610
theorem observation5611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5611
theorem observation5612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5612
theorem observation5613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5613
theorem observation5614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5614
theorem observation5615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5615
theorem observation5616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5616
theorem observation5617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5617
theorem observation5618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5618
theorem observation5619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5619
theorem observation5620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5620
theorem observation5621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5621
theorem observation5622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5622
theorem observation5623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5623
theorem observation5624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5624
theorem observation5625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5625
theorem observation5626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5626
theorem observation5627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5627
theorem observation5628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5628
theorem observation5629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5629
theorem observation5630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5630
theorem observation5631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5631
theorem observation5632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5632
theorem observation5633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5633
theorem observation5634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5634
theorem observation5635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5635
theorem observation5636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5636
theorem observation5637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5637
theorem observation5638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5638
theorem observation5639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5639
theorem observation5640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5640
theorem observation5641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5641
theorem observation5642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5642
theorem observation5643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5643
theorem observation5644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5644
theorem observation5645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5645
theorem observation5646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5646
theorem observation5647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5647
theorem observation5648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5648
theorem observation5649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5649
theorem observation5650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5650
theorem observation5651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5651
theorem observation5652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5652
theorem observation5653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5653
theorem observation5654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5654
theorem observation5655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5655
theorem observation5656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5656
theorem observation5657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5657
theorem observation5658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5658
theorem observation5659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5659
theorem observation5660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5660
theorem observation5661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5661
theorem observation5662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5662
theorem observation5663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5663
theorem observation5664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5664
theorem observation5665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5665
theorem observation5666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5666
theorem observation5667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5667
theorem observation5668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5668
theorem observation5669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5669
theorem observation5670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5670
theorem observation5671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5671
theorem observation5672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5672
theorem observation5673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5673
theorem observation5674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5674
theorem observation5675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5675
theorem observation5676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5676
theorem observation5677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5677
theorem observation5678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5678
theorem observation5679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5679
theorem observation5680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5680
theorem observation5681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5681
theorem observation5682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5682
theorem observation5683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5683
theorem observation5684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5684
theorem observation5685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5685
theorem observation5686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5686
theorem observation5687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5687
theorem observation5688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5688
theorem observation5689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5689
theorem observation5690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5690
theorem observation5691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5691
theorem observation5692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5692
theorem observation5693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5693
theorem observation5694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5694
theorem observation5695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5695
theorem observation5696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5696
theorem observation5697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5697
theorem observation5698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5698
theorem observation5699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5699
theorem observation5700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5700
theorem observation5701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5701
theorem observation5702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5702
theorem observation5703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5703
theorem observation5704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5704
theorem observation5705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5705
theorem observation5706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5706
theorem observation5707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5707
theorem observation5708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5708
theorem observation5709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5709
theorem observation5710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5710
theorem observation5711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5711
theorem observation5712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5712
theorem observation5713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5713
theorem observation5714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5714
theorem observation5715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5715
theorem observation5716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5716
theorem observation5717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5717
theorem observation5718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5718
theorem observation5719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5719
theorem observation5720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5720
theorem observation5721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5721
theorem observation5722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5722
theorem observation5723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5723
theorem observation5724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5724
theorem observation5725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5725
theorem observation5726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5726
theorem observation5727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5727
theorem observation5728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5728
theorem observation5729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5729
theorem observation5730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5730
theorem observation5731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5731
theorem observation5732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5732
theorem observation5733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5733
theorem observation5734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5734
theorem observation5735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5735
theorem observation5736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5736
theorem observation5737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5737
theorem observation5738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5738
theorem observation5739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5739
theorem observation5740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5740
theorem observation5741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5741
theorem observation5742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5742
theorem observation5743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5743
theorem observation5744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5744
theorem observation5745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5745
theorem observation5746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5746
theorem observation5747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5747
theorem observation5748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5748
theorem observation5749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5749
theorem observation5750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5750
theorem observation5751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5751
theorem observation5752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5752
theorem observation5753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5753
theorem observation5754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5754
theorem observation5755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5755
theorem observation5756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5756
theorem observation5757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5757
theorem observation5758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5758
theorem observation5759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5759
theorem observation5760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5760
theorem observation5761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5761
theorem observation5762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5762
theorem observation5763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5763
theorem observation5764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5764
theorem observation5765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5765
theorem observation5766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5766
theorem observation5767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5767
theorem observation5768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5768
theorem observation5769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5769
theorem observation5770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5770
theorem observation5771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5771
theorem observation5772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5772
theorem observation5773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5773
theorem observation5774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5774
theorem observation5775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5775
theorem observation5776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5776
theorem observation5777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5777
theorem observation5778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5778
theorem observation5779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5779
theorem observation5780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5780
theorem observation5781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5781
theorem observation5782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5782
theorem observation5783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5783
theorem observation5784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5784
theorem observation5785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5785
theorem observation5786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5786
theorem observation5787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5787
theorem observation5788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5788
theorem observation5789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5789
theorem observation5790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5790
theorem observation5791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5791
theorem observation5792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5792
theorem observation5793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5793
theorem observation5794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5794
theorem observation5795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5795
theorem observation5796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5796
theorem observation5797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5797
theorem observation5798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5798
theorem observation5799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5799
theorem observation5800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5800
theorem observation5801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5801
theorem observation5802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5802
theorem observation5803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5803
theorem observation5804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5804
theorem observation5805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5805
theorem observation5806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5806
theorem observation5807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5807
theorem observation5808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5808
theorem observation5809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5809
theorem observation5810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5810
theorem observation5811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5811
theorem observation5812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5812
theorem observation5813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5813
theorem observation5814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5814
theorem observation5815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5815
theorem observation5816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5816
theorem observation5817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5817
theorem observation5818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5818
theorem observation5819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5819
theorem observation5820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5820
theorem observation5821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5821
theorem observation5822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5822
theorem observation5823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5823
theorem observation5824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5824
theorem observation5825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5825
theorem observation5826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5826
theorem observation5827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5827
theorem observation5828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5828
theorem observation5829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5829
theorem observation5830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5830
theorem observation5831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5831
theorem observation5832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5832
theorem observation5833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5833
theorem observation5834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5834
theorem observation5835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5835
theorem observation5836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5836
theorem observation5837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5837
theorem observation5838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5838
theorem observation5839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5839
theorem observation5840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5840
theorem observation5841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5841
theorem observation5842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5842
theorem observation5843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5843
theorem observation5844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5844
theorem observation5845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5845
theorem observation5846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5846
theorem observation5847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5847
theorem observation5848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5848
theorem observation5849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5849
theorem observation5850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5850
theorem observation5851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5851
theorem observation5852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5852
theorem observation5853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5853
theorem observation5854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5854
theorem observation5855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5855
theorem observation5856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5856
theorem observation5857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5857
theorem observation5858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5858
theorem observation5859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5859
theorem observation5860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5860
theorem observation5861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5861
theorem observation5862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5862
theorem observation5863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5863
theorem observation5864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5864
theorem observation5865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5865
theorem observation5866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5866
theorem observation5867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5867
theorem observation5868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5868
theorem observation5869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5869
theorem observation5870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5870
theorem observation5871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5871
theorem observation5872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5872
theorem observation5873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5873
theorem observation5874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5874
theorem observation5875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5875
theorem observation5876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5876
theorem observation5877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5877
theorem observation5878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5878
theorem observation5879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5879
theorem observation5880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5880
theorem observation5881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5881
theorem observation5882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5882
theorem observation5883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5883
theorem observation5884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5884
theorem observation5885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5885
theorem observation5886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5886
theorem observation5887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5887
theorem observation5888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5888
theorem observation5889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5889
theorem observation5890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5890
theorem observation5891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5891
theorem observation5892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5892
theorem observation5893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5893
theorem observation5894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5894
theorem observation5895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5895
theorem observation5896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5896
theorem observation5897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5897
theorem observation5898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5898
theorem observation5899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5899
theorem observation5900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5900
theorem observation5901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5901
theorem observation5902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5902
theorem observation5903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5903
theorem observation5904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5904
theorem observation5905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5905
theorem observation5906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5906
theorem observation5907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5907
theorem observation5908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5908
theorem observation5909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5909
theorem observation5910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5910
theorem observation5911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5911
theorem observation5912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5912
theorem observation5913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5913
theorem observation5914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5914
theorem observation5915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5915
theorem observation5916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5916
theorem observation5917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5917
theorem observation5918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5918
theorem observation5919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5919
theorem observation5920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5920
theorem observation5921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5921
theorem observation5922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5922
theorem observation5923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5923
theorem observation5924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5924
theorem observation5925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5925
theorem observation5926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5926
theorem observation5927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5927
theorem observation5928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5928
theorem observation5929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5929
theorem observation5930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5930
theorem observation5931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5931
theorem observation5932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5932
theorem observation5933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5933
theorem observation5934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5934
theorem observation5935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5935
theorem observation5936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5936
theorem observation5937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5937
theorem observation5938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5938
theorem observation5939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5939
theorem observation5940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5940
theorem observation5941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5941
theorem observation5942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5942
theorem observation5943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5943
theorem observation5944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5944
theorem observation5945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5945
theorem observation5946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5946
theorem observation5947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5947
theorem observation5948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5948
theorem observation5949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5949
theorem observation5950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5950
theorem observation5951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5951
theorem observation5952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5952
theorem observation5953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5953
theorem observation5954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5954
theorem observation5955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5955
theorem observation5956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5956
theorem observation5957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5957
theorem observation5958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5958
theorem observation5959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5959
theorem observation5960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5960
theorem observation5961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5961
theorem observation5962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5962
theorem observation5963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5963
theorem observation5964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5964
theorem observation5965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5965
theorem observation5966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5966
theorem observation5967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5967
theorem observation5968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5968
theorem observation5969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5969
theorem observation5970 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5970
theorem observation5971 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5971
theorem observation5972 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5972
theorem observation5973 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5973
theorem observation5974 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5974
theorem observation5975 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5975
theorem observation5976 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5976
theorem observation5977 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5977
theorem observation5978 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5978
theorem observation5979 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5979
theorem observation5980 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5980
theorem observation5981 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5981
theorem observation5982 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5982
theorem observation5983 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5983
theorem observation5984 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5984
theorem observation5985 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5985
theorem observation5986 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5986
theorem observation5987 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5987
theorem observation5988 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5988
theorem observation5989 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5989
theorem observation5990 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5990
theorem observation5991 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5991
theorem observation5992 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5992
theorem observation5993 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5993
theorem observation5994 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5994
theorem observation5995 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5995
theorem observation5996 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5996
theorem observation5997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5997
theorem observation5998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5998
theorem observation5999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation5999
theorem observation6000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6000
theorem observation6001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6001
theorem observation6002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6002
theorem observation6003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6003
theorem observation6004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6004
theorem observation6005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6005
theorem observation6006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6006
theorem observation6007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6007
theorem observation6008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6008
theorem observation6009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6009
theorem observation6010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6010
theorem observation6011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6011
theorem observation6012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6012
theorem observation6013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6013
theorem observation6014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6014
theorem observation6015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6015
theorem observation6016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6016
theorem observation6017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6017
theorem observation6018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6018
theorem observation6019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6019
theorem observation6020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6020
theorem observation6021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6021
theorem observation6022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6022
theorem observation6023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6023
theorem observation6024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6024
theorem observation6025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6025
theorem observation6026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6026
theorem observation6027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6027
theorem observation6028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6028
theorem observation6029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6029
theorem observation6030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6030
theorem observation6031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6031
theorem observation6032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6032
theorem observation6033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6033
theorem observation6034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6034
theorem observation6035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6035
theorem observation6036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6036
theorem observation6037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6037
theorem observation6038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6038
theorem observation6039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6039
theorem observation6040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6040
theorem observation6041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6041
theorem observation6042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6042
theorem observation6043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6043
theorem observation6044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6044
theorem observation6045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6045
theorem observation6046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6046
theorem observation6047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6047
theorem observation6048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6048
theorem observation6049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6049
theorem observation6050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6050
theorem observation6051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6051
theorem observation6052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6052
theorem observation6053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6053
theorem observation6054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6054
theorem observation6055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6055
theorem observation6056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6056
theorem observation6057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6057
theorem observation6058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6058
theorem observation6059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6059
theorem observation6060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6060
theorem observation6061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6061
theorem observation6062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6062
theorem observation6063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6063
theorem observation6064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6064
theorem observation6065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6065
theorem observation6066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6066
theorem observation6067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6067
theorem observation6068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6068
theorem observation6069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6069
theorem observation6070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6070
theorem observation6071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6071
theorem observation6072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6072
theorem observation6073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6073
theorem observation6074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6074
theorem observation6075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6075
theorem observation6076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6076
theorem observation6077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6077
theorem observation6078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6078
theorem observation6079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6079
theorem observation6080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6080
theorem observation6081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6081
theorem observation6082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6082
theorem observation6083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6083
theorem observation6084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6084
theorem observation6085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6085
theorem observation6086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6086
theorem observation6087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6087
theorem observation6088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6088
theorem observation6089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6089
theorem observation6090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6090
theorem observation6091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6091
theorem observation6092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6092
theorem observation6093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6093
theorem observation6094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6094
theorem observation6095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6095
theorem observation6096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6096
theorem observation6097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6097
theorem observation6098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6098
theorem observation6099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6099
theorem observation6100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6100
theorem observation6101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6101
theorem observation6102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6102
theorem observation6103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6103
theorem observation6104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6104
theorem observation6105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6105
theorem observation6106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6106
theorem observation6107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6107
theorem observation6108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6108
theorem observation6109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6109
theorem observation6110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6110
theorem observation6111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6111
theorem observation6112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6112
theorem observation6113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6113
theorem observation6114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6114
theorem observation6115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6115
theorem observation6116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6116
theorem observation6117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6117
theorem observation6118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6118
theorem observation6119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6119
theorem observation6120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6120
theorem observation6121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6121
theorem observation6122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6122
theorem observation6123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6123
theorem observation6124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6124
theorem observation6125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6125
theorem observation6126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6126
theorem observation6127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6127
theorem observation6128 : k450 = k450 /\ k544 = k544 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k449, k4, k6, k8, k120] k465 = true := by decide
#print axioms observation6128
theorem observation6129 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6129 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation6129
theorem observation6130 : k551 = k551 /\ k551 = k551 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6130
theorem observation6131 : k545 = k545 /\ k545 = k545 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6131
theorem observation6132 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6132
theorem observation6133 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6133
theorem observation6134 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation6134
theorem observation6135 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6135
theorem observation6136 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6136
theorem observation6137 : k450 = k450 /\ k528 = k528 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k449, k4, k6, k8, k120] k465 = true := by decide
#print axioms observation6137
theorem observation6138 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6138 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation6138
theorem observation6139 : k556 = k556 /\ k556 = k556 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6139
theorem observation6140 : k530 = k530 /\ k530 = k530 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6140
theorem observation6141 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6141
theorem observation6142 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6142
theorem observation6143 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation6143
theorem observation6144 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6144
theorem observation6145 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6145
theorem observation6146 : k450 = k450 /\ k544 = k544 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k449, k4, k6, k8, k120] k465 = true := by decide
#print axioms observation6146
theorem observation6147 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6147 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation6147
theorem observation6148 : k561 = k561 /\ k561 = k561 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6148
theorem observation6149 : k545 = k545 /\ k545 = k545 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6149
theorem observation6150 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6150
theorem observation6151 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6151
theorem observation6152 : k149 = k149 /\ k149 = k149 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive (.sig "A")) ({ arity := 1, products := [[.sig "A"]] } : Family) .primitive k149 = true := by decide
#print axioms observation6152
theorem observation6153 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6153
theorem observation6154 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6154
theorem observation6155 : k563 = k563 /\ k564 = k564 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k562, k6, k8, k189] k578 = true := by decide
#print axioms observation6155
theorem observation6156 : k578 = k578 /\ k578 = k578 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6156 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k198, k132, k139] k575 = some k578 := by decide
#print axioms observation6156
theorem observation6157 : k597 = k597 /\ k597 = k597 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6157
theorem observation6158 : k583 = k583 /\ k583 = k583 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6158
theorem observation6159 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6159
theorem observation6160 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6160
theorem observation6161 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation6161
theorem observation6162 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6162
theorem observation6163 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6163
theorem observation6164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6164
theorem observation6165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6165
theorem observation6166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6166
theorem observation6167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6167
theorem observation6168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6168
theorem observation6169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6169
theorem observation6170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6170
theorem observation6171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6171
theorem observation6172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6172
theorem observation6173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6173
theorem observation6174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6174
theorem observation6175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6175
theorem observation6176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6176
theorem observation6177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6177
theorem observation6178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6178
theorem observation6179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6179
theorem observation6180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6180
theorem observation6181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6181
theorem observation6182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6182
theorem observation6183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6183
theorem observation6184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6184
theorem observation6185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6185
theorem observation6186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6186
theorem observation6187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6187
theorem observation6188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6188
theorem observation6189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6189
theorem observation6190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6190
theorem observation6191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6191
theorem observation6192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6192
theorem observation6193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6193
theorem observation6194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6194
theorem observation6195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6195
theorem observation6196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6196
theorem observation6197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6197
theorem observation6198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6198
theorem observation6199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6199
theorem observation6200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6200
theorem observation6201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6201
theorem observation6202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6202
theorem observation6203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6203
theorem observation6204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6204
theorem observation6205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6205
theorem observation6206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6206
theorem observation6207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6207
theorem observation6208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6208
theorem observation6209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6209
theorem observation6210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6210
theorem observation6211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6211
theorem observation6212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6212
theorem observation6213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6213
theorem observation6214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6214
theorem observation6215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6215
theorem observation6216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6216
theorem observation6217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6217
theorem observation6218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6218
theorem observation6219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6219
theorem observation6220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6220
theorem observation6221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6221
theorem observation6222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6222
theorem observation6223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6223
theorem observation6224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6224
theorem observation6225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6225
theorem observation6226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6226
theorem observation6227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6227
theorem observation6228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6228
theorem observation6229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6229
theorem observation6230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6230
theorem observation6231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6231
theorem observation6232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6232
theorem observation6233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6233
theorem observation6234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6234
theorem observation6235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6235
theorem observation6236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6236
theorem observation6237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6237
theorem observation6238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6238
theorem observation6239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6239
theorem observation6240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6240
theorem observation6241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6241
theorem observation6242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6242
theorem observation6243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6243
theorem observation6244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6244
theorem observation6245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6245
theorem observation6246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6246
theorem observation6247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6247
theorem observation6248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6248
theorem observation6249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6249
theorem observation6250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6250
theorem observation6251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6251
theorem observation6252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6252
theorem observation6253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6253
theorem observation6254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6254
theorem observation6255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6255
theorem observation6256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6256
theorem observation6257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6257
theorem observation6258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6258
theorem observation6259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6259
theorem observation6260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6260
theorem observation6261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6261
theorem observation6262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6262
theorem observation6263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6263
theorem observation6264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6264
theorem observation6265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6265
theorem observation6266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6266
theorem observation6267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6267
theorem observation6268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6268
theorem observation6269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6269
theorem observation6270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6270
theorem observation6271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6271
theorem observation6272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6272
theorem observation6273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6273
theorem observation6274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6274
theorem observation6275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6275
theorem observation6276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6276
theorem observation6277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6277
theorem observation6278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6278
theorem observation6279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6279
theorem observation6280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6280
theorem observation6281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6281
theorem observation6282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6282
theorem observation6283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6283
theorem observation6284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6284
theorem observation6285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6285
theorem observation6286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6286
theorem observation6287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6287
theorem observation6288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6288
theorem observation6289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6289
theorem observation6290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6290
theorem observation6291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6291
theorem observation6292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6292
theorem observation6293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6293
theorem observation6294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6294
theorem observation6295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6295
theorem observation6296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6296
theorem observation6297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6297
theorem observation6298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6298
theorem observation6299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6299
theorem observation6300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6300
theorem observation6301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6301
theorem observation6302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6302
theorem observation6303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6303
theorem observation6304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6304
theorem observation6305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6305
theorem observation6306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6306
theorem observation6307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6307
theorem observation6308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6308
theorem observation6309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6309
theorem observation6310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6310
theorem observation6311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6311
theorem observation6312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6312
theorem observation6313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6313
theorem observation6314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6314
theorem observation6315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6315
theorem observation6316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6316
theorem observation6317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6317
theorem observation6318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6318
theorem observation6319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6319
theorem observation6320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6320
theorem observation6321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6321
theorem observation6322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6322
theorem observation6323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6323
theorem observation6324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6324
theorem observation6325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6325
theorem observation6326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6326
theorem observation6327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6327
theorem observation6328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6328
theorem observation6329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6329
theorem observation6330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6330
theorem observation6331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6331
theorem observation6332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6332
theorem observation6333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6333
theorem observation6334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6334
theorem observation6335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6335
theorem observation6336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6336
theorem observation6337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6337
theorem observation6338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6338
theorem observation6339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6339
theorem observation6340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6340
theorem observation6341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6341
theorem observation6342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6342
theorem observation6343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6343
theorem observation6344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6344
theorem observation6345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6345
theorem observation6346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6346
theorem observation6347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6347
theorem observation6348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6348
theorem observation6349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6349
theorem observation6350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6350
theorem observation6351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6351
theorem observation6352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6352
theorem observation6353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6353
theorem observation6354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6354
theorem observation6355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6355
theorem observation6356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6356
theorem observation6357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6357
theorem observation6358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6358
theorem observation6359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6359
theorem observation6360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6360
theorem observation6361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6361
theorem observation6362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6362
theorem observation6363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6363
theorem observation6364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6364
theorem observation6365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6365
theorem observation6366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6366
theorem observation6367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6367
theorem observation6368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6368
theorem observation6369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6369
theorem observation6370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6370
theorem observation6371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6371
theorem observation6372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6372
theorem observation6373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6373
theorem observation6374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6374
theorem observation6375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6375
theorem observation6376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6376
theorem observation6377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6377
theorem observation6378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6378
theorem observation6379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6379
theorem observation6380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6380
theorem observation6381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6381
theorem observation6382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6382
theorem observation6383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6383
theorem observation6384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6384
theorem observation6385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6385
theorem observation6386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6386
theorem observation6387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6387
theorem observation6388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6388
theorem observation6389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6389
theorem observation6390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6390
theorem observation6391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6391
theorem observation6392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6392
theorem observation6393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6393
theorem observation6394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6394
theorem observation6395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6395
theorem observation6396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6396
theorem observation6397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6397
theorem observation6398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6398
theorem observation6399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6399
theorem observation6400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6400
theorem observation6401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6401
theorem observation6402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6402
theorem observation6403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6403
theorem observation6404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6404
theorem observation6405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6405
theorem observation6406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6406
theorem observation6407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6407
theorem observation6408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6408
theorem observation6409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6409
theorem observation6410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6410
theorem observation6411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6411
theorem observation6412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6412
theorem observation6413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6413
theorem observation6414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6414
theorem observation6415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6415
theorem observation6416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6416
theorem observation6417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6417
theorem observation6418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6418
theorem observation6419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6419
theorem observation6420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6420
theorem observation6421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6421
theorem observation6422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6422
theorem observation6423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6423
theorem observation6424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6424
theorem observation6425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6425
theorem observation6426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6426
theorem observation6427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6427
theorem observation6428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6428
theorem observation6429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6429
theorem observation6430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6430
theorem observation6431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6431
theorem observation6432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6432
theorem observation6433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6433
theorem observation6434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6434
theorem observation6435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6435
theorem observation6436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6436
theorem observation6437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6437
theorem observation6438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6438
theorem observation6439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6439
theorem observation6440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6440
theorem observation6441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6441
theorem observation6442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6442
theorem observation6443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6443
theorem observation6444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6444
theorem observation6445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6445
theorem observation6446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6446
theorem observation6447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6447
theorem observation6448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6448
theorem observation6449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6449
theorem observation6450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6450
theorem observation6451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6451
theorem observation6452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6452
theorem observation6453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6453
theorem observation6454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6454
theorem observation6455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6455
theorem observation6456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6456
theorem observation6457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6457
theorem observation6458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6458
theorem observation6459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6459
theorem observation6460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6460
theorem observation6461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6461
theorem observation6462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6462
theorem observation6463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6463
theorem observation6464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6464
theorem observation6465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6465
theorem observation6466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6466
theorem observation6467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6467
theorem observation6468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6468
theorem observation6469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6469
theorem observation6470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6470
theorem observation6471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6471
theorem observation6472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6472
theorem observation6473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6473
theorem observation6474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6474
theorem observation6475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6475
theorem observation6476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6476
theorem observation6477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6477
theorem observation6478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6478
theorem observation6479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6479
theorem observation6480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6480
theorem observation6481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6481
theorem observation6482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6482
theorem observation6483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6483
theorem observation6484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6484
theorem observation6485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6485
theorem observation6486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6486
theorem observation6487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6487
theorem observation6488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6488
theorem observation6489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6489
theorem observation6490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6490
theorem observation6491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6491
theorem observation6492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6492
theorem observation6493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6493
theorem observation6494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6494
theorem observation6495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6495
theorem observation6496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6496
theorem observation6497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6497
theorem observation6498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6498
theorem observation6499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6499
theorem observation6500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6500
theorem observation6501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6501
theorem observation6502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6502
theorem observation6503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6503
theorem observation6504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6504
theorem observation6505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6505
theorem observation6506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6506
theorem observation6507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6507
theorem observation6508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6508
theorem observation6509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6509
theorem observation6510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6510
theorem observation6511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6511
theorem observation6512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6512
theorem observation6513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6513
theorem observation6514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6514
theorem observation6515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6515
theorem observation6516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6516
theorem observation6517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6517
theorem observation6518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6518
theorem observation6519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6519
theorem observation6520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6520
theorem observation6521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6521
theorem observation6522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6522
theorem observation6523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6523
theorem observation6524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6524
theorem observation6525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6525
theorem observation6526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6526
theorem observation6527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6527
theorem observation6528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6528
theorem observation6529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6529
theorem observation6530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6530
theorem observation6531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6531
theorem observation6532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6532
theorem observation6533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6533
theorem observation6534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6534
theorem observation6535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6535
theorem observation6536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6536
theorem observation6537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6537
theorem observation6538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6538
theorem observation6539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6539
theorem observation6540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6540
theorem observation6541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6541
theorem observation6542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6542
theorem observation6543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6543
theorem observation6544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6544
theorem observation6545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6545
theorem observation6546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6546
theorem observation6547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6547
theorem observation6548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6548
theorem observation6549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6549
theorem observation6550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6550
theorem observation6551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6551
theorem observation6552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6552
theorem observation6553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6553
theorem observation6554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6554
theorem observation6555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6555
theorem observation6556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6556
theorem observation6557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6557
theorem observation6558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6558
theorem observation6559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6559
theorem observation6560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6560
theorem observation6561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6561
theorem observation6562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6562
theorem observation6563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6563
theorem observation6564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6564
theorem observation6565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6565
theorem observation6566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6566
theorem observation6567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6567
theorem observation6568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6568
theorem observation6569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6569
theorem observation6570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6570
theorem observation6571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6571
theorem observation6572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6572
theorem observation6573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6573
theorem observation6574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6574
theorem observation6575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6575
theorem observation6576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6576
theorem observation6577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6577
theorem observation6578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6578
theorem observation6579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6579
theorem observation6580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6580
theorem observation6581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6581
theorem observation6582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6582
theorem observation6583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6583
theorem observation6584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6584
theorem observation6585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6585
theorem observation6586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6586
theorem observation6587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6587
theorem observation6588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6588
theorem observation6589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6589
theorem observation6590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6590
theorem observation6591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6591
theorem observation6592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6592
theorem observation6593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6593
theorem observation6594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6594
theorem observation6595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6595
theorem observation6596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6596
theorem observation6597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6597
theorem observation6598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6598
theorem observation6599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6599
theorem observation6600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6600
theorem observation6601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6601
theorem observation6602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6602
theorem observation6603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6603
theorem observation6604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6604
theorem observation6605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6605
theorem observation6606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6606
theorem observation6607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6607
theorem observation6608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6608
theorem observation6609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6609
theorem observation6610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6610
theorem observation6611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6611
theorem observation6612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6612
theorem observation6613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6613
theorem observation6614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6614
theorem observation6615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6615
theorem observation6616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6616
theorem observation6617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6617
theorem observation6618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6618
theorem observation6619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6619
theorem observation6620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6620
theorem observation6621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6621
theorem observation6622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6622
theorem observation6623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6623
theorem observation6624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6624
theorem observation6625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6625
theorem observation6626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6626
theorem observation6627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6627
theorem observation6628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6628
theorem observation6629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6629
theorem observation6630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6630
theorem observation6631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6631
theorem observation6632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6632
theorem observation6633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6633
theorem observation6634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6634
theorem observation6635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6635
theorem observation6636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6636
theorem observation6637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6637
theorem observation6638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6638
theorem observation6639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6639
theorem observation6640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6640
theorem observation6641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6641
theorem observation6642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6642
theorem observation6643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6643
theorem observation6644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6644
theorem observation6645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6645
theorem observation6646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6646
theorem observation6647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6647
theorem observation6648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6648
theorem observation6649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6649
theorem observation6650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6650
theorem observation6651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6651
theorem observation6652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6652
theorem observation6653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6653
theorem observation6654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6654
theorem observation6655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6655
theorem observation6656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6656
theorem observation6657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6657
theorem observation6658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6658
theorem observation6659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6659
theorem observation6660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6660
theorem observation6661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6661
theorem observation6662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6662
theorem observation6663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6663
theorem observation6664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6664
theorem observation6665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6665
theorem observation6666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6666
theorem observation6667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6667
theorem observation6668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6668
theorem observation6669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6669
theorem observation6670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6670
theorem observation6671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6671
theorem observation6672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6672
theorem observation6673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6673
theorem observation6674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6674
theorem observation6675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6675
theorem observation6676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6676
theorem observation6677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6677
theorem observation6678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6678
theorem observation6679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6679
theorem observation6680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6680
theorem observation6681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6681
theorem observation6682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6682
theorem observation6683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6683
theorem observation6684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6684
theorem observation6685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6685
theorem observation6686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6686
theorem observation6687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6687
theorem observation6688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6688
theorem observation6689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6689
theorem observation6690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6690
theorem observation6691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6691
theorem observation6692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6692
theorem observation6693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6693
theorem observation6694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6694
theorem observation6695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6695
theorem observation6696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6696
theorem observation6697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6697
theorem observation6698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6698
theorem observation6699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6699
theorem observation6700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6700
theorem observation6701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6701
theorem observation6702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6702
theorem observation6703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6703
theorem observation6704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6704
theorem observation6705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6705
theorem observation6706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6706
theorem observation6707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6707
theorem observation6708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6708
theorem observation6709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6709
theorem observation6710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6710
theorem observation6711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6711
theorem observation6712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6712
theorem observation6713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6713
theorem observation6714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6714
theorem observation6715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6715
theorem observation6716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6716
theorem observation6717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6717
theorem observation6718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6718
theorem observation6719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6719
theorem observation6720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6720
theorem observation6721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6721
theorem observation6722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6722
theorem observation6723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6723
theorem observation6724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6724
theorem observation6725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6725
theorem observation6726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6726
theorem observation6727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6727
theorem observation6728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6728
theorem observation6729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6729
theorem observation6730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6730
theorem observation6731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6731
theorem observation6732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6732
theorem observation6733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6733
theorem observation6734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6734
theorem observation6735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6735
theorem observation6736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6736
theorem observation6737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6737
theorem observation6738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6738
theorem observation6739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6739
theorem observation6740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6740
theorem observation6741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6741
theorem observation6742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6742
theorem observation6743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6743
theorem observation6744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6744
theorem observation6745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6745
theorem observation6746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6746
theorem observation6747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6747
theorem observation6748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6748
theorem observation6749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6749
theorem observation6750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6750
theorem observation6751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6751
theorem observation6752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6752
theorem observation6753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6753
theorem observation6754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6754
theorem observation6755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6755
theorem observation6756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6756
theorem observation6757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6757
theorem observation6758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6758
theorem observation6759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6759
theorem observation6760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6760
theorem observation6761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6761
theorem observation6762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6762
theorem observation6763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6763
theorem observation6764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6764
theorem observation6765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6765
theorem observation6766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6766
theorem observation6767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6767
theorem observation6768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6768
theorem observation6769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6769
theorem observation6770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6770
theorem observation6771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6771
theorem observation6772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6772
theorem observation6773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6773
theorem observation6774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6774
theorem observation6775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6775
theorem observation6776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6776
theorem observation6777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6777
theorem observation6778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6778
theorem observation6779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6779
theorem observation6780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6780
theorem observation6781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6781
theorem observation6782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6782
theorem observation6783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6783
theorem observation6784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6784
theorem observation6785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6785
theorem observation6786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6786
theorem observation6787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6787
theorem observation6788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6788
theorem observation6789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6789
theorem observation6790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6790
theorem observation6791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6791
theorem observation6792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6792
theorem observation6793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6793
theorem observation6794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6794
theorem observation6795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6795
theorem observation6796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6796
theorem observation6797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6797
theorem observation6798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6798
theorem observation6799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6799
theorem observation6800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6800
theorem observation6801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6801
theorem observation6802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6802
theorem observation6803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6803
theorem observation6804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6804
theorem observation6805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6805
theorem observation6806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6806
theorem observation6807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6807
theorem observation6808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6808
theorem observation6809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6809
theorem observation6810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6810
theorem observation6811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6811
theorem observation6812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6812
theorem observation6813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6813
theorem observation6814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6814
theorem observation6815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6815
theorem observation6816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6816
theorem observation6817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6817
theorem observation6818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6818
theorem observation6819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6819
theorem observation6820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6820
theorem observation6821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6821
theorem observation6822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6822
theorem observation6823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6823
theorem observation6824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6824
theorem observation6825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6825
theorem observation6826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6826
theorem observation6827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6827
theorem observation6828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6828
theorem observation6829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6829
theorem observation6830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6830
theorem observation6831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6831
theorem observation6832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6832
theorem observation6833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6833
theorem observation6834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6834
theorem observation6835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6835
theorem observation6836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6836
theorem observation6837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6837
theorem observation6838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6838
theorem observation6839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6839
theorem observation6840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6840
theorem observation6841 : k563 = k563 /\ k598 = k598 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k10, k562, k6, k8, k189] k578 = true := by decide
#print axioms observation6841
theorem observation6842 : k578 = k578 /\ k578 = k578 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6842 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k198, k132, k139] k575 = some k578 := by decide
#print axioms observation6842
theorem observation6843 : k605 = k605 /\ k605 = k605 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6843
theorem observation6844 : k599 = k599 /\ k599 = k599 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6844
theorem observation6845 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6845
theorem observation6846 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6846
theorem observation6847 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation6847
theorem observation6848 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6848
theorem observation6849 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6849
theorem observation6850 : k563 = k563 /\ k564 = k564 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k562, k6, k8, k189] k578 = true := by decide
#print axioms observation6850
theorem observation6851 : k578 = k578 /\ k578 = k578 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6851 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k198, k132, k139] k575 = some k578 := by decide
#print axioms observation6851
theorem observation6852 : k610 = k610 /\ k610 = k610 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6852
theorem observation6853 : k583 = k583 /\ k583 = k583 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6853
theorem observation6854 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6854
theorem observation6855 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6855
theorem observation6856 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation6856
theorem observation6857 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6857
theorem observation6858 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6858
theorem observation6859 : k563 = k563 /\ k598 = k598 /\ "VERIFIED" = "VERIFIED" /\ publishes [k190, k118, k119, k191, k10, k562, k6, k8, k189] k578 = true := by decide
#print axioms observation6859
theorem observation6860 : k578 = k578 /\ k578 = k578 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6860 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k198, k132, k139] k575 = some k578 := by decide
#print axioms observation6860
theorem observation6861 : k615 = k615 /\ k615 = k615 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6861
theorem observation6862 : k599 = k599 /\ k599 = k599 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6862
theorem observation6863 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6863
theorem observation6864 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6864
theorem observation6865 : k216 = k216 /\ k216 = k216 /\ "PRIMITIVE_SET_SINGLETON" = "PRIMITIVE_SET_SINGLETON" /\ checkLeaf (.primitive .int) ({ arity := 1, products := [[.int]] } : Family) .primitive k216 = true := by decide
#print axioms observation6865
theorem observation6866 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6866
theorem observation6867 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6867
theorem observation6868 : k618 = k618 /\ k619 = k619 /\ "VERIFIED" = "VERIFIED" /\ publishes [k118, k119, k616, k271, k617, k6, k8, k269] k636 = true := by decide
#print axioms observation6868
theorem observation6869 : k636 = k636 /\ k636 = k636 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine6869 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k622, k132, k139] k633 = some k636 := by decide
#print axioms observation6869
theorem observation6870 : k662 = k662 /\ k662 = k662 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6870
theorem observation6871 : k648 = k648 /\ k648 = k648 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6871
theorem observation6872 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation6872
theorem observation6873 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation6873
theorem observation6874 : k643 = k643 /\ k643 = k643 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "univ"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) .exact k643 = true := by decide
#print axioms observation6874
theorem observation6875 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation6875
theorem observation6876 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation6876
theorem observation6877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6877
theorem observation6878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6878
theorem observation6879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6879
theorem observation6880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6880
theorem observation6881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6881
theorem observation6882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6882
theorem observation6883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6883
theorem observation6884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6884
theorem observation6885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6885
theorem observation6886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6886
theorem observation6887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6887
theorem observation6888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6888
theorem observation6889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6889
theorem observation6890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6890
theorem observation6891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6891
theorem observation6892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6892
theorem observation6893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6893
theorem observation6894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6894
theorem observation6895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6895
theorem observation6896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6896
theorem observation6897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6897
theorem observation6898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6898
theorem observation6899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6899
theorem observation6900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6900
theorem observation6901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6901
theorem observation6902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6902
theorem observation6903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6903
theorem observation6904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6904
theorem observation6905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6905
theorem observation6906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6906
theorem observation6907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6907
theorem observation6908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6908
theorem observation6909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6909
theorem observation6910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6910
theorem observation6911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6911
theorem observation6912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6912
theorem observation6913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6913
theorem observation6914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6914
theorem observation6915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6915
theorem observation6916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6916
theorem observation6917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6917
theorem observation6918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6918
theorem observation6919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6919
theorem observation6920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6920
theorem observation6921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6921
theorem observation6922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6922
theorem observation6923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6923
theorem observation6924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6924
theorem observation6925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6925
theorem observation6926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6926
theorem observation6927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6927
theorem observation6928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6928
theorem observation6929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6929
theorem observation6930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6930
theorem observation6931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6931
theorem observation6932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6932
theorem observation6933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6933
theorem observation6934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6934
theorem observation6935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6935
theorem observation6936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6936
theorem observation6937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6937
theorem observation6938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6938
theorem observation6939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6939
theorem observation6940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6940
theorem observation6941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6941
theorem observation6942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6942
theorem observation6943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6943
theorem observation6944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6944
theorem observation6945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6945
theorem observation6946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6946
theorem observation6947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6947
theorem observation6948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6948
theorem observation6949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6949
theorem observation6950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6950
theorem observation6951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6951
theorem observation6952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6952
theorem observation6953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6953
theorem observation6954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6954
theorem observation6955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6955
theorem observation6956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6956
theorem observation6957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6957
theorem observation6958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6958
theorem observation6959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6959
theorem observation6960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6960
theorem observation6961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6961
theorem observation6962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6962
theorem observation6963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6963
theorem observation6964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6964
theorem observation6965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6965
theorem observation6966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6966
theorem observation6967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6967
theorem observation6968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6968
theorem observation6969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6969
theorem observation6970 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6970
theorem observation6971 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6971
theorem observation6972 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6972
theorem observation6973 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6973
theorem observation6974 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6974
theorem observation6975 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6975
theorem observation6976 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6976
theorem observation6977 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6977
theorem observation6978 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6978
theorem observation6979 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6979
theorem observation6980 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6980
theorem observation6981 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6981
theorem observation6982 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6982
theorem observation6983 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6983
theorem observation6984 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6984
theorem observation6985 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6985
theorem observation6986 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6986
theorem observation6987 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6987
theorem observation6988 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6988
theorem observation6989 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6989
theorem observation6990 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6990
theorem observation6991 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6991
theorem observation6992 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6992
theorem observation6993 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6993
theorem observation6994 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6994
theorem observation6995 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6995
theorem observation6996 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6996
theorem observation6997 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6997
theorem observation6998 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6998
theorem observation6999 : "REJECTED" = "REJECTED" := by decide
#print axioms observation6999
theorem observation7000 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7000
theorem observation7001 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7001
theorem observation7002 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7002
theorem observation7003 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7003
theorem observation7004 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7004
theorem observation7005 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7005
theorem observation7006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7006
theorem observation7007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7007
theorem observation7008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7008
theorem observation7009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7009
theorem observation7010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7010
theorem observation7011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7011
theorem observation7012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7012
theorem observation7013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7013
theorem observation7014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7014
theorem observation7015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7015
theorem observation7016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7016
theorem observation7017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7017
theorem observation7018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7018
theorem observation7019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7019
theorem observation7020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7020
theorem observation7021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7021
theorem observation7022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7022
theorem observation7023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7023
theorem observation7024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7024
theorem observation7025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7025
theorem observation7026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7026
theorem observation7027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7027
theorem observation7028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7028
theorem observation7029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7029
theorem observation7030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7030
theorem observation7031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7031
theorem observation7032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7032
theorem observation7033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7033
theorem observation7034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7034
theorem observation7035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7035
theorem observation7036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7036
theorem observation7037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7037
theorem observation7038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7038
theorem observation7039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7039
theorem observation7040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7040
theorem observation7041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7041
theorem observation7042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7042
theorem observation7043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7043
theorem observation7044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7044
theorem observation7045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7045
theorem observation7046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7046
theorem observation7047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7047
theorem observation7048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7048
theorem observation7049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7049
theorem observation7050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7050
theorem observation7051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7051
theorem observation7052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7052
theorem observation7053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7053
theorem observation7054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7054
theorem observation7055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7055
theorem observation7056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7056
theorem observation7057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7057
theorem observation7058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7058
theorem observation7059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7059
theorem observation7060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7060
theorem observation7061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7061
theorem observation7062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7062
theorem observation7063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7063
theorem observation7064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7064
theorem observation7065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7065
theorem observation7066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7066
theorem observation7067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7067
theorem observation7068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7068
theorem observation7069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7069
theorem observation7070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7070
theorem observation7071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7071
theorem observation7072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7072
theorem observation7073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7073
theorem observation7074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7074
theorem observation7075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7075
theorem observation7076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7076
theorem observation7077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7077
theorem observation7078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7078
theorem observation7079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7079
theorem observation7080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7080
theorem observation7081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7081
theorem observation7082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7082
theorem observation7083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7083
theorem observation7084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7084
theorem observation7085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7085
theorem observation7086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7086
theorem observation7087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7087
theorem observation7088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7088
theorem observation7089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7089
theorem observation7090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7090
theorem observation7091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7091
theorem observation7092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7092
theorem observation7093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7093
theorem observation7094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7094
theorem observation7095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7095
theorem observation7096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7096
theorem observation7097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7097
theorem observation7098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7098
theorem observation7099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7099
theorem observation7100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7100
theorem observation7101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7101
theorem observation7102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7102
theorem observation7103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7103
theorem observation7104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7104
theorem observation7105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7105
theorem observation7106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7106
theorem observation7107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7107
theorem observation7108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7108
theorem observation7109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7109
theorem observation7110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7110
theorem observation7111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7111
theorem observation7112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7112
theorem observation7113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7113
theorem observation7114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7114
theorem observation7115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7115
theorem observation7116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7116
theorem observation7117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7117
theorem observation7118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7118
theorem observation7119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7119
theorem observation7120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7120
theorem observation7121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7121
theorem observation7122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7122
theorem observation7123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7123
theorem observation7124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7124
theorem observation7125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7125
theorem observation7126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7126
theorem observation7127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7127
theorem observation7128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7128
theorem observation7129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7129
theorem observation7130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7130
theorem observation7131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7131
theorem observation7132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7132
theorem observation7133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7133
theorem observation7134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7134
theorem observation7135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7135
theorem observation7136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7136
theorem observation7137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7137
theorem observation7138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7138
theorem observation7139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7139
theorem observation7140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7140
theorem observation7141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7141
theorem observation7142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7142
theorem observation7143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7143
theorem observation7144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7144
theorem observation7145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7145
theorem observation7146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7146
theorem observation7147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7147
theorem observation7148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7148
theorem observation7149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7149
theorem observation7150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7150
theorem observation7151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7151
theorem observation7152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7152
theorem observation7153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7153
theorem observation7154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7154
theorem observation7155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7155
theorem observation7156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7156
theorem observation7157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7157
theorem observation7158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7158
theorem observation7159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7159
theorem observation7160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7160
theorem observation7161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7161
theorem observation7162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7162
theorem observation7163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7163
theorem observation7164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7164
theorem observation7165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7165
theorem observation7166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7166
theorem observation7167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7167
theorem observation7168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7168
theorem observation7169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7169
theorem observation7170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7170
theorem observation7171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7171
theorem observation7172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7172
theorem observation7173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7173
theorem observation7174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7174
theorem observation7175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7175
theorem observation7176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7176
theorem observation7177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7177
theorem observation7178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7178
theorem observation7179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7179
theorem observation7180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7180
theorem observation7181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7181
theorem observation7182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7182
theorem observation7183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7183
theorem observation7184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7184
theorem observation7185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7185
theorem observation7186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7186
theorem observation7187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7187
theorem observation7188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7188
theorem observation7189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7189
theorem observation7190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7190
theorem observation7191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7191
theorem observation7192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7192
theorem observation7193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7193
theorem observation7194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7194
theorem observation7195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7195
theorem observation7196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7196
theorem observation7197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7197
theorem observation7198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7198
theorem observation7199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7199
theorem observation7200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7200
theorem observation7201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7201
theorem observation7202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7202
theorem observation7203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7203
theorem observation7204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7204
theorem observation7205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7205
theorem observation7206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7206
theorem observation7207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7207
theorem observation7208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7208
theorem observation7209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7209
theorem observation7210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7210
theorem observation7211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7211
theorem observation7212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7212
theorem observation7213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7213
theorem observation7214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7214
theorem observation7215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7215
theorem observation7216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7216
theorem observation7217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7217
theorem observation7218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7218
theorem observation7219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7219
theorem observation7220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7220
theorem observation7221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7221
theorem observation7222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7222
theorem observation7223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7223
theorem observation7224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7224
theorem observation7225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7225
theorem observation7226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7226
theorem observation7227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7227
theorem observation7228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7228
theorem observation7229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7229
theorem observation7230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7230
theorem observation7231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7231
theorem observation7232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7232
theorem observation7233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7233
theorem observation7234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7234
theorem observation7235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7235
theorem observation7236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7236
theorem observation7237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7237
theorem observation7238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7238
theorem observation7239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7239
theorem observation7240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7240
theorem observation7241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7241
theorem observation7242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7242
theorem observation7243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7243
theorem observation7244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7244
theorem observation7245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7245
theorem observation7246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7246
theorem observation7247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7247
theorem observation7248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7248
theorem observation7249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7249
theorem observation7250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7250
theorem observation7251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7251
theorem observation7252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7252
theorem observation7253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7253
theorem observation7254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7254
theorem observation7255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7255
theorem observation7256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7256
theorem observation7257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7257
theorem observation7258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7258
theorem observation7259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7259
theorem observation7260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7260
theorem observation7261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7261
theorem observation7262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7262
theorem observation7263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7263
theorem observation7264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7264
theorem observation7265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7265
theorem observation7266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7266
theorem observation7267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7267
theorem observation7268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7268
theorem observation7269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7269
theorem observation7270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7270
theorem observation7271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7271
theorem observation7272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7272
theorem observation7273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7273
theorem observation7274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7274
theorem observation7275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7275
theorem observation7276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7276
theorem observation7277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7277
theorem observation7278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7278
theorem observation7279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7279
theorem observation7280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7280
theorem observation7281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7281
theorem observation7282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7282
theorem observation7283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7283
theorem observation7284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7284
theorem observation7285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7285
theorem observation7286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7286
theorem observation7287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7287
theorem observation7288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7288
theorem observation7289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7289
theorem observation7290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7290
theorem observation7291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7291
theorem observation7292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7292
theorem observation7293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7293
theorem observation7294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7294
theorem observation7295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7295
theorem observation7296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7296
theorem observation7297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7297
theorem observation7298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7298
theorem observation7299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7299
theorem observation7300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7300
theorem observation7301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7301
theorem observation7302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7302
theorem observation7303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7303
theorem observation7304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7304
theorem observation7305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7305
theorem observation7306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7306
theorem observation7307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7307
theorem observation7308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7308
theorem observation7309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7309
theorem observation7310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7310
theorem observation7311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7311
theorem observation7312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7312
theorem observation7313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7313
theorem observation7314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7314
theorem observation7315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7315
theorem observation7316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7316
theorem observation7317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7317
theorem observation7318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7318
theorem observation7319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7319
theorem observation7320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7320
theorem observation7321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7321
theorem observation7322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7322
theorem observation7323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7323
theorem observation7324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7324
theorem observation7325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7325
theorem observation7326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7326
theorem observation7327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7327
theorem observation7328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7328
theorem observation7329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7329
theorem observation7330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7330
theorem observation7331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7331
theorem observation7332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7332
theorem observation7333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7333
theorem observation7334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7334
theorem observation7335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7335
theorem observation7336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7336
theorem observation7337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7337
theorem observation7338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7338
theorem observation7339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7339
theorem observation7340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7340
theorem observation7341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7341
theorem observation7342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7342
theorem observation7343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7343
theorem observation7344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7344
theorem observation7345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7345
theorem observation7346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7346
theorem observation7347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7347
theorem observation7348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7348
theorem observation7349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7349
theorem observation7350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7350
theorem observation7351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7351
theorem observation7352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7352
theorem observation7353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7353
theorem observation7354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7354
theorem observation7355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7355
theorem observation7356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7356
theorem observation7357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7357
theorem observation7358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7358
theorem observation7359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7359
theorem observation7360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7360
theorem observation7361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7361
theorem observation7362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7362
theorem observation7363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7363
theorem observation7364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7364
theorem observation7365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7365
theorem observation7366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7366
theorem observation7367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7367
theorem observation7368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7368
theorem observation7369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7369
theorem observation7370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7370
theorem observation7371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7371
theorem observation7372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7372
theorem observation7373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7373
theorem observation7374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7374
theorem observation7375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7375
theorem observation7376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7376
theorem observation7377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7377
theorem observation7378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7378
theorem observation7379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7379
theorem observation7380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7380
theorem observation7381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7381
theorem observation7382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7382
theorem observation7383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7383
theorem observation7384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7384
theorem observation7385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7385
theorem observation7386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7386
theorem observation7387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7387
theorem observation7388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7388
theorem observation7389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7389
theorem observation7390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7390
theorem observation7391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7391
theorem observation7392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7392
theorem observation7393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7393
theorem observation7394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7394
theorem observation7395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7395
theorem observation7396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7396
theorem observation7397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7397
theorem observation7398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7398
theorem observation7399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7399
theorem observation7400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7400
theorem observation7401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7401
theorem observation7402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7402
theorem observation7403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7403
theorem observation7404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7404
theorem observation7405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7405
theorem observation7406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7406
theorem observation7407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7407
theorem observation7408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7408
theorem observation7409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7409
theorem observation7410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7410
theorem observation7411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7411
theorem observation7412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7412
theorem observation7413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7413
theorem observation7414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7414
theorem observation7415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7415
theorem observation7416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7416
theorem observation7417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7417
theorem observation7418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7418
theorem observation7419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7419
theorem observation7420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7420
theorem observation7421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7421
theorem observation7422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7422
theorem observation7423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7423
theorem observation7424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7424
theorem observation7425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7425
theorem observation7426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7426
theorem observation7427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7427
theorem observation7428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7428
theorem observation7429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7429
theorem observation7430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7430
theorem observation7431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7431
theorem observation7432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7432
theorem observation7433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7433
theorem observation7434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7434
theorem observation7435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7435
theorem observation7436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7436
theorem observation7437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7437
theorem observation7438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7438
theorem observation7439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7439
theorem observation7440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7440
theorem observation7441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7441
theorem observation7442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7442
theorem observation7443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7443
theorem observation7444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7444
theorem observation7445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7445
theorem observation7446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7446
theorem observation7447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7447
theorem observation7448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7448
theorem observation7449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7449
theorem observation7450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7450
theorem observation7451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7451
theorem observation7452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7452
theorem observation7453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7453
theorem observation7454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7454
theorem observation7455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7455
theorem observation7456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7456
theorem observation7457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7457
theorem observation7458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7458
theorem observation7459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7459
theorem observation7460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7460
theorem observation7461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7461
theorem observation7462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7462
theorem observation7463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7463
theorem observation7464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7464
theorem observation7465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7465
theorem observation7466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7466
theorem observation7467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7467
theorem observation7468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7468
theorem observation7469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7469
theorem observation7470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7470
theorem observation7471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7471
theorem observation7472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7472
theorem observation7473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7473
theorem observation7474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7474
theorem observation7475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7475
theorem observation7476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7476
theorem observation7477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7477
theorem observation7478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7478
theorem observation7479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7479
theorem observation7480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7480
theorem observation7481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7481
theorem observation7482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7482
theorem observation7483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7483
theorem observation7484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7484
theorem observation7485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7485
theorem observation7486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7486
theorem observation7487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7487
theorem observation7488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7488
theorem observation7489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7489
theorem observation7490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7490
theorem observation7491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7491
theorem observation7492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7492
theorem observation7493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7493
theorem observation7494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7494
theorem observation7495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7495
theorem observation7496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7496
theorem observation7497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7497
theorem observation7498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7498
theorem observation7499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7499
theorem observation7500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7500
theorem observation7501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7501
theorem observation7502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7502
theorem observation7503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7503
theorem observation7504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7504
theorem observation7505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7505
theorem observation7506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7506
theorem observation7507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7507
theorem observation7508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7508
theorem observation7509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7509
theorem observation7510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7510
theorem observation7511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7511
theorem observation7512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7512
theorem observation7513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7513
theorem observation7514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7514
theorem observation7515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7515
theorem observation7516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7516
theorem observation7517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7517
theorem observation7518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7518
theorem observation7519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7519
theorem observation7520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7520
theorem observation7521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7521
theorem observation7522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7522
theorem observation7523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7523
theorem observation7524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7524
theorem observation7525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7525
theorem observation7526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7526
theorem observation7527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7527
theorem observation7528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7528
theorem observation7529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7529
theorem observation7530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7530
theorem observation7531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7531
theorem observation7532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7532
theorem observation7533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7533
theorem observation7534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7534
theorem observation7535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7535
theorem observation7536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7536
theorem observation7537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7537
theorem observation7538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7538
theorem observation7539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7539
theorem observation7540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7540
theorem observation7541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7541
theorem observation7542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7542
theorem observation7543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7543
theorem observation7544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7544
theorem observation7545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7545
theorem observation7546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7546
theorem observation7547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7547
theorem observation7548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7548
theorem observation7549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7549
theorem observation7550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7550
theorem observation7551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7551
theorem observation7552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7552
theorem observation7553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7553
theorem observation7554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7554
theorem observation7555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7555
theorem observation7556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7556
theorem observation7557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7557
theorem observation7558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7558
theorem observation7559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7559
theorem observation7560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7560
theorem observation7561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7561
theorem observation7562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7562
theorem observation7563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7563
theorem observation7564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7564
theorem observation7565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7565
theorem observation7566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7566
theorem observation7567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7567
theorem observation7568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7568
theorem observation7569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7569
theorem observation7570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7570
theorem observation7571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7571
theorem observation7572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7572
theorem observation7573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7573
theorem observation7574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7574
theorem observation7575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7575
theorem observation7576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7576
theorem observation7577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7577
theorem observation7578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7578
theorem observation7579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7579
theorem observation7580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7580
theorem observation7581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7581
theorem observation7582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7582
theorem observation7583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7583
theorem observation7584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7584
theorem observation7585 : k618 = k618 /\ k663 = k663 /\ "VERIFIED" = "VERIFIED" /\ publishes [k118, k119, k616, k10, k271, k617, k6, k8, k269] k636 = true := by decide
#print axioms observation7585
theorem observation7586 : k636 = k636 /\ k636 = k636 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7586 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k622, k132, k139] k633 = some k636 := by decide
#print axioms observation7586
theorem observation7587 : k670 = k670 /\ k670 = k670 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7587
theorem observation7588 : k664 = k664 /\ k664 = k664 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7588
theorem observation7589 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7589
theorem observation7590 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7590
theorem observation7591 : k643 = k643 /\ k643 = k643 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "univ"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) .exact k643 = true := by decide
#print axioms observation7591
theorem observation7592 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation7592
theorem observation7593 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7593
theorem observation7594 : k618 = k618 /\ k619 = k619 /\ "VERIFIED" = "VERIFIED" /\ publishes [k118, k119, k616, k271, k617, k6, k8, k269] k636 = true := by decide
#print axioms observation7594
theorem observation7595 : k636 = k636 /\ k636 = k636 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7595 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k622, k132, k139] k633 = some k636 := by decide
#print axioms observation7595
theorem observation7596 : k675 = k675 /\ k675 = k675 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7596
theorem observation7597 : k648 = k648 /\ k648 = k648 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7597
theorem observation7598 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7598
theorem observation7599 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7599
theorem observation7600 : k643 = k643 /\ k643 = k643 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "univ"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) .exact k643 = true := by decide
#print axioms observation7600
theorem observation7601 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation7601
theorem observation7602 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7602
theorem observation7603 : k618 = k618 /\ k663 = k663 /\ "VERIFIED" = "VERIFIED" /\ publishes [k118, k119, k616, k10, k271, k617, k6, k8, k269] k636 = true := by decide
#print axioms observation7603
theorem observation7604 : k636 = k636 /\ k636 = k636 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7604 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k622, k132, k139] k633 = some k636 := by decide
#print axioms observation7604
theorem observation7605 : k680 = k680 /\ k680 = k680 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7605
theorem observation7606 : k664 = k664 /\ k664 = k664 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7606
theorem observation7607 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7607
theorem observation7608 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7608
theorem observation7609 : k643 = k643 /\ k643 = k643 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "univ"]] } : Family)) ({ arity := 1, products := [[.sig "univ"]] } : Family) .exact k643 = true := by decide
#print axioms observation7609
theorem observation7610 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation7610
theorem observation7611 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7611
theorem observation7612 : k683 = k683 /\ k684 = k684 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k119, k4, k8, k349, k681, k682] k691 = true := by decide
#print axioms observation7612
theorem observation7613 : k691 = k691 /\ k691 = k691 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7613 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k354, k139] k688 = some k691 := by decide
#print axioms observation7613
theorem observation7614 : k708 = k708 /\ k708 = k708 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7614
theorem observation7615 : k694 = k694 /\ k694 = k694 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7615
theorem observation7616 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7616
theorem observation7617 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7617
theorem observation7618 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation7618
theorem observation7619 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation7619
theorem observation7620 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7620
theorem observation7621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7621
theorem observation7622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7622
theorem observation7623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7623
theorem observation7624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7624
theorem observation7625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7625
theorem observation7626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7626
theorem observation7627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7627
theorem observation7628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7628
theorem observation7629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7629
theorem observation7630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7630
theorem observation7631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7631
theorem observation7632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7632
theorem observation7633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7633
theorem observation7634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7634
theorem observation7635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7635
theorem observation7636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7636
theorem observation7637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7637
theorem observation7638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7638
theorem observation7639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7639
theorem observation7640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7640
theorem observation7641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7641
theorem observation7642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7642
theorem observation7643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7643
theorem observation7644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7644
theorem observation7645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7645
theorem observation7646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7646
theorem observation7647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7647
theorem observation7648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7648
theorem observation7649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7649
theorem observation7650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7650
theorem observation7651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7651
theorem observation7652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7652
theorem observation7653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7653
theorem observation7654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7654
theorem observation7655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7655
theorem observation7656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7656
theorem observation7657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7657
theorem observation7658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7658
theorem observation7659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7659
theorem observation7660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7660
theorem observation7661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7661
theorem observation7662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7662
theorem observation7663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7663
theorem observation7664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7664
theorem observation7665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7665
theorem observation7666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7666
theorem observation7667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7667
theorem observation7668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7668
theorem observation7669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7669
theorem observation7670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7670
theorem observation7671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7671
theorem observation7672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7672
theorem observation7673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7673
theorem observation7674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7674
theorem observation7675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7675
theorem observation7676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7676
theorem observation7677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7677
theorem observation7678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7678
theorem observation7679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7679
theorem observation7680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7680
theorem observation7681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7681
theorem observation7682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7682
theorem observation7683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7683
theorem observation7684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7684
theorem observation7685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7685
theorem observation7686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7686
theorem observation7687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7687
theorem observation7688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7688
theorem observation7689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7689
theorem observation7690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7690
theorem observation7691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7691
theorem observation7692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7692
theorem observation7693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7693
theorem observation7694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7694
theorem observation7695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7695
theorem observation7696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7696
theorem observation7697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7697
theorem observation7698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7698
theorem observation7699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7699
theorem observation7700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7700
theorem observation7701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7701
theorem observation7702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7702
theorem observation7703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7703
theorem observation7704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7704
theorem observation7705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7705
theorem observation7706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7706
theorem observation7707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7707
theorem observation7708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7708
theorem observation7709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7709
theorem observation7710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7710
theorem observation7711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7711
theorem observation7712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7712
theorem observation7713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7713
theorem observation7714 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7714
theorem observation7715 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7715
theorem observation7716 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7716
theorem observation7717 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7717
theorem observation7718 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7718
theorem observation7719 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7719
theorem observation7720 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7720
theorem observation7721 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7721
theorem observation7722 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7722
theorem observation7723 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7723
theorem observation7724 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7724
theorem observation7725 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7725
theorem observation7726 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7726
theorem observation7727 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7727
theorem observation7728 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7728
theorem observation7729 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7729
theorem observation7730 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7730
theorem observation7731 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7731
theorem observation7732 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7732
theorem observation7733 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7733
theorem observation7734 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7734
theorem observation7735 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7735
theorem observation7736 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7736
theorem observation7737 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7737
theorem observation7738 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7738
theorem observation7739 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7739
theorem observation7740 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7740
theorem observation7741 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7741
theorem observation7742 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7742
theorem observation7743 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7743
theorem observation7744 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7744
theorem observation7745 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7745
theorem observation7746 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7746
theorem observation7747 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7747
theorem observation7748 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7748
theorem observation7749 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7749
theorem observation7750 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7750
theorem observation7751 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7751
theorem observation7752 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7752
theorem observation7753 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7753
theorem observation7754 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7754
theorem observation7755 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7755
theorem observation7756 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7756
theorem observation7757 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7757
theorem observation7758 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7758
theorem observation7759 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7759
theorem observation7760 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7760
theorem observation7761 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7761
theorem observation7762 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7762
theorem observation7763 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7763
theorem observation7764 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7764
theorem observation7765 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7765
theorem observation7766 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7766
theorem observation7767 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7767
theorem observation7768 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7768
theorem observation7769 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7769
theorem observation7770 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7770
theorem observation7771 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7771
theorem observation7772 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7772
theorem observation7773 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7773
theorem observation7774 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7774
theorem observation7775 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7775
theorem observation7776 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7776
theorem observation7777 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7777
theorem observation7778 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7778
theorem observation7779 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7779
theorem observation7780 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7780
theorem observation7781 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7781
theorem observation7782 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7782
theorem observation7783 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7783
theorem observation7784 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7784
theorem observation7785 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7785
theorem observation7786 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7786
theorem observation7787 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7787
theorem observation7788 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7788
theorem observation7789 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7789
theorem observation7790 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7790
theorem observation7791 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7791
theorem observation7792 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7792
theorem observation7793 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7793
theorem observation7794 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7794
theorem observation7795 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7795
theorem observation7796 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7796
theorem observation7797 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7797
theorem observation7798 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7798
theorem observation7799 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7799
theorem observation7800 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7800
theorem observation7801 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7801
theorem observation7802 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7802
theorem observation7803 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7803
theorem observation7804 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7804
theorem observation7805 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7805
theorem observation7806 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7806
theorem observation7807 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7807
theorem observation7808 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7808
theorem observation7809 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7809
theorem observation7810 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7810
theorem observation7811 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7811
theorem observation7812 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7812
theorem observation7813 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7813
theorem observation7814 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7814
theorem observation7815 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7815
theorem observation7816 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7816
theorem observation7817 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7817
theorem observation7818 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7818
theorem observation7819 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7819
theorem observation7820 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7820
theorem observation7821 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7821
theorem observation7822 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7822
theorem observation7823 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7823
theorem observation7824 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7824
theorem observation7825 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7825
theorem observation7826 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7826
theorem observation7827 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7827
theorem observation7828 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7828
theorem observation7829 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7829
theorem observation7830 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7830
theorem observation7831 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7831
theorem observation7832 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7832
theorem observation7833 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7833
theorem observation7834 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7834
theorem observation7835 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7835
theorem observation7836 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7836
theorem observation7837 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7837
theorem observation7838 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7838
theorem observation7839 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7839
theorem observation7840 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7840
theorem observation7841 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7841
theorem observation7842 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7842
theorem observation7843 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7843
theorem observation7844 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7844
theorem observation7845 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7845
theorem observation7846 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7846
theorem observation7847 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7847
theorem observation7848 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7848
theorem observation7849 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7849
theorem observation7850 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7850
theorem observation7851 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7851
theorem observation7852 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7852
theorem observation7853 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7853
theorem observation7854 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7854
theorem observation7855 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7855
theorem observation7856 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7856
theorem observation7857 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7857
theorem observation7858 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7858
theorem observation7859 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7859
theorem observation7860 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7860
theorem observation7861 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7861
theorem observation7862 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7862
theorem observation7863 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7863
theorem observation7864 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7864
theorem observation7865 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7865
theorem observation7866 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7866
theorem observation7867 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7867
theorem observation7868 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7868
theorem observation7869 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7869
theorem observation7870 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7870
theorem observation7871 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7871
theorem observation7872 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7872
theorem observation7873 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7873
theorem observation7874 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7874
theorem observation7875 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7875
theorem observation7876 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7876
theorem observation7877 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7877
theorem observation7878 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7878
theorem observation7879 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7879
theorem observation7880 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7880
theorem observation7881 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7881
theorem observation7882 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7882
theorem observation7883 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7883
theorem observation7884 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7884
theorem observation7885 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7885
theorem observation7886 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7886
theorem observation7887 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7887
theorem observation7888 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7888
theorem observation7889 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7889
theorem observation7890 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7890
theorem observation7891 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7891
theorem observation7892 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7892
theorem observation7893 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7893
theorem observation7894 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7894
theorem observation7895 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7895
theorem observation7896 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7896
theorem observation7897 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7897
theorem observation7898 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7898
theorem observation7899 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7899
theorem observation7900 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7900
theorem observation7901 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7901
theorem observation7902 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7902
theorem observation7903 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7903
theorem observation7904 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7904
theorem observation7905 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7905
theorem observation7906 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7906
theorem observation7907 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7907
theorem observation7908 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7908
theorem observation7909 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7909
theorem observation7910 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7910
theorem observation7911 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7911
theorem observation7912 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7912
theorem observation7913 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7913
theorem observation7914 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7914
theorem observation7915 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7915
theorem observation7916 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7916
theorem observation7917 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7917
theorem observation7918 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7918
theorem observation7919 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7919
theorem observation7920 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7920
theorem observation7921 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7921
theorem observation7922 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7922
theorem observation7923 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7923
theorem observation7924 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7924
theorem observation7925 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7925
theorem observation7926 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7926
theorem observation7927 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7927
theorem observation7928 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7928
theorem observation7929 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7929
theorem observation7930 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7930
theorem observation7931 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7931
theorem observation7932 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7932
theorem observation7933 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7933
theorem observation7934 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7934
theorem observation7935 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7935
theorem observation7936 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7936
theorem observation7937 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7937
theorem observation7938 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7938
theorem observation7939 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7939
theorem observation7940 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7940
theorem observation7941 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7941
theorem observation7942 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7942
theorem observation7943 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7943
theorem observation7944 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7944
theorem observation7945 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7945
theorem observation7946 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7946
theorem observation7947 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7947
theorem observation7948 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7948
theorem observation7949 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7949
theorem observation7950 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7950
theorem observation7951 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7951
theorem observation7952 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7952
theorem observation7953 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7953
theorem observation7954 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7954
theorem observation7955 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7955
theorem observation7956 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7956
theorem observation7957 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7957
theorem observation7958 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7958
theorem observation7959 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7959
theorem observation7960 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7960
theorem observation7961 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7961
theorem observation7962 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7962
theorem observation7963 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7963
theorem observation7964 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7964
theorem observation7965 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7965
theorem observation7966 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7966
theorem observation7967 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7967
theorem observation7968 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7968
theorem observation7969 : "REJECTED" = "REJECTED" := by decide
#print axioms observation7969
theorem observation7970 : k683 = k683 /\ k684 = k684 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k119, k4, k8, k349, k681, k682] k691 = true := by decide
#print axioms observation7970
theorem observation7971 : k691 = k691 /\ k691 = k691 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7971 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k354, k139] k688 = some k691 := by decide
#print axioms observation7971
theorem observation7972 : k716 = k716 /\ k716 = k716 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7972
theorem observation7973 : k710 = k710 /\ k710 = k710 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7973
theorem observation7974 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7974
theorem observation7975 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7975
theorem observation7976 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation7976
theorem observation7977 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation7977
theorem observation7978 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7978
theorem observation7979 : k683 = k683 /\ k684 = k684 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k119, k4, k8, k349, k681, k682] k691 = true := by decide
#print axioms observation7979
theorem observation7980 : k691 = k691 /\ k691 = k691 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7980 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k354, k139] k688 = some k691 := by decide
#print axioms observation7980
theorem observation7981 : k721 = k721 /\ k721 = k721 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7981
theorem observation7982 : k694 = k694 /\ k694 = k694 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7982
theorem observation7983 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7983
theorem observation7984 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7984
theorem observation7985 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation7985
theorem observation7986 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation7986
theorem observation7987 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7987
theorem observation7988 : k683 = k683 /\ k684 = k684 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k119, k4, k8, k349, k681, k682] k691 = true := by decide
#print axioms observation7988
theorem observation7989 : k691 = k691 /\ k691 = k691 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7989 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k354, k139] k688 = some k691 := by decide
#print axioms observation7989
theorem observation7990 : k726 = k726 /\ k726 = k726 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7990
theorem observation7991 : k710 = k710 /\ k710 = k710 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7991
theorem observation7992 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7992
theorem observation7993 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation7993
theorem observation7994 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation7994
theorem observation7995 : k367 = k367 /\ k367 = k367 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 2, products := [] } : Family)) ({ arity := 2, products := [] } : Family) .exact k367 = true := by decide
#print axioms observation7995
theorem observation7996 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation7996
theorem observation7997 : k450 = k450 /\ k451 = k451 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation7997
theorem observation7998 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine7998 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation7998
theorem observation7999 : k731 = k731 /\ k731 = k731 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation7999
theorem observation8000 : k491 = k491 /\ k491 = k491 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8000
theorem observation8001 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8001
theorem observation8002 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation8002
theorem observation8003 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation8003
theorem observation8004 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation8004
theorem observation8005 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation8005
theorem observation8006 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8006
theorem observation8007 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8007
theorem observation8008 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8008
theorem observation8009 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8009
theorem observation8010 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8010
theorem observation8011 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8011
theorem observation8012 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8012
theorem observation8013 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8013
theorem observation8014 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8014
theorem observation8015 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8015
theorem observation8016 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8016
theorem observation8017 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8017
theorem observation8018 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8018
theorem observation8019 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8019
theorem observation8020 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8020
theorem observation8021 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8021
theorem observation8022 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8022
theorem observation8023 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8023
theorem observation8024 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8024
theorem observation8025 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8025
theorem observation8026 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8026
theorem observation8027 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8027
theorem observation8028 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8028
theorem observation8029 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8029
theorem observation8030 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8030
theorem observation8031 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8031
theorem observation8032 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8032
theorem observation8033 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8033
theorem observation8034 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8034
theorem observation8035 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8035
theorem observation8036 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8036
theorem observation8037 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8037
theorem observation8038 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8038
theorem observation8039 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8039
theorem observation8040 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8040
theorem observation8041 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8041
theorem observation8042 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8042
theorem observation8043 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8043
theorem observation8044 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8044
theorem observation8045 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8045
theorem observation8046 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8046
theorem observation8047 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8047
theorem observation8048 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8048
theorem observation8049 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8049
theorem observation8050 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8050
theorem observation8051 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8051
theorem observation8052 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8052
theorem observation8053 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8053
theorem observation8054 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8054
theorem observation8055 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8055
theorem observation8056 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8056
theorem observation8057 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8057
theorem observation8058 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8058
theorem observation8059 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8059
theorem observation8060 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8060
theorem observation8061 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8061
theorem observation8062 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8062
theorem observation8063 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8063
theorem observation8064 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8064
theorem observation8065 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8065
theorem observation8066 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8066
theorem observation8067 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8067
theorem observation8068 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8068
theorem observation8069 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8069
theorem observation8070 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8070
theorem observation8071 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8071
theorem observation8072 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8072
theorem observation8073 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8073
theorem observation8074 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8074
theorem observation8075 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8075
theorem observation8076 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8076
theorem observation8077 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8077
theorem observation8078 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8078
theorem observation8079 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8079
theorem observation8080 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8080
theorem observation8081 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8081
theorem observation8082 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8082
theorem observation8083 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8083
theorem observation8084 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8084
theorem observation8085 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8085
theorem observation8086 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8086
theorem observation8087 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8087
theorem observation8088 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8088
theorem observation8089 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8089
theorem observation8090 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8090
theorem observation8091 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8091
theorem observation8092 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8092
theorem observation8093 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8093
theorem observation8094 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8094
theorem observation8095 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8095
theorem observation8096 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8096
theorem observation8097 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8097
theorem observation8098 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8098
theorem observation8099 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8099
theorem observation8100 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8100
theorem observation8101 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8101
theorem observation8102 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8102
theorem observation8103 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8103
theorem observation8104 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8104
theorem observation8105 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8105
theorem observation8106 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8106
theorem observation8107 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8107
theorem observation8108 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8108
theorem observation8109 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8109
theorem observation8110 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8110
theorem observation8111 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8111
theorem observation8112 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8112
theorem observation8113 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8113
theorem observation8114 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8114
theorem observation8115 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8115
theorem observation8116 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8116
theorem observation8117 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8117
theorem observation8118 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8118
theorem observation8119 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8119
theorem observation8120 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8120
theorem observation8121 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8121
theorem observation8122 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8122
theorem observation8123 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8123
theorem observation8124 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8124
theorem observation8125 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8125
theorem observation8126 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8126
theorem observation8127 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8127
theorem observation8128 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8128
theorem observation8129 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8129
theorem observation8130 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8130
theorem observation8131 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8131
theorem observation8132 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8132
theorem observation8133 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8133
theorem observation8134 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8134
theorem observation8135 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8135
theorem observation8136 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8136
theorem observation8137 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8137
theorem observation8138 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8138
theorem observation8139 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8139
theorem observation8140 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8140
theorem observation8141 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8141
theorem observation8142 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8142
theorem observation8143 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8143
theorem observation8144 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8144
theorem observation8145 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8145
theorem observation8146 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8146
theorem observation8147 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8147
theorem observation8148 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8148
theorem observation8149 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8149
theorem observation8150 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8150
theorem observation8151 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8151
theorem observation8152 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8152
theorem observation8153 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8153
theorem observation8154 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8154
theorem observation8155 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8155
theorem observation8156 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8156
theorem observation8157 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8157
theorem observation8158 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8158
theorem observation8159 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8159
theorem observation8160 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8160
theorem observation8161 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8161
theorem observation8162 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8162
theorem observation8163 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8163
theorem observation8164 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8164
theorem observation8165 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8165
theorem observation8166 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8166
theorem observation8167 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8167
theorem observation8168 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8168
theorem observation8169 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8169
theorem observation8170 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8170
theorem observation8171 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8171
theorem observation8172 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8172
theorem observation8173 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8173
theorem observation8174 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8174
theorem observation8175 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8175
theorem observation8176 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8176
theorem observation8177 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8177
theorem observation8178 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8178
theorem observation8179 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8179
theorem observation8180 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8180
theorem observation8181 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8181
theorem observation8182 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8182
theorem observation8183 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8183
theorem observation8184 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8184
theorem observation8185 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8185
theorem observation8186 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8186
theorem observation8187 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8187
theorem observation8188 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8188
theorem observation8189 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8189
theorem observation8190 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8190
theorem observation8191 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8191
theorem observation8192 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8192
theorem observation8193 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8193
theorem observation8194 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8194
theorem observation8195 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8195
theorem observation8196 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8196
theorem observation8197 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8197
theorem observation8198 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8198
theorem observation8199 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8199
theorem observation8200 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8200
theorem observation8201 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8201
theorem observation8202 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8202
theorem observation8203 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8203
theorem observation8204 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8204
theorem observation8205 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8205
theorem observation8206 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8206
theorem observation8207 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8207
theorem observation8208 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8208
theorem observation8209 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8209
theorem observation8210 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8210
theorem observation8211 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8211
theorem observation8212 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8212
theorem observation8213 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8213
theorem observation8214 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8214
theorem observation8215 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8215
theorem observation8216 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8216
theorem observation8217 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8217
theorem observation8218 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8218
theorem observation8219 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8219
theorem observation8220 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8220
theorem observation8221 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8221
theorem observation8222 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8222
theorem observation8223 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8223
theorem observation8224 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8224
theorem observation8225 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8225
theorem observation8226 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8226
theorem observation8227 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8227
theorem observation8228 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8228
theorem observation8229 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8229
theorem observation8230 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8230
theorem observation8231 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8231
theorem observation8232 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8232
theorem observation8233 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8233
theorem observation8234 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8234
theorem observation8235 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8235
theorem observation8236 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8236
theorem observation8237 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8237
theorem observation8238 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8238
theorem observation8239 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8239
theorem observation8240 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8240
theorem observation8241 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8241
theorem observation8242 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8242
theorem observation8243 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8243
theorem observation8244 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8244
theorem observation8245 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8245
theorem observation8246 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8246
theorem observation8247 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8247
theorem observation8248 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8248
theorem observation8249 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8249
theorem observation8250 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8250
theorem observation8251 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8251
theorem observation8252 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8252
theorem observation8253 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8253
theorem observation8254 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8254
theorem observation8255 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8255
theorem observation8256 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8256
theorem observation8257 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8257
theorem observation8258 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8258
theorem observation8259 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8259
theorem observation8260 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8260
theorem observation8261 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8261
theorem observation8262 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8262
theorem observation8263 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8263
theorem observation8264 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8264
theorem observation8265 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8265
theorem observation8266 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8266
theorem observation8267 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8267
theorem observation8268 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8268
theorem observation8269 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8269
theorem observation8270 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8270
theorem observation8271 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8271
theorem observation8272 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8272
theorem observation8273 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8273
theorem observation8274 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8274
theorem observation8275 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8275
theorem observation8276 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8276
theorem observation8277 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8277
theorem observation8278 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8278
theorem observation8279 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8279
theorem observation8280 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8280
theorem observation8281 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8281
theorem observation8282 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8282
theorem observation8283 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8283
theorem observation8284 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8284
theorem observation8285 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8285
theorem observation8286 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8286
theorem observation8287 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8287
theorem observation8288 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8288
theorem observation8289 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8289
theorem observation8290 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8290
theorem observation8291 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8291
theorem observation8292 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8292
theorem observation8293 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8293
theorem observation8294 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8294
theorem observation8295 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8295
theorem observation8296 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8296
theorem observation8297 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8297
theorem observation8298 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8298
theorem observation8299 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8299
theorem observation8300 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8300
theorem observation8301 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8301
theorem observation8302 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8302
theorem observation8303 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8303
theorem observation8304 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8304
theorem observation8305 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8305
theorem observation8306 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8306
theorem observation8307 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8307
theorem observation8308 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8308
theorem observation8309 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8309
theorem observation8310 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8310
theorem observation8311 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8311
theorem observation8312 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8312
theorem observation8313 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8313
theorem observation8314 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8314
theorem observation8315 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8315
theorem observation8316 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8316
theorem observation8317 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8317
theorem observation8318 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8318
theorem observation8319 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8319
theorem observation8320 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8320
theorem observation8321 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8321
theorem observation8322 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8322
theorem observation8323 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8323
theorem observation8324 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8324
theorem observation8325 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8325
theorem observation8326 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8326
theorem observation8327 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8327
theorem observation8328 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8328
theorem observation8329 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8329
theorem observation8330 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8330
theorem observation8331 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8331
theorem observation8332 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8332
theorem observation8333 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8333
theorem observation8334 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8334
theorem observation8335 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8335
theorem observation8336 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8336
theorem observation8337 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8337
theorem observation8338 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8338
theorem observation8339 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8339
theorem observation8340 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8340
theorem observation8341 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8341
theorem observation8342 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8342
theorem observation8343 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8343
theorem observation8344 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8344
theorem observation8345 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8345
theorem observation8346 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8346
theorem observation8347 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8347
theorem observation8348 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8348
theorem observation8349 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8349
theorem observation8350 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8350
theorem observation8351 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8351
theorem observation8352 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8352
theorem observation8353 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8353
theorem observation8354 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8354
theorem observation8355 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8355
theorem observation8356 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8356
theorem observation8357 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8357
theorem observation8358 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8358
theorem observation8359 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8359
theorem observation8360 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8360
theorem observation8361 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8361
theorem observation8362 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8362
theorem observation8363 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8363
theorem observation8364 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8364
theorem observation8365 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8365
theorem observation8366 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8366
theorem observation8367 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8367
theorem observation8368 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8368
theorem observation8369 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8369
theorem observation8370 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8370
theorem observation8371 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8371
theorem observation8372 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8372
theorem observation8373 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8373
theorem observation8374 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8374
theorem observation8375 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8375
theorem observation8376 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8376
theorem observation8377 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8377
theorem observation8378 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8378
theorem observation8379 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8379
theorem observation8380 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8380
theorem observation8381 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8381
theorem observation8382 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8382
theorem observation8383 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8383
theorem observation8384 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8384
theorem observation8385 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8385
theorem observation8386 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8386
theorem observation8387 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8387
theorem observation8388 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8388
theorem observation8389 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8389
theorem observation8390 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8390
theorem observation8391 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8391
theorem observation8392 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8392
theorem observation8393 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8393
theorem observation8394 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8394
theorem observation8395 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8395
theorem observation8396 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8396
theorem observation8397 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8397
theorem observation8398 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8398
theorem observation8399 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8399
theorem observation8400 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8400
theorem observation8401 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8401
theorem observation8402 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8402
theorem observation8403 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8403
theorem observation8404 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8404
theorem observation8405 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8405
theorem observation8406 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8406
theorem observation8407 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8407
theorem observation8408 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8408
theorem observation8409 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8409
theorem observation8410 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8410
theorem observation8411 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8411
theorem observation8412 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8412
theorem observation8413 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8413
theorem observation8414 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8414
theorem observation8415 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8415
theorem observation8416 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8416
theorem observation8417 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8417
theorem observation8418 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8418
theorem observation8419 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8419
theorem observation8420 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8420
theorem observation8421 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8421
theorem observation8422 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8422
theorem observation8423 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8423
theorem observation8424 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8424
theorem observation8425 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8425
theorem observation8426 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8426
theorem observation8427 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8427
theorem observation8428 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8428
theorem observation8429 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8429
theorem observation8430 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8430
theorem observation8431 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8431
theorem observation8432 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8432
theorem observation8433 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8433
theorem observation8434 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8434
theorem observation8435 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8435
theorem observation8436 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8436
theorem observation8437 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8437
theorem observation8438 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8438
theorem observation8439 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8439
theorem observation8440 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8440
theorem observation8441 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8441
theorem observation8442 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8442
theorem observation8443 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8443
theorem observation8444 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8444
theorem observation8445 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8445
theorem observation8446 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8446
theorem observation8447 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8447
theorem observation8448 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8448
theorem observation8449 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8449
theorem observation8450 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8450
theorem observation8451 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8451
theorem observation8452 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8452
theorem observation8453 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8453
theorem observation8454 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8454
theorem observation8455 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8455
theorem observation8456 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8456
theorem observation8457 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8457
theorem observation8458 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8458
theorem observation8459 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8459
theorem observation8460 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8460
theorem observation8461 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8461
theorem observation8462 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8462
theorem observation8463 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8463
theorem observation8464 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8464
theorem observation8465 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8465
theorem observation8466 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8466
theorem observation8467 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8467
theorem observation8468 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8468
theorem observation8469 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8469
theorem observation8470 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8470
theorem observation8471 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8471
theorem observation8472 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8472
theorem observation8473 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8473
theorem observation8474 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8474
theorem observation8475 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8475
theorem observation8476 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8476
theorem observation8477 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8477
theorem observation8478 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8478
theorem observation8479 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8479
theorem observation8480 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8480
theorem observation8481 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8481
theorem observation8482 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8482
theorem observation8483 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8483
theorem observation8484 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8484
theorem observation8485 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8485
theorem observation8486 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8486
theorem observation8487 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8487
theorem observation8488 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8488
theorem observation8489 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8489
theorem observation8490 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8490
theorem observation8491 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8491
theorem observation8492 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8492
theorem observation8493 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8493
theorem observation8494 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8494
theorem observation8495 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8495
theorem observation8496 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8496
theorem observation8497 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8497
theorem observation8498 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8498
theorem observation8499 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8499
theorem observation8500 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8500
theorem observation8501 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8501
theorem observation8502 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8502
theorem observation8503 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8503
theorem observation8504 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8504
theorem observation8505 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8505
theorem observation8506 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8506
theorem observation8507 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8507
theorem observation8508 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8508
theorem observation8509 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8509
theorem observation8510 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8510
theorem observation8511 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8511
theorem observation8512 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8512
theorem observation8513 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8513
theorem observation8514 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8514
theorem observation8515 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8515
theorem observation8516 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8516
theorem observation8517 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8517
theorem observation8518 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8518
theorem observation8519 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8519
theorem observation8520 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8520
theorem observation8521 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8521
theorem observation8522 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8522
theorem observation8523 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8523
theorem observation8524 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8524
theorem observation8525 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8525
theorem observation8526 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8526
theorem observation8527 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8527
theorem observation8528 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8528
theorem observation8529 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8529
theorem observation8530 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8530
theorem observation8531 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8531
theorem observation8532 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8532
theorem observation8533 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8533
theorem observation8534 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8534
theorem observation8535 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8535
theorem observation8536 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8536
theorem observation8537 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8537
theorem observation8538 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8538
theorem observation8539 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8539
theorem observation8540 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8540
theorem observation8541 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8541
theorem observation8542 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8542
theorem observation8543 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8543
theorem observation8544 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8544
theorem observation8545 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8545
theorem observation8546 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8546
theorem observation8547 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8547
theorem observation8548 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8548
theorem observation8549 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8549
theorem observation8550 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8550
theorem observation8551 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8551
theorem observation8552 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8552
theorem observation8553 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8553
theorem observation8554 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8554
theorem observation8555 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8555
theorem observation8556 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8556
theorem observation8557 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8557
theorem observation8558 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8558
theorem observation8559 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8559
theorem observation8560 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8560
theorem observation8561 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8561
theorem observation8562 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8562
theorem observation8563 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8563
theorem observation8564 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8564
theorem observation8565 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8565
theorem observation8566 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8566
theorem observation8567 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8567
theorem observation8568 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8568
theorem observation8569 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8569
theorem observation8570 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8570
theorem observation8571 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8571
theorem observation8572 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8572
theorem observation8573 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8573
theorem observation8574 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8574
theorem observation8575 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8575
theorem observation8576 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8576
theorem observation8577 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8577
theorem observation8578 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8578
theorem observation8579 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8579
theorem observation8580 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8580
theorem observation8581 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8581
theorem observation8582 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8582
theorem observation8583 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8583
theorem observation8584 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8584
theorem observation8585 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8585
theorem observation8586 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8586
theorem observation8587 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8587
theorem observation8588 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8588
theorem observation8589 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8589
theorem observation8590 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8590
theorem observation8591 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8591
theorem observation8592 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8592
theorem observation8593 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8593
theorem observation8594 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8594
theorem observation8595 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8595
theorem observation8596 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8596
theorem observation8597 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8597
theorem observation8598 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8598
theorem observation8599 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8599
theorem observation8600 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8600
theorem observation8601 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8601
theorem observation8602 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8602
theorem observation8603 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8603
theorem observation8604 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8604
theorem observation8605 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8605
theorem observation8606 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8606
theorem observation8607 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8607
theorem observation8608 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8608
theorem observation8609 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8609
theorem observation8610 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8610
theorem observation8611 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8611
theorem observation8612 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8612
theorem observation8613 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8613
theorem observation8614 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8614
theorem observation8615 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8615
theorem observation8616 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8616
theorem observation8617 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8617
theorem observation8618 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8618
theorem observation8619 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8619
theorem observation8620 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8620
theorem observation8621 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8621
theorem observation8622 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8622
theorem observation8623 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8623
theorem observation8624 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8624
theorem observation8625 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8625
theorem observation8626 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8626
theorem observation8627 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8627
theorem observation8628 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8628
theorem observation8629 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8629
theorem observation8630 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8630
theorem observation8631 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8631
theorem observation8632 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8632
theorem observation8633 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8633
theorem observation8634 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8634
theorem observation8635 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8635
theorem observation8636 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8636
theorem observation8637 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8637
theorem observation8638 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8638
theorem observation8639 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8639
theorem observation8640 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8640
theorem observation8641 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8641
theorem observation8642 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8642
theorem observation8643 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8643
theorem observation8644 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8644
theorem observation8645 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8645
theorem observation8646 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8646
theorem observation8647 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8647
theorem observation8648 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8648
theorem observation8649 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8649
theorem observation8650 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8650
theorem observation8651 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8651
theorem observation8652 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8652
theorem observation8653 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8653
theorem observation8654 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8654
theorem observation8655 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8655
theorem observation8656 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8656
theorem observation8657 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8657
theorem observation8658 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8658
theorem observation8659 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8659
theorem observation8660 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8660
theorem observation8661 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8661
theorem observation8662 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8662
theorem observation8663 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8663
theorem observation8664 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8664
theorem observation8665 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8665
theorem observation8666 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8666
theorem observation8667 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8667
theorem observation8668 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8668
theorem observation8669 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8669
theorem observation8670 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8670
theorem observation8671 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8671
theorem observation8672 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8672
theorem observation8673 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8673
theorem observation8674 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8674
theorem observation8675 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8675
theorem observation8676 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8676
theorem observation8677 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8677
theorem observation8678 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8678
theorem observation8679 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8679
theorem observation8680 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8680
theorem observation8681 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8681
theorem observation8682 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8682
theorem observation8683 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8683
theorem observation8684 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8684
theorem observation8685 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8685
theorem observation8686 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8686
theorem observation8687 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8687
theorem observation8688 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8688
theorem observation8689 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8689
theorem observation8690 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8690
theorem observation8691 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8691
theorem observation8692 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8692
theorem observation8693 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8693
theorem observation8694 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8694
theorem observation8695 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8695
theorem observation8696 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8696
theorem observation8697 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8697
theorem observation8698 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8698
theorem observation8699 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8699
theorem observation8700 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8700
theorem observation8701 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8701
theorem observation8702 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8702
theorem observation8703 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8703
theorem observation8704 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8704
theorem observation8705 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8705
theorem observation8706 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8706
theorem observation8707 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8707
theorem observation8708 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8708
theorem observation8709 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8709
theorem observation8710 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8710
theorem observation8711 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8711
theorem observation8712 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8712
theorem observation8713 : "REJECTED" = "REJECTED" := by decide
#print axioms observation8713
theorem observation8714 : k450 = k450 /\ k506 = k506 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation8714
theorem observation8715 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine8715 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation8715
theorem observation8716 : k736 = k736 /\ k736 = k736 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8716
theorem observation8717 : k511 = k511 /\ k511 = k511 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8717
theorem observation8718 : k50 = k50 /\ "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" = "3bdad8f587b547cbce4cc60b65ddc2e165a1a8cbfaf6b42ca9e54a5fe4b7f5da" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8718
theorem observation8719 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation8719
theorem observation8720 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation8720
theorem observation8721 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation8721
theorem observation8722 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation8722
theorem observation8723 : k450 = k450 /\ k451 = k451 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation8723
theorem observation8724 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine8724 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation8724
theorem observation8725 : k741 = k741 /\ k741 = k741 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8725
theorem observation8726 : k491 = k491 /\ k491 = k491 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8726
theorem observation8727 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8727
theorem observation8728 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation8728
theorem observation8729 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation8729
theorem observation8730 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation8730
theorem observation8731 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation8731
theorem observation8732 : k450 = k450 /\ k506 = k506 /\ "VERIFIED" = "VERIFIED" /\ publishes [k117, k118, k119, k7, k10, k449, k4, k6, k8] k465 = true := by decide
#print axioms observation8732
theorem observation8733 : k465 = k465 /\ k465 = k465 /\ "VERIFIED" = "VERIFIED" /\ reconstruct combine8733 "alloy-dependent-chain-theory-v11" "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" "ARROW" [k125, k132, k139] k462 = some k465 := by decide
#print axioms observation8733
theorem observation8734 : k746 = k746 /\ k746 = k746 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8734
theorem observation8735 : k511 = k511 /\ k511 = k511 /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8735
theorem observation8736 : k106 = k106 /\ "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" = "89e7eca47a6a3c4773e64b18226fdc094a387e46b5224ef92d5601efffaab661" /\ "VERIFIED" = "VERIFIED" := by decide
#print axioms observation8736
theorem observation8737 : "alloy-dependent-chain-theory-v11" = "alloy-dependent-chain-theory-v11" /\ "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" = "3387749f582a53216caa599105386b710e9e5e748110c59e1b3bf3401ac03cf8" := by decide
#print axioms observation8737
theorem observation8738 : k472 = k472 /\ k472 = k472 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "A"]] } : Family)) ({ arity := 1, products := [[.sig "A"]] } : Family) .exact k472 = true := by decide
#print axioms observation8738
theorem observation8739 : k479 = k479 /\ k479 = k479 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "B"]] } : Family)) ({ arity := 1, products := [[.sig "B"]] } : Family) .exact k479 = true := by decide
#print axioms observation8739
theorem observation8740 : k488 = k488 /\ k488 = k488 /\ "EXACT_RELATION" = "EXACT_RELATION" /\ checkLeaf (.relation ({ arity := 1, products := [[.sig "C"]] } : Family)) ({ arity := 1, products := [[.sig "C"]] } : Family) .exact k488 = true := by decide
#print axioms observation8740
end ACGN.FourthFive.DependentChainWitnessReplay
