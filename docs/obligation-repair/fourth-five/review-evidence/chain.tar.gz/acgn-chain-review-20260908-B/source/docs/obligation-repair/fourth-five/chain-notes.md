# A2-07 And A2-11 Dependent Chain Witnesses

Candidate contribution only. The aggregate harness owns the frozen input root,
registered claims/verifiers, two clean builds, provenance, separate review,
and final machine-readable closure decision. Neither a synthetic encoder test
nor this note is authority for a Java observation or parent-status promotion.

## Integration

- Proof: `docs/section3-repair-audit/formal/DependentChainWitnesses.lean`.
  No imports or proof dependencies. Lean 4.33.0; 18 named theorem audits.
- Java main: `is.fivefivefive.CanDis.theory.DependentChainWitnessesRegressionTest`.
  Zero arguments runs assertions; one argument writes the observation TSV only
  after all checks pass. Source-only javac compilation needs no verifier types.
  Runtime classpath must contain the producer, libraries, and verifier classes.
  All reflective operations target public APIs through `getMethod` or public
  constructors. There is no private lookup, accessibility override, reflection
  mutation, allocation bypass, or additional helper file.
- The main temporarily sets and finally restores the existing TEST_ONLY
  provenance property. It never supplies publication provenance or commits.
- Extractor: `DependentChainWitnessesExtractor ROOT OUTPUT.tsv`, JDK 17,
  no helper dependency. It resolves 13 whole classes and checks fixed AST and
  binding hashes, including method/field/constructor ownership and modifiers.
  The AST representation includes literals. It deletes stale output first.
- Plugin: `scripts/fourth_chain_replays.py`; `generate(build, formal)` returns
  `[('DependentChainWitnessReplay.lean', source, 8618)]`.
  Namespace: `ACGN.FourthFive.DependentChainWitnessReplay`.
- Inputs: `dependent-chain-witness.tsv` and
  `dependent-chain-witness-source.tsv`. The plugin reads no other trace.
- `negatives(build, formal)` returns 11 closed false-proposition modules.
  `source_mutations()` returns 16 five-tuples ending with
  `DependentChainWitnessesExtractor`. Each source anchor is unique. Mutations
  run only in isolated copies, never in this worktree.
- Encoder checks: `PYTHONDONTWRITEBYTECODE=1 python3 scripts/test_fourth_chain_replays.py -v`.
  Fourteen tests. Their synthetic rows are never substituted for Java evidence.

## Frozen Candidate Surface

Parent A2-07 retains claim hash
`1f73b67ab4d51c8aa6cea982b564d710f2a6711852633153eedd075026a87f6e`.
Parent A2-11 retains claim hash
`d12228a367db5e5046a6eb901b867b559db8c57590b6c91ada4e8dd473459ef5`.
The old matrix and packages are unchanged by this contribution.

| Check | Pass Predicate | Blocking Condition |
| --- | --- | --- |
| General proof | All 18 theorems compile and every audit contains only admitted foundations | Missing theorem/audit, warning, failed compilation, forbidden assumption |
| Source conformance | Exactly 13 fixed owner/AST/binding tuples | Missing, duplicate, foreign, unresolved, or changed tuple |
| Actual observations | Main completes all 48 writer bundles and the exact 8,605-row census | Any failed assertion, missing output, census drift |
| Replay | All 8,618 generated propositions compile with audited ordinary kernel decisions | Schema/census/input drift, false proposition, missing audit |
| Controls | All 11 false-decide modules and 16 source variants reject at their intended boundaries | Acceptance, syntax/import failure, compiler failure instead of source-pin rejection |
| Encoder | All 14 adversarial tests pass | Missing or failed test |

Every verification-relevant source/library/tool/compiler option, this proof,
the regression, extractor, plugin, encoder test, and notes must be in the
aggregate manifest. Source or evidence changes invalidate the prior root.
Development checks below do not replace the aggregate's two isolated builds.

## Proof Boundary

`derive` is executable on exact family and primitive descriptors. The exact
rule requires the stored family to be exactly the view, with positive retained
arity and positional product widths. The primitive rule requires precisely
one unary alternative containing the supplied Int or nominal column. An opaque
or missing type has no rule. Explicit `univ` is a supplied nominal column,
never a fallback. A positive-arity empty family admits the exact rule but
cannot be justified by a primitive singleton rule.

These descriptors are the image of validated Java types, not a proof of the
entire GraphType parser, nominal-name admission grammar, or union normalization.
The finite replay independently constructs exact Java type keys. Primitive
AlloyCarrier storage is retained separately from its unary relation view.
The general proof never obtains parser authority from text or equality.
Parser-authenticated subfamily admission is not added to `derive`; attempts
to substitute that rule on the exact fixtures are negative controls, not
positive claims about external parser authority.

`leafProof` and `leafKey` preserve the typing rule, exact stored type, relation
view, port, and DAG key. Theorems establish their coordinate injectivity.
`applicationKey` retains the binary source association, kind, context, output,
DAG, ordered children, and complete case sequence.

`foldSteps` is a general executable reconstruction parameterized by an explicit
combination function. It starts at operand zero, numbers steps from one,
records both input DAGs, the full case matrix, and the result DAG, and continues
through every remaining operand. `fold_step_count` proves no step is omitted.
The two reconstruction theorems connect successful reconstruction in both
directions to the complete fold. A mismatching final result is rejected.
Index injectivity preserves version, digest spelling, kind, every operand,
every fold-step key, and result. The step theorem retains the serialized index
coordinate, inputs, matrix, and result. The certificate detail theorem also
retains profile, exact source, source occurrence, and target.

Combination semantics are a declared dependency, not an assumed universal Java
refinement theorem. For this finite census Python independently computes exact
JOIN boundary matches, removes exactly the adjacent boundary columns, or takes
the ordered ARROW Cartesian product; it constructs all case keys and DAGs.
The generated Lean replay instantiates `Combine` with that finite table and
checks `reconstruct` against actual producer and writer index keys. Certificate
keys, complete source trees, typed ports, profiles, endpoints, target operator,
ordered dependent Seq schema, and source occurrence payloads are independently
constructed in Python, not copied from observed expected fields.

SHA-256 injectivity is not proved. The fixed theory text/version digest and
five-field profile fingerprint are recomputed by Python and checked against
real Java/writer values. Cryptographic binding remains explicit trust.

## Finite Census

The TSV has seven exact columns: `surface fixture coordinate producer writer
verifier status`. The three value cells use canonical ASCII Base64. Keys use
the real length-prefixed structural format, parsed recursively with strict
framing, node/depth/size bounds, no leading-zero counts, and no trailing bytes.
Unknown/duplicate/missing fixtures, malformed encodings, and undeclared failure
classes block. Observed outcomes are retained as propositions, not replaced
with the Python oracle.

- 96 leaf-grid rows: twelve stored types by eight relation/nonrelation views.
  They include Int, AlloyCarrier with prefixed and unprefixed nominal names,
  explicit `univ`, unary/binary relations, retained-arity empty relations,
  Bool, type variables, malformed carrier shape, and a variable carrier child.
- 48 actual writer bundles: JOIN and ARROW; six fixtures (`exact`, `primitive`,
  `int`, `univ`, `empty`, `repeat`); both overflow profiles; both three-leaf
  binary associations. JOIN repeat reuses the same port three times.
- 240 chain rows record the theory index, certificate key, source key, profile,
  and theory version/text/digest. 144 rows record all leaf proof keys and rules.
- 8,125 public-verifier one-field controls, once per operator/fixture:
  5,910 recursive index coordinates; 1,457 writer-wire scalar coordinates;
  530 recursive leaf-proof coordinates; 108 certificate detail slots;
  72 alternative known leaf rules; and 48 kind/profile/target/source controls.
  Key traversal changes every tag/scalar, deletes each child independently,
  and swaps every adjacent pair of distinct children. Equal-child swaps are
  explicitly excluded as vacuous; duplicate preservation is checked positively.
- 13 source rows plus 8,605 observations give 8,618 replay theorems.

Every base bundle goes through actual producer certification, the real writer,
public `Codec` and `Bundle`, and public `IndependentVerifier` with `FULL`.
The fixtures have an independently fixed empty CALL set. The caller commitment
is computed from the fixed fixture identifier, its input bytes, and that empty
set; it is not obtained by feeding `CallOccurrenceCommitment.inspect()` back
into verification. The declared theory's full manifest scalars are checked
before pinning its content digest. This grants only TEST_ONLY fixture trust,
not parser provenance, source-command authority, or external subtype authority.

Controls mutate one field of a decoded real writer record, rebuild the enclosing
manifest digest, require public Bundle parsing to succeed, re-encode through
the real Codec, then invoke public FULL verification on a fresh verifier.
No producer object crosses that API. Rejection must not be INTERNAL_ERROR or
RESOURCE_LIMIT. Profile DIGEST_MISMATCH is a semantic field check after valid
envelope/manifest parsing, not an unrepaired enclosing digest failure.

## Development Evidence And Blocker

At initial review handoff: the 18-theorem general module compiled; all fourteen
encoder tests passed; the 8,618-theorem **synthetic** replay compiled; all eleven
synthetic negative modules rejected on false `decide`; the baseline extractor
and all sixteen isolated compiler-resolved source controls passed their checks.
The verifier source pin was consciously updated after reviewing main's single
source-command version-literal correction; its resolved binding hash did not
change. There is no accept-current-source mode.

The actual Java census is currently blocked by a concrete writer/verifier
mismatch at `JOIN:primitive:0:1`. Local certification accepts the right-associated
source `A . ((A->B) . (B->C))`, with A stored as AlloyCarrier. The index verifier
reconstructs the left fold and requires the intermediate unary relation B.
The writer registers source-association types but omits that intermediate
relation type from the exact type ledger. FULL verification returns REJECTED /
THEORY_MISMATCH: `A dependent product has no declared exact relation type`.
The regression does not mask this failure by declaring its output successful
or by adding unrelated fixture types to the ledger. A failed partial diagnostic
is written as `<requested trace>.failed.tsv`; it is not a completed observation
trace and the plugin never consumes it. Shared writer changes require main
coordination. No production writer edit has been made by this contribution.

## Classification

PROVED: the registered exact-leaf, structural-coordinate, complete-fold, and
reconstruction theorems under their explicit descriptor/combination boundary.
TESTED: only actually completed Java observations; synthetic encoder fixtures
are separate and cannot supply missing Java evidence. CHECKED: source pins,
schemas, finite census, key reconstruction, audited replay propositions and
rejection controls, when their respective executions finish successfully.

TRUSTED: Lean 4.33.0 kernel and printed standard foundations (`propext`,
`Classical.choice`, `Quot.sound`); JDK17 compiler binding resolution/JVM/public
reflection/standard library; pinned local libraries; Python and the reviewed
source-to-descriptor interpretation; SHA-256; filesystem/OS/hardware; and the
aggregate snapshot, evidence, provenance, and build machinery.

OUT OF SCOPE: whole-Java/heap/compiler/byte-parser refinement; general subtype,
disjointness, correlated-union normalization, or parser-authenticated subfamily
semantics; arbitrary nominal-name grammar; universal SHA-256 injectivity;
new rewrite, parser, certificate, or publication authority; production results,
unlisted claims, future revisions, and automatic promotion of the old parents.
