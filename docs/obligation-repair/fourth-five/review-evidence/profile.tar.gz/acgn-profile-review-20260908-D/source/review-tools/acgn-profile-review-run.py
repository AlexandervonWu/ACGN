#!/usr/bin/env python3
"""Independent bounded evidence capture; not a replacement closure verifier."""
import base64
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

sys.dont_write_bytecode = True
LIVE = Path('/home/augustus/ACGN')
ROOT = Path(sys.argv[2]) if len(sys.argv) > 2 else LIVE
OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=False)
SNAP = OUT / 'source'
SNAP.mkdir()
FORMAL = OUT / 'formal'
FORMAL.mkdir()
COMMANDS = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

paths = set()
for directory in ('src', 'certificate-verifier/src', 'certificate-verifier/test', 'lib', 'scripts'):
    paths.update(p for p in (ROOT / directory).rglob('*') if p.is_file()
                 and '__pycache__' not in p.parts)
for name in ('lean-toolchain', 'docs/obligation-repair/fourth-five/closure-config.json',
             'docs/obligation-repair/fourth-five/profile-notes.md',
             'docs/obligation-repair/fourth-five/harness-notes.md',
             'docs/section3-repair-audit/formal/SemanticProfileWire.lean',
             'docs/section3-repair-audit/claim-ledger.md',
             'docs/section3-repair-audit/assurance-scope.tsv',
             'docs/section3-repair-audit/requirements-traceability.tsv'):
    paths.add(ROOT / name)
manifest = {'schema_version': '1.0', 'files': []}
for path in sorted(paths):
    relative = path.relative_to(ROOT)
    digest = sha(path)
    target = SNAP / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    assert sha(target) == digest
    manifest['files'].append({'path': relative.as_posix(), 'sha256': digest})
for path in sorted(Path('/tmp/acgn-profile-review-20260908-C/observed').glob('profile-*.acgncert')):
    relative = Path('review-witnesses') / path.name
    target = SNAP / relative
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(path, target)
    manifest['files'].append({'path': relative.as_posix(), 'sha256': sha(path)})
for path in (Path('/tmp/PublicProfileReview.java'), Path(__file__)):
    relative = Path('review-tools') / path.name
    target = SNAP / relative
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(path, target)
    manifest['files'].append({'path': relative.as_posix(), 'sha256': sha(path)})
manifest['files'].sort(key=lambda item: item['path'])
canonical = json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()
(OUT / 'manifest.json').write_bytes(canonical)
INPUT_ROOT = hashlib.sha256(canonical).hexdigest()
save(OUT / 'capture.json', {'claim_id': 'FF-P3-03', 'review_input_root': INPUT_ROOT,
                         'driver_sha256': sha(Path(__file__)),
                         'closure_claim': False, 'input_files': len(manifest['files'])})
print('review input root:', INPUT_ROOT, flush=True)

def run(label, argv, cwd=SNAP, extra=None):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.update(extra or {})
    log = OUT / (label + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(list(map(str, argv)), cwd=cwd, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    COMMANDS.append({'id': label, 'argv': list(map(str, argv)), 'cwd': str(cwd),
                     'exit_code': result.returncode, 'log': log.name, 'log_sha256': sha(log),
                     'review_input_root': INPUT_ROOT})
    save(OUT / 'commands.json', COMMANDS)
    print(label, 'exit', result.returncode, flush=True)
    return result.returncode

for tool in ('java', 'javac'):
    assert run(tool + '-version', [tool, '-version']) == 0
LEAN = Path('/home/augustus/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean')
assert run('lean-version', [LEAN, '--version']) == 0
assert run('python-version', [sys.executable, '--version']) == 0
assert run('uname', ['uname', '-a']) == 0
sys.path.insert(0, str(SNAP / 'scripts'))
import run_next_obligation_repairs as engine
def fixture_run(label, argv, extra=None):
    assert run(label, argv, extra=extra) == 0
    return OUT / (label + '.log')
engine.initialize_fixture_git(fixture_run)

producer = OUT / 'producer-classes'
verifier = OUT / 'verifier-classes'
extractor = OUT / 'extractor-classes'
for path in (producer, verifier, extractor):
    path.mkdir()
javac = ['javac', '-J-Xmx1g', '--release', '17', '-proc:none', '-encoding', 'UTF-8']
jars = str(SNAP / 'lib/*')
assert run('compile-verifier', [*javac, '-d', verifier,
                              *sorted((SNAP / 'certificate-verifier/src').rglob('*.java'))]) == 0
assert run('compile-producer', [*javac, '-cp', os.pathsep.join((jars, str(verifier))), '-d', producer,
                              *sorted((SNAP / 'src').rglob('*.java'))]) == 0
assert run('compile-extractor', [*javac, '-d', extractor,
                               SNAP / 'scripts/java/SemanticProfileWireExtractor.java']) == 0
OBS = OUT / 'observed'
OBS.mkdir()
java = ['java', '-ea', '-Xmx1g', '-cp', os.pathsep.join(map(str, (producer, verifier, jars)))]
assert run('profile-observations', [*java,
           'is.fivefivefive.CanDis.theory.SemanticProfileWireRegressionTest', OBS / 'semantic-profile-wire.tsv']) == 0
engine.read_tsv(OBS / 'semantic-profile-wire.tsv')
shutil.copyfile('/tmp/PublicProfileReview.java', OUT / 'PublicProfileReview.java')
assert run('compile-public-probe', [*javac, '-cp', verifier, '-d', extractor,
                                   OUT / 'PublicProfileReview.java']) == 0
assert run('public-original-certificates', ['java', '-cp', os.pathsep.join(map(str, (verifier, extractor))),
                                           'PublicProfileReview', SNAP / 'review-witnesses']) == 0
assert run('profile-source-census', ['java', '-Xmx1g', '-cp', extractor,
           'SemanticProfileWireExtractor', SNAP, OBS / 'semantic-profile-wire-source.tsv']) == 0
assert run('profile-encoder-tests', [sys.executable, '-B', SNAP / 'scripts/test_fourth_profile_replays.py']) == 0

import fourth_profile_replays as profile
from next_obligation_replays import rows
observed = rows(OBS / 'semantic-profile-wire.tsv', profile.FIELDS)
extracted = rows(OBS / 'semantic-profile-wire-source.tsv', profile.SOURCE_FIELDS)
replay, count = profile.program(observed, extracted)
(FORMAL / 'SemanticProfileWireReplay.lean').write_text(replay)
shutil.copyfile(SNAP / 'docs/section3-repair-audit/formal/SemanticProfileWire.lean',
                FORMAL / 'SemanticProfileWire.lean')
proof_rc = run('general-proof', [LEAN, '-o', 'SemanticProfileWire.olean', 'SemanticProfileWire.lean'],
               FORMAL, {'LEAN_PATH': str(FORMAL)})
assert proof_rc == 0
engine.check_proof_log(OUT / 'general-proof.log', engine.proof_inventory(FORMAL / 'SemanticProfileWire.lean'))
replay_rc = run('observed-replay', [LEAN, 'SemanticProfileWireReplay.lean'], FORMAL,
                {'LEAN_PATH': str(FORMAL)})
assert replay_rc == 0
engine.check_proof_log(OUT / 'observed-replay.log', engine.proof_inventory(FORMAL / 'SemanticProfileWireReplay.lean'))
mismatches = []
for row in observed:
    want = profile.expected_outcome(row['surface'], row['authority'], row['mutation'])
    actual = (row['outcome'], profile.decoded(row['detail']))
    if actual != want:
        mismatches.append({'case': row['case'], 'fixture': row['fixture'],
                           'mutation': row['mutation'], 'expected': want, 'actual': actual})
save(OUT / 'outcome-mismatches.json', mismatches)
print('observed outcome mismatches:', len(mismatches), flush=True)
assert not mismatches

import run_fourth_obligation_repairs as fourth
lean_controls = profile.negatives(OBS, FORMAL)
for label, name, code in lean_controls:
    directory = OUT / 'negative-controls' / label
    directory.mkdir(parents=True)
    (directory / name).write_text(code)
    label = 'reject-' + label
    assert run(label, [LEAN, name], directory, {'LEAN_PATH': str(FORMAL)}) == 1
    fourth.check_rejection(label, (OUT / (label + '.log')).read_text())

source_controls = profile.source_mutations()
frozen = {entry['path']: entry['sha256'] for entry in manifest['files']}
for spec in source_controls:
    label = 'source-reject-profile-' + spec[0]
    target = OUT / (spec[0] + '.tsv')
    with engine.mutated_source(SNAP, spec, frozen):
        assert run(label, ['java', '-Xmx1g', '-cp', extractor,
                          'SemanticProfileWireExtractor', SNAP, target]) == 1
        fourth.check_rejection(label, (OUT / (label + '.log')).read_text())
        assert not target.exists()

configured = OUT / 'configured-invocation' / 'semantic-profile-wire.tsv'
configured.parent.mkdir()
configured_rc = run('configured-test-invocation', [*java,
    'is.fivefivefive.CanDis.theory.SemanticProfileWireRegressionTest', configured])
try:
    engine.read_tsv(configured)
    read_result = 'accepted'
except Exception as error:
    read_result = type(error).__name__ + ': ' + str(error)
    (OUT / 'configured-read-tsv.log').write_text(traceback.format_exc())

mutation = []
for entry in manifest['files']:
    path = SNAP / entry['path']
    assert sha(path) == entry['sha256'], entry['path']
    if not entry['path'].startswith(('review-tools/', 'review-witnesses/')) and (
            not (LIVE / entry['path']).is_file() or sha(LIVE / entry['path']) != entry['sha256']):
        mutation.append(entry['path'])
save(OUT / 'live-input-changes.json', mutation)
save(OUT / 'review-results.json', {
    'claim_id': 'FF-P3-03', 'review_input_root': INPUT_ROOT,
    'status': 'BLOCKED' if replay_rc != 0 or read_result != 'accepted' else 'CHECKS_COMPLETED',
    'not_a_full_closure_run': True, 'general_proof_exit': proof_rc,
    'observed_replay_exit': replay_rc, 'observations': count,
    'outcome_mismatches': len(mismatches), 'configured_test_exit': configured_rc,
    'lean_negative_controls': len(lean_controls), 'source_negative_controls': len(source_controls),
    'configured_output_is_directory': configured.is_dir(), 'configured_read_tsv': read_result,
    'live_input_changes': mutation,
    'full_clean_builds': 0, 'independent_clean_compilations': 1,
    'full_closure_determinism': 'NOT_RUN', 'full_closure_provenance': 'NOT_EVALUATED'})
print('evidence:', OUT, flush=True)
