import Std

namespace ACGN.FourthFive.SemanticProfileWire

-- Scalars are the exact wire texts, including the canonical decimal bitwidth.
-- Numeric admission and source-command authority are separate boundaries.
structure Profile where
  bitwidth : String
  overflow : String
  temporal : String
  rewrite : String
  signature : String
  deriving DecidableEq, BEq

def fields (p : Profile) : List String :=
  [p.bitwidth, p.overflow, p.temporal, p.rewrite, p.signature]

def reconstruct : List String -> Option Profile
  | [b, o, t, r, s] => some ⟨b, o, t, r, s⟩
  | _ => none

-- Java String.length counts supplementary scalar values as two UTF-16 units.
-- Lean Strings contain Unicode scalar values; isolated Java surrogates are
-- excluded here and rejected by the production certificate UTF-8 codec.
def utf16Length (s : String) : Nat :=
  (s.toList.map fun c => if c.toNat < 65536 then 1 else 2).sum

def frame (s : String) : String := toString (utf16Length s) ++ ":" ++ s

def encode (p : Profile) : String :=
  "16:semantic-profile[5:" ++ frame p.bitwidth ++ frame p.overflow ++
    frame p.temporal ++ frame p.rewrite ++ frame p.signature ++ "]{0:}"

-- Independent list-based reconstruction, not a call to the producer encoder.
def verifierEncoding (xs : List String) : Option String :=
  match xs with
  | [b, o, t, r, s] => some (frame "semantic-profile" ++ "[5:" ++
      frame b ++ frame o ++ frame t ++ frame r ++ frame s ++ "]{0:}")
  | _ => none

def exact (p : Profile) (xs : List String) : Bool := decide (reconstruct xs = some p)

inductive Authority where
  | custom | compatibility | source
  deriving DecidableEq, BEq

def exportAllowed (a : Authority) (testOnly : Bool) : Bool :=
  a == .source || (testOnly && a == .compatibility)

theorem reconstruct_fields (p : Profile) : reconstruct (fields p) = some p := by
  cases p
  rfl

theorem reconstruct_some_iff (xs : List String) (p : Profile) :
    reconstruct xs = some p ↔ xs = fields p := by
  cases xs with
  | nil => simp [reconstruct, fields]
  | cons b xs => cases xs with
    | nil => simp [reconstruct, fields]
    | cons o xs => cases xs with
      | nil => simp [reconstruct, fields]
      | cons t xs => cases xs with
        | nil => simp [reconstruct, fields]
        | cons r xs => cases xs with
          | nil => simp [reconstruct, fields]
          | cons s xs => cases xs with
            | nil => cases p; simp [reconstruct, fields, Profile.mk.injEq]
            | cons x xs => simp [reconstruct, fields]

theorem five_fields (p : Profile) : (fields p).length = 5 := rfl

theorem fields_injective (p q : Profile) : fields p = fields q ↔ p = q := by
  cases p; cases q
  simp [fields, Profile.mk.injEq]

theorem exact_iff (p : Profile) (xs : List String) :
    exact p xs = true ↔ xs = fields p := by
  simp [exact, reconstruct_some_iff]

theorem all_field_mutations_rejected (p q : Profile) (h : p ≠ q) :
    exact p (fields q) = false := by
  simp [exact, reconstruct_fields, Ne.symm h]

theorem encoding_agreement (p : Profile) :
    verifierEncoding (fields p) = some (encode p) := by
  rfl

theorem reconstructed_encoding (xs : List String) (p : Profile)
    (h : reconstruct xs = some p) : verifierEncoding xs = some (encode p) := by
  rw [(reconstruct_some_iff xs p).mp h]
  exact encoding_agreement p

theorem frame_preserves_text (s : String) :
    frame s = toString (utf16Length s) ++ ":" ++ s := rfl

theorem custom_never_exports (testOnly : Bool) :
    exportAllowed .custom testOnly = false := by cases testOnly <;> rfl

theorem compatibility_not_publication : exportAllowed .compatibility false = false := rfl

theorem source_exports (testOnly : Bool) :
    exportAllowed .source testOnly = true := by cases testOnly <;> rfl

-- A digest is only a deterministic function here. No injectivity assumption.
theorem equal_payload_equal_digest (digest : String -> String) (p q : Profile)
    (h : fields p = fields q) : digest (encode p) = digest (encode q) := by
  rw [(fields_injective p q).mp h]

#print axioms reconstruct_fields
#print axioms reconstruct_some_iff
#print axioms five_fields
#print axioms fields_injective
#print axioms exact_iff
#print axioms all_field_mutations_rejected
#print axioms encoding_agreement
#print axioms reconstructed_encoding
#print axioms frame_preserves_text
#print axioms custom_never_exports
#print axioms compatibility_not_publication
#print axioms source_exports
#print axioms equal_payload_equal_digest

end ACGN.FourthFive.SemanticProfileWire
