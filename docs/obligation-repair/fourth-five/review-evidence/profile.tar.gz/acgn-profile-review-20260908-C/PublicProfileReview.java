import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HexFormat;
import org.acgn.cert.*;

/** Reads untouched writer outputs and calls only public verifier APIs. */
public final class PublicProfileReview {
    private static String sha(byte[] value) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value));
    }

    private static String framed(String... values) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        for (String value : values) {
            byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
            digest.update(ByteBuffer.allocate(4).putInt(bytes.length).array());
            digest.update(bytes);
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    public static void main(String[] args) throws Exception {
        String subject = framed("call-occurrence-commitment-v1/subject",
                "fixture/semantic-profile-wire", sha("profile-wire".getBytes(StandardCharsets.UTF_8)));
        var commitment = new CallOccurrenceCommitment(subject,
                framed("call-occurrence-commitment-v1", subject));
        System.out.println("file\tsha256\tcanonicalReencodeEqual\toutcome\tcode\tdetail");
        try (var paths = Files.list(Path.of(args[0]))) {
            for (Path path : paths.filter(p -> p.getFileName().toString().startsWith("profile-"))
                    .filter(p -> p.toString().endsWith(".acgncert")).sorted().toList()) {
                byte[] bytes = Files.readAllBytes(path);
                Wire.Node root = Codec.decode(bytes, Limits.defaults());
                Bundle bundle = Bundle.parse(root);
                VerificationPolicy policy = VerificationPolicy.trust(bundle.theoryDigest())
                        .withCallOccurrenceCommitment(commitment);
                VerificationResult result = new IndependentVerifier().verify(bytes, Profile.KERNEL, policy);
                System.out.println(String.join("\t", path.getFileName().toString(), sha(bytes),
                        Boolean.toString(Arrays.equals(bytes, Codec.encode(root))),
                        result.outcome().toString(), result.code().toString(), result.detail()));
            }
        }
    }
}
