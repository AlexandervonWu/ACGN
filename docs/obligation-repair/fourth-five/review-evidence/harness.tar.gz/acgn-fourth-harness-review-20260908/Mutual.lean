namespace HarnessReview
mutual
  def zero : Nat := 0
end
theorem valid : zero = 0 := by rfl
#print axioms valid
end HarnessReview
