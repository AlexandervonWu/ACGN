"""Independent, finite orchestration checks, never target-claim evidence."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path("/home/augustus/ACGN")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import run_fourth_obligation_repairs as profile

FILES = [
    "scripts/run_fourth_obligation_repairs.py",
    "scripts/fourth_obligation_replays.py",
    "scripts/test_fourth_obligation_repairs.py",
    "docs/obligation-repair/fourth-five/closure-config.json",
    "docs/obligation-repair/fourth-five/harness-notes.md",
]
runner = profile.load_runner()
manifest = {name: runner.digest(ROOT / name) for name in FILES}
review_hash = hashlib.sha256(runner.canonical_bytes(manifest)).hexdigest()
report = {
    "reviewOnly": True,
    "closureId": "REVIEW-ONLY-NOT-A-CLOSURE",
    "inputRootHash": review_hash,
    "inputHashScope": "Only the five reviewed harness files, not closure inputs",
    "verifierSetHash": runner.digest(HERE / "probe.py"),
    "manifest": manifest,
    "environment": {"python": sys.version},
    "commands": [],
    "checks": [],
}
lean = str(Path.home() / ".elan/toolchains/leanprover--lean4---v4.33.0/bin/lean")
env = dict(os.environ, LC_ALL="C", TZ="UTC", PYTHONDONTWRITEBYTECODE="1")
env.pop("LEAN_PATH", None)
commands = runner.Commands(HERE, report, env, 30)
commands.run("lean-version", [lean, "--version"], HERE)
commands.run("java-version", ["java", "-version"], HERE)
commands.run("driver-tests", [sys.executable, "-B", ROOT / FILES[2]], ROOT)

cases = [
    ("build1-reject-container-false", [lean, "False.lean"], "PASS"),
    ("build1-reject-chain-syntax", [lean, "Syntax.lean"], "BLOCKED"),
    ("build1-reject-profile-missing-module", [lean, "Missing.lean"], "INFRASTRUCTURE_FAILURE"),
    ("build1-source-reject-profile-missing-main", ["java", "-cp", str(HERE), "MissingFourthHarnessReviewMain"], "INFRASTRUCTURE_FAILURE"),
]
for label, argv, expected in cases:
    error_text = None
    try:
        commands.run(label, argv, HERE, reject=True)
        actual = "PASS"
    except profile.Blocked as error:
        actual, error_text = "BLOCKED", str(error)
    except OSError as error:
        actual, error_text = "INFRASTRUCTURE_FAILURE", str(error)
    report["checks"].append({
        "id": label, "expected": expected, "observed": actual,
        "matches": actual == expected, "error": error_text,
        "exitCode": report["commands"][-1]["exitCode"],
        "recordStatus": report["commands"][-1]["status"],
    })

inventory = runner.proof_inventory(HERE / "Mutual.lean")
log = commands.run("mutual-proof", [lean, "Mutual.lean"], HERE)
runner.check_proof_log(log, inventory)
report["checks"].append({
    "id": "mutual-proof", "expectedInventory": ["HarnessReview.valid"],
    "observedInventory": inventory, "matches": inventory == ["HarnessReview.valid"],
})
report["inputsUnchanged"] = manifest == {name: runner.digest(ROOT / name) for name in FILES}
report["status"] = "PASS" if report["inputsUnchanged"] and all(c["matches"] for c in report["checks"]) else "BLOCKED"
runner.write_json(HERE / "review-checks.json", report)
print(json.dumps({"status": report["status"], "checks": report["checks"], "inputsUnchanged": report["inputsUnchanged"]}, indent=2))
sys.exit(0 if report["status"] == "PASS" else 1)
